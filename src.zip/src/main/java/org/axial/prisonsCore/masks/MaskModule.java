/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Server
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 */
package org.axial.prisonsCore.masks;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.masks.command.MasksCommand;
import org.axial.prisonsCore.masks.config.ConfigManager;
import org.axial.prisonsCore.masks.config.MaskConfigManager;
import org.axial.prisonsCore.masks.listener.BlockBreakListener;
import org.axial.prisonsCore.masks.listener.InventoryClickListener;
import org.axial.prisonsCore.masks.listener.MaskAbilityListener;
import org.axial.prisonsCore.masks.listener.MaskEquipListener;
import org.axial.prisonsCore.masks.listener.MaskMenuListener;
import org.axial.prisonsCore.masks.listener.MaskPlaceListener;
import org.axial.prisonsCore.masks.listener.PlayerInteractListener;
import org.axial.prisonsCore.masks.listener.PlayerMoveListener;
import org.axial.prisonsCore.masks.listener.PlayerSneakListener;
import org.axial.prisonsCore.masks.manager.MaskManager;
import org.axial.prisonsCore.masks.manager.MaskVisualManager;
import org.axial.prisonsCore.masks.util.SkullUtil;
import org.bukkit.Server;
import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;

public class MaskModule {
    private final PrisonsCore plugin;
    private ConfigManager configManager;
    private MaskConfigManager maskConfigManager;
    private MaskManager maskManager;
    private MaskVisualManager maskVisualManager;
    private MaskEquipListener maskEquipListener;

    public MaskModule(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public void enable() {
        this.plugin.saveResource("mask-config.yml", false);
        this.plugin.saveResource("mask-language.yml", false);
        this.plugin.saveResource("masks.yml", false);
        SkullUtil.init(this.plugin);
        this.configManager = new ConfigManager(this.plugin);
        this.maskConfigManager = new MaskConfigManager(this.plugin);
        this.maskManager = new MaskManager(this);
        this.maskVisualManager = new MaskVisualManager(this, this.maskManager);
        this.maskEquipListener = new MaskEquipListener(this);
        PluginManager pm = this.plugin.getServer().getPluginManager();
        this.registerListener(pm, new InventoryClickListener(this));
        this.registerListener(pm, new PlayerInteractListener(this));
        this.registerListener(pm, new MaskAbilityListener(this));
        this.registerListener(pm, new MaskPlaceListener(this));
        this.registerListener(pm, new BlockBreakListener(this));
        this.registerListener(pm, new PlayerSneakListener(this));
        this.registerListener(pm, new PlayerMoveListener(this));
        this.registerListener(pm, new MaskMenuListener());
        this.registerListener(pm, this.maskEquipListener);
        if (this.plugin.getCommand("masks") != null) {
            MasksCommand executor = new MasksCommand(this);
            this.plugin.getCommand("masks").setExecutor((CommandExecutor)executor);
            this.plugin.getCommand("masks").setTabCompleter(executor);
        } else {
            this.plugin.getLogger().warning("Command 'masks' missing from plugin.yml; mask feature not registered.");
        }
    }

    public void disable() {
        for (Player player : this.plugin.getServer().getOnlinePlayers()) {
            this.maskVisualManager.clearHelmetVisual(player);
            this.maskManager.removePlayerEffects(player.getUniqueId());
        }
    }

    public void reload() {
        this.configManager.reload();
        this.maskConfigManager.reload();
        this.maskManager.reload();
    }

    private void registerListener(PluginManager pm, Listener listener) {
        pm.registerEvents(listener, (Plugin)this.plugin);
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public Server getServer() {
        return this.plugin.getServer();
    }

    public ConfigManager getConfigManager() {
        return this.configManager;
    }

    public MaskConfigManager getMaskConfigManager() {
        return this.maskConfigManager;
    }

    public MaskManager getMaskManager() {
        return this.maskManager;
    }

    public MaskVisualManager getMaskVisualManager() {
        return this.maskVisualManager;
    }

    public MaskEquipListener getMaskEquipListener() {
        return this.maskEquipListener;
    }
}
