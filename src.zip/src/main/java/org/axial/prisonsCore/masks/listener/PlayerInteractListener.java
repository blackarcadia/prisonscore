/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.masks.listener;

import java.util.Map;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.masks.model.Mask;
import org.axial.prisonsCore.masks.model.MaskItem;
import org.axial.prisonsCore.masks.util.SkullUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class PlayerInteractListener
implements Listener {
    private final MaskModule module;

    public PlayerInteractListener(MaskModule module) {
        this.module = module;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player player;
        ItemStack heldItem;
        if ((event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) && event.getHand() == EquipmentSlot.HAND && (heldItem = (player = event.getPlayer()).getInventory().getItemInMainHand()) != null && !heldItem.getType().isAir() && MaskItem.hasAppliedMask(heldItem)) {
            event.setCancelled(true);
            String maskId = MaskItem.getAppliedMaskId(heldItem);
            Mask mask = this.module.getMaskManager().getMask(maskId);
            if (mask == null) {
                return;
            }
            boolean wasWearing = false;
            ItemStack equippedHelmet = player.getInventory().getHelmet();
            if (equippedHelmet != null && heldItem.equals((Object)equippedHelmet)) {
                wasWearing = true;
            }
            String lorePrefix = this.module.getConfigManager().getMaskLorePrefix();
            ItemStack helmetWithoutMask = MaskItem.removeMaskFromHelmet(heldItem, lorePrefix);
            ItemStack maskItem = mask.createItem();
            player.getInventory().setItemInMainHand(helmetWithoutMask);
            if (player.getInventory().firstEmpty() == -1) {
                player.getWorld().dropItemNaturally(player.getLocation(), maskItem);
                player.sendMessage(this.module.getConfigManager().getMessage("mask_removed") + " \u00a7c(Dropped on ground - inventory full)");
            } else {
                player.getInventory().addItem(new ItemStack[]{maskItem});
                player.sendMessage(this.module.getConfigManager().getMessage("mask_removed", Map.of("mask", SkullUtil.colorize(mask.getName()))));
            }
            if (wasWearing) {
                this.module.getMaskManager().removePlayerEffects(player.getUniqueId());
                this.module.getMaskVisualManager().clearHelmetVisual(player);
                this.module.getMaskEquipListener().forceUpdateMaskEffects(player);
            }
            this.module.getMaskManager().playRemoveSound(player);
        }
    }
}

