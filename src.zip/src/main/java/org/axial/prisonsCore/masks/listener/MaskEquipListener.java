/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.masks.listener;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.masks.model.MaskItem;
import org.axial.prisonsCore.service.SeasonService;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class MaskEquipListener
implements Listener {
    private final MaskModule module;
    private final Set<UUID> activeMaskPlayers;

    public MaskEquipListener(MaskModule module) {
        this.module = module;
        this.activeMaskPlayers = new HashSet<UUID>();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        this.updateMaskEffects(player);
        this.module.getServer().getScheduler().runTaskLater((Plugin)this.module.getPlugin(), () -> this.updateMaskEffects(player), 2L);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        this.activeMaskPlayers.remove(player.getUniqueId());
        this.module.getMaskManager().removePlayerEffects(player.getUniqueId());
        this.module.getMaskVisualManager().removePlayer(player.getUniqueId());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            this.module.getServer().getScheduler().runTaskLater((Plugin)this.module.getPlugin(), () -> this.updateMaskEffects(player), 1L);
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        this.activeMaskPlayers.remove(player.getUniqueId());
        this.module.getMaskManager().removePlayerEffects(player.getUniqueId());
    }

    public void updateMaskEffects(Player player) {
        UUID playerId = player.getUniqueId();
        SeasonService seasonService = this.module.getPlugin().getSeasonService();
        if (seasonService != null && !seasonService.isFeatureUnlocked(SeasonService.UnlockFeature.MASKS)) {
            this.activeMaskPlayers.remove(playerId);
            this.module.getMaskManager().removePlayerEffects(playerId);
            this.module.getMaskVisualManager().clearHelmetVisual(player);
            return;
        }
        ItemStack helmet = player.getInventory().getHelmet();
        String maskId = null;
        if (helmet != null && (maskId = MaskItem.getAppliedMaskId(helmet)) == null) {
            maskId = MaskItem.getMaskId(helmet);
        }
        if (maskId != null) {
            this.activeMaskPlayers.add(playerId);
            this.module.getMaskManager().updatePlayerMaskEffects(player);
        } else if (this.activeMaskPlayers.contains(playerId)) {
            this.activeMaskPlayers.remove(playerId);
            this.module.getMaskManager().removePlayerEffects(playerId);
        }
        this.module.getMaskVisualManager().updateHelmetVisual(player);
    }

    public void forceUpdateMaskEffects(Player player) {
        this.updateMaskEffects(player);
    }

    public boolean hasMaskEquipped(Player player) {
        return this.activeMaskPlayers.contains(player.getUniqueId());
    }
}
