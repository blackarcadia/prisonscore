/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.masks.model;

public class MaskAbilities {
    private final boolean noHunger;
    private final double damageBoost;
    private final boolean fly;
    private final boolean speed;
    private final int speedLevel;
    private final boolean coal;
    private final boolean damage;
    private final boolean jump;
    private final int jumpLevel;
    private final boolean eco;
    private final double sellBonus;
    private final int haste;
    private final int crouchHaste;
    private final int extraHearts;
    private final int healthBoostLevel;
    private final int baseHealthBonus;
    private final double skeletonDamageBoost;
    private final int belowYLevel;
    private final int belowYHasteLevel;
    private final boolean poisonImmunity;
    private final double energyBonusPercent;

    public MaskAbilities(boolean noHunger, double damageBoost, boolean fly, boolean speed, boolean coal, boolean damage, boolean jump, int jumpLevel, boolean eco, double sellBonus, int haste, int crouchHaste, int extraHearts, int healthBoostLevel, int baseHealthBonus, double skeletonDamageBoost, int belowYLevel, int belowYHasteLevel, int speedLevel, boolean poisonImmunity, double energyBonusPercent) {
        this.noHunger = noHunger;
        this.damageBoost = damageBoost;
        this.fly = fly;
        this.speed = speed;
        this.speedLevel = speedLevel;
        this.coal = coal;
        this.damage = damage;
        this.jump = jump;
        this.jumpLevel = jumpLevel;
        this.eco = eco;
        this.sellBonus = sellBonus;
        this.haste = haste;
        this.crouchHaste = crouchHaste;
        this.extraHearts = extraHearts;
        this.healthBoostLevel = healthBoostLevel;
        this.baseHealthBonus = baseHealthBonus;
        this.skeletonDamageBoost = skeletonDamageBoost;
        this.belowYLevel = belowYLevel;
        this.belowYHasteLevel = belowYHasteLevel;
        this.poisonImmunity = poisonImmunity;
        this.energyBonusPercent = energyBonusPercent;
    }

    public boolean hasNoHunger() {
        return this.noHunger;
    }

    public double getDamageBoost() {
        return this.damageBoost;
    }

    public boolean hasFly() {
        return this.fly;
    }

    public boolean hasSpeed() {
        return this.speed;
    }

    public int getSpeedLevel() {
        return this.speedLevel;
    }

    public boolean hasCoal() {
        return this.coal;
    }

    public boolean hasDamage() {
        return this.damage;
    }

    public boolean hasJump() {
        return this.jump;
    }

    public int getJumpLevel() {
        return this.jumpLevel;
    }

    public boolean hasEco() {
        return this.eco;
    }

    public double getSellBonus() {
        return this.sellBonus;
    }

    public int getHaste() {
        return this.haste;
    }

    public int getCrouchHaste() {
        return this.crouchHaste;
    }

    public int getExtraHearts() {
        return this.extraHearts;
    }

    public int getHealthBoostLevel() {
        return this.healthBoostLevel;
    }

    public int getBaseHealthBonus() {
        return this.baseHealthBonus;
    }

    public double getSkeletonDamageBoost() {
        return this.skeletonDamageBoost;
    }

    public int getBelowYLevel() {
        return this.belowYLevel;
    }

    public int getBelowYHasteLevel() {
        return this.belowYHasteLevel;
    }

    public boolean hasBelowYHaste() {
        return this.belowYHasteLevel > 0;
    }

    public boolean hasPoisonImmunity() {
        return this.poisonImmunity;
    }

    public double getEnergyBonusPercent() {
        return this.energyBonusPercent;
    }

    public static class Builder {
        private boolean noHunger = false;
        private double damageBoost = 0.0;
        private boolean fly = false;
        private boolean speed = false;
        private int speedLevel = 0;
        private boolean coal = false;
        private boolean damage = false;
        private boolean jump = false;
        private int jumpLevel = 0;
        private boolean eco = false;
        private double sellBonus = 1.0;
        private int haste = 0;
        private int crouchHaste = 0;
        private int extraHearts = 0;
        private int healthBoostLevel = 0;
        private int baseHealthBonus = 0;
        private double skeletonDamageBoost = 0.0;
        private int belowYLevel = 55;
        private int belowYHasteLevel = 0;
        private boolean poisonImmunity = false;
        private double energyBonusPercent = 0.0;

        public Builder noHunger(boolean value) {
            this.noHunger = value;
            return this;
        }

        public Builder damageBoost(double value) {
            this.damageBoost = value;
            return this;
        }

        public Builder fly(boolean value) {
            this.fly = value;
            return this;
        }

        public Builder speed(boolean value) {
            this.speed = value;
            return this;
        }

        public Builder speedLevel(int value) {
            this.speedLevel = value;
            return this;
        }

        public Builder coal(boolean value) {
            this.coal = value;
            return this;
        }

        public Builder damage(boolean value) {
            this.damage = value;
            return this;
        }

        public Builder jump(boolean value) {
            this.jump = value;
            return this;
        }

        public Builder jumpLevel(int value) {
            this.jumpLevel = value;
            return this;
        }

        public Builder eco(boolean value) {
            this.eco = value;
            return this;
        }

        public Builder sellBonus(double value) {
            this.sellBonus = value;
            return this;
        }

        public Builder haste(int value) {
            this.haste = value;
            return this;
        }

        public Builder crouchHaste(int value) {
            this.crouchHaste = value;
            return this;
        }

        public Builder extraHearts(int value) {
            this.extraHearts = value;
            return this;
        }

        public Builder healthBoostLevel(int value) {
            this.healthBoostLevel = value;
            return this;
        }

        public Builder baseHealthBonus(int value) {
            this.baseHealthBonus = value;
            return this;
        }

        public Builder skeletonDamageBoost(double value) {
            this.skeletonDamageBoost = value;
            return this;
        }

        public Builder belowYLevel(int value) {
            this.belowYLevel = value;
            return this;
        }

        public Builder belowYHasteLevel(int value) {
            this.belowYHasteLevel = value;
            return this;
        }

        public Builder poisonImmunity(boolean value) {
            this.poisonImmunity = value;
            return this;
        }

        public Builder energyBonusPercent(double value) {
            this.energyBonusPercent = value;
            return this;
        }

        public MaskAbilities build() {
            return new MaskAbilities(this.noHunger, this.damageBoost, this.fly, this.speed, this.coal, this.damage, this.jump, this.jumpLevel, this.eco, this.sellBonus, this.haste, this.crouchHaste, this.extraHearts, this.healthBoostLevel, this.baseHealthBonus, this.skeletonDamageBoost, this.belowYLevel, this.belowYHasteLevel, this.speedLevel, this.poisonImmunity, this.energyBonusPercent);
        }
    }
}

