/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.profile.PlayerProfile
 *  org.bukkit.profile.PlayerTextures
 */
package org.axial.prisonsCore.masks.util;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Base64;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

public class SkullUtil {
    private static final Pattern BASE64_PATTERN = Pattern.compile("\"url\":\"(https?://[^\"]+)\"");
    private static Plugin plugin;

    private SkullUtil() {
    }

    public static void init(PrisonsCore corePlugin) {
        plugin = corePlugin;
    }

    public static ItemStack createSkull(String base64Texture, String name) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta)skull.getItemMeta();
        if (meta == null) {
            return skull;
        }
        meta.setDisplayName(SkullUtil.colorize(name));
        String json = new String(Base64.getDecoder().decode(base64Texture));
        Matcher matcher = BASE64_PATTERN.matcher(json);
        String textureUrl = null;
        if (matcher.find()) {
            textureUrl = matcher.group(1);
        }
        if (textureUrl == null) {
            skull.setItemMeta((ItemMeta)meta);
            return skull;
        }
        try {
            PlayerProfile profile = SkullUtil.createProfile(textureUrl);
            meta.setOwnerProfile(profile);
        }
        catch (MalformedURLException e) {
            plugin.getLogger().warning("Invalid texture URL: " + textureUrl);
            skull.setItemMeta((ItemMeta)meta);
            return skull;
        }
        skull.setItemMeta((ItemMeta)meta);
        return skull;
    }

    private static PlayerProfile createProfile(String textureUrl) throws MalformedURLException {
        PlayerProfile profile = plugin.getServer().createPlayerProfile(UUID.randomUUID(), "Mask");
        PlayerTextures textures = profile.getTextures();
        textures.setSkin(new URL(textureUrl));
        profile.setTextures(textures);
        return profile;
    }

    public static String colorize(String text) {
        return text == null ? "" : text.replace("&", "\u00a7");
    }

    public static NamespacedKey getNamespacedKey(String key) {
        return new NamespacedKey(plugin, key);
    }
}

