/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.masks.model;

import java.util.ArrayList;
import java.util.List;
import org.axial.prisonsCore.masks.model.Mask;
import org.axial.prisonsCore.masks.util.SkullUtil;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class MaskItem {
    public static final String MASK_KEY = "mask_id";
    public static final String MASK_APPLIED_KEY = "mask_applied";
    public static final String MASK_LORE_PREFIX = "\u00a78[\u00a77Mask\u00a78] ";

    private MaskItem() {
    }

    public static ItemStack createMaskItem(Mask mask) {
        ItemStack item = SkullUtil.createSkull(mask.getSkin(), mask.getName());
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(SkullUtil.getNamespacedKey(MASK_KEY), PersistentDataType.STRING, mask.getId());
            ArrayList<String> lore = new ArrayList<String>();
            for (String line : mask.lore()) {
                lore.add(SkullUtil.colorize(line));
            }
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    public static boolean isMask(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(SkullUtil.getNamespacedKey(MASK_KEY), PersistentDataType.STRING);
    }

    public static String getMaskId(ItemStack item) {
        if (!MaskItem.isMask(item)) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        return (String)meta.getPersistentDataContainer().get(SkullUtil.getNamespacedKey(MASK_KEY), PersistentDataType.STRING);
    }

    public static boolean hasAppliedMask(ItemStack helmet) {
        if (helmet == null || !helmet.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = helmet.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(SkullUtil.getNamespacedKey(MASK_APPLIED_KEY), PersistentDataType.STRING);
    }

    public static String getAppliedMaskId(ItemStack helmet) {
        if (!MaskItem.hasAppliedMask(helmet)) {
            return null;
        }
        ItemMeta meta = helmet.getItemMeta();
        if (meta == null) {
            return null;
        }
        return (String)meta.getPersistentDataContainer().get(SkullUtil.getNamespacedKey(MASK_APPLIED_KEY), PersistentDataType.STRING);
    }

    public static ItemStack applyMaskToHelmet(ItemStack helmet, String maskId, String maskName, String lorePrefix, String loreFormat) {
        ItemStack result = helmet.clone();
        ItemMeta meta = result.getItemMeta();
        if (meta == null) {
            return helmet;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        container.set(SkullUtil.getNamespacedKey(MASK_APPLIED_KEY), PersistentDataType.STRING, maskId);
        ArrayList<String> lore = (ArrayList<String>) meta.getLore();
        if (lore == null) {
            lore = new ArrayList<String>();
        }
        String coloredPrefix = SkullUtil.colorize(lorePrefix);
        lore.removeIf(line -> line != null && line.startsWith(coloredPrefix));
        String loreLine = loreFormat.replace("{prefix}", coloredPrefix).replace("{mask_name}", SkullUtil.colorize(maskName));
        lore.add(loreLine);
        meta.setLore(lore);
        result.setItemMeta(meta);
        return result;
    }

    public static ItemStack removeMaskFromHelmet(ItemStack helmet) {
        return MaskItem.removeMaskFromHelmet(helmet, MASK_LORE_PREFIX);
    }

    public static ItemStack removeMaskFromHelmet(ItemStack helmet, String lorePrefix) {
        ItemStack result = helmet.clone();
        ItemMeta meta = result.getItemMeta();
        if (meta == null) {
            return helmet;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        container.remove(SkullUtil.getNamespacedKey(MASK_APPLIED_KEY));
        if (meta.hasLore()) {
            List<String> lore = meta.getLore();
            if (lore != null) {
                String coloredPrefix = SkullUtil.colorize(lorePrefix);
                lore.removeIf(line -> line != null && line.startsWith(coloredPrefix));
                if (lore.isEmpty()) {
                    meta.setLore(null);
                } else {
                    meta.setLore(lore);
                }
            }
        }
        result.setItemMeta(meta);
        return result;
    }
}
