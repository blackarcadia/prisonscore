/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.masks.config;

import java.util.List;
import java.util.Map;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.masks.config.MaskUpdater;

public class MaskConfigManager {
    private final MaskUpdater maskUpdater;

    public MaskConfigManager(PrisonsCore plugin) {
        this.maskUpdater = new MaskUpdater(plugin);
        this.maskUpdater.updateMasks();
    }

    public List<String> getMaskIds() {
        return this.maskUpdater.getMaskIds();
    }

    public Map<String, Object> getMaskConfig(String maskId) {
        return this.maskUpdater.getMaskConfig(maskId);
    }

    public void reload() {
        this.maskUpdater.reload();
    }
}

