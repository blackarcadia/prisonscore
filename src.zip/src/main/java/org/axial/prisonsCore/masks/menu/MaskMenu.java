package org.axial.prisonsCore.masks.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.masks.model.Mask;
import org.axial.prisonsCore.masks.util.SkullUtil;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class MaskMenu implements InventoryHolder {
    private final MaskModule module;
    private final Inventory inventory;

    public MaskMenu(MaskModule module) {
        this.module = module;
        List<Mask> masks = this.resolveMasksToDisplay();
        int size = this.resolveMenuSize(masks.size());
        String title = SkullUtil.colorize(this.module.getConfigManager().getMenuTitle());
        this.inventory = Bukkit.createInventory(this, size, title);
        this.placeMasks(masks, size);
        this.fillEmptySlots();
    }

    private List<Mask> resolveMasksToDisplay() {
        List<String> configuredList = this.module.getConfigManager().getMenuMaskIds().stream().map(id -> id.toLowerCase(Locale.ENGLISH)).collect(Collectors.toList());
        boolean useAll = configuredList.isEmpty();
        List<Mask> filtered = new ArrayList<Mask>();
        if (useAll) {
            for (Mask mask : this.module.getMaskManager().getAllMasks()) {
                String id = mask.getId().toLowerCase(Locale.ENGLISH);
                if (!this.module.getConfigManager().isMaskEnabledInMenu(id)) {
                    continue;
                }
                filtered.add(mask);
            }
        } else {
            for (String requestedId : configuredList) {
                Mask mask = this.module.getMaskManager().getMask(requestedId);
                if (mask == null) {
                    continue;
                }
                String id = mask.getId().toLowerCase(Locale.ENGLISH);
                if (!this.module.getConfigManager().isMaskEnabledInMenu(id)) {
                    continue;
                }
                filtered.add(mask);
            }
        }
        return filtered;
    }

    private int resolveMenuSize(int maskCount) {
        int configured = this.module.getConfigManager().getMenuSize();
        if (configured > 0) {
            return configured;
        }
        int calculated = Math.max(9, ((maskCount - 1) / 9 + 1) * 9);
        return Math.min(54, calculated);
    }

    private void placeMasks(List<Mask> masks, int size) {
        for (Mask mask : masks) {
            int slot = this.module.getConfigManager().getMenuSlot(mask.getId());
            if (slot < 0 || slot >= size || this.inventory.getItem(slot) != null) {
                slot = this.findFirstEmptySlot(size);
            }
            if (slot == -1) continue;
            this.inventory.setItem(slot, mask.createItem());
        }
    }

    private int findFirstEmptySlot(int size) {
        for (int i = 0; i < size; ++i) {
            ItemStack item = this.inventory.getItem(i);
            if (item == null || item.getType() == Material.AIR) {
                return i;
            }
        }
        return -1;
    }

    private void fillEmptySlots() {
        ItemStack placeholder = this.createPlaceholderItem();
        for (int i = 0; i < this.inventory.getSize(); ++i) {
            ItemStack item = this.inventory.getItem(i);
            if (item == null || item.getType() == Material.AIR) {
                this.inventory.setItem(i, placeholder.clone());
            }
        }
    }

    private ItemStack createPlaceholderItem() {
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            pane.setItemMeta(meta);
        }
        return pane;
    }

    public void open(Player player) {
        player.openInventory(this.inventory);
    }

    @Override
    public Inventory getInventory() {
        return this.inventory;
    }
}
