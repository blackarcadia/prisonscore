/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package org.axial.prisonsCore.masks.config;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class MaskUpdater {
    private final PrisonsCore plugin;
    private static final String MASKS_FILE = "masks.yml";
    private static final String DEFAULT_CONFIG_VERSION = "1.0.0";

    public MaskUpdater(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public void updateMasks() {
        File dataFile = new File(this.plugin.getDataFolder(), MASKS_FILE);
        if (!dataFile.exists()) {
            this.plugin.saveResource(MASKS_FILE, false);
            this.plugin.getLogger().info("Created new masks.yml file.");
            return;
        }
        YamlConfiguration userConfig = YamlConfiguration.loadConfiguration((File)dataFile);
        FileConfiguration defaultConfig = this.loadDefaultConfig();
        if (defaultConfig == null) {
            this.plugin.getLogger().warning("Could not load default mask configuration.");
            return;
        }
        ConfigurationSection userMasksSection = userConfig.getConfigurationSection("masks");
        ConfigurationSection defaultMasksSection = defaultConfig.getConfigurationSection("masks");
        if (defaultMasksSection == null) {
            this.plugin.getLogger().warning("No default masks found in plugin resources.");
            return;
        }
        Set userMaskIds = userMasksSection != null ? userMasksSection.getKeys(false) : new HashSet();
        Set defaultMaskIds = defaultMasksSection.getKeys(false);
        boolean addedNewMasks = false;
        int addedCount = 0;
        for (Object maskId : defaultMaskIds) {
            if (userMaskIds.contains(maskId)) continue;
            this.addMaskToConfig((FileConfiguration)userConfig, defaultMasksSection, (String) maskId);
            this.plugin.getLogger().info("Added new mask from plugin update: " + maskId);
            addedNewMasks = true;
            ++addedCount;
        }
        if (addedNewMasks) {
            userConfig.set("config_version", (Object)defaultConfig.getString("config_version", DEFAULT_CONFIG_VERSION));
            try {
                userConfig.save(dataFile);
                this.plugin.getLogger().info("Successfully added " + addedCount + " new mask(s) to masks.yml!");
            }
            catch (IOException ex) {
                this.plugin.getLogger().log(Level.SEVERE, "Could not save updated masks.yml", ex);
            }
        } else {
            this.plugin.getLogger().info("Masks are up to date. No new masks to add.");
        }
    }

    private void addMaskToConfig(FileConfiguration userConfig, ConfigurationSection defaultMasks, String maskId) {
        String basePath = "masks." + maskId;
        userConfig.set(basePath + ".name", (Object)defaultMasks.getString(maskId + ".name"));
        userConfig.set(basePath + ".skin", (Object)defaultMasks.getString(maskId + ".skin"));
        userConfig.set(basePath + ".lore", (Object)defaultMasks.getStringList(maskId + ".lore"));
        ConfigurationSection abilitiesSection = defaultMasks.getConfigurationSection(maskId + ".abilities");
        if (abilitiesSection != null) {
            for (String abilityKey : abilitiesSection.getKeys(false)) {
                Object value = abilitiesSection.get(abilityKey);
                userConfig.set(basePath + ".abilities." + abilityKey, value);
            }
        }
    }

    /*
     * Enabled aggressive exception aggregation
     */
    private FileConfiguration loadDefaultConfig() {
        try (InputStream defaultStream = this.plugin.getResource(MASKS_FILE);){
            YamlConfiguration yamlConfiguration;
            if (defaultStream == null) {
                FileConfiguration fileConfiguration = null;
                return fileConfiguration;
            }
            try (InputStreamReader reader = new InputStreamReader(defaultStream, StandardCharsets.UTF_8);){
                yamlConfiguration = YamlConfiguration.loadConfiguration((Reader)reader);
            }
            return yamlConfiguration;
        }
        catch (IOException ex) {
            this.plugin.getLogger().log(Level.SEVERE, "Error loading default masks.yml", ex);
            return null;
        }
    }

    public List<String> getMaskIds() {
        File masksFile = new File(this.plugin.getDataFolder(), MASKS_FILE);
        if (!masksFile.exists()) {
            return List.of();
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration((File)masksFile);
        ConfigurationSection masksSection = config.getConfigurationSection("masks");
        return masksSection == null ? List.of() : masksSection.getKeys(false).stream().toList();
    }

    public Map<String, Object> getMaskConfig(String maskId) {
        HashMap<String, Object> config = new HashMap<String, Object>();
        File masksFile = new File(this.plugin.getDataFolder(), MASKS_FILE);
        if (!masksFile.exists()) {
            return config;
        }
        YamlConfiguration fileConfig = YamlConfiguration.loadConfiguration((File)masksFile);
        String base = "masks." + maskId;
        config.put("name", fileConfig.getString(base + ".name", maskId));
        config.put("skin", fileConfig.getString(base + ".skin", ""));
        config.put("lore", fileConfig.getStringList(base + ".lore"));
        config.put("no_hunger", fileConfig.getBoolean(base + ".abilities.no_hunger", false));
        config.put("damage_boost", fileConfig.getDouble(base + ".abilities.damage_boost", 0.0));
        config.put("fly", fileConfig.getBoolean(base + ".abilities.fly", false));
        config.put("speed", fileConfig.getBoolean(base + ".abilities.speed", false));
        config.put("coal", fileConfig.getBoolean(base + ".abilities.coal", false));
        config.put("damage", fileConfig.getBoolean(base + ".abilities.damage", false));
        config.put("jump", fileConfig.getBoolean(base + ".abilities.jump", false));
        config.put("jump_level", fileConfig.getInt(base + ".abilities.jump_level", 0));
        config.put("eco", fileConfig.getBoolean(base + ".abilities.eco", false));
        config.put("sell_bonus", fileConfig.getDouble(base + ".abilities.sell_bonus", 1.0));
        config.put("haste", fileConfig.getInt(base + ".abilities.haste", 0));
        config.put("crouch_haste", fileConfig.getInt(base + ".abilities.crouch_haste", 0));
        config.put("extra_hearts", fileConfig.getInt(base + ".abilities.extra_hearts", 0));
        config.put("health_boost_level", fileConfig.getInt(base + ".abilities.health_boost_level", 0));
        config.put("base_health_bonus", fileConfig.getInt(base + ".abilities.base_health_bonus", 0));
        config.put("skeleton_damage_boost", fileConfig.getDouble(base + ".abilities.skeleton_damage_boost", 0.0));
        config.put("below_y_level", fileConfig.getInt(base + ".abilities.below_y_level", 55));
        config.put("below_y_haste_level", fileConfig.getInt(base + ".abilities.below_y_haste_level", 0));
        config.put("speed_level", fileConfig.getInt(base + ".abilities.speed_level", 0));
        config.put("poison_immunity", fileConfig.getBoolean(base + ".abilities.poison_immunity", false));
        config.put("energy_bonus_percent", fileConfig.getDouble(base + ".abilities.energy_bonus_percent", 0.0));
        return config;
    }

    public void reload() {
        this.updateMasks();
    }
}

