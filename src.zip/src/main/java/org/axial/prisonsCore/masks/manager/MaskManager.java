/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.NamespacedKey
 *  org.bukkit.Sound
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.attribute.AttributeModifier
 *  org.bukkit.attribute.AttributeModifier$Operation
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.potion.PotionEffect
 *  org.bukkit.potion.PotionEffectType
 *  org.jetbrains.annotations.NotNull
 */
package org.axial.prisonsCore.masks.manager;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.masks.model.Mask;
import org.axial.prisonsCore.masks.model.MaskAbilities;
import org.axial.prisonsCore.masks.model.MaskItem;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.jetbrains.annotations.NotNull;

public class MaskManager {
    private final MaskModule module;
    private final Map<String, Mask> masks;
    private final Map<UUID, String> playerMasks;
    private final Set<UUID> noHungerPlayers = new HashSet<UUID>();
    private final Set<UUID> flyPlayers = new HashSet<UUID>();
    private final Set<UUID> speedPlayers = new HashSet<UUID>();
    private final Set<UUID> coalPlayers = new HashSet<UUID>();
    private final Set<UUID> damagePlayers = new HashSet<UUID>();
    private final Set<UUID> jumpPlayers = new HashSet<UUID>();
    private final Set<UUID> ecoPlayers = new HashSet<UUID>();
    private final Set<UUID> sellBonusPlayers = new HashSet<UUID>();
    private final Set<UUID> hastePlayers = new HashSet<UUID>();
    private final Set<UUID> crouchHastePlayers = new HashSet<UUID>();
    private final Set<UUID> extraHeartPlayers = new HashSet<UUID>();
    private final Set<UUID> baseHealthPlayers = new HashSet<UUID>();
    private final Set<UUID> poisonImmunePlayers = new HashSet<UUID>();
    private static final NamespacedKey EXTRA_HEARTS_KEY = NamespacedKey.fromString((String)"masks:extra_hearts");
    private static final NamespacedKey BASE_HEALTH_KEY = NamespacedKey.fromString((String)"masks:base_health");

    public MaskManager(MaskModule module) {
        this.module = module;
        this.masks = new HashMap<String, Mask>();
        this.playerMasks = new HashMap<UUID, String>();
        this.loadMasks();
    }

    public void reload() {
        this.masks.clear();
        this.loadMasks();
    }

    private void loadMasks() {
        for (String maskId : this.module.getMaskConfigManager().getMaskIds()) {
            Map<String, Object> config = this.module.getMaskConfigManager().getMaskConfig(maskId);
            MaskAbilities abilities = new MaskAbilities.Builder().noHunger((Boolean)config.getOrDefault("no_hunger", false)).damageBoost(this.toDouble(config.getOrDefault("damage_boost", 0))).fly((Boolean)config.getOrDefault("fly", false)).speed((Boolean)config.getOrDefault("speed", false)).coal((Boolean)config.getOrDefault("coal", false)).damage((Boolean)config.getOrDefault("damage", false)).jump((Boolean)config.getOrDefault("jump", false)).jumpLevel(((Number)config.getOrDefault("jump_level", 0)).intValue()).eco((Boolean)config.getOrDefault("eco", false)).sellBonus(this.toDouble(config.getOrDefault("sell_bonus", 1))).haste(((Number)config.getOrDefault("haste", 0)).intValue()).crouchHaste(((Number)config.getOrDefault("crouch_haste", 0)).intValue()).extraHearts(((Number)config.getOrDefault("extra_hearts", 0)).intValue()).healthBoostLevel(((Number)config.getOrDefault("health_boost_level", 0)).intValue()).baseHealthBonus(((Number)config.getOrDefault("base_health_bonus", 0)).intValue()).skeletonDamageBoost(this.toDouble(config.getOrDefault("skeleton_damage_boost", 0))).belowYLevel(((Number)config.getOrDefault("below_y_level", 55)).intValue()).belowYHasteLevel(((Number)config.getOrDefault("below_y_haste_level", 0)).intValue()).speedLevel(((Number)config.getOrDefault("speed_level", 0)).intValue()).poisonImmunity((Boolean)config.getOrDefault("poison_immunity", false)).energyBonusPercent(this.toDouble(config.getOrDefault("energy_bonus_percent", 0))).build();
            Mask mask = new Mask(maskId, (String)config.get("name"), (String)config.get("skin"), (List)config.get("lore"), abilities);
            this.masks.put(maskId.toLowerCase(), mask);
        }
    }

    private double toDouble(Object value) {
        return value instanceof Number ? ((Number)value).doubleValue() : 0.0;
    }

    public Mask getMask(String id) {
        return this.masks.get(id.toLowerCase());
    }

    public Collection<Mask> getAllMasks() {
        return this.masks.values();
    }

    public ItemStack createMaskItem(String maskId) {
        Mask mask = this.masks.get(maskId.toLowerCase());
        return mask != null ? mask.createItem() : null;
    }

    public String getWornMaskId(Player player) {
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null) {
            return null;
        }
        String applied = MaskItem.getAppliedMaskId(helmet);
        if (applied != null) {
            return applied;
        }
        return MaskItem.getMaskId(helmet);
    }

    public void updatePlayerMaskEffects(Player player) {
        UUID playerId = player.getUniqueId();
        String currentMaskId = this.getWornMaskId(player);
        String previousMaskId = this.playerMasks.get(playerId);
        if (previousMaskId != null && !previousMaskId.equals(currentMaskId)) {
            this.removeMaskEffects(player, previousMaskId);
        }
        if (currentMaskId != null) {
            this.applyMaskEffects(player, currentMaskId);
        }
        this.playerMasks.put(playerId, currentMaskId);
    }

    private void removeMaskEffects(Player player, String maskId) {
        Mask mask = this.getMask(maskId);
        if (mask == null) {
            return;
        }
        MaskAbilities abilities = mask.getAbilities();
        UUID playerId = player.getUniqueId();
        if (abilities.hasNoHunger()) {
            this.noHungerPlayers.remove(playerId);
        }
        if (abilities.hasFly()) {
            this.disableFlight(player);
        }
        if (abilities.hasSpeed() || abilities.getSpeedLevel() > 0) {
            this.removeSpeed(player);
        }
        if (abilities.hasCoal()) {
            this.coalPlayers.remove(playerId);
        }
        if (abilities.hasDamage()) {
            this.damagePlayers.remove(playerId);
        }
        if (abilities.hasJump() || abilities.getJumpLevel() > 0) {
            this.removeJump(player);
        }
        if (abilities.hasEco()) {
            this.ecoPlayers.remove(playerId);
        }
        if (abilities.getSellBonus() > 1.0) {
            this.sellBonusPlayers.remove(playerId);
        }
        if (abilities.getHaste() > 0) {
            this.removeHaste(player);
        }
        if (abilities.getCrouchHaste() > 0) {
            this.removeCrouchHaste(player);
        }
        if (abilities.getExtraHearts() > 0) {
            this.removeExtraHearts(player);
        }
        if (abilities.getHealthBoostLevel() > 0) {
            this.removeHealthBoost(player);
        }
        if (abilities.getBaseHealthBonus() > 0) {
            this.removeBaseHealthBonus(player);
        }
        if (abilities.hasPoisonImmunity()) {
            this.poisonImmunePlayers.remove(playerId);
        }
    }

    private void applyMaskEffects(Player player, String maskId) {
        Mask mask = this.getMask(maskId);
        if (mask == null) {
            return;
        }
        MaskAbilities abilities = mask.getAbilities();
        UUID playerId = player.getUniqueId();
        if (abilities.hasNoHunger()) {
            this.noHungerPlayers.add(playerId);
        }
        if (abilities.hasFly()) {
            this.enableFlight(player);
        }
        if (abilities.hasSpeed() || abilities.getSpeedLevel() > 0) {
            this.applySpeed(player, abilities);
        }
        if (abilities.hasCoal()) {
            this.coalPlayers.add(playerId);
        }
        if (abilities.hasDamage()) {
            this.damagePlayers.add(playerId);
        }
        if (abilities.hasJump() || abilities.getJumpLevel() > 0) {
            this.applyJump(player, abilities);
        }
        if (abilities.hasEco()) {
            this.ecoPlayers.add(playerId);
        }
        if (abilities.getSellBonus() > 1.0) {
            this.sellBonusPlayers.add(playerId);
        }
        if (abilities.getHaste() > 0) {
            this.applyHaste(player, abilities.getHaste());
        }
        if (abilities.getCrouchHaste() > 0 && player.isSneaking()) {
            this.applyCrouchHaste(player);
        }
        if (abilities.getExtraHearts() > 0) {
            this.applyExtraHearts(player, abilities.getExtraHearts());
        }
        if (abilities.getHealthBoostLevel() > 0) {
            this.applyHealthBoost(player, abilities.getHealthBoostLevel());
        }
        if (abilities.getBaseHealthBonus() > 0) {
            this.applyBaseHealthBonus(player, abilities.getBaseHealthBonus());
        }
        if (abilities.hasPoisonImmunity()) {
            this.poisonImmunePlayers.add(playerId);
            player.removePotionEffect(PotionEffectType.POISON);
        }
        this.updateMovementEffects(player);
    }

    private void enableFlight(Player player) {
        this.flyPlayers.add(player.getUniqueId());
        player.setAllowFlight(true);
        player.setFlying(true);
    }

    private void disableFlight(Player player) {
        this.flyPlayers.remove(player.getUniqueId());
        player.setAllowFlight(false);
        player.setFlying(false);
    }

    private void applySpeed(Player player, MaskAbilities abilities) {
        this.speedPlayers.add(player.getUniqueId());
        int level = abilities.getSpeedLevel() > 0 ? abilities.getSpeedLevel() : 2;
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, level - 1, false, false, true));
    }

    private void removeSpeed(Player player) {
        this.speedPlayers.remove(player.getUniqueId());
        player.removePotionEffect(PotionEffectType.SPEED);
    }

    private void applyJump(Player player, MaskAbilities abilities) {
        this.jumpPlayers.add(player.getUniqueId());
        int level = abilities.getJumpLevel() > 0 ? abilities.getJumpLevel() : 2;
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, level - 1, false, false, true));
    }

    private void removeJump(Player player) {
        this.jumpPlayers.remove(player.getUniqueId());
        player.removePotionEffect(PotionEffectType.JUMP_BOOST);
    }

    private void applyHaste(Player player, int level) {
        this.hastePlayers.add(player.getUniqueId());
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, Integer.MAX_VALUE, level - 1, false, false, true));
    }

    private void removeHaste(Player player) {
        this.hastePlayers.remove(player.getUniqueId());
        player.removePotionEffect(PotionEffectType.HASTE);
    }

    private void applyExtraHearts(Player player, int hearts) {
        this.extraHeartPlayers.add(player.getUniqueId());
        AttributeInstance attr = this.getMaxHealthAttribute(player);
        if (attr == null) {
            return;
        }
        this.removeExtraHeartsModifier(attr);
        double healthBoost = (double)hearts * 2.0;
        attr.addModifier(new AttributeModifier(EXTRA_HEARTS_KEY, healthBoost, AttributeModifier.Operation.ADD_NUMBER));
    }

    private void removeExtraHearts(Player player) {
        this.extraHeartPlayers.remove(player.getUniqueId());
        AttributeInstance attr = this.getMaxHealthAttribute(player);
        if (attr == null) {
            return;
        }
        this.removeExtraHeartsModifier(attr);
        if (player.getHealth() > attr.getValue()) {
            player.setHealth(attr.getValue());
        }
    }

    private void removeExtraHeartsModifier(AttributeInstance attr) {
        for (AttributeModifier modifier : attr.getModifiers()) {
            if (!modifier.getKey().equals((Object)EXTRA_HEARTS_KEY)) continue;
            attr.removeModifier(modifier);
            break;
        }
    }

    private void applyBaseHealthBonus(Player player, int hearts) {
        this.baseHealthPlayers.add(player.getUniqueId());
        AttributeInstance attr = this.getMaxHealthAttribute(player);
        if (attr == null) {
            return;
        }
        this.removeBaseHealthModifier(attr);
        double bonus = (double)hearts * 2.0;
        attr.addModifier(new AttributeModifier(BASE_HEALTH_KEY, bonus, AttributeModifier.Operation.ADD_NUMBER));
    }

    private void removeBaseHealthBonus(Player player) {
        this.baseHealthPlayers.remove(player.getUniqueId());
        AttributeInstance attr = this.getMaxHealthAttribute(player);
        if (attr == null) {
            return;
        }
        this.removeBaseHealthModifier(attr);
        if (player.getHealth() > attr.getValue()) {
            player.setHealth(attr.getValue());
        }
    }

    private void removeBaseHealthModifier(AttributeInstance attr) {
        for (AttributeModifier modifier : attr.getModifiers()) {
            if (!modifier.getKey().equals((Object)BASE_HEALTH_KEY)) continue;
            attr.removeModifier(modifier);
            break;
        }
    }

    private void applyHealthBoost(Player player, int level) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, level - 1, false, false, true));
    }

    private void removeHealthBoost(Player player) {
        player.removePotionEffect(PotionEffectType.HEALTH_BOOST);
    }

    private AttributeInstance getMaxHealthAttribute(Player player) {
        Attribute attribute = this.resolveMaxHealthAttribute();
        return attribute != null ? player.getAttribute(attribute) : null;
    }

    private Attribute resolveMaxHealthAttribute() {
        try {
            return Attribute.valueOf((String)"GENERIC_MAX_HEALTH");
        }
        catch (IllegalArgumentException ignored) {
            try {
                return Attribute.valueOf((String)"MAX_HEALTH");
            }
            catch (IllegalArgumentException ex) {
                return null;
            }
        }
    }

    public void applyCrouchHaste(Player player) {
        int level = this.getMask(this.playerMasks.get(player.getUniqueId())).getAbilities().getCrouchHaste() - 1;
        if (level >= 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, Integer.MAX_VALUE, level, false, false, true));
        }
    }

    public void removeCrouchHaste(Player player) {
        this.crouchHastePlayers.remove(player.getUniqueId());
        player.removePotionEffect(PotionEffectType.HASTE);
    }

    public void playEquipSound(Player player) {
        if (this.module.getConfigManager().playSounds()) {
            player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 1.0f, 1.0f);
        }
    }

    public void playRemoveSound(Player player) {
        if (this.module.getConfigManager().playSounds()) {
            player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 1.0f, 0.8f);
        }
    }

    public void updateMovementEffects(Player player) {
        int desiredSpeed = 0;
        int belowYHaste;
        int crouchHaste;
        String maskId = this.getWornMaskId(player);
        if (maskId == null) {
            return;
        }
        Mask mask = this.getMask(maskId);
        if (mask == null) {
            return;
        }
        MaskAbilities abilities = mask.getAbilities();
        int baseHaste = abilities.getHaste();
        int desiredHaste = Math.max(baseHaste, Math.max(crouchHaste = player.isSneaking() ? abilities.getCrouchHaste() : 0, belowYHaste = abilities.hasBelowYHaste() && player.getLocation().getBlockY() < abilities.getBelowYLevel() ? abilities.getBelowYHasteLevel() : 0));
        if (desiredHaste > 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, Integer.MAX_VALUE, desiredHaste - 1, false, false, true));
        } else {
            player.removePotionEffect(PotionEffectType.HASTE);
        }
        int n = abilities.getSpeedLevel() > 0 ? abilities.getSpeedLevel() : (desiredSpeed = abilities.hasSpeed() ? 2 : 0);
        if (desiredSpeed > 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, desiredSpeed - 1, false, false, true));
        } else {
            player.removePotionEffect(PotionEffectType.SPEED);
        }
    }

    public void removePlayerEffects(@NotNull UUID uniqueId) {
        Player player = this.module.getServer().getPlayer(uniqueId);
        if (player == null) {
            return;
        }
        String maskId = this.playerMasks.get(uniqueId);
        if (maskId != null) {
            this.removeMaskEffects(player, maskId);
        }
        this.playerMasks.remove(uniqueId);
        this.removeExtraHearts(player);
        this.removeHealthBoost(player);
        this.removeBaseHealthBonus(player);
        this.poisonImmunePlayers.remove(uniqueId);
    }

    public boolean hasCoalAbility(@NotNull UUID uniqueId) {
        return this.coalPlayers.contains(uniqueId);
    }

    public boolean hasNoHunger(@NotNull UUID uniqueId) {
        return this.noHungerPlayers.contains(uniqueId);
    }

    public boolean hasPoisonImmunity(@NotNull UUID uniqueId) {
        return this.poisonImmunePlayers.contains(uniqueId);
    }

    public double getDamageBoost(Player player) {
        String maskId = this.getWornMaskId(player);
        if (maskId == null) {
            return 0.0;
        }
        Mask mask = this.masks.get(maskId.toLowerCase());
        if (mask == null) {
            return 0.0;
        }
        return mask.getAbilities().getDamageBoost();
    }

    public double getSkeletonDamageBoost(Player player) {
        String maskId = this.getWornMaskId(player);
        if (maskId == null) {
            return 0.0;
        }
        Mask mask = this.masks.get(maskId.toLowerCase());
        if (mask == null) {
            return 0.0;
        }
        return mask.getAbilities().getSkeletonDamageBoost();
    }

    public double getEnergyBonusPercent(Player player) {
        String maskId = this.getWornMaskId(player);
        if (maskId == null) {
            return 0.0;
        }
        Mask mask = this.masks.get(maskId.toLowerCase());
        if (mask == null) {
            return 0.0;
        }
        return mask.getAbilities().getEnergyBonusPercent();
    }
}

