/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.masks.listener;

import java.util.Map;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.masks.model.Mask;
import org.axial.prisonsCore.masks.model.MaskItem;
import org.axial.prisonsCore.masks.util.SkullUtil;
import org.axial.prisonsCore.service.SeasonService;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class InventoryClickListener
implements Listener {
    private final MaskModule module;

    public InventoryClickListener(MaskModule module) {
        this.module = module;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity clicker = event.getWhoClicked();
        if (!(clicker instanceof Player)) {
            return;
        }
        Player player = (Player)clicker;
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();
        if (!this.handleMaskRemoval(event, player, cursor, current)) {
            this.handleMaskApplication(event, player, cursor, current);
        }
    }

    private boolean handleMaskRemoval(InventoryClickEvent event, Player player, ItemStack cursor, ItemStack current) {
        if (cursor != null && cursor.getType() != Material.AIR) {
            return false;
        }
        if (current == null || current.getType() == Material.AIR) {
            return false;
        }
        if (!MaskItem.hasAppliedMask(current)) {
            return false;
        }
        if (event.getClick() != ClickType.RIGHT) {
            return false;
        }
        event.setCancelled(true);
        String maskId = MaskItem.getAppliedMaskId(current);
        Mask mask = this.module.getMaskManager().getMask(maskId);
        if (mask == null) {
            return true;
        }
        boolean wasWearing = false;
        ItemStack equippedHelmet = player.getInventory().getHelmet();
        if (equippedHelmet != null && equippedHelmet.equals((Object)current)) {
            wasWearing = true;
        }
        ItemStack helmetWithoutMask = MaskItem.removeMaskFromHelmet(current);
        ItemStack maskItem = mask.createItem();
        event.setCurrentItem(helmetWithoutMask);
        if (player.getInventory().firstEmpty() == -1) {
            player.getWorld().dropItemNaturally(player.getLocation(), maskItem);
            player.sendMessage(this.module.getConfigManager().getMessage("mask_removed") + " \u00a7c(Dropped on ground - inventory full)");
        } else {
            player.getInventory().addItem(new ItemStack[]{maskItem});
            player.sendMessage(this.module.getConfigManager().getMessage("mask_removed", Map.of("mask", SkullUtil.colorize(mask.getName()))));
        }
        if (wasWearing) {
            this.module.getMaskManager().removePlayerEffects(player.getUniqueId());
            this.module.getMaskVisualManager().clearHelmetVisual(player);
            this.module.getMaskEquipListener().forceUpdateMaskEffects(player);
        }
        this.module.getMaskManager().playRemoveSound(player);
        return true;
    }

    public void handleMaskApplication(InventoryClickEvent event, Player player, ItemStack cursor, ItemStack current) {
        if (!MaskItem.isMask(cursor)) {
            return;
        }
        if (current == null || current.getType() == Material.AIR) {
            return;
        }
        if (!this.isHelmet(current.getType())) {
            return;
        }
        if (current != null && MaskItem.isMask(current)) {
            player.sendMessage(this.module.getConfigManager().getMessage("cannot_place_mask_on_mask"));
            event.setCancelled(true);
            return;
        }
        if (MaskItem.hasAppliedMask(current)) {
            player.sendMessage(this.module.getConfigManager().getMessage("helmet_has_mask"));
            event.setCancelled(true);
            return;
        }
        String maskId = MaskItem.getMaskId(cursor);
        Mask mask = this.module.getMaskManager().getMask(maskId);
        if (mask == null) {
            return;
        }
        SeasonService seasonService = this.module.getPlugin().getSeasonService();
        if (seasonService != null && !seasonService.isFeatureUnlocked(SeasonService.UnlockFeature.MASKS)) {
            player.sendMessage("§cMasks unlock on Day " + seasonService.getUnlockDay(SeasonService.UnlockFeature.MASKS) + ".");
            event.setCancelled(true);
            return;
        }
        event.setCancelled(true);
        String lorePrefix = this.module.getConfigManager().getMaskLorePrefix();
        String loreFormat = this.module.getConfigManager().getMaskLoreFormat();
        ItemStack maskedHelmet = MaskItem.applyMaskToHelmet(current, maskId, mask.getName(), lorePrefix, loreFormat);
        event.setCurrentItem(maskedHelmet);
        if (cursor.getAmount() > 1) {
            cursor.setAmount(cursor.getAmount() - 1);
        } else {
            event.getView().setCursor(null);
        }
        this.module.getMaskManager().playEquipSound(player);
        player.sendMessage(this.module.getConfigManager().getMessage("mask_applied", Map.of("mask", SkullUtil.colorize(mask.getName()))));
    }

    private boolean isHelmet(Material material) {
        return switch (material) {
            case Material.LEATHER_HELMET, Material.CHAINMAIL_HELMET, Material.IRON_HELMET, Material.GOLDEN_HELMET, Material.DIAMOND_HELMET, Material.NETHERITE_HELMET, Material.TURTLE_HELMET, Material.PLAYER_HEAD, Material.CARVED_PUMPKIN -> true;
            default -> false;
        };
    }
}
