/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.masks.manager;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.masks.manager.MaskManager;
import org.axial.prisonsCore.masks.model.Mask;
import org.axial.prisonsCore.masks.model.MaskItem;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class MaskVisualManager {
    private final MaskModule module;
    private final MaskManager maskManager;
    private final Set<UUID> visualOverridePlayers;

    public MaskVisualManager(MaskModule module, MaskManager maskManager) {
        this.module = module;
        this.maskManager = maskManager;
        this.visualOverridePlayers = new HashSet<UUID>();
    }

    public void updateHelmetVisual(Player player) {
        Mask mask;
        UUID playerId = player.getUniqueId();
        ItemStack helmet = player.getInventory().getHelmet();
        if (helmet == null) {
            if (this.visualOverridePlayers.contains(playerId)) {
                this.clearHelmetVisual(player);
            }
            return;
        }
        String maskId = MaskItem.getAppliedMaskId(helmet);
        if (maskId != null && (mask = this.maskManager.getMask(maskId)) != null) {
            this.applyMaskVisual(player, mask);
            this.visualOverridePlayers.add(playerId);
            return;
        }
        if (this.visualOverridePlayers.contains(playerId)) {
            this.clearHelmetVisual(player);
        }
    }

    private void applyMaskVisual(Player player, Mask mask) {
        ItemStack maskVisual = MaskItem.createMaskItem(mask);
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            onlinePlayer.sendEquipmentChange((LivingEntity)player, EquipmentSlot.HEAD, maskVisual);
        }
    }

    public void clearHelmetVisual(Player player) {
        UUID playerId = player.getUniqueId();
        ItemStack actualHelmet = player.getInventory().getHelmet();
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            onlinePlayer.sendEquipmentChange((LivingEntity)player, EquipmentSlot.HEAD, actualHelmet);
        }
        this.visualOverridePlayers.remove(playerId);
    }

    public void refreshAllVisuals() {
        for (UUID playerId : this.visualOverridePlayers) {
            Player player = Bukkit.getPlayer((UUID)playerId);
            if (player == null || !player.isOnline()) continue;
            this.updateHelmetVisual(player);
        }
    }

    public boolean hasVisualOverride(UUID playerId) {
        return this.visualOverridePlayers.contains(playerId);
    }

    public void removePlayer(UUID playerId) {
        this.visualOverridePlayers.remove(playerId);
    }

    public void refreshVisualsForViewer(Player viewer) {
        for (UUID playerId : this.visualOverridePlayers) {
            Mask mask;
            String maskId;
            ItemStack helmet;
            Player maskedPlayer = Bukkit.getPlayer((UUID)playerId);
            if (maskedPlayer == null || !maskedPlayer.isOnline() || maskedPlayer.equals((Object)viewer) || (helmet = maskedPlayer.getInventory().getHelmet()) == null || (maskId = MaskItem.getAppliedMaskId(helmet)) == null || (mask = this.maskManager.getMask(maskId)) == null) continue;
            ItemStack maskVisual = MaskItem.createMaskItem(mask);
            viewer.sendEquipmentChange((LivingEntity)maskedPlayer, EquipmentSlot.HEAD, maskVisual);
        }
    }
}

