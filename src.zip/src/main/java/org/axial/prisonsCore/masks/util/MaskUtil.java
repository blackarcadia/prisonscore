/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.masks.util;

public class MaskUtil {
    private MaskUtil() {
    }
}

