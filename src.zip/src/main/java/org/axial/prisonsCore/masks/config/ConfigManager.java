/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 */
package org.axial.prisonsCore.masks.config;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.ConfigurationSection;

public class ConfigManager {
    private static final String LANGUAGE_FILE = "mask-language.yml";
    private static final String SETTINGS_FILE = "mask-config.yml";
    private final PrisonsCore plugin;
    private FileConfiguration languageConfig;
    private File languageFile;
    private FileConfiguration settingsConfig;
    private File settingsFile;

    public ConfigManager(PrisonsCore plugin) {
        this.plugin = plugin;
        this.loadLanguageConfig();
        this.loadSettingsConfig();
    }

    public void reload() {
        this.loadLanguageConfig();
        this.loadSettingsConfig();
    }

    private void loadLanguageConfig() {
        this.languageFile = new File(this.plugin.getDataFolder(), LANGUAGE_FILE);
        if (!this.languageFile.exists()) {
            this.plugin.saveResource(LANGUAGE_FILE, false);
        }
        this.languageConfig = YamlConfiguration.loadConfiguration((File)this.languageFile);
    }

    private void loadSettingsConfig() {
        this.settingsFile = new File(this.plugin.getDataFolder(), SETTINGS_FILE);
        if (!this.settingsFile.exists()) {
            this.plugin.saveResource(SETTINGS_FILE, false);
        }
        this.settingsConfig = YamlConfiguration.loadConfiguration((File)this.settingsFile);
    }

    public String getMessage(String path) {
        String prefix = this.languageConfig.getString("prefix", "&8[&6Masks&8] &r");
        String message = this.languageConfig.getString(path, "&cMessage not found: " + path);
        return prefix + message;
    }

    public String getMessage(String path, Map<String, String> placeholders) {
        String message = this.getMessage(path);
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            message = message.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return message;
    }

    public String getRawMessage(String path) {
        return this.languageConfig.getString(path, "");
    }

    public List<String> getMaskIds() {
        return this.settingsConfig.getConfigurationSection("masks") != null ? this.settingsConfig.getConfigurationSection("masks").getKeys(false).stream().toList() : List.of();
    }

    public boolean showMaskInLore() {
        return this.settingsConfig.getBoolean("settings.show_mask_in_lore", true);
    }

    public boolean showParticles() {
        return this.settingsConfig.getBoolean("settings.show_particles", true);
    }

    public boolean playSounds() {
        return this.settingsConfig.getBoolean("settings.play_sounds", true);
    }

    public String getMaskLorePrefix() {
        return this.languageConfig.getString("mask_lore_prefix", "&8[&7Mask&8] ");
    }

    public String getMaskLoreFormat() {
        return this.languageConfig.getString("mask_lore_format", "{prefix}{mask_name}");
    }

    public List<String> getMenuMaskIds() {
        return this.settingsConfig.getStringList("menu.mask_ids");
    }

    public int getMenuSize() {
        int size = this.settingsConfig.getInt("menu.size", -1);
        if (size >= 9 && size % 9 == 0) {
            return Math.min(size, 54);
        }
        return 0;
    }

    public String getMenuTitle() {
        String title = this.settingsConfig.getString("menu.title", null);
        if (title != null) {
            return title;
        }
        return this.languageConfig.getString("menu_title", "Masks");
    }

    public int getMenuSlot(String maskId) {
        return this.settingsConfig.getInt("menu.slots." + maskId.toLowerCase(), -1);
    }

    public boolean isMaskEnabledInMenu(String maskId) {
        ConfigurationSection section = this.settingsConfig.getConfigurationSection("menu.masks");
        if (section == null) {
            return true;
        }
        return section.getBoolean(maskId, true);
    }

    public Map<String, Object> getMaskConfig(String maskId) {
        HashMap<String, Object> config = new HashMap<String, Object>();
        String base = "masks." + maskId;
        config.put("name", this.settingsConfig.getString(base + ".name", maskId));
        config.put("skin", this.settingsConfig.getString(base + ".skin", ""));
        config.put("lore", this.settingsConfig.getStringList(base + ".lore"));
        config.put("no_hunger", this.settingsConfig.getBoolean(base + ".abilities.no_hunger", false));
        config.put("damage_boost", this.settingsConfig.getDouble(base + ".abilities.damage_boost", 0.0));
        config.put("money_per_interval", this.settingsConfig.getDouble(base + ".abilities.money_per_interval", 0.0));
        config.put("interval_minutes", this.settingsConfig.getInt(base + ".abilities.interval_minutes", 15));
        config.put("fly", this.settingsConfig.getBoolean(base + ".abilities.fly", false));
        config.put("speed", this.settingsConfig.getBoolean(base + ".abilities.speed", false));
        config.put("coal", this.settingsConfig.getBoolean(base + ".abilities.coal", false));
        config.put("damage", this.settingsConfig.getBoolean(base + ".abilities.damage", false));
        config.put("jump", this.settingsConfig.getBoolean(base + ".abilities.jump", false));
        config.put("eco", this.settingsConfig.getBoolean(base + ".abilities.eco", false));
        config.put("sell_bonus", this.settingsConfig.getDouble(base + ".abilities.sell_bonus", 1.0));
        config.put("haste", this.settingsConfig.getInt(base + ".abilities.haste", 0));
        config.put("crouch_haste", this.settingsConfig.getInt(base + ".abilities.crouch_haste", 0));
        return config;
    }
}
