/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Skeleton
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityPotionEffectEvent
 *  org.bukkit.event.entity.FoodLevelChangeEvent
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.potion.PotionEffectType
 */
package org.axial.prisonsCore.masks.listener;

import org.axial.prisonsCore.masks.MaskModule;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffectType;

public class MaskAbilityListener
implements Listener {
    private final MaskModule module;

    public MaskAbilityListener(MaskModule module) {
        this.module = module;
    }

    @EventHandler
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        HumanEntity humanEntity = event.getEntity();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        this.module.getMaskManager().updatePlayerMaskEffects(player);
        if (this.module.getMaskManager().hasNoHunger(player.getUniqueId()) && event.getFoodLevel() < player.getFoodLevel()) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        Entity damager = event.getDamager();
        if (damager instanceof Player) {
            Player player = (Player)damager;
            this.module.getMaskManager().updatePlayerMaskEffects(player);
            double damageBoost = this.module.getMaskManager().getDamageBoost(player);
            double skeletonBoost = event.getEntity() instanceof Skeleton ? this.module.getMaskManager().getSkeletonDamageBoost(player) : 0.0;
            double totalBoost = damageBoost + skeletonBoost;
            if (totalBoost > 0.0) {
                double originalDamage = event.getDamage();
                double boostedDamage = originalDamage * (1.0 + totalBoost / 100.0);
                event.setDamage(boostedDamage);
            }
        }
    }

    @EventHandler
    public void onPlayerDamaged(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        this.module.getServer().getScheduler().runTaskLater((Plugin)this.module.getPlugin(), () -> this.module.getMaskVisualManager().updateHelmetVisual(player), 1L);
    }

    @EventHandler
    public void onPotionEffect(EntityPotionEffectEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player)) {
            return;
        }
        Player player = (Player)entity;
        if (event.getNewEffect() == null) {
            return;
        }
        if (event.getNewEffect().getType() != PotionEffectType.POISON) {
            return;
        }
        this.module.getMaskManager().updatePlayerMaskEffects(player);
        if (this.module.getMaskManager().hasPoisonImmunity(player.getUniqueId())) {
            event.setCancelled(true);
            player.removePotionEffect(PotionEffectType.POISON);
        }
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        HumanEntity humanEntity = event.getWhoClicked();
        if (!(humanEntity instanceof Player)) {
            return;
        }
        Player player = (Player)humanEntity;
        this.module.getServer().getScheduler().runTaskLater((Plugin)this.module.getPlugin(), () -> this.module.getMaskManager().updatePlayerMaskEffects(player), 1L);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.module.getMaskManager().removePlayerEffects(event.getPlayer().getUniqueId());
    }
}

