/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.masks.command;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.masks.menu.MaskMenu;
import org.axial.prisonsCore.masks.model.Mask;
import org.axial.prisonsCore.masks.util.SkullUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class MasksCommand
implements CommandExecutor, TabCompleter {
    private final MaskModule module;

    public MasksCommand(MaskModule module) {
        this.module = module;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(this.module.getConfigManager().getMessage("player_only"));
                return true;
            }
            new MaskMenu(this.module).open((Player)sender);
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "give": {
                this.handleGive(sender, args);
                break;
            }
            case "list": {
                this.handleList(sender);
                break;
            }
            case "reload": {
                this.handleReload(sender);
                break;
            }
            default: {
                this.sendHelp(sender);
            }
        }
        return true;
    }

    private void handleGive(CommandSender sender, String[] args) {
        if (!sender.hasPermission("masks.admin")) {
            sender.sendMessage(this.module.getConfigManager().getMessage("no_permission"));
            return;
        }
        if (args.length < 3) {
            sender.sendMessage("\u00a7cUsage: /masks give <player> <mask>");
            return;
        }
        Player target = Bukkit.getPlayer((String)args[1]);
        if (target == null) {
            sender.sendMessage(this.module.getConfigManager().getMessage("player_not_found"));
            return;
        }
        Mask mask = this.module.getMaskManager().getMask(args[2]);
        if (mask == null) {
            sender.sendMessage(this.module.getConfigManager().getMessage("invalid_mask"));
            return;
        }
        ItemStack maskItem = mask.createItem();
        if (target.getInventory().firstEmpty() == -1) {
            target.getWorld().dropItemNaturally(target.getLocation(), maskItem);
        } else {
            target.getInventory().addItem(new ItemStack[]{maskItem});
        }
        Map<String, String> placeholders = Map.of("player", target.getName(), "mask", SkullUtil.colorize(mask.getName()));
        sender.sendMessage(this.module.getConfigManager().getMessage("mask_given", placeholders));
        target.sendMessage(this.module.getConfigManager().getMessage("mask_received", Map.of("mask", SkullUtil.colorize(mask.getName()))));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ENGLISH);
            ArrayList<String> options = new ArrayList<String>();
            options.add("give");
            options.add("list");
            options.add("reload");
            return options.stream().filter(opt -> opt.toLowerCase(Locale.ENGLISH).startsWith(prefix)).collect(Collectors.toList());
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            String prefix = args[1].toLowerCase(Locale.ENGLISH);
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(name -> name.toLowerCase(Locale.ENGLISH).startsWith(prefix)).collect(Collectors.toList());
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            String prefix = args[2].toLowerCase(Locale.ENGLISH);
            return this.module.getMaskManager().getAllMasks().stream().map(Mask::getId).filter(id -> id.toLowerCase(Locale.ENGLISH).startsWith(prefix)).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

    private void handleList(CommandSender sender) {
        if (!sender.hasPermission("masks.admin")) {
            sender.sendMessage(this.module.getConfigManager().getMessage("no_permission"));
            return;
        }
        sender.sendMessage(this.module.getConfigManager().getRawMessage("list_header"));
        for (Mask mask : this.module.getMaskManager().getAllMasks()) {
            String format = this.module.getConfigManager().getRawMessage("list_format").replace("{mask_name}", SkullUtil.colorize(mask.getName())).replace("{mask_id}", mask.getId());
            sender.sendMessage(format);
        }
    }

    private void handleReload(CommandSender sender) {
        if (!sender.hasPermission("masks.admin")) {
            sender.sendMessage(this.module.getConfigManager().getMessage("no_permission"));
            return;
        }
        this.module.reload();
        sender.sendMessage(this.module.getConfigManager().getMessage("plugin_reloaded"));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(this.module.getConfigManager().getRawMessage("help_header"));
        sender.sendMessage(this.module.getConfigManager().getRawMessage("help_give"));
        sender.sendMessage(this.module.getConfigManager().getRawMessage("help_list"));
        sender.sendMessage(this.module.getConfigManager().getRawMessage("help_reload"));
    }
}
