/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.masks.model;

import java.util.List;
import org.axial.prisonsCore.masks.model.MaskAbilities;
import org.axial.prisonsCore.masks.model.MaskItem;
import org.bukkit.inventory.ItemStack;

public class Mask {
    private final String id;
    private final String name;
    private final String skin;
    private final List<String> lore;
    private final MaskAbilities abilities;

    public Mask(String id, String name, String skin, List<String> lore, MaskAbilities abilities) {
        this.id = id;
        this.name = name;
        this.skin = skin;
        this.lore = lore;
        this.abilities = abilities;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public String getSkin() {
        return this.skin;
    }

    public List<String> lore() {
        return this.lore;
    }

    public MaskAbilities getAbilities() {
        return this.abilities;
    }

    public ItemStack createItem() {
        return MaskItem.createMaskItem(this);
    }
}

