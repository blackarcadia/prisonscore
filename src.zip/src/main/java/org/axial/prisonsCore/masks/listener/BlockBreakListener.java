/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.masks.listener;

import java.util.HashMap;
import java.util.Map;
import org.axial.prisonsCore.masks.MaskModule;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public class BlockBreakListener
implements Listener {
    private final MaskModule module;
    private final Map<Material, Material> oreToDropMap;

    public BlockBreakListener(MaskModule module) {
        this.module = module;
        this.oreToDropMap = new HashMap<Material, Material>();
        this.oreToDropMap.put(Material.COAL_ORE, Material.COAL);
        this.oreToDropMap.put(Material.DEEPSLATE_COAL_ORE, Material.COAL);
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (block.getType() == Material.COAL_ORE || block.getType() == Material.DEEPSLATE_COAL_ORE) {
            ItemStack tool = player.getInventory().getItemInMainHand();
            this.module.getMaskManager().updatePlayerMaskEffects(player);
            if (this.module.getMaskManager().hasCoalAbility(player.getUniqueId()) && !this.hasSilkTouch(tool)) {
                event.setDropItems(false);
                int baseAmount = 1;
                int fortuneLevel = this.getFortuneLevel(tool);
                int dropAmount = this.calculateFortuneDrops(baseAmount, fortuneLevel);
                int totalAmount = dropAmount + 2;
                block.getWorld().dropItemNaturally(block.getLocation(), new ItemStack(Material.COAL, totalAmount));
                int xp = 0;
                xp = (int)(Math.random() * 3.0) + 1;
                if (xp > 0) {
                    player.giveExp(xp);
                }
            }
        }
    }

    private boolean hasSilkTouch(ItemStack tool) {
        return tool != null && tool.hasItemMeta() && tool.getItemMeta().getEnchants().containsKey(Enchantment.SILK_TOUCH);
    }

    private int getFortuneLevel(ItemStack tool) {
        return tool != null && tool.hasItemMeta() ? tool.getItemMeta().getEnchantLevel(Enchantment.FORTUNE) : 0;
    }

    private int calculateFortuneDrops(int baseAmount, int fortuneLevel) {
        if (fortuneLevel <= 0) {
            return baseAmount;
        }
        int multiplier = (int)(Math.random() * (double)(fortuneLevel + 1)) + 1;
        return baseAmount * multiplier;
    }
}

