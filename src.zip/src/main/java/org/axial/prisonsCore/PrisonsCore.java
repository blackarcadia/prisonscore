/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.NamespacedKey
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 */
package org.axial.prisonsCore;

import java.io.File;
import java.util.Random;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.cell.CellListener;
import org.axial.prisonsCore.cell.CellMenu;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.cell.CellSignChunkListener;
import org.axial.prisonsCore.cell.CellToolListener;
import org.axial.prisonsCore.cell.CellStartupListener;
import org.axial.prisonsCore.cell.guard.CellGuardListener;
import org.axial.prisonsCore.cell.guard.CellGuardChunkListener;
import org.axial.prisonsCore.cell.guard.CellGuardService;
import org.axial.prisonsCore.command.ApplyOreCommand;
import org.axial.prisonsCore.command.BalTopCommand;
import org.axial.prisonsCore.command.BalanceCommand;
import org.axial.prisonsCore.command.BossCommand;
import org.axial.prisonsCore.command.BankNoteCommand;
import org.axial.prisonsCore.command.AlienSupplyCrateCommand;
import org.axial.prisonsCore.command.AlienKeyCommand;
import org.axial.prisonsCore.command.WithdrawCommand;
import org.axial.prisonsCore.command.CellCommand;
import org.axial.prisonsCore.command.ChargeOrbCommand;
import org.axial.prisonsCore.command.ContrabandCommand;
import org.axial.prisonsCore.command.CustomBlockCommand;
import org.axial.prisonsCore.command.EconomyAdminCommand;
import org.axial.prisonsCore.command.EnchantDustCommand;
import org.axial.prisonsCore.command.EnchantGiveCommand;
import org.axial.prisonsCore.command.EnchantsCommand;
import org.axial.prisonsCore.command.EnchanterCommand;
import org.axial.prisonsCore.command.EnergyBoosterCommand;
import org.axial.prisonsCore.command.EnergyCommand;
import org.axial.prisonsCore.command.ExtractCommand;
import org.axial.prisonsCore.command.GangCommand;
import org.axial.prisonsCore.command.GangPointsCommand;
import org.axial.prisonsCore.command.GearCommand;
import org.axial.prisonsCore.command.GearEnchantGiveCommand;
import org.axial.prisonsCore.command.GlobalBoosterCommand;
import org.axial.prisonsCore.command.GlobalCommandTabCompleter;
import org.axial.prisonsCore.command.GeneratorCommand;
import org.axial.prisonsCore.command.GKitAdminCommand;
import org.axial.prisonsCore.command.GuardCommand;
import org.axial.prisonsCore.command.HubCommand;
import org.axial.prisonsCore.command.InvseeCommand;
import org.axial.prisonsCore.command.JetCommand;
import org.axial.prisonsCore.command.KitCommand;
import org.axial.prisonsCore.command.LevelCapCommand;
import org.axial.prisonsCore.command.LevelCommand;
import org.axial.prisonsCore.command.LevelsCommand;
import org.axial.prisonsCore.command.MeteorCommand;
import org.axial.prisonsCore.command.MeteorTimeCommand;
import org.axial.prisonsCore.command.MiningTotalExpCommand;
import org.axial.prisonsCore.command.HomeCommand;
import org.axial.prisonsCore.command.HomesCommand;
import org.axial.prisonsCore.command.InvasionCommand;
import org.axial.prisonsCore.command.MsgCommand;
import org.axial.prisonsCore.command.MsgToggleCommand;
import org.axial.prisonsCore.command.NearCommand;
import org.axial.prisonsCore.command.NickCommand;
import org.axial.prisonsCore.command.ReplyCommand;
import org.axial.prisonsCore.command.OreOnlyWorldCommand;
import org.axial.prisonsCore.command.PayCommand;
import org.axial.prisonsCore.command.PowerboxCommand;
import org.axial.prisonsCore.command.PickaxeCommand;
import org.axial.prisonsCore.command.PickaxePrestigeCommand;
import org.axial.prisonsCore.command.ProtectionScrollCommand;
import org.axial.prisonsCore.command.DestructionScrollCommand;
import org.axial.prisonsCore.command.PrisonCoinAdminCommand;
import org.axial.prisonsCore.command.PrisonRiotCommand;
import org.axial.prisonsCore.command.PlayerVaultCommand;
import org.axial.prisonsCore.command.PrestigeCommand;
import org.axial.prisonsCore.command.PrestigeTokenCommand;
import org.axial.prisonsCore.command.PrisonsCoreCommand;
import org.axial.prisonsCore.command.PrisonsReloadCommand;
import org.axial.prisonsCore.command.RaidShopCommand;
import org.axial.prisonsCore.command.RankTokenCommand;
import org.axial.prisonsCore.command.StashCommand;
import org.axial.prisonsCore.command.RefinedCommand;
import org.axial.prisonsCore.command.RenameScrollCommand;
import org.axial.prisonsCore.command.ReputationCommand;
import org.axial.prisonsCore.command.ResetKitCooldownCommand;
import org.axial.prisonsCore.command.SafezoneCommand;
import org.axial.prisonsCore.command.SatchelCommand;
import org.axial.prisonsCore.command.SellCommand;
import org.axial.prisonsCore.command.SetPlayerLevelCommand;
import org.axial.prisonsCore.command.SetItemLevelCommand;
import org.axial.prisonsCore.command.SetPlayerPrestigeCommand;
import org.axial.prisonsCore.command.SetSpawnCommand;
import org.axial.prisonsCore.command.SetHomeCommand;
import org.axial.prisonsCore.command.SetWarpCommand;
import org.axial.prisonsCore.command.ShardCommand;
import org.axial.prisonsCore.command.ShopCommand;
import org.axial.prisonsCore.command.StoreCommand;
import org.axial.prisonsCore.command.SpawnCommand;
import org.axial.prisonsCore.command.TpAcceptCommand;
import org.axial.prisonsCore.command.TpDenyCommand;
import org.axial.prisonsCore.command.TpToggleCommand;
import org.axial.prisonsCore.command.TpaCommand;
import org.axial.prisonsCore.command.TinkererCommand;
import org.axial.prisonsCore.command.ToggleCommand;
import org.axial.prisonsCore.command.TutorialCommand;
import org.axial.prisonsCore.command.TutorialSetSpawnCommand;
import org.axial.prisonsCore.command.UtilityCommand;
import org.axial.prisonsCore.command.VanishCommand;
import org.axial.prisonsCore.command.WarpCommand;
import org.axial.prisonsCore.command.WormholeCommand;
import org.axial.prisonsCore.command.WorthCommand;
import org.axial.prisonsCore.command.XpBoosterCommand;
import org.axial.prisonsCore.service.GangPointService;
import org.axial.prisonsCore.config.EnergyBarConfig;
import org.axial.prisonsCore.config.LevelConfig;
import org.axial.prisonsCore.config.PlayerLevelConfig;
import org.axial.prisonsCore.grappling.GrapplingHookCommand;
import org.axial.prisonsCore.grappling.GrapplingHookModule;
import org.axial.prisonsCore.grappling.GrapplingListener;
import org.axial.prisonsCore.util.ConfigUpdater;
import org.axial.prisonsCore.gui.EnchanterMenu;
import org.axial.prisonsCore.gui.EnchantsMenu;
import org.axial.prisonsCore.gui.AdminEnchantMenu;
import org.axial.prisonsCore.gui.ContrabandMenu;
import org.axial.prisonsCore.gui.KitMenu;
import org.axial.prisonsCore.gui.LevelsMenu;
import org.axial.prisonsCore.gui.LevelCapMenu;
import org.axial.prisonsCore.gui.PrestigeMenu;
import org.axial.prisonsCore.gui.PickaxePrestigeMenu;
import org.axial.prisonsCore.gui.PlayerVaultMenu;
import org.axial.prisonsCore.gui.PowerboxMenu;
import org.axial.prisonsCore.gui.AlienSupplyCrateMenu;
import org.axial.prisonsCore.gui.PrisonRiotMenu;
import org.axial.prisonsCore.gui.RaidShopMenu;
import org.axial.prisonsCore.gui.LockboxMenu;
import org.axial.prisonsCore.gui.ShardMenu;
import org.axial.prisonsCore.gui.ShopMenu;
import org.axial.prisonsCore.gui.StoreMenu;
import org.axial.prisonsCore.gui.TinkererMenu;
import org.axial.prisonsCore.service.CustomBlockBuffService;
import org.axial.prisonsCore.gui.StashMenu;
import org.axial.prisonsCore.gui.ToggleMenu;
import org.axial.prisonsCore.gui.WarpMenu;
import org.axial.prisonsCore.listener.BlockProgressListener;
import org.axial.prisonsCore.listener.BankNoteListener;
import org.axial.prisonsCore.listener.BoosterListener;
import org.axial.prisonsCore.listener.ChargeOrbListener;
import org.axial.prisonsCore.listener.ChargePowderListener;
import org.axial.prisonsCore.listener.ChatFormatListener;
import org.axial.prisonsCore.listener.CombatLogListener;
import org.axial.prisonsCore.listener.ConnectionMessageListener;
import org.axial.prisonsCore.listener.ContrabandListener;
import org.axial.prisonsCore.listener.DangleListener;
import org.axial.prisonsCore.listener.DeathAnimationListener;
import org.axial.prisonsCore.listener.DupeTrackingListener;
import org.axial.prisonsCore.listener.EnchantOrbListener;
import org.axial.prisonsCore.listener.EnergyApplyListener;
import org.axial.prisonsCore.listener.EnergyExtractorListener;
import org.axial.prisonsCore.listener.FallDamageListener;
import org.axial.prisonsCore.listener.FlareListener;
import org.axial.prisonsCore.listener.GearBreakListener;
import org.axial.prisonsCore.listener.GangChatListener;
import org.axial.prisonsCore.listener.GangInviteListener;
import org.axial.prisonsCore.listener.GangPointRedeemListener;
import org.axial.prisonsCore.listener.GearEnchantListener;
import org.axial.prisonsCore.listener.GearEnchantOrbListener;
import org.axial.prisonsCore.listener.GearLevelListener;
import org.axial.prisonsCore.listener.GKitTokenListener;
import org.axial.prisonsCore.listener.GuardListener;
import org.axial.prisonsCore.listener.GuardStartupListener;
import org.axial.prisonsCore.listener.GuardSpawnerListener;
import org.axial.prisonsCore.listener.HologramStartupListener;
import org.axial.prisonsCore.listener.ItemShowcaseChatListener;
import org.axial.prisonsCore.listener.JetListener;
import org.axial.prisonsCore.listener.LockboxTaskListener;
import org.axial.prisonsCore.listener.MiningDigPacketListener;
import org.axial.prisonsCore.listener.MiningLevelScoreboardListener;
import org.axial.prisonsCore.listener.MiningListener;
import org.axial.prisonsCore.listener.NoNaturalMobSpawnsListener;
import org.axial.prisonsCore.listener.PickaxeBuffListener;
import org.axial.prisonsCore.listener.PVPListener;
import org.axial.prisonsCore.listener.PowerboxListener;
import org.axial.prisonsCore.listener.AlienSupplyCrateListener;
import org.axial.prisonsCore.listener.PrivateMessageListener;
import org.axial.prisonsCore.listener.PrisonCoinTokenListener;
import org.axial.prisonsCore.listener.RaidPointListener;
import org.axial.prisonsCore.listener.RankTokenListener;
import org.axial.prisonsCore.listener.RenameScrollListener;
import org.axial.prisonsCore.listener.ReputationListener;
import org.axial.prisonsCore.listener.ScrollListener;
import org.axial.prisonsCore.listener.SatchelListener;
import org.axial.prisonsCore.listener.SafezoneListener;
import org.axial.prisonsCore.listener.ShardListener;
import org.axial.prisonsCore.listener.StopCommandListener;
import org.axial.prisonsCore.listener.TeleportListener;
import org.axial.prisonsCore.listener.TightDropListener;
import org.axial.prisonsCore.listener.ToolLevelListener;
import org.axial.prisonsCore.listener.TutorialListener;
import org.axial.prisonsCore.listener.WormholeEnchanter;
import org.axial.prisonsCore.listener.WormholeStartupListener;
import org.axial.prisonsCore.masks.MaskModule;
import org.axial.prisonsCore.placeholder.PrisonsPlaceholderExpansion;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.axial.prisonsCore.service.BlockProgressService;
import org.axial.prisonsCore.service.BankNoteService;
import org.axial.prisonsCore.service.AxialModVerificationService;
import org.axial.prisonsCore.hologram.HologramService;
import org.axial.prisonsCore.hologram.command.HologramCommand;
import org.axial.prisonsCore.service.BoosterService;
import org.axial.prisonsCore.service.CellBusterManager;
import org.axial.prisonsCore.service.ChargeOrbService;
import org.axial.prisonsCore.service.CombatLogManager;
import org.axial.prisonsCore.service.ContrabandService;
import org.axial.prisonsCore.service.CustomBlockService;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.service.DupeTrackingService;
import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.service.AlienInvasionService;
import org.axial.prisonsCore.service.AlienSupplyCrateService;
import org.axial.prisonsCore.service.EnchantDustService;
import org.axial.prisonsCore.service.EnchantOrbService;
import org.axial.prisonsCore.service.EnergyItemService;
import org.axial.prisonsCore.service.FeatureToggleService;
import org.axial.prisonsCore.service.GangService;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.HarbourerBossService;
import org.axial.prisonsCore.service.GeneratorService;
import org.axial.prisonsCore.service.GlobalBoosterService;
import org.axial.prisonsCore.service.GuardDisplayService;
import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.service.JetService;
import org.axial.prisonsCore.service.KitService;
import org.axial.prisonsCore.service.LevelDisplayService;
import org.axial.prisonsCore.service.LevelRequirementService;
import org.axial.prisonsCore.service.MeteorService;
import org.axial.prisonsCore.service.LockboxService;
import org.axial.prisonsCore.service.MiningLevelScoreboardService;
import org.axial.prisonsCore.service.RankTokenService;
import org.axial.prisonsCore.service.OreOnlyWorldService;
import org.axial.prisonsCore.service.OreRegenService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.PrisonCoinService;
import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.service.PrivateMessageService;
import org.axial.prisonsCore.service.PlayerToggleService;
import org.axial.prisonsCore.service.PlayerTabService;
import org.axial.prisonsCore.service.PlayerVaultService;
import org.axial.prisonsCore.service.RaidPointService;
import org.axial.prisonsCore.service.PrisonRiotService;
import org.axial.prisonsCore.service.PowerboxService;
import org.axial.prisonsCore.service.RenameScrollService;
import org.axial.prisonsCore.service.ProtectionScrollService;
import org.axial.prisonsCore.service.DestructionScrollService;
import org.axial.prisonsCore.service.ReputationService;
import org.axial.prisonsCore.service.SafezoneService;
import org.axial.prisonsCore.service.SatchelManager;
import org.axial.prisonsCore.service.ItemAnimationService;
import org.axial.prisonsCore.service.StashService;
import org.axial.prisonsCore.service.SlownessEffectService;
import org.axial.prisonsCore.service.ShardService;
import org.axial.prisonsCore.service.SeasonService;
import org.axial.prisonsCore.service.TeleportService;
import org.axial.prisonsCore.service.TutorialService;
import org.axial.prisonsCore.service.VanishService;
import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.event.PacketListenerCommon;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.LanguageService;
import org.bukkit.Difficulty;
import org.bukkit.GameRule;
import org.bukkit.NamespacedKey;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.World;

public final class PrisonsCore
extends JavaPlugin {
    private static final String[] BUNDLED_CONFIGS = new String[]{"config.yml", "items.yml", "pickaxes.yml", "guards.yml", "gear-enchants.yml", "enchants.yml", "satchels.yml", "worth.yml", "teleport.yml", "jet.yml", "cells.yml", "contraband.yml", "economy.yml", "fragments.yml", "languages.yml", "shards.yml", "lang/jet.yml", "custom-blocks.yml", "scoreboard-default.yml", "scoreboard-pickaxe.yml", "axialskins.yml", "axialskins-languages.yml", "skins.yml", "prison-riot.yml", "prison-coins.yml"};
    private PickaxeManager pickaxeManager;
    private EnergyItemService energyItemService;
    private BankNoteService bankNoteService;
    private RaidPointService raidPointService;
    private CustomEnchantService customEnchantService;
    private EnchanterMenu enchanterMenu;
    private EnchantsMenu enchantsMenu;
    private AdminEnchantMenu adminEnchantMenu;
    private LevelConfig levelConfig;
    private PlayerDataService playerDataService;
    private PlayerToggleService playerToggleService;
    private PrivateMessageService privateMessageService;
    private PlayerVaultService playerVaultService;
    private PlayerTabService playerTabService;
    private PlayerLevelService playerLevelService;
    private PlayerLevelConfig playerLevelConfig;
    private OreOnlyWorldService oreOnlyWorldService;
    private OreRegenService oreRegenService;
    private LevelRequirementService levelRequirementService;
    private EnchantOrbService enchantOrbService;
    private BlockProgressService blockProgressService;
    private MiningDigPacketListener miningDigPacketListener;
    private GuardService guardService;
    private HarbourerBossService harbourerBossService;
    private AlienInvasionService alienInvasionService;
    private ChargeOrbService chargeOrbService;
    private EnchantDustService enchantDustService;
    private GearManager gearManager;
    private GearEnchantService gearEnchantService;
    private GearEnchantListener gearEnchantListener;
    private PickaxePrestigeMenu pickaxePrestigeMenu;
    private PrestigeMenu prestigeMenu;
    private RenameScrollService renameScrollService;
    private ProtectionScrollService protectionScrollService;
    private DestructionScrollService destructionScrollService;
    private ReputationService reputationService;
    private SafezoneService safezoneService;
    private GangService gangService;
    private SatchelManager satchelManager;
    private EconomyService economyService;
    private PrisonCoinService prisonCoinService;
    private TeleportService teleportService;
    private JetService jetService;
    private ShardService shardService;
    private ContrabandService contrabandService;
    private KitService kitService;
    private RankTokenService rankTokenService;
    private MeteorService meteorService;
    private GeneratorService generatorService;
    private CustomBlockBuffService customBlockBuffService;
    private CustomBlockService customBlockService;
    private LockboxService lockboxService;
    private DupeTrackingService dupeTrackingService;
    private LevelDisplayService levelDisplayService;
    private MiningLevelScoreboardService miningLevelScoreboardService;
    private LevelsMenu levelsMenu;
    private ContrabandMenu contrabandMenu;
    private PowerboxService powerboxService;
    private PowerboxMenu powerboxMenu;
    private AlienSupplyCrateService alienSupplyCrateService;
    private AlienSupplyCrateMenu alienSupplyCrateMenu;
    private KitMenu kitMenu;
    private PlayerVaultMenu playerVaultMenu;
    private ShopMenu shopMenu;
    private StoreMenu storeMenu;
    private RaidShopMenu raidShopMenu;
    private PrisonRiotMenu prisonRiotMenu;
    private TinkererMenu tinkererMenu;
    private WarpMenu warpMenu;
    private FeatureToggleService featureToggleService;
    private BoosterService boosterService;
    private GlobalBoosterService globalBoosterService;
    private PrisonRiotService prisonRiotService;
    private LevelCapMenu levelCapMenu;
    private GuardDisplayService guardDisplayService;
    private CellService cellService;
    private CellMenu cellMenu;
    private CellGuardService cellGuardService;
    private CellBusterManager cellBusterManager;
    private WormholeEnchanter wormholeEnchanter;
    private WormholeEnchanter tutorialWormholeEnchanter;
    private GangPointService gangPointService;
    private Random random;
    private LanguageService languageService;
    private YamlConfiguration pickaxeConfig;
    private YamlConfiguration enchantsConfig;
    private YamlConfiguration gearEnchantsConfig;
    private YamlConfiguration guardsConfig;
    private YamlConfiguration itemsConfig;
    private MaskModule maskModule;
    private AxialSkinsModule axialSkinsModule;
    private GrapplingHookModule grapplingHookModule;
    private CombatLogManager combatLogManager;
    private TutorialService tutorialService;
    private HologramService hologramService;
    private SeasonService seasonService;
    private VanishService vanishService;
    private SlownessEffectService slownessEffectService;
    private ItemAnimationService itemAnimationService;
    private StashService stashService;
    private StashMenu stashMenu;
    private ToggleMenu toggleMenu;
    private AxialModVerificationService axialModVerificationService;

    public SeasonService getSeasonService() {
        return seasonService;
    }

    public LevelCapMenu getLevelCapMenu() {
        return levelCapMenu;
    }

    public PlayerLevelService getPlayerLevelService() {
        return this.playerLevelService;
    }

    public PlayerToggleService getPlayerToggleService() {
        return this.playerToggleService;
    }

    public EconomyService getEconomyService() {
        return this.economyService;
    }

    public PrisonCoinService getPrisonCoinService() {
        return this.prisonCoinService;
    }

    public MaskModule getMaskModule() {
        return this.maskModule;
    }

    public GlobalBoosterService getGlobalBoosterService() {
        return this.globalBoosterService;
    }

    public BoosterService getBoosterService() {
        return this.boosterService;
    }

    public MeteorService getMeteorService() {
        return this.meteorService;
    }

    public ItemAnimationService getItemAnimationService() {
        return this.itemAnimationService;
    }

    public StashService getStashService() {
        return this.stashService;
    }

    public VanishService getVanishService() {
        return this.vanishService;
    }

    public PickaxeManager getPickaxeManager() {
        return this.pickaxeManager;
    }

    public EnergyItemService getEnergyItemService() {
        return this.energyItemService;
    }

    public BankNoteService getBankNoteService() {
        return this.bankNoteService;
    }

    public RankTokenService getRankTokenService() {
        return this.rankTokenService;
    }

    public RaidPointService getRaidPointService() {
        return this.raidPointService;
    }

    public PrisonRiotService getPrisonRiotService() {
        return this.prisonRiotService;
    }

    public MiningLevelScoreboardService getMiningLevelScoreboardService() {
        return this.miningLevelScoreboardService;
    }

    public AlienInvasionService getAlienInvasionService() {
        return this.alienInvasionService;
    }

    public ChargeOrbService getChargeOrbService() {
        return this.chargeOrbService;
    }

    public RenameScrollService getRenameScrollService() {
        return this.renameScrollService;
    }

    public ProtectionScrollService getProtectionScrollService() {
        return this.protectionScrollService;
    }

    public DestructionScrollService getDestructionScrollService() {
        return this.destructionScrollService;
    }

    public AxialSkinsModule getAxialSkinsModule() {
        return this.axialSkinsModule;
    }

    public void onEnable() {
        this.saveDefaultConfig();
        this.refreshBundledConfigs();
        this.reloadConfig();
        this.loadServices();
        this.maskModule = new MaskModule(this);
        this.maskModule.enable();
        this.axialSkinsModule.enable();
        this.registerCommands();
        this.registerGlobalTabCompletion();
        this.registerListeners();
        this.disableNaturalMobSpawning();
        if (this.playerTabService != null) {
            this.playerTabService.start();
        }
        if (this.vanishService != null) {
            this.vanishService.start();
        }
        if (this.slownessEffectService != null) {
            this.slownessEffectService.start();
        }
        if (this.alienInvasionService != null) {
            this.alienInvasionService.start();
        }
        if (this.prisonRiotService != null) {
            this.prisonRiotService.start();
        }
    }

    public void onDisable() {

        if (this.gangService != null) {
            this.gangService.save();
        }
        if (this.meteorService != null) {
            this.meteorService.despawnAll();
        }
        // Save cell snapshots while generator state is still loaded in memory.
        if (this.cellService != null) {
            this.cellService.saveData();
            this.cellService.saveDefinitions();
        }
        if (this.generatorService != null) {
            this.generatorService.shutdown();
        }
        if (this.oreRegenService != null) {
            this.oreRegenService.shutdown();
        }
        if (this.customBlockBuffService != null) {
            this.customBlockBuffService.shutdown();
        }
        if (this.customBlockService != null) {
            this.customBlockService.shutdown();
        }
        if (this.lockboxService != null) {
            this.lockboxService.shutdown();
        }
        if (this.guardService != null) {
            this.guardService.shutdown();
        }
        if (this.harbourerBossService != null) {
            this.harbourerBossService.shutdown();
        }
        if (this.alienInvasionService != null) {
            this.alienInvasionService.shutdown();
        }
        if (this.miningLevelScoreboardService != null) {
            this.miningLevelScoreboardService.stop();
        }
        if (this.axialModVerificationService != null) {
            this.axialModVerificationService.stop();
        }
        if (this.boosterService != null) {
            this.boosterService.stop();
        }
        if (this.globalBoosterService != null) {
            this.globalBoosterService.stop();
        }
        if (this.prisonRiotService != null) {
            this.prisonRiotService.stop();
        }
        if (this.stashService != null) {
            this.stashService.stop();
        }
        if (this.playerDataService != null) {
            this.playerDataService.save();
        }
        if (this.playerVaultMenu != null) {
            this.playerVaultMenu.saveOpenVaults();
        }
        if (this.playerVaultService != null) {
            this.playerVaultService.save();
        }
        if (this.playerTabService != null) {
            this.playerTabService.stop();
        }
        if (this.vanishService != null) {
            this.vanishService.stop();
        }
        if (this.slownessEffectService != null) {
            this.slownessEffectService.stop();
        }
        if (this.miningDigPacketListener != null && PacketEvents.getAPI() != null) {
            PacketEvents.getAPI().getEventManager().unregisterListener((PacketListenerCommon)this.miningDigPacketListener);
            this.miningDigPacketListener = null;
        }
        if (this.gearEnchantListener != null) {
            this.gearEnchantListener.stop();
        }
        if (this.axialSkinsModule != null) {
            this.axialSkinsModule.disable();
        }
        if (this.tutorialService != null) {
            this.tutorialService.save();
            this.tutorialService.shutdown();
        }
        if (this.wormholeEnchanter != null) {
            this.wormholeEnchanter.shutdown();
        }
        if (this.tutorialWormholeEnchanter != null) {
            this.tutorialWormholeEnchanter.shutdown();
        }
        if (this.economyService != null) {
            this.economyService.saveBalances();
        }

        // =========================
        // 🔥 THEN SAVE CELL GUARDS (CRITICAL ORDER FIX)
        // =========================
        if (this.cellGuardService != null) {
            this.cellGuardService.shutdown();
        }

        if (this.maskModule != null) {
            this.maskModule.disable();
        }
        if (this.combatLogManager != null) {
            this.combatLogManager.shutdown();
        }
        if (this.dupeTrackingService != null) {
            this.dupeTrackingService.stop();
        }
        if (this.safezoneService != null) {
            this.safezoneService.save();
        }
        if (this.hologramService != null) {
            this.hologramService.save();
        }
        if (this.seasonService != null) {
            this.seasonService.save();
        }
        if (this.teleportService != null) {
            this.teleportService.save();
        }
    }

    public void reloadAllConfigs() {
        this.refreshBundledConfigs();
        this.reloadConfig();
        this.languageService = new LanguageService((Plugin)this);
        Lang.init(this.languageService);
        if (this.playerDataService != null) {
            this.playerDataService.load();
        }
        this.itemsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "items.yml"));
        this.pickaxeConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "pickaxes.yml"));
        this.guardsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "guards.yml"));
        this.enchantsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "enchants.yml"));
        this.gearEnchantsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "gear-enchants.yml"));
        this.pickaxeManager.reloadTypes();
        this.pickaxeManager.setCustomEnchantService(this.customEnchantService);
        this.customEnchantService.reload();
        this.enchantDustService.reload(this);
        this.gearEnchantService.reload();
        this.energyItemService.reload();
        if (this.bankNoteService != null) {
            this.bankNoteService.reload();
        }
        if (this.raidPointService != null) {
            this.raidPointService.reload();
        }
        if (this.prisonCoinService != null) {
            this.prisonCoinService.reload();
        }
        this.renameScrollService.reload();
        if (this.protectionScrollService != null) {
            this.protectionScrollService.reload();
        }
        if (this.destructionScrollService != null) {
            this.destructionScrollService.reload();
        }
        if (this.customBlockService != null) {
            this.customBlockService.reload();
        }
        if (this.lockboxService != null) {
            this.lockboxService.refreshMenu(null);
        }
        if (this.economyService != null) {
            this.economyService.reload();
        }
        this.satchelManager.reload();
        if (this.storeMenu != null) {
            this.storeMenu.reload();
        }
        this.enchantOrbService.reload(this);
        this.guardService.reload();
        if (this.safezoneService != null) {
            this.safezoneService.reload();
        }
        if (this.alienInvasionService != null) {
            this.alienInvasionService.reload();
        }
        this.gangService.load();
        if (this.chargeOrbService != null) {
            this.chargeOrbService.reload();
        }
        if (this.shardService != null) {
            this.shardService.reload();
        }
        if (this.contrabandService != null) {
            this.contrabandService.reload();
        }
        if (this.axialSkinsModule != null) {
            this.axialSkinsModule.reload();
        }
        if (this.teleportService != null) {
            this.teleportService.load();
        }
        if (this.tutorialService != null) {
            this.tutorialService.load();
        }
        if (this.hologramService != null) {
            this.hologramService.despawnAll();
            this.hologramService = new HologramService(this);
            this.hologramService.spawnAll();
        }
        if (this.featureToggleService != null) {
            this.featureToggleService.reload();
        }
        if (this.globalBoosterService != null) {
            this.globalBoosterService.reload();
        }
        if (this.stashService != null) {
            this.stashService.reload();
        }
        if (this.meteorService != null) {
            this.meteorService.reload();
        }
        if (this.wormholeEnchanter != null) {
            this.wormholeEnchanter.reload();
        }
        if (this.tutorialWormholeEnchanter != null) {
            this.tutorialWormholeEnchanter.reload();
        }
        if (this.miningLevelScoreboardService != null) {
            this.miningLevelScoreboardService.reload();
        }
        if (this.maskModule != null) {
            this.maskModule.reload();
        }
        if (this.grapplingHookModule != null) {
            this.grapplingHookModule.reload();
        }
        if (this.oreOnlyWorldService != null) {
            this.oreOnlyWorldService.reload();
        }
    }

    private void disableNaturalMobSpawning() {
        for (World world : this.getServer().getWorlds()) {
            world.setDifficulty(Difficulty.HARD);
            world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        }
    }

    private void loadServices() {
        this.itemsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "items.yml"));
        this.pickaxeConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "pickaxes.yml"));
        this.guardsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "guards.yml"));
        this.enchantsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "enchants.yml"));
        this.gearEnchantsConfig = YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "gear-enchants.yml"));
        YamlConfiguration.loadConfiguration((File)new File(this.getDataFolder(), "satchels.yml"));
        EnergyBarConfig barConfig = new EnergyBarConfig(
                this.getConfig().getInt("energy.bar-length", 50),
                this.getConfig().getString("energy.filled-char", "|"),
                this.getConfig().getString("energy.empty-char", "|"),
                this.getConfig().getString("energy.filled-color", "&a"),
                this.getConfig().getString("energy.empty-color", "&c"),
                this.getConfig().getString("energy.format", "{bar}")
        );
        this.levelConfig = new LevelConfig(this.getConfig().getInt("pickaxe-level.start-level", 1), 40.0);
        this.playerLevelConfig = new PlayerLevelConfig(this.getConfig().getInt("player-level.max-level", 105), this.getConfig().getInt("player-level.prestige-start", 100), this.getConfig().getInt("player-level.base-exp", 100), this.getConfig().getDouble("player-level.multiplier", 1.2), PlayerLevelService.readOreExp(this.getConfig().getConfigurationSection("player-level.ore-exp")));
        this.featureToggleService = new FeatureToggleService(this);
        this.pickaxeManager = new PickaxeManager(this, barConfig, this.levelConfig.getStartLevel(), this.levelConfig.getPercentPerLevel());
        this.gearManager = new GearManager(this, barConfig);
        this.economyService = new EconomyService(this);
        this.economyService.setup();
        this.playerDataService = new PlayerDataService(this);
        this.playerToggleService = new PlayerToggleService(this.playerDataService);
        this.privateMessageService = new PrivateMessageService(this.playerDataService, this.playerToggleService);
        this.playerVaultService = new PlayerVaultService(this);
        this.energyItemService = new EnergyItemService(this);
        this.rankTokenService = new RankTokenService(this);
        this.bankNoteService = new BankNoteService(this, this.economyService);
        this.raidPointService = new RaidPointService(this, this.playerDataService);
        this.prisonCoinService = new PrisonCoinService(this, this.playerDataService);
        this.renameScrollService = new RenameScrollService(this);
        this.protectionScrollService = new ProtectionScrollService(this);
        this.destructionScrollService = new DestructionScrollService(this);
        this.satchelManager = new SatchelManager(this, barConfig);
        this.jetService = new JetService(this);
        this.customEnchantService = new CustomEnchantService(this);
        this.pickaxeManager.setCustomEnchantService(this.customEnchantService);
        this.enchantDustService = new EnchantDustService(this);
        this.gearEnchantService = new GearEnchantService(this);
        this.guardService = new GuardService(this);
        this.harbourerBossService = new HarbourerBossService(this);
        this.alienInvasionService = new AlienInvasionService(this);
        this.guardDisplayService = new GuardDisplayService(this, this.guardService);
        this.reputationService = new ReputationService(this, this.guardService);
        this.safezoneService = new SafezoneService(this);
        this.gangService = new GangService(this);
        this.gangPointService = new GangPointService(this);
        this.languageService = new LanguageService((Plugin)this);
        Lang.init(this.languageService);
        this.cellBusterManager = new CellBusterManager(this, barConfig, this.levelConfig.getStartLevel(), this.customEnchantService);
        this.enchanterMenu = new EnchanterMenu(this, this.pickaxeManager, this.customEnchantService, this.enchantDustService, this.gearManager, this.gearEnchantService, this.satchelManager, this.cellBusterManager);
        this.enchantsMenu = new EnchantsMenu(this.customEnchantService, this.gearEnchantService);
        this.adminEnchantMenu = new AdminEnchantMenu(this.customEnchantService, this.gearEnchantService, this.enchantOrbService);
        this.wormholeEnchanter = new WormholeEnchanter(this, this.pickaxeManager, this.customEnchantService, this.gearManager, this.gearEnchantService, this.satchelManager, this.cellBusterManager, this.enchantDustService, "wormhole.yml");
        this.tutorialWormholeEnchanter = new WormholeEnchanter(this, this.pickaxeManager, this.customEnchantService, this.gearManager, this.gearEnchantService, this.satchelManager, this.cellBusterManager, this.enchantDustService, "tutorialwormhole.yml", true);
        this.pickaxePrestigeMenu = new PickaxePrestigeMenu(this, this.pickaxeManager);
        this.tinkererMenu = new TinkererMenu(this, this.pickaxeManager, this.gearManager, this.chargeOrbService, this.energyItemService);
        this.playerLevelService = new PlayerLevelService(this, this.playerLevelConfig);
        this.teleportService = new TeleportService(this, this.playerLevelService);
        this.prisonRiotService = new PrisonRiotService(this, this.playerDataService, this.playerLevelService, this.pickaxeManager, this.gearManager, this.customEnchantService);
        this.prisonRiotMenu = new PrisonRiotMenu(this, this.prisonRiotService, this.playerDataService, this.contrabandService);
        this.prisonRiotService.setRiotMenu(this.prisonRiotMenu);
        this.oreOnlyWorldService = new OreOnlyWorldService(this);
        this.cellService = new CellService(this, this.economyService, this.playerLevelService, this.teleportService, this.cellBusterManager, null);
        this.cellGuardService = new CellGuardService(this, this.cellService);
        this.cellService.setCellGuardService(this.cellGuardService);
        this.gearEnchantListener = new GearEnchantListener(this, this.pickaxeManager, this.gearManager, this.gearEnchantService, this.bankNoteService, this.guardService, this.cellGuardService);
        this.cellMenu = new CellMenu(this, this.cellService, this.economyService);
        this.meteorService = new MeteorService(this, this.playerLevelService);
        this.generatorService = new GeneratorService(this, this.cellService, this.featureToggleService);
        this.cellService.setGeneratorService(this.generatorService);
        this.levelDisplayService = new LevelDisplayService(this, this.playerLevelService);
        this.miningLevelScoreboardService = new MiningLevelScoreboardService(this, this.playerLevelService, this.playerDataService, this.pickaxeManager, this.economyService, this.guardService, this.meteorService, this.alienInvasionService);
        this.levelsMenu = new LevelsMenu(this, this.playerLevelService);
        this.levelCapMenu = new LevelCapMenu(this);
        this.prestigeMenu = new PrestigeMenu(this.playerLevelService);
        this.shopMenu = new ShopMenu(this.economyService, this.pickaxeManager, this.gearManager, this.cellService, this.cellGuardService, this.generatorService, this.featureToggleService, this.satchelManager);
        this.warpMenu = new WarpMenu(this.teleportService, this.playerDataService);
        this.boosterService = new BoosterService(this, this.playerLevelService);
        this.axialModVerificationService = new AxialModVerificationService(this, this.boosterService);
        this.axialModVerificationService.start();
        this.globalBoosterService = new GlobalBoosterService(this);
        this.customBlockBuffService = new CustomBlockBuffService(this);
        this.playerTabService = new PlayerTabService(this, this.pickaxeManager, this.playerLevelService);
        this.vanishService = new VanishService(this);
        this.slownessEffectService = new SlownessEffectService(this, this.cellService, this.pickaxeManager);
        this.itemAnimationService = new ItemAnimationService(this);
        this.stashService = new StashService(this, this.playerToggleService);
        this.stashMenu = new StashMenu(this, this.stashService);
        this.toggleMenu = new ToggleMenu(this, this.playerToggleService);
        this.lockboxService = new LockboxService(this, this.meteorService, null);
        this.customBlockService = new CustomBlockService(this, this.energyItemService, this.economyService, this.boosterService, this.lockboxService);
        this.dupeTrackingService = new DupeTrackingService(this);
        this.oreRegenService = new OreRegenService(this, this.generatorService, this.meteorService);
        this.meteorService.setOreRegenService(this.oreRegenService);
        this.levelRequirementService = new LevelRequirementService(this.getConfig());
        this.enchantOrbService = new EnchantOrbService(this, this.customEnchantService);
        this.blockProgressService = new BlockProgressService((Plugin)this, this.getConfig().getLong("block-progress.hold-ticks", 100L));
        this.chargeOrbService = new ChargeOrbService(this);
        this.shardService = new ShardService(this, this.pickaxeManager, this.energyItemService, this.chargeOrbService);
        this.contrabandService = new ContrabandService(this, this.energyItemService, this.shardService, this.chargeOrbService, this.satchelManager, this.economyService, this.bankNoteService, this.cellGuardService);
        this.shardService.reload();
        this.storeMenu = new StoreMenu(this, this.prisonCoinService, this.contrabandService);
        this.raidShopMenu = new RaidShopMenu(this, this.raidPointService, this.energyItemService, this.contrabandService);
        this.playerLevelService.setContrabandService(this.contrabandService);
        this.playerLevelService.setShardService(this.shardService);
        this.kitService = new KitService(this, this.playerDataService, this.playerLevelService, this.energyItemService, this.shardService, this.gearManager, this.contrabandService);
        this.powerboxService = new PowerboxService(this, this.energyItemService, this.chargeOrbService, this.bankNoteService, this.boosterService, this.rankTokenService, this.meteorService, this.contrabandService, this.kitService);
        this.storeMenu.setPowerboxService(this.powerboxService);
        this.storeMenu.reload();
        this.powerboxMenu = new PowerboxMenu(this, this.powerboxService);
        this.alienSupplyCrateService = new AlienSupplyCrateService(this);
        this.alienSupplyCrateMenu = new AlienSupplyCrateMenu(this, this.alienSupplyCrateService);
        this.playerVaultMenu = new PlayerVaultMenu(this, this.playerVaultService);
        this.tutorialService = new TutorialService(this, this.teleportService, this.playerLevelService, this.boosterService, this.shardService, this.playerDataService, this.miningLevelScoreboardService);
        this.hologramService = new HologramService(this);
        this.seasonService = new SeasonService(this);
        this.hologramService.spawnAll();
        this.contrabandMenu = new ContrabandMenu(this, this.contrabandService);
        this.kitMenu = new KitMenu(this.kitService, this.playerLevelService);
        this.random = new Random();
        this.grapplingHookModule = new GrapplingHookModule(this, barConfig);
        this.grapplingHookModule.reload();
        this.axialSkinsModule = new AxialSkinsModule(this);
        this.combatLogManager = new CombatLogManager(this);
        if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PrisonsPlaceholderExpansion(this.playerLevelService, this.reputationService, this.gangService, this.meteorService, (Plugin)this).register();
            this.getLogger().info("PlaceholderAPI detected. Registered prisons placeholders.");
        }
    }

    private void registerCommands() {
        PickaxeCommand pickaxeCommand = new PickaxeCommand(this, this.pickaxeManager);
        this.getCommand("pickaxe").setExecutor((CommandExecutor)pickaxeCommand);
        this.getCommand("pickaxe").setTabCompleter((TabCompleter)pickaxeCommand);
        this.getCommand("extract").setExecutor((CommandExecutor)new ExtractCommand(this, this.pickaxeManager, this.energyItemService));
        this.getCommand("tinkerer").setExecutor((CommandExecutor)new TinkererCommand(this.tinkererMenu));
        this.getCommand("enchants").setExecutor((CommandExecutor)new EnchantsCommand(this.enchantsMenu, this.tutorialService, this.featureToggleService));
        this.getCommand("enchanter").setExecutor((CommandExecutor)new EnchanterCommand(this, this.pickaxeManager, this.enchanterMenu, this.featureToggleService));
        EnergyCommand energyCommand = new EnergyCommand(this, this.energyItemService);
        this.getCommand("energy").setExecutor((CommandExecutor)energyCommand);
        this.getCommand("energy").setTabCompleter((TabCompleter)energyCommand);
        this.getCommand("prestige").setExecutor((CommandExecutor)new PrestigeCommand(this.playerLevelService, this.prestigeMenu));
        this.getCommand("setplayerlevel").setExecutor((CommandExecutor)new SetPlayerLevelCommand(this, this.playerLevelService));
        this.getCommand("setplayerprestige").setExecutor((CommandExecutor)new SetPlayerPrestigeCommand(this.playerLevelService));
        this.getCommand("setitemlevel").setExecutor((CommandExecutor)new SetItemLevelCommand(this.pickaxeManager, this.gearManager));
        this.getCommand("miningtotalexp").setExecutor((CommandExecutor)new MiningTotalExpCommand(this.playerLevelService));
        this.getCommand("levelcap").setExecutor((CommandExecutor)new LevelCapCommand(this, this.playerLevelService));
        this.getCommand("levelcap").setTabCompleter((TabCompleter)new LevelCapCommand(this, this.playerLevelService));
        this.getCommand("level").setExecutor((CommandExecutor)new LevelCommand(this.playerLevelService));
        EnchantGiveCommand enchantGiveCommand = new EnchantGiveCommand(this, this.customEnchantService, this.enchantOrbService, this.adminEnchantMenu);
        this.getCommand("enchant").setExecutor((CommandExecutor)enchantGiveCommand);
        this.getCommand("enchant").setTabCompleter((TabCompleter)enchantGiveCommand);
        GearEnchantGiveCommand gearEnchantGiveCommand = new GearEnchantGiveCommand(this.gearEnchantService, this.adminEnchantMenu);
        this.getCommand("gearenchant").setExecutor((CommandExecutor)gearEnchantGiveCommand);
        this.getCommand("gearenchant").setTabCompleter((TabCompleter)gearEnchantGiveCommand);
        GuardCommand guardCommand = new GuardCommand(this.guardService);
        this.getCommand("guard").setExecutor((CommandExecutor)guardCommand);
        this.getCommand("guard").setTabCompleter((TabCompleter)guardCommand);
        BossCommand bossCommand = new BossCommand(this.harbourerBossService);
        this.getCommand("boss").setExecutor((CommandExecutor)bossCommand);
        this.getCommand("boss").setTabCompleter((TabCompleter)bossCommand);
        InvasionCommand invasionCommand = new InvasionCommand(this.alienInvasionService);
        this.getCommand("invasion").setExecutor((CommandExecutor)invasionCommand);
        this.getCommand("invasion").setTabCompleter((TabCompleter)invasionCommand);
        PrisonsReloadCommand reloadCommand = new PrisonsReloadCommand(this);
        this.getCommand("prisonsreload").setExecutor((CommandExecutor)reloadCommand);
        PrisonsCoreCommand prisonsCoreCommand = new PrisonsCoreCommand(this.featureToggleService);
        this.getCommand("prisonscore").setExecutor((CommandExecutor)prisonsCoreCommand);
        this.getCommand("prisonscore").setTabCompleter((TabCompleter)prisonsCoreCommand);
        this.getCommand("stash").setExecutor((CommandExecutor)new StashCommand(this.stashMenu));
        this.getCommand("toggle").setExecutor((CommandExecutor)new ToggleCommand(this.toggleMenu));
        GangCommand gangCommand = new GangCommand(this.gangService);
        this.getCommand("gang").setExecutor((CommandExecutor)gangCommand);
        this.getCommand("gang").setTabCompleter((TabCompleter)gangCommand);
        GangPointsCommand gangPointsCommand = new GangPointsCommand(this.gangPointService);
        this.getCommand("gangpoints").setExecutor((CommandExecutor)gangPointsCommand);
        this.getCommand("gangpoints").setTabCompleter((TabCompleter)gangPointsCommand);
        ReputationCommand reputationCommand = new ReputationCommand(this.reputationService);
        this.getCommand("reputation").setExecutor((CommandExecutor)reputationCommand);
        this.getCommand("reputation").setTabCompleter((TabCompleter)reputationCommand);
        this.getCommand("wormhole").setExecutor((CommandExecutor)new WormholeCommand(this, this.wormholeEnchanter));
        this.getCommand("tutorialwormhole").setExecutor((CommandExecutor)new WormholeCommand(this, this.tutorialWormholeEnchanter, "tutorialwormhole"));
        SafezoneCommand safezoneCommand = new SafezoneCommand(this.safezoneService);
        this.getCommand("safezone").setExecutor((CommandExecutor)safezoneCommand);
        this.getCommand("safezone").setTabCompleter((TabCompleter)safezoneCommand);
        SatchelCommand satchelCommand = new SatchelCommand(this.satchelManager);
        this.getCommand("satchel").setExecutor((CommandExecutor)satchelCommand);
        this.getCommand("satchel").setTabCompleter((TabCompleter)satchelCommand);
        this.getCommand("chargeorb").setExecutor((CommandExecutor)new ChargeOrbCommand(this, this.chargeOrbService));
        this.getCommand("dust").setExecutor((CommandExecutor)new EnchantDustCommand(this.enchantDustService));
        this.getCommand("gear").setExecutor((CommandExecutor)new GearCommand(this.gearManager));
        RenameScrollCommand renameScrollCommand = new RenameScrollCommand(this.renameScrollService);
        this.getCommand("renamescroll").setExecutor((CommandExecutor)renameScrollCommand);
        this.getCommand("renamescroll").setTabCompleter((TabCompleter)renameScrollCommand);
        ProtectionScrollCommand protectionScrollCommand = new ProtectionScrollCommand(this.protectionScrollService);
        this.getCommand("protectionscroll").setExecutor((CommandExecutor)protectionScrollCommand);
        this.getCommand("protectionscroll").setTabCompleter((TabCompleter)protectionScrollCommand);
        DestructionScrollCommand destructionScrollCommand = new DestructionScrollCommand(this.destructionScrollService);
        this.getCommand("destructionscroll").setExecutor((CommandExecutor)destructionScrollCommand);
        this.getCommand("destructionscroll").setTabCompleter((TabCompleter)destructionScrollCommand);
        this.getCommand("prestigetoken").setExecutor((CommandExecutor)new PrestigeTokenCommand(this.pickaxeManager, Keys.pickaxePrestigeToken(this)));
        this.getCommand("pickaxeprestige").setExecutor((CommandExecutor)new PickaxePrestigeCommand(this.pickaxePrestigeMenu, this.pickaxeManager));
        PrisonRiotCommand prisonRiotCommand = new PrisonRiotCommand(this.prisonRiotService, this.prisonRiotMenu);
        this.getCommand("prisonriot").setExecutor((CommandExecutor)prisonRiotCommand);
        this.getCommand("pr").setExecutor((CommandExecutor)prisonRiotCommand);
        this.getCommand("riot").setExecutor((CommandExecutor)prisonRiotCommand);
        this.getCommand("applyore").setExecutor((CommandExecutor)new ApplyOreCommand(this.pickaxeManager));
        this.getCommand("balance").setExecutor((CommandExecutor)new BalanceCommand(this.economyService));
        this.getCommand("withdraw").setExecutor((CommandExecutor)new WithdrawCommand(this.economyService, this.bankNoteService));
        this.getCommand("banknote").setExecutor((CommandExecutor)new BankNoteCommand(this.economyService, this.bankNoteService));
        this.getCommand("pay").setExecutor((CommandExecutor)new PayCommand(this.economyService, this.playerToggleService));
        MsgCommand msgCommand = new MsgCommand(this.privateMessageService);
        this.getCommand("msg").setExecutor((CommandExecutor)msgCommand);
        this.getCommand("msg").setTabCompleter((TabCompleter)msgCommand);
        this.getCommand("r").setExecutor((CommandExecutor)new ReplyCommand(this.privateMessageService));
        this.getCommand("msgtoggle").setExecutor((CommandExecutor)new MsgToggleCommand(this.playerToggleService));
        this.getCommand("sell").setExecutor((CommandExecutor)new SellCommand(this.economyService, this.satchelManager));
        this.getCommand("setworth").setExecutor((CommandExecutor)new WorthCommand(this.economyService));
        this.getCommand("baltop").setExecutor((CommandExecutor)new BalTopCommand(this.economyService));
        this.getCommand("eco").setExecutor((CommandExecutor)new EconomyAdminCommand(this.economyService));
        PrisonCoinAdminCommand prisonCoinAdminCommand = new PrisonCoinAdminCommand(this.prisonCoinService);
        this.getCommand("prisoncoins").setExecutor((CommandExecutor)prisonCoinAdminCommand);
        this.getCommand("prisoncoins").setTabCompleter((TabCompleter)prisonCoinAdminCommand);
        this.getCommand("tpa").setExecutor((CommandExecutor)new TpaCommand(this.teleportService, this.playerToggleService));
        this.getCommand("tpaccept").setExecutor((CommandExecutor)new TpAcceptCommand(this.teleportService));
        this.getCommand("tpdeny").setExecutor((CommandExecutor)new TpDenyCommand(this.teleportService));
        this.getCommand("tptoggle").setExecutor((CommandExecutor)new TpToggleCommand(this.teleportService));
        this.getCommand("setwarp").setExecutor((CommandExecutor)new SetWarpCommand());
        this.getCommand("warp").setExecutor((CommandExecutor)new WarpCommand(this.teleportService, this.warpMenu));
        this.getCommand("setspawn").setExecutor((CommandExecutor)new SetSpawnCommand());
        this.getCommand("spawn").setExecutor((CommandExecutor)new SpawnCommand(this.teleportService));
        this.getCommand("sethome").setExecutor((CommandExecutor)new SetHomeCommand(this.teleportService, this.playerDataService));
        this.getCommand("home").setExecutor((CommandExecutor)new HomeCommand(this.teleportService, this.playerDataService));
        this.getCommand("homes").setExecutor((CommandExecutor)new HomesCommand(this.playerDataService));
        this.getCommand("tutorialsetspawn").setExecutor((CommandExecutor)new TutorialSetSpawnCommand());
        this.getCommand("tutorial").setExecutor((CommandExecutor)new TutorialCommand(this.tutorialService, this.playerToggleService));
        this.getCommand("near").setExecutor((CommandExecutor)new NearCommand());
        this.getCommand("nick").setExecutor((CommandExecutor)new NickCommand(this.playerDataService));
        this.getCommand("jet").setExecutor((CommandExecutor)new JetCommand(this.jetService));
        ContrabandCommand contrabandCommand = new ContrabandCommand(this.contrabandService);
        this.getCommand("contraband").setExecutor((CommandExecutor)contrabandCommand);
        this.getCommand("contraband").setTabCompleter((TabCompleter)contrabandCommand);
        AlienSupplyCrateCommand alienSupplyCrateCommand = new AlienSupplyCrateCommand(this, this.alienSupplyCrateService);
        this.getCommand("aliencrate").setExecutor((CommandExecutor)alienSupplyCrateCommand);
        this.getCommand("aliencrate").setTabCompleter((TabCompleter)alienSupplyCrateCommand);
        AlienKeyCommand alienKeyCommand = new AlienKeyCommand(this, this.alienSupplyCrateService);
        this.getCommand("alienkey").setExecutor((CommandExecutor)alienKeyCommand);
        this.getCommand("alienkey").setTabCompleter((TabCompleter)alienKeyCommand);
        PowerboxCommand powerboxCommand = new PowerboxCommand(this, this.powerboxService);
        this.getCommand("powerbox").setExecutor((CommandExecutor)powerboxCommand);
        this.getCommand("powerbox").setTabCompleter((TabCompleter)powerboxCommand);
        this.getCommand("kit").setExecutor((CommandExecutor)new KitCommand(this.kitMenu));
        GKitAdminCommand gkitAdminCommand = new GKitAdminCommand(this.kitService, this.meteorService);
        this.getCommand("gkit").setExecutor((CommandExecutor)gkitAdminCommand);
        this.getCommand("gkit").setTabCompleter((TabCompleter)gkitAdminCommand);
        this.getCommand("ranktoken").setExecutor((CommandExecutor)new RankTokenCommand(this.rankTokenService));
        ResetKitCooldownCommand resetKitCooldownCommand = new ResetKitCooldownCommand(this.kitService);
        this.getCommand("resetkitcooldown").setExecutor((CommandExecutor)resetKitCooldownCommand);
        this.getCommand("resetkitcooldown").setTabCompleter((TabCompleter)resetKitCooldownCommand);
        this.getCommand("fragment").setExecutor((CommandExecutor)new ShardCommand(this.shardService));
        this.getCommand("meteor").setExecutor((CommandExecutor)new MeteorCommand(this.meteorService));
        this.getCommand("meteortime").setExecutor((CommandExecutor)new MeteorTimeCommand(this.meteorService));
        OreOnlyWorldCommand oreOnlyWorldCommand = new OreOnlyWorldCommand(this.oreOnlyWorldService);
        this.getCommand("oreonly").setExecutor((CommandExecutor)oreOnlyWorldCommand);
        this.getCommand("oreonly").setTabCompleter((TabCompleter)oreOnlyWorldCommand);
        XpBoosterCommand xpBoosterCommand = new XpBoosterCommand(this.boosterService);
        this.getCommand("xpbooster").setExecutor((CommandExecutor)xpBoosterCommand);
        this.getCommand("xpbooster").setTabCompleter((TabCompleter)xpBoosterCommand);
        EnergyBoosterCommand energyBoosterCommand = new EnergyBoosterCommand(this.boosterService);
        this.getCommand("energybooster").setExecutor((CommandExecutor)energyBoosterCommand);
        this.getCommand("energybooster").setTabCompleter((TabCompleter)energyBoosterCommand);
        GlobalBoosterCommand globalBoosterCommand = new GlobalBoosterCommand(this.globalBoosterService);
        this.getCommand("globalbooster").setExecutor((CommandExecutor)globalBoosterCommand);
        GeneratorCommand generatorCommand = new GeneratorCommand(this.generatorService);
        this.getCommand("generator").setExecutor((CommandExecutor)generatorCommand);
        this.getCommand("generator").setTabCompleter((TabCompleter)generatorCommand);
        RefinedCommand refinedCommand = new RefinedCommand(this.generatorService);
        this.getCommand("refined").setExecutor((CommandExecutor)refinedCommand);
        this.getCommand("refined").setTabCompleter((TabCompleter)refinedCommand);
        CustomBlockCommand customBlockCommand = new CustomBlockCommand(this.customBlockService);
        this.getCommand("customblock").setExecutor((CommandExecutor)customBlockCommand);
        this.getCommand("customblock").setTabCompleter((TabCompleter)customBlockCommand);
        CellCommand cellCommand = new CellCommand(this, this.cellService, this.cellMenu, this.cellGuardService);
        this.getCommand("cell").setExecutor((CommandExecutor)cellCommand);
        this.getCommand("cell").setTabCompleter((TabCompleter)cellCommand);
        GrapplingHookCommand grapplingHookCommand = new GrapplingHookCommand(this.grapplingHookModule);
        this.getCommand("grapplinghook").setExecutor((CommandExecutor)grapplingHookCommand);
        this.getCommand("grapplinghook").setTabCompleter((TabCompleter)grapplingHookCommand);
        UtilityCommand utility = new UtilityCommand();
        this.getCommand("fix").setExecutor((CommandExecutor)utility);
        this.getCommand("feed").setExecutor((CommandExecutor)utility);
        this.getCommand("gmc").setExecutor((CommandExecutor)utility);
        this.getCommand("gms").setExecutor((CommandExecutor)utility);
        this.getCommand("gmsp").setExecutor((CommandExecutor)utility);
        this.getCommand("fly").setExecutor((CommandExecutor)utility);
        this.getCommand("top").setExecutor((CommandExecutor)utility);
        this.getCommand("hub").setExecutor((CommandExecutor)new HubCommand());
        InvseeCommand invseeCommand = new InvseeCommand();
        this.getCommand("invsee").setExecutor((CommandExecutor)invseeCommand);
        this.getCommand("invsee").setTabCompleter((TabCompleter)invseeCommand);
        this.getCommand("vanish").setExecutor((CommandExecutor)new VanishCommand(this.vanishService));
        this.getCommand("levels").setExecutor((CommandExecutor)new LevelsCommand(this.levelsMenu, this.tutorialService, this.featureToggleService));
        this.getCommand("shop").setExecutor((CommandExecutor)new ShopCommand(this.shopMenu, this.featureToggleService, this.safezoneService, this.cellService));
        this.getCommand("store").setExecutor((CommandExecutor)new StoreCommand(this.storeMenu, this.safezoneService, this.cellService));
        this.getCommand("raidshop").setExecutor((CommandExecutor)new RaidShopCommand(this.raidShopMenu));
        PlayerVaultCommand playerVaultCommand = new PlayerVaultCommand(this.playerVaultService, this.playerVaultMenu, this.safezoneService, this.cellService);
        this.getCommand("pv").setExecutor((CommandExecutor)playerVaultCommand);
        this.getCommand("pv").setTabCompleter((TabCompleter)playerVaultCommand);
        HologramCommand hologramCommand = new HologramCommand(this.hologramService);
        this.getCommand("hologram").setExecutor((CommandExecutor)hologramCommand);
        this.getCommand("hologram").setTabCompleter((TabCompleter)hologramCommand);
    }

    private void registerListeners() {
        this.getServer().getPluginManager().registerEvents((Listener)new MiningListener(this, this.pickaxeManager, this.gearManager, this.playerLevelService, this.oreRegenService, this.customEnchantService, this.economyService, this.levelRequirementService, this.blockProgressService, this.guardService, this.satchelManager, this.meteorService, this.generatorService, this.harbourerBossService, this.boosterService, this.maskModule != null ? this.maskModule.getMaskManager() : null, this.tutorialService, this.oreOnlyWorldService, this.playerToggleService, this.prisonCoinService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.oreRegenService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new EnergyApplyListener(this, this.pickaxeManager, this.gearManager, this.satchelManager, this.energyItemService, this.grapplingHookModule), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new BankNoteListener(this.economyService, this.bankNoteService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new PrisonCoinTokenListener(this.prisonCoinService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new SatchelListener(this.satchelManager, this.economyService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new TeleportListener(this, this.teleportService, this.tutorialService, this.playerDataService, this.featureToggleService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new JetListener(this.jetService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GangChatListener(this, this.gangService, this.playerDataService, this.tutorialService, this.playerToggleService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GangInviteListener(this.gangService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ChatFormatListener(this.playerLevelService, this.playerDataService, this.gangService, this.tutorialService, this.playerToggleService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new PrivateMessageListener(this.privateMessageService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ItemShowcaseChatListener(this, this.gangService, this.playerDataService, this.tutorialService, this.playerToggleService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new TutorialListener(this.tutorialService, this.playerToggleService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new FlareListener(this.meteorService, this.kitService, this.featureToggleService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GKitTokenListener(this.kitService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new RankTokenListener(this.rankTokenService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new PVPListener(this.featureToggleService, this.guardService, this.cellGuardService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new MiningLevelScoreboardListener(this.miningLevelScoreboardService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.contrabandMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.powerboxMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.alienSupplyCrateMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.lockboxService.getMenu(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ContrabandListener(this.contrabandService, this.contrabandMenu, this.lockboxService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new PowerboxListener(this.powerboxService, this.powerboxMenu), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new AlienSupplyCrateListener(this.alienSupplyCrateService, this.alienSupplyCrateMenu), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new LockboxTaskListener(this.lockboxService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.kitMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new BoosterListener(this.boosterService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GearLevelListener(this.gearManager, this.playerLevelService, this.seasonService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ToolLevelListener(this.gearManager, this.playerLevelService, this.levelRequirementService, this.seasonService, this.cellService, this.prisonRiotService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.generatorService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.customBlockService, (Plugin)this);
        ShardMenu shardMenu = new ShardMenu(this, this.shardService, this.economyService);
        this.getServer().getPluginManager().registerEvents((Listener)shardMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ShardListener(this.shardService, shardMenu), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.enchanterMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.enchantsMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.adminEnchantMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GearBreakListener(this.gearManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.gearEnchantListener, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GearEnchantOrbListener(this.gearEnchantService, this.gearManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.oreRegenService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new EnchantOrbListener(this.enchantOrbService, this.pickaxeManager, this.customEnchantService, this.cellBusterManager, this.enchantDustService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new BlockProgressListener(this.pickaxeManager, this.gearManager, this.gearEnchantService, this.blockProgressService, this.oreOnlyWorldService, this.cellService, this.generatorService, this.meteorService, this.prisonRiotService), (Plugin)this);
        if (this.blockProgressService != null && this.blockProgressService.isPacketEventsEnabled() && PacketEvents.getAPI() != null) {
            this.miningDigPacketListener = new MiningDigPacketListener(this.blockProgressService);
            PacketEvents.getAPI().getEventManager().registerListener((PacketListenerCommon)this.miningDigPacketListener);
        }
        this.getServer().getPluginManager().registerEvents((Listener)new SafezoneListener(this.safezoneService, this.guardService, this.cellGuardService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.alienInvasionService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GuardListener(this.guardService, this.pickaxeManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GuardSpawnerListener(this.guardService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GuardStartupListener(this.guardService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.harbourerBossService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new HologramStartupListener(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new NoNaturalMobSpawnsListener(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ChargeOrbListener(this.chargeOrbService, this.pickaxeManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new PickaxeBuffListener(this.pickaxeManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new EnergyExtractorListener(this.energyItemService, this.pickaxeManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new RaidPointListener(this.raidPointService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.pickaxePrestigeMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.tinkererMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.prestigeMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ReputationListener(this.reputationService, this.guardService, this.cellGuardService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GangPointRedeemListener(this.gangService, this.gangPointService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new StopCommandListener(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new RenameScrollListener(this, this.pickaxeManager, this.renameScrollService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ScrollListener(this, this.gearManager, this.gearEnchantService, this.protectionScrollService, this.destructionScrollService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new DeathAnimationListener(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new DangleListener(this, this.pickaxeManager, this.customEnchantService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ChargePowderListener(this.enchantDustService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CombatLogListener(this.combatLogManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new ConnectionMessageListener(this.axialModVerificationService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new FallDamageListener(this.combatLogManager), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new TightDropListener(this, this.protectionScrollService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new DupeTrackingListener(this.dupeTrackingService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.playerTabService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.vanishService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.slownessEffectService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.stashMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.toggleMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.globalBoosterService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.wormholeEnchanter, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.tutorialWormholeEnchanter, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new WormholeStartupListener(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.levelsMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.shopMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.storeMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.raidShopMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.prisonRiotMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.prisonRiotService, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.playerVaultMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.warpMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this.cellMenu, (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CellListener(this.cellService, this.gearManager, this.gearEnchantService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CellToolListener(this, this.cellService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CellStartupListener(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CellSignChunkListener(this), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CellGuardListener(this.cellService, this.cellGuardService, this.featureToggleService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new CellGuardChunkListener(this.cellGuardService), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)new GrapplingListener(this.grapplingHookModule), (Plugin)this);
        if (!this.economyService.isReady()) {
            this.getServer().getScheduler().runTaskLater((Plugin)this, this.economyService::setup, 20L);
        }
        this.getServer().getScheduler().runTaskLater((Plugin)this, () -> {
            if (this.cellService != null) {
                this.cellService.restoreConfiguredDoors();
            }
        }, 20L);
        this.miningLevelScoreboardService.start();
        this.boosterService.start();
        this.globalBoosterService.start();
        this.stashService.start();
        this.guardDisplayService.start();
        this.meteorService.start();
        this.dupeTrackingService.start();
        this.gearEnchantListener.start();
    }

    private void registerGlobalTabCompletion() {
        for (String commandName : this.getDescription().getCommands().keySet()) {
            PluginCommand command = this.getCommand(commandName);
            if (command == null) {
                continue;
            }
            TabCompleter existing = command.getTabCompleter();
            if (existing instanceof GlobalCommandTabCompleter) {
                continue;
            }
            command.setTabCompleter(new GlobalCommandTabCompleter(this, existing));
        }
    }

    public Random getRandom() {
        return this.random;
    }

    public FeatureToggleService getFeatureToggleService() {
        return this.featureToggleService;
    }

    public WarpMenu getWarpMenu() {
        return this.warpMenu;
    }

    public TeleportService getTeleportService() {
        return this.teleportService;
    }

    public SatchelManager getSatchelManager() {
        return this.satchelManager;
    }

    public GearManager getGearManager() {
        return this.gearManager;
    }

    public GearEnchantService getGearEnchantService() {
        return this.gearEnchantService;
    }

    public ShardService getShardService() {
        return this.shardService;
    }

    public ContrabandService getContrabandService() {
        return this.contrabandService;
    }

    public PowerboxService getPowerboxService() {
        return this.powerboxService;
    }

    public PowerboxMenu getPowerboxMenu() {
        return this.powerboxMenu;
    }

    public AlienSupplyCrateService getAlienSupplyCrateService() {
        return this.alienSupplyCrateService;
    }

    public AlienSupplyCrateMenu getAlienSupplyCrateMenu() {
        return this.alienSupplyCrateMenu;
    }

    public KitService getKitService() {
        return this.kitService;
    }

    public OreOnlyWorldService getOreOnlyWorldService() {
        return this.oreOnlyWorldService;
    }

    public SafezoneService getSafezoneService() {
        return this.safezoneService;
    }

    public CellService getCellService() {
        return this.cellService;
    }

    public GeneratorService getGeneratorService() {
        return this.generatorService;
    }

    public CustomBlockService getCustomBlockService() {
        return this.customBlockService;
    }

    public CustomBlockBuffService getCustomBlockBuffService() {
        return this.customBlockBuffService;
    }

    public GangPointService getGangPointService() {
        return this.gangPointService;
    }

    public CellGuardService getCellGuardService() {
        return this.cellGuardService;
    }

    public GuardDisplayService getGuardDisplayService() {
        return this.guardDisplayService;
    }

    public CustomEnchantService getCustomEnchantService() {
        return this.customEnchantService;
    }

    public CellBusterManager getCellBusterManager() {
        return this.cellBusterManager;
    }

    public TutorialService getTutorialService() {
        return this.tutorialService;
    }

    public PlayerDataService getPlayerDataService() {
        return this.playerDataService;
    }

    public WormholeEnchanter getWormholeEnchanter() {
        return this.wormholeEnchanter;
    }

    public WormholeEnchanter getTutorialWormholeEnchanter() {
        return this.tutorialWormholeEnchanter;
    }

    public HologramService getHologramService() {
        return this.hologramService;
    }

    private void refreshBundledConfigs() {
        for (String path : BUNDLED_CONFIGS) {
            if ("config.yml".equals(path)) {
                ConfigUpdater.saveDefaultAndMerge(this, path);
                continue;
            }
            File destination = new File(this.getDataFolder(), path);
            File parent = destination.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                this.getLogger().warning("Could not create parent directories for " + destination.getAbsolutePath());
                continue;
            }
            if (!destination.exists()) {
                this.saveResource(path, false);
            }
        }
    }
}
