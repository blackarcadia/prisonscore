package org.axial.prisonsCore.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.model.EnchantRarity;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.service.EnchantOrbService;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class AdminEnchantMenu implements Listener {
    private static final int SIZE = 54;
    private static final int[] LIST_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private static final int ROOT_PICKAXE_SLOT = 20;
    private static final int ROOT_GEAR_SLOT = 24;
    private static final int BACK_SLOT = 49;
    private static final int EXIT_SLOT = 45;
    private static final int PREV_SLOT = 48;
    private static final int NEXT_SLOT = 50;
    private static final int PAGE_SLOT = 52;

    private final CustomEnchantService enchantService;
    private final GearEnchantService gearEnchantService;
    private final EnchantOrbService enchantOrbService;

    public AdminEnchantMenu(CustomEnchantService enchantService, GearEnchantService gearEnchantService, EnchantOrbService enchantOrbService) {
        this.enchantService = enchantService;
        this.gearEnchantService = gearEnchantService;
        this.enchantOrbService = enchantOrbService;
    }

    public void open(Player player) {
        if (player == null) {
            return;
        }
        MenuHolder holder = new MenuHolder(Screen.ROOT);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Admin Enchants"));
        holder.inventory = inventory;
        this.fillRootFrame(inventory);
        inventory.setItem(ROOT_PICKAXE_SLOT, this.card(Material.DIAMOND_PICKAXE, "&b&lPickaxe Enchants", List.of("&7Click to browse mining enchants.", "&7Left click an enchant to receive an orb.")));
        inventory.setItem(ROOT_GEAR_SLOT, this.card(Material.DIAMOND_CHESTPLATE, "&a&lGear Enchants", List.of("&7Click to browse armor and weapon enchants.", "&7Left click an enchant to receive an orb.")));
        player.openInventory(inventory);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof MenuHolder holder)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getCurrentItem() == null || event.getCurrentItem().getType().isAir()) {
            return;
        }
        switch (holder.screen) {
            case ROOT -> this.handleRootClick(player, event.getRawSlot());
            case PICKAXES -> this.handlePickaxeClick(player, holder, event.getRawSlot());
            case GEAR -> this.handleGearClick(player, holder, event.getRawSlot());
        }
    }

    private void handleRootClick(Player player, int slot) {
        if (slot == ROOT_PICKAXE_SLOT) {
            this.openPickaxeMenu(player);
        } else if (slot == ROOT_GEAR_SLOT) {
            this.openGearMenu(player);
        }
    }

    private void handlePickaxeClick(Player player, MenuHolder holder, int slot) {
        if (slot == PREV_SLOT) {
            this.openPickaxeMenu(player, Math.max(0, holder.page - 1));
            return;
        }
        if (slot == NEXT_SLOT) {
            this.openPickaxeMenu(player, holder.page + 1);
            return;
        }
        if (slot == BACK_SLOT || slot == EXIT_SLOT) {
            this.open(player);
            return;
        }
        CustomEnchant enchant = this.pickaxeBySlot(slot, holder.page);
        if (enchant != null) {
            this.givePickaxeOrb(player, enchant);
        }
    }

    private void handleGearClick(Player player, MenuHolder holder, int slot) {
        if (slot == PREV_SLOT) {
            this.openGearMenu(player, Math.max(0, holder.page - 1));
            return;
        }
        if (slot == NEXT_SLOT) {
            this.openGearMenu(player, holder.page + 1);
            return;
        }
        if (slot == BACK_SLOT || slot == EXIT_SLOT) {
            this.open(player);
            return;
        }
        CustomEnchant enchant = this.gearBySlot(slot, holder.page);
        if (enchant != null) {
            this.giveGearOrb(player, enchant);
        }
    }

    private void openPickaxeMenu(Player player) {
        this.openPickaxeMenu(player, 0);
    }

    private void openPickaxeMenu(Player player, int page) {
        MenuHolder holder = new MenuHolder(Screen.PICKAXES, page);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Pickaxe Enchants"));
        holder.inventory = inventory;
        this.fillListFrame(inventory, "&b&lPickaxe Enchants", "&7Left click an enchant to give yourself the orb.");
        List<CustomEnchant> enchants = this.getPickaxeEnchants();
        this.placeEnchantList(inventory, enchants, holder.page, true);
        inventory.setItem(BACK_SLOT, this.nav(Material.ARROW, "&7Back", List.of("&7Return to the admin enchant index.")));
        inventory.setItem(EXIT_SLOT, this.nav(Material.BOOK, "&dHome", List.of("&7Return to the main menu.")));
        player.openInventory(inventory);
    }

    private void openGearMenu(Player player) {
        this.openGearMenu(player, 0);
    }

    private void openGearMenu(Player player, int page) {
        MenuHolder holder = new MenuHolder(Screen.GEAR, page);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Gear Enchants"));
        holder.inventory = inventory;
        this.fillListFrame(inventory, "&a&lGear Enchants", "&7Left click an enchant to give yourself the orb.");
        List<CustomEnchant> enchants = this.getGearEnchants();
        this.placeEnchantList(inventory, enchants, holder.page, false);
        inventory.setItem(BACK_SLOT, this.nav(Material.ARROW, "&7Back", List.of("&7Return to the admin enchant index.")));
        inventory.setItem(EXIT_SLOT, this.nav(Material.BOOK, "&dHome", List.of("&7Return to the main menu.")));
        player.openInventory(inventory);
    }

    private void placeEnchantList(Inventory inventory, List<CustomEnchant> enchants, int page, boolean pickaxe) {
        List<CustomEnchant> ordered = enchants.stream()
                .sorted(Comparator.comparingInt((CustomEnchant enchant) -> this.rarityOrder(enchant.getRarity()))
                        .thenComparing(enchant -> Text.strip(enchant.getDisplayName()), String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
        int maxPage = this.maxPage(ordered.size());
        int clampedPage = Math.max(0, Math.min(page, maxPage));
        int start = clampedPage * LIST_SLOTS.length;
        int end = Math.min(ordered.size(), start + LIST_SLOTS.length);
        for (int i = start; i < end; ++i) {
            CustomEnchant enchant = ordered.get(i);
            inventory.setItem(LIST_SLOTS[i - start], this.enchantCard(enchant, pickaxe));
        }
        if (ordered.size() > LIST_SLOTS.length) {
            inventory.setItem(PREV_SLOT, this.nav(clampedPage > 0 ? Material.ARROW : Material.GRAY_DYE, "&ePrevious Page", List.of("&7Go to the previous page.")));
            inventory.setItem(NEXT_SLOT, this.nav(clampedPage < maxPage ? Material.ARROW : Material.GRAY_DYE, "&eNext Page", List.of("&7Go to the next page.")));
            inventory.setItem(PAGE_SLOT, this.info(Material.PAPER, "&fPage &7" + (clampedPage + 1) + "&8/&7" + (maxPage + 1), List.of("&7Entries: &f" + ordered.size())));
        }
    }

    private ItemStack enchantCard(CustomEnchant enchant, boolean pickaxe) {
        Material material = enchant.getRarity() == null ? Material.GRAY_DYE : enchant.getRarity().getDisplayMaterial();
        String displayName = (enchant.getRarity() == null ? "" : enchant.getRarity().getColorCode()) + enchant.getDisplayName();
        ArrayList<String> lore = new ArrayList<String>();
        if (enchant.getDescription() != null && !enchant.getDescription().isBlank()) {
            lore.add("&7" + enchant.getDescription());
        }
        lore.add("");
        lore.add("&7Type: &f" + (pickaxe ? "Pickaxe" : this.describeTargets(enchant)));
        lore.add("&7Max Level: &f" + this.roman(enchant.getMaxLevel()));
        lore.add("&7Click to receive: &f" + enchant.getDisplayNameForLevel(enchant.getMaxLevel()));
        return this.info(material, displayName, lore);
    }

    private void givePickaxeOrb(Player player, CustomEnchant enchant) {
        if (player == null || enchant == null || this.enchantOrbService == null) {
            return;
        }
        ItemStack orb = this.enchantOrbService.createOrb(enchant.getId(), enchant.getMaxLevel(), 100);
        if (orb == null) {
            return;
        }
        this.giveOrDrop(player, orb);
        player.sendMessage(Text.color("&aGave you " + enchant.getDisplayNameForLevel(enchant.getMaxLevel()) + " &a(orbs are 100% success)."));
    }

    private void giveGearOrb(Player player, CustomEnchant enchant) {
        if (player == null || enchant == null || this.gearEnchantService == null) {
            return;
        }
        ItemStack orb = this.gearEnchantService.createOrb(enchant.getId(), enchant.getMaxLevel(), 100);
        if (orb == null) {
            return;
        }
        this.giveOrDrop(player, orb);
        player.sendMessage(Text.color("&aGave you " + enchant.getDisplayNameForLevel(enchant.getMaxLevel()) + " &a(orbs are 100% success)."));
    }

    private void giveOrDrop(Player player, ItemStack stack) {
        if (player == null || stack == null) {
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
        if (!leftover.isEmpty()) {
            leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }
    }

    private List<CustomEnchant> getPickaxeEnchants() {
        if (this.enchantService == null) {
            return List.of();
        }
        return this.enchantService.getAll().stream().filter(enchant -> enchant != null && !enchant.getId().equalsIgnoreCase("buster_efficiency")).collect(Collectors.toList());
    }

    private List<CustomEnchant> getGearEnchants() {
        if (this.gearEnchantService == null) {
            return List.of();
        }
        return this.gearEnchantService.getAll().stream().filter(enchant -> enchant != null).collect(Collectors.toList());
    }

    private CustomEnchant pickaxeBySlot(int slot, int page) {
        List<CustomEnchant> enchants = this.getPickaxeEnchants().stream()
                .sorted(Comparator.comparingInt((CustomEnchant enchant) -> this.rarityOrder(enchant.getRarity()))
                        .thenComparing(enchant -> Text.strip(enchant.getDisplayName()), String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
        int index = this.indexForSlot(slot);
        if (index < 0) {
            return null;
        }
        index += Math.max(0, page) * LIST_SLOTS.length;
        return index >= 0 && index < enchants.size() ? enchants.get(index) : null;
    }

    private CustomEnchant gearBySlot(int slot, int page) {
        List<CustomEnchant> enchants = this.getGearEnchants().stream()
                .sorted(Comparator.comparingInt((CustomEnchant enchant) -> this.rarityOrder(enchant.getRarity()))
                        .thenComparing(enchant -> Text.strip(enchant.getDisplayName()), String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
        int index = this.indexForSlot(slot);
        if (index < 0) {
            return null;
        }
        index += Math.max(0, page) * LIST_SLOTS.length;
        return index >= 0 && index < enchants.size() ? enchants.get(index) : null;
    }

    private int indexForSlot(int slot) {
        for (int i = 0; i < LIST_SLOTS.length; ++i) {
            if (LIST_SLOTS[i] == slot) {
                return i;
            }
        }
        return -1;
    }

    private void fillRootFrame(Inventory inventory) {
        ItemStack pane = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack accent = this.pane(Material.MAGENTA_STAINED_GLASS_PANE);
        for (int slot = 0; slot < SIZE; ++slot) {
            inventory.setItem(slot, pane);
        }
        inventory.setItem(0, accent);
        inventory.setItem(8, accent);
        inventory.setItem(45, accent);
        inventory.setItem(53, accent);
    }

    private void fillListFrame(Inventory inventory, String header, String subtitle) {
        ItemStack pane = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack accent = this.pane(Material.PURPLE_STAINED_GLASS_PANE);
        for (int slot = 0; slot < SIZE; ++slot) {
            inventory.setItem(slot, pane);
        }
        for (int slot : LIST_SLOTS) {
            inventory.setItem(slot, null);
        }
        inventory.setItem(1, this.info(Material.NETHER_STAR, header, List.of(subtitle)));
        inventory.setItem(4, accent);
        inventory.setItem(49, accent);
        inventory.setItem(45, this.info(Material.BOOK, "&dHome", List.of("&7Return to the main menu.")));
    }

    private ItemStack card(Material material, String name, List<String> lore) {
        return this.info(material, name, lore);
    }

    private ItemStack nav(Material material, String name, List<String> lore) {
        return this.info(material, name, lore);
    }

    private ItemStack info(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(name));
            ArrayList<net.kyori.adventure.text.Component> components = new ArrayList<net.kyori.adventure.text.Component>();
            if (lore != null) {
                for (String line : lore) {
                    components.add(Text.componentNoItalics(line));
                }
            }
            meta.lore(components);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(" "));
            item.setItemMeta(meta);
        }
        return item;
    }

    private int rarityOrder(EnchantRarity rarity) {
        if (rarity == null) {
            return Integer.MAX_VALUE;
        }
        return switch (rarity) {
            case BASIC -> 0;
            case UNIQUE, UNCOMMON -> 1;
            case RARE -> 2;
            case ELITE -> 3;
            case LEGENDARY -> 4;
        };
    }

    private int maxPage(int count) {
        if (count <= 0) {
            return 0;
        }
        return (count - 1) / LIST_SLOTS.length;
    }

    private String describeTargets(CustomEnchant enchant) {
        if (enchant == null) {
            return "Unknown";
        }
        return enchant.getApplicableTypes().isEmpty() ? "All Gear" : String.join(", ", enchant.getApplicableTypes());
    }

    private String roman(int number) {
        int n = Math.max(1, number);
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                sb.append(numerals[i]);
                n -= values[i];
            }
        }
        return sb.toString();
    }

    private enum Screen {
        ROOT,
        PICKAXES,
        GEAR
    }

    private static final class MenuHolder implements InventoryHolder {
        private final Screen screen;
        private final int page;
        private Inventory inventory;

        private MenuHolder(Screen screen) {
            this(screen, 0);
        }

        private MenuHolder(Screen screen, int page) {
            this.screen = screen;
            this.page = Math.max(0, page);
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
