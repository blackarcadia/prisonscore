package org.axial.prisonsCore.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.service.ContrabandService;
import org.axial.prisonsCore.service.PrisonRiotService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class PrisonRiotMenu implements Listener {

    private static final int MAIN_SIZE = 27;
    private static final int INFO_SIZE = 27;
    private final PrisonsCore plugin;
    private final PrisonRiotService riotService;
    private final PlayerDataService playerDataService;
    private final ContrabandService contrabandService;

    public PrisonRiotMenu(PrisonsCore plugin, PrisonRiotService riotService, PlayerDataService playerDataService, ContrabandService contrabandService) {
        this.plugin = plugin;
        this.riotService = riotService;
        this.playerDataService = playerDataService;
        this.contrabandService = contrabandService;
    }

    public void openMain(Player player) {
        RiotHolder holder = new RiotHolder(MenuType.MAIN);
        Inventory inventory = Bukkit.createInventory(holder, MAIN_SIZE, Text.color("&8Prison Riot"));
        holder.inventory = inventory;
        this.fill(inventory);
        inventory.setItem(0, this.namedItem(Material.BEACON, "&b&lPrison Riot Shop", this.shopLore(player)));
        inventory.setItem(11, this.namedItem(Material.NETHER_STAR, "&b&lPrison Riot Gamemodes", this.gamemodeLore()));
        inventory.setItem(13, this.namedItem(Material.NOTE_BLOCK, "&b&lPrison Riot", this.riotLore()));
        inventory.setItem(15, this.namedItem(Material.NETHER_BRICK, "&b&lSpecial Blocks", this.specialBlocksLore()));
        inventory.setItem(26, this.namedItem(Material.BOOK, "&b&lPrison Riot Rules", this.rulesLore()));
        player.openInventory(inventory);
    }

    public void openShop(Player player) {
        RiotHolder holder = new RiotHolder(MenuType.SHOP);
        Inventory inventory = Bukkit.createInventory(holder, INFO_SIZE, Text.color("&8Prison Riot Shop"));
        holder.inventory = inventory;
        this.fill(inventory);
        inventory.setItem(4, this.balanceItem(player));
        inventory.setItem(10, this.shopItem(15, "basic_cont"));
        inventory.setItem(11, this.shopItem(20, "rare_cont"));
        inventory.setItem(12, this.shopItem(25, "elite_cont"));
        inventory.setItem(13, this.shopItem(50, "legendary_cont"));
        inventory.setItem(22, this.namedItem(Material.ARROW, "&7&lBack", this.backLore()));
        player.openInventory(inventory);
    }

    public void openGamemodes(Player player) {
        RiotHolder holder = new RiotHolder(MenuType.GAMEMODES);
        Inventory inventory = Bukkit.createInventory(holder, INFO_SIZE, Text.color("&8Prison Riot Gamemodes"));
        holder.inventory = inventory;
        this.fill(inventory);
        inventory.setItem(13, this.namedItem(Material.NETHER_STAR, "&b&l" + this.riotService.getModeName(), this.gamemodeLore()));
        inventory.setItem(22, this.namedItem(Material.ARROW, "&7&lBack", this.backLore()));
        player.openInventory(inventory);
    }

    public void openSpecialBlocks(Player player) {
        RiotHolder holder = new RiotHolder(MenuType.SPECIAL_BLOCKS);
        Inventory inventory = Bukkit.createInventory(holder, INFO_SIZE, Text.color("&8Special Blocks"));
        holder.inventory = inventory;
        this.fill(inventory);
        inventory.setItem(10, this.blockItem(Material.COAL_ORE, "Coal Ore", this.riotService.getOrePoints(Material.COAL_ORE)));
        inventory.setItem(11, this.blockItem(Material.IRON_ORE, "Iron Ore", this.riotService.getOrePoints(Material.IRON_ORE)));
        inventory.setItem(12, this.blockItem(Material.LAPIS_ORE, "Lapis Ore", this.riotService.getOrePoints(Material.LAPIS_ORE)));
        inventory.setItem(14, this.blockItem(Material.GOLD_ORE, "Gold Ore", this.riotService.getOrePoints(Material.GOLD_ORE)));
        inventory.setItem(15, this.blockItem(Material.REDSTONE_ORE, "Redstone Ore", this.riotService.getOrePoints(Material.REDSTONE_ORE)));
        inventory.setItem(16, this.blockItem(Material.DIAMOND_ORE, "Diamond Ore", this.riotService.getOrePoints(Material.DIAMOND_ORE)));
        inventory.setItem(13, this.blockItem(Material.EMERALD_ORE, "Emerald Ore", this.riotService.getOrePoints(Material.EMERALD_ORE)));
        inventory.setItem(22, this.namedItem(Material.ARROW, "&7&lBack", this.backLore()));
        player.openInventory(inventory);
    }

    public void openRules(Player player) {
        RiotHolder holder = new RiotHolder(MenuType.RULES);
        Inventory inventory = Bukkit.createInventory(holder, INFO_SIZE, Text.color("&8Prison Riot Rules"));
        holder.inventory = inventory;
        this.fill(inventory);
        inventory.setItem(13, this.namedItem(Material.BOOK, "&b&lPrison Riot Rules", this.rulesLore()));
        inventory.setItem(22, this.namedItem(Material.ARROW, "&7&lBack", this.backLore()));
        player.openInventory(inventory);
    }

    public void refreshOpenMenus() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player == null || !player.isOnline()) {
                continue;
            }
            if (!(player.getOpenInventory().getTopInventory().getHolder() instanceof RiotHolder holder)) {
                continue;
            }
            this.refreshMenu(player, holder);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof RiotHolder holder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (holder.type == MenuType.MAIN) {
            switch (event.getRawSlot()) {
                case 0 -> this.openShop(player);
                case 13 -> {
                    this.riotService.joinQueue(player);
                    this.openMain(player);
                }
                case 15 -> this.openSpecialBlocks(player);
                case 11, 26 -> {
                }
                default -> {
                }
            }
            return;
        }
        if (holder.type == MenuType.SHOP && this.isShopSlot(event.getRawSlot())) {
            this.purchaseShopEntry(player, this.entryForSlot(event.getRawSlot()));
            return;
        }
        if (event.getRawSlot() == 22) {
            this.openMain(player);
        }
    }

    private void refreshMenu(Player player, RiotHolder holder) {
        if (holder.inventory == null) {
            return;
        }
        switch (holder.type) {
            case MAIN -> this.refreshMain(holder.inventory, player);
            case SHOP -> this.refreshShop(holder.inventory, player);
            case GAMEMODES -> this.refreshGamemodes(holder.inventory);
            case SPECIAL_BLOCKS -> this.refreshSpecialBlocks(holder.inventory);
            case RULES -> this.refreshRules(holder.inventory);
        }
    }

    private void refreshMain(Inventory inventory, Player player) {
        inventory.setItem(0, this.namedItem(Material.BEACON, "&b&lPrison Riot Shop", this.shopLore(player)));
        inventory.setItem(11, this.namedItem(Material.NETHER_STAR, "&b&lPrison Riot Gamemodes", this.gamemodeLore()));
        inventory.setItem(13, this.namedItem(Material.NOTE_BLOCK, "&b&lPrison Riot", this.riotLore()));
        inventory.setItem(15, this.namedItem(Material.NETHER_BRICK, "&b&lSpecial Blocks", this.specialBlocksLore()));
        inventory.setItem(26, this.namedItem(Material.BOOK, "&b&lPrison Riot Rules", this.rulesLore()));
    }

    private void refreshShop(Inventory inventory, Player player) {
        inventory.setItem(4, this.balanceItem(player));
        inventory.setItem(10, this.shopItem(15, "basic_cont"));
        inventory.setItem(11, this.shopItem(20, "rare_cont"));
        inventory.setItem(12, this.shopItem(25, "elite_cont"));
        inventory.setItem(13, this.shopItem(50, "legendary_cont"));
    }

    private void refreshGamemodes(Inventory inventory) {
        inventory.setItem(13, this.namedItem(Material.NETHER_STAR, "&b&l" + this.riotService.getModeName(), this.gamemodeLore()));
    }

    private void refreshSpecialBlocks(Inventory inventory) {
        inventory.setItem(10, this.blockItem(Material.COAL_ORE, "Coal Ore", this.riotService.getOrePoints(Material.COAL_ORE)));
        inventory.setItem(11, this.blockItem(Material.IRON_ORE, "Iron Ore", this.riotService.getOrePoints(Material.IRON_ORE)));
        inventory.setItem(12, this.blockItem(Material.LAPIS_ORE, "Lapis Ore", this.riotService.getOrePoints(Material.LAPIS_ORE)));
        inventory.setItem(13, this.blockItem(Material.EMERALD_ORE, "Emerald Ore", this.riotService.getOrePoints(Material.EMERALD_ORE)));
        inventory.setItem(14, this.blockItem(Material.GOLD_ORE, "Gold Ore", this.riotService.getOrePoints(Material.GOLD_ORE)));
        inventory.setItem(15, this.blockItem(Material.REDSTONE_ORE, "Redstone Ore", this.riotService.getOrePoints(Material.REDSTONE_ORE)));
        inventory.setItem(16, this.blockItem(Material.DIAMOND_ORE, "Diamond Ore", this.riotService.getOrePoints(Material.DIAMOND_ORE)));
    }

    private void refreshRules(Inventory inventory) {
        inventory.setItem(13, this.namedItem(Material.BOOK, "&b&lPrison Riot Rules", this.rulesLore()));
    }

    private ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.setDisplayName(Text.color(name));
        if (lore != null) {
            meta.setLore(lore);
        }
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack blockItem(Material material, String label, int points) {
        List<String> lore = new ArrayList<>();
        lore.add(Text.color("&7Points per block: &f" + points));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Break these during the event"));
        lore.add(Text.color("&7to build your placement."));
        return this.namedItem(material, "&b&l" + label, lore);
    }

    private List<String> riotLore() {
        ArrayList<String> lore = new ArrayList<>();
        lore.add(Text.color("&e&lMODE: &f" + this.riotService.getModeName()));
        lore.add(Text.color("&e&lSTARTS IN: &f&n" + this.riotService.getStartCountdownText()));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Break blocks to compete with prisoners in a non"));
        lore.add(Text.color("&7PvP enabled arena."));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&e&l* &f&lRequires Level: &710 or above"));
        lore.add(Text.color("&e&l* &f&lRounds: &7" + this.riotService.getTotalRounds()));
        lore.add(Text.color("&e&l* &f&lTime Per Round: &7" + this.prettyDuration(this.riotService.getRoundLengthSeconds())));
        lore.add(Text.color("&e&l* &f&lEvent Duration: &7" + this.prettyDuration(this.riotService.getRoundLengthSeconds() * this.riotService.getTotalRounds())));
        lore.add(Text.color("&e&l* &f&lMax Players: &7" + this.riotService.getMaxPlayers()));
        lore.add(Text.color("&e&l* &f&lSafe: &7Yes (PvP Disabled)"));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Queue Opens In: " + this.prettyDuration(this.riotService.getQueueDurationSeconds())));
        return lore;
    }

    private List<String> shopLore(Player player) {
        ArrayList<String> lore = new ArrayList<>();
        int points = this.playerDataService.get(player.getUniqueId()).getPrisonRiotShopPoints();
        lore.add(Text.color("&7Your balance: &f" + points));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Spend riot shop points on"));
        lore.add(Text.color("&7contraband rewards here."));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&eClick a contraband to purchase"));
        return lore;
    }

    private ItemStack balanceItem(Player player) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        int points = this.playerDataService.get(player.getUniqueId()).getPrisonRiotShopPoints();
        meta.setDisplayName(Text.color("&c&lRiot Shop Points"));
        ArrayList<String> lore = new ArrayList<>();
        lore.add(Text.color("&7Your balance: &f" + points));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Purchase contraband from the"));
        lore.add(Text.color("&7riot shop with these points."));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack shopItem(int cost, String contrabandId) {
        ItemStack output = this.contrabandService == null ? null : this.contrabandService.createContraband(contrabandId);
        ItemStack item = output != null ? output.clone() : new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        ArrayList<String> lore = new ArrayList<>();
        if (meta.hasLore()) {
            lore.addAll(meta.getLore());
        }
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Current Price: &f" + cost + " riot points"));
        lore.add(Text.color("&eLeft-Click &7to purchase"));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isShopSlot(int slot) {
        return slot == 10 || slot == 11 || slot == 12 || slot == 13;
    }

    private ShopEntry entryForSlot(int slot) {
        for (ShopEntry entry : ShopEntry.values()) {
            if (entry.slot == slot) {
                return entry;
            }
        }
        return null;
    }

    private void purchaseShopEntry(Player player, ShopEntry entry) {
        if (player == null || entry == null) {
            return;
        }
        int current = this.playerDataService.get(player.getUniqueId()).getPrisonRiotShopPoints();
        if (current < entry.cost) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
            player.sendMessage(Text.color("&cYou need " + entry.cost + " riot points."));
            return;
        }
        ItemStack reward = entry.createReward(this);
        if (reward == null) {
            player.sendMessage(Text.color("&cThat contraband is not configured."));
            return;
        }
        this.playerDataService.update(player.getUniqueId(), data -> data.setPrisonRiotShopPoints(current - entry.cost));
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, reward);
        } else {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(reward);
            leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(Text.color("&aPurchased " + Text.strip(entry.displayName) + " &afor &f" + entry.cost + " riot points."));
        player.getOpenInventory().getTopInventory().setItem(4, this.balanceItem(player));
    }

    private List<String> gamemodeLore() {
        ArrayList<String> lore = new ArrayList<>();
        lore.add(Text.color("&7Current mode: &f" + this.riotService.getModeName()));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7The riot is non-PvP and"));
        lore.add(Text.color("&7built around mining points."));
        return lore;
    }

    private List<String> specialBlocksLore() {
        ArrayList<String> lore = new ArrayList<>();
        lore.add(Text.color("&7Coal, iron, lapis, gold,"));
        lore.add(Text.color("&7redstone, diamond, emerald."));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&eClick to view block point values"));
        return lore;
    }

    private List<String> rulesLore() {
        ArrayList<String> lore = new ArrayList<>();
        lore.add(Text.color("&7Break blocks and score points."));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7PvP is disabled."));
        lore.add(Text.color("&7Keep mining through all rounds."));
        return lore;
    }

    private List<String> backLore() {
        ArrayList<String> lore = new ArrayList<>();
        lore.add(Text.color("&7Return to the main menu."));
        return lore;
    }

    private void fill(Inventory inventory) {
        ItemStack pane = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            pane.setItemMeta(meta);
        }
        for (int i = 0; i < inventory.getSize(); ++i) {
            inventory.setItem(i, pane);
        }
    }

    private String formatSeconds(int seconds) {
        int safe = Math.max(0, seconds);
        int minutes = safe / 60;
        int remain = safe % 60;
        return String.format("%d:%02d", minutes, remain);
    }

    private String prettyDuration(int seconds) {
        int minutes = Math.max(1, seconds / 60);
        return minutes + (minutes == 1 ? " minute" : " minutes");
    }

    private enum MenuType {
        MAIN,
        SHOP,
        GAMEMODES,
        SPECIAL_BLOCKS,
        RULES
    }

    private enum ShopEntry {
        BASIC_CONTRABAND(10, 15, "basic_cont", "&fBasic Contraband"),
        RARE_CONTRABAND(11, 20, "rare_cont", "&9Rare Contraband"),
        ELITE_CONTRABAND(12, 25, "elite_cont", "&dElite Contraband"),
        LEGENDARY_CONTRABAND(13, 50, "legendary_cont", "&6Legendary Contraband");

        private final int slot;
        private final int cost;
        private final String contrabandId;
        private final String displayName;

        ShopEntry(int slot, int cost, String contrabandId, String displayName) {
            this.slot = slot;
            this.cost = cost;
            this.contrabandId = contrabandId;
            this.displayName = displayName;
        }

        private ItemStack createReward(PrisonRiotMenu menu) {
            return menu.contrabandService == null ? null : menu.contrabandService.createContraband(this.contrabandId);
        }
    }

    private static final class RiotHolder implements InventoryHolder {
        private final MenuType type;
        private Inventory inventory;

        private RiotHolder(MenuType type) {
            this.type = type;
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
