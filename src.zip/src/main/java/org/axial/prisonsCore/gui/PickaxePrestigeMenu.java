package org.axial.prisonsCore.gui;

import java.util.List;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.PickaxeManager.PrestigeBuff;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class PickaxePrestigeMenu implements Listener {
    private static final int SIZE = 27;
    private final PrisonsCore plugin;
    private final PickaxeManager pickaxeManager;

    public PickaxePrestigeMenu(PrisonsCore plugin, PickaxeManager pickaxeManager) {
        this.plugin = plugin;
        this.pickaxeManager = pickaxeManager;
    }

    public void open(Player player) {
        ItemStack held = player.getInventory().getItemInMainHand();
        if (!this.pickaxeManager.isPrisonPickaxe(held)) {
            player.sendMessage(Text.color("&cHold a prison pickaxe."));
            return;
        }
        if (!this.pickaxeManager.hasPrestigeToken(held)) {
            player.sendMessage(Text.color("&cApply a prestige token first."));
            return;
        }
        if (!this.pickaxeManager.canPrestige(held)) {
            player.sendMessage(Text.color("&cYou do not meet the prestige requirements."));
            return;
        }
        Inventory inv = Bukkit.createInventory(new Holder(), SIZE, Text.color("&dPickaxe Prestige"));
        this.fill(inv);
        for (PrestigeBuff buff : PrestigeBuff.values()) {
            inv.setItem(this.slotFor(buff), this.buildBuffItem(held, buff));
        }
        player.openInventory(inv);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder)) {
            return;
        }
        event.setCancelled(true);
        if (event.getRawSlot() < 0 || event.getRawSlot() >= event.getInventory().getSize()) {
            return;
        }
        Player player = (Player)event.getWhoClicked();
        PrestigeBuff buff = this.getBuff(event.getRawSlot());
        if (buff == null) {
            return;
        }
        ItemStack pickaxe = player.getInventory().getItemInMainHand();
        if (!this.pickaxeManager.isPrisonPickaxe(pickaxe) || !this.pickaxeManager.hasPrestigeToken(pickaxe) || !this.pickaxeManager.canPrestige(pickaxe)) {
            player.closeInventory();
            return;
        }
        if (this.pickaxeManager.isPrestigeBuffMaxed(pickaxe, buff)) {
            player.sendMessage(Text.color("&cThat buff is already at its maximum level."));
            return;
        }
        if (!this.pickaxeManager.addPrestigeBuffLevel(pickaxe, buff)) {
            player.sendMessage(Text.color("&cThat buff could not be upgraded."));
            return;
        }
        this.pickaxeManager.consumePrestigeTokenAndReset(pickaxe);
        player.sendMessage(Text.color("&aApplied &b" + buff.getDisplayName() + " &ato your pickaxe."));
        player.closeInventory();
    }

    private void fill(Inventory inventory) {
        ItemStack pane = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            pane.setItemMeta(meta);
        }
        for (int i = 0; i < inventory.getSize(); ++i) {
            inventory.setItem(i, pane);
        }
    }

    private ItemStack buildBuffItem(ItemStack pickaxe, PrestigeBuff buff) {
        ItemStack item = new ItemStack(this.iconFor(buff));
        ItemMeta meta = item.getItemMeta();
        int level = this.pickaxeManager.getPrestigeBuffLevel(pickaxe, buff);
        if (meta != null) {
            meta.setDisplayName(Text.color("&b&l" + buff.getDisplayName()));
            String description = this.pickaxeManager.getPrestigeBuffDescription(pickaxe, buff);
            List<String> lore = new java.util.ArrayList<String>();
            lore.add(Text.color("&7" + (description == null ? buff.describe(Math.max(1, level)) : description)));
            if (buff == PrestigeBuff.FRAGMENT_FINDER) {
                lore.add(Text.color("&7Current fragment chance bonus: &f+" + this.pickaxeManager.getFragmentFinderChanceBonusPercent(pickaxe) + "%"));
            }
            lore.add("");
            lore.add(Text.color("&f&lLevel: &7" + level + " / " + buff.getMaxLevel()));
            lore.add("");
            lore.add(Text.color(level >= buff.getMaxLevel() ? "&f&lMax Level Reached" : "&aClick to apply this buff"));
            meta.setLore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private PrestigeBuff getBuff(int slot) {
        return switch (slot) {
            case 10 -> PrestigeBuff.INTENSITY;
            case 11 -> PrestigeBuff.DRILL;
            case 12 -> PrestigeBuff.XP_MASTERY;
            case 13 -> PrestigeBuff.VANISH;
            case 14 -> PrestigeBuff.HOARDER;
            case 15 -> PrestigeBuff.FRAGMENT_FINDER;
            case 16 -> PrestigeBuff.PIT_RECHARGE;
            default -> null;
        };
    }

    private int slotFor(PrestigeBuff buff) {
        return switch (buff) {
            case INTENSITY -> 10;
            case DRILL -> 11;
            case XP_MASTERY -> 12;
            case VANISH -> 13;
            case HOARDER -> 14;
            case FRAGMENT_FINDER -> 15;
            case PIT_RECHARGE -> 16;
        };
    }

    private Material iconFor(PrestigeBuff buff) {
        return switch (buff) {
            case INTENSITY -> Material.NETHERITE_CHESTPLATE;
            case DRILL -> Material.DIAMOND_PICKAXE;
            case XP_MASTERY -> Material.EXPERIENCE_BOTTLE;
            case VANISH -> Material.ENDER_EYE;
            case HOARDER -> Material.CHEST;
            case FRAGMENT_FINDER -> Material.AMETHYST_SHARD;
            case PIT_RECHARGE -> Material.ENCHANTED_BOOK;
        };
    }

    private static final class Holder implements InventoryHolder {
        private Holder() {
        }

        @Override
        public Inventory getInventory() {
            return null;
        }
    }
}
