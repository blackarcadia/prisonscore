package org.axial.prisonsCore.gui;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.ChargeOrbService;
import org.axial.prisonsCore.service.EnergyItemService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class TinkererMenu implements Listener {
    private static final int SIZE = 54;
    private static final int ITEM_START = 9;
    private static final int ITEM_END = 44;
    private static final int CONFIRM_SLOT = 4;
    private static final int BOTTOM_ROW_START = 45;
    private final PrisonsCore plugin;
    private final PickaxeManager pickaxeManager;
    private final GearManager gearManager;
    private final ChargeOrbService chargeOrbService;
    private final EnergyItemService energyItemService;
    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();

    public TinkererMenu(PrisonsCore plugin, PickaxeManager pickaxeManager, GearManager gearManager, ChargeOrbService chargeOrbService, EnergyItemService energyItemService) {
        this.plugin = plugin;
        this.pickaxeManager = pickaxeManager;
        this.gearManager = gearManager;
        this.chargeOrbService = chargeOrbService;
        this.energyItemService = energyItemService;
    }

    public void open(Player player) {
        Session existing = this.sessions.remove(player.getUniqueId());
        if (existing != null) {
            this.returnItems(player, existing);
        }
        Session session = new Session(player.getUniqueId());
        Inventory inventory = Bukkit.createInventory((InventoryHolder)session, SIZE, Text.color("&8Tinkerer"));
        session.inventory = inventory;
        this.fillBackground(inventory);
        this.refreshFooter(session);
        player.playSound(player.getLocation(), Sound.ENTITY_VILLAGER_TRADE, 1.0f, 1.0f);
        player.openInventory(inventory);
        this.sessions.put(player.getUniqueId(), session);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Session session)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int raw = event.getRawSlot();
        if (raw < event.getView().getTopInventory().getSize()) {
            if (raw == CONFIRM_SLOT) {
                event.setCancelled(true);
                this.confirm(session, player);
                return;
            }
            if (raw >= ITEM_START && raw <= ITEM_END) {
                ItemStack current = event.getCurrentItem();
                if (current != null && !current.getType().isAir()) {
                    event.setCancelled(true);
                    this.returnItem(player, session, raw, current);
                    this.refreshFooter(session);
                    return;
                }
            }
            event.setCancelled(true);
            return;
        }
        ItemStack current = event.getCurrentItem();
        if (current == null || current.getType().isAir()) {
            return;
        }
        if (!this.isEligible(current)) {
            event.setCancelled(true);
            player.sendMessage(Text.color("&cThat item cannot be tinkered."));
            return;
        }
        event.setCancelled(true);
        if (!this.placeIntoTinkerer(session, current.clone())) {
            player.sendMessage(Text.color("&cThe tinkerer is full."));
            return;
        }
        if (event.getClickedInventory() != null) {
            event.getClickedInventory().setItem(event.getSlot(), null);
        }
        this.playXpSound(player);
        this.refreshFooter(session);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Session)) {
            return;
        }
        int topSize = event.getView().getTopInventory().getSize();
        for (Integer raw : event.getRawSlots()) {
            if (raw != null && raw.intValue() < topSize) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof Session session)) {
            return;
        }
        this.sessions.remove(session.owner);
        if (session.confirmed || session.returned) {
            return;
        }
        this.returnItems((Player)event.getPlayer(), session);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        InventoryHolder holder = event.getPlayer().getOpenInventory().getTopInventory().getHolder();
        if (!(holder instanceof Session session)) {
            return;
        }
        this.sessions.remove(session.owner);
        if (session.confirmed || session.returned) {
            return;
        }
        this.returnItems(event.getPlayer(), session);
    }

    private void confirm(Session session, Player player) {
        if (session.confirmed || session.returned) {
            return;
        }
        List<ItemStack> items = session.items();
        if (items.isEmpty()) {
            player.sendMessage(Text.color("&cPlace some eligible items into the tinkerer first."));
            return;
        }
        int totalCharge = this.calculateCharge(items);
        if (totalCharge <= 0) {
            player.sendMessage(Text.color("&cThose items have no tinkerer value."));
            return;
        }
        session.confirmed = true;
        session.clearItems();
        this.sessions.remove(session.owner);
        if (this.energyItemService != null) {
            this.energyItemService.giveEnergyItem(player, totalCharge);
        }
        player.sendMessage(Text.color("&aTinkerer accepted for &e" + String.format("%,d", totalCharge) + " &acharge."));
        player.closeInventory();
    }

    private void returnItems(Player player, Session session) {
        if (session == null || player == null || session.returned) {
            return;
        }
        session.returned = true;
        boolean returnedAny = false;
        for (int slot = ITEM_START; slot <= ITEM_END; ++slot) {
            ItemStack stack = session.inventory.getItem(slot);
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
            leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
            session.inventory.setItem(slot, null);
            returnedAny = true;
        }
        if (returnedAny) {
            this.playXpSound(player);
        }
    }

    private void returnItem(Player player, Session session, int slot, ItemStack stack) {
        if (session == null || player == null || session.returned || slot < ITEM_START || slot > ITEM_END) {
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack.clone());
        leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        session.inventory.setItem(slot, null);
        this.playXpSound(player);
    }

    private boolean placeIntoTinkerer(Session session, ItemStack stack) {
        if (session == null || session.inventory == null || stack == null || stack.getType().isAir()) {
            return false;
        }
        for (int slot = ITEM_START; slot <= ITEM_END; ++slot) {
            ItemStack existing = session.inventory.getItem(slot);
            if (existing != null && !existing.getType().isAir()) {
                continue;
            }
            session.inventory.setItem(slot, stack);
            return true;
        }
        return false;
    }

    private boolean isEligible(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return false;
        }
        if (this.chargeOrbService != null && (this.chargeOrbService.isChargeOrb(stack) || this.isChargeOrbVisual(stack))) {
            return true;
        }
        if (this.pickaxeManager != null && this.pickaxeManager.isPrisonPickaxe(stack)) {
            return true;
        }
        if (this.hasGearEnchantData(stack)) {
            return true;
        }
        return false;
    }

    private boolean isChargeOrbVisual(ItemStack stack) {
        if (this.chargeOrbService == null || stack == null || stack.getType().isAir()) {
            return false;
        }
        if (stack.getType() != this.chargeOrbService.getMaterial() || !stack.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) {
            return false;
        }
        String display = Text.strip(meta.getDisplayName()).toLowerCase(Locale.ROOT);
        return display.contains("charge orb");
    }

    private void playXpSound(Player player) {
        if (player == null) {
            return;
        }
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.3f);
    }

    private int calculateCharge(List<ItemStack> items) {
        int total = 0;
        for (ItemStack stack : items) {
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            total += this.calculateCharge(stack);
        }
        return total;
    }

    private int calculateCharge(ItemStack stack) {
        int amount = Math.max(1, stack.getAmount());
        if (this.chargeOrbService != null && this.chargeOrbService.isChargeOrb(stack)) {
            return Math.max(1, this.chargeOrbService.getPercent(stack) * 150 * amount);
        }
        int value = 0;
        if (this.pickaxeManager != null && this.pickaxeManager.isPrisonPickaxe(stack)) {
            value += this.pickaxeManager.getLevel(stack) * 200;
            value += this.sumEnchantValue(this.pickaxeManager.getEnchants(stack));
            value += this.pickaxeManager.getTotalChargePercent(stack) * 100;
        } else if (this.hasGearEnchantData(stack) && this.gearManager != null && this.gearManager.isGear(stack)) {
            value += this.gearManager.getLevel(stack) * 200;
            value += this.sumEnchantValue(this.gearManager.getEnchants(stack));
        }
        return Math.max(1, value * amount);
    }

    private boolean hasGearEnchantData(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return false;
        }
        return stack.getItemMeta().getPersistentDataContainer().has(Keys.gearEnchants(this.plugin), PersistentDataType.STRING);
    }

    private int sumEnchantValue(Map<String, Integer> enchants) {
        if (enchants == null || enchants.isEmpty()) {
            return 0;
        }
        int total = 0;
        for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
            int level = Math.max(1, entry.getValue());
            total += 100 + (level * 125);
        }
        return total;
    }

    private void refreshFooter(Session session) {
        if (session == null || session.inventory == null) {
            return;
        }
        int itemCount = 0;
        int totalCharge = 0;
        for (int slot = ITEM_START; slot <= ITEM_END; ++slot) {
            ItemStack stack = session.inventory.getItem(slot);
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            ++itemCount;
            totalCharge += this.calculateCharge(stack);
        }
        session.inventory.setItem(CONFIRM_SLOT, this.confirmItem(totalCharge, itemCount > 0));
    }

    private ItemStack confirmItem(int totalCharge, boolean enabled) {
        ItemStack stack = new ItemStack(enabled ? Material.LIME_DYE : Material.RED_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(enabled ? "&a&lACCEPT &7(Click)" : "&c&lNOTHING OFFERED"));
            List<String> lore = new ArrayList<String>();
            if (enabled) {
                lore.add("");
                lore.add(Text.color("&d&lTinkerer will return:"));
                lore.add(Text.color("&d&l* &f" + Text.formatNumber(Math.max(0, totalCharge)) + " &d&lRaw Charge"));
                lore.add("");
                lore.add(Text.color("&c-----&c&l WARNING &c -----"));
                lore.add(Text.color("&cAll items traded will be lost forever!"));
            } else {
                lore.add("");
                lore.add(Text.color("&7Offer pickaxes/gear/charge orbs"));
                lore.add(Text.color("&7and enchants to trade for raw charge."));
            }
            meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private void fillBackground(Inventory inventory) {
        ItemStack pane = this.backgroundPane();
        for (int slot = 0; slot < 9; ++slot) {
            if (slot != CONFIRM_SLOT) {
                inventory.setItem(slot, pane);
            }
        }
        for (int slot = BOTTOM_ROW_START; slot < SIZE; ++slot) {
            inventory.setItem(slot, pane);
        }
    }

    private ItemStack backgroundPane() {
        ItemStack stack = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private static final class Session implements InventoryHolder {
        private final UUID owner;
        private Inventory inventory;
        private boolean confirmed;
        private boolean returned;

        private Session(UUID owner) {
            this.owner = owner;
        }

        private List<ItemStack> items() {
            ArrayList<ItemStack> items = new ArrayList<ItemStack>();
            if (this.inventory == null) {
                return items;
            }
            for (int slot = ITEM_START; slot <= ITEM_END; ++slot) {
                ItemStack stack = this.inventory.getItem(slot);
                if (stack == null || stack.getType().isAir()) {
                    continue;
                }
                items.add(stack.clone());
            }
            return items;
        }

        private void clearItems() {
            if (this.inventory == null) {
                return;
            }
            for (int slot = ITEM_START; slot <= ITEM_END; ++slot) {
                this.inventory.setItem(slot, null);
            }
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
