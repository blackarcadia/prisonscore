package org.axial.prisonsCore.gui;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import org.axial.prisonsCore.cell.guard.CellGuardService;
import org.axial.prisonsCore.cell.guard.CellGuardTier;
import net.kyori.adventure.text.Component;
import org.axial.prisonsCore.cell.CellDoorType;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.model.PickaxeType;
import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.service.FeatureToggleService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.GeneratorService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.SatchelManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ShopMenu implements Listener {
    private static final int ROOT_INVENTORY_SIZE = 36;
    private static final int CATEGORY_INVENTORY_SIZE = 36;
    private static final int GEAR_CATEGORY_INVENTORY_SIZE = 45;
    private static final int GENERATOR_CATEGORY_INVENTORY_SIZE = 45;
    private static final int[] CATEGORY_SLOTS = new int[]{11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
    private static final int[] DEFAULT_ITEM_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};
    private static final int[] GEAR_ITEM_SLOTS = new int[]{0, 1, 2, 3, 5, 6, 9, 10, 11, 12, 14, 15, 18, 19, 20, 21, 23, 24, 27, 28, 29, 30, 32, 33};
    private static final int[] GENERATOR_ITEM_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 28, 29, 30, 31, 32, 33, 34};
    private static final int PAGED_INVENTORY_SIZE = 45;
    private static final int[] PAGED_ITEM_SLOTS = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35};
    private static final int PAGED_PREV_SLOT = 39;
    private static final int PAGED_BACK_SLOT = 40;
    private static final int PAGED_NEXT_SLOT = 41;
    private final EconomyService economyService;
    private final PickaxeManager pickaxeManager;
    private final GearManager gearManager;
    private final CellService cellService;
    private final CellGuardService cellGuardService;
    private final GeneratorService generatorService;
    private final FeatureToggleService featureToggleService;
    private final SatchelManager satchelManager;
    private final Map<Category, List<ShopItem>> itemsByCategory = new EnumMap<>(Category.class);

    public ShopMenu(EconomyService economyService, PickaxeManager pickaxeManager, GearManager gearManager, CellService cellService, CellGuardService cellGuardService, GeneratorService generatorService, FeatureToggleService featureToggleService, SatchelManager satchelManager) {
        this.economyService = economyService;
        this.pickaxeManager = pickaxeManager;
        this.gearManager = gearManager;
        this.cellService = cellService;
        this.cellGuardService = cellGuardService;
        this.generatorService = generatorService;
        this.featureToggleService = featureToggleService;
        this.satchelManager = satchelManager;
        this.loadItems();
    }

    public void open(Player player) {
        RootHolder holder = new RootHolder();
        Inventory inventory = Bukkit.createInventory(holder, ROOT_INVENTORY_SIZE, Text.color("&8Server Shop"));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        for (int i = 0; i < Category.values().length && i < CATEGORY_SLOTS.length; ++i) {
            Category category = Category.values()[i];
            inventory.setItem(CATEGORY_SLOTS[i], this.categoryItem(category));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.0f);
        player.openInventory(inventory);
    }

    private void openCategory(Player player, Category category) {
        List<ShopItem> items = this.itemsByCategory.getOrDefault(category, List.of());
        int[] itemSlots = this.itemSlots(category);
        if (items.size() > itemSlots.length) {
            this.openPagedCategory(player, category, 0, itemSlots);
            return;
        }
        CategoryHolder holder = new CategoryHolder(category);
        Inventory inventory = Bukkit.createInventory(holder, this.inventorySize(category), Text.color("&8" + Text.strip(category.displayName)));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        inventory.setItem(this.backSlot(category), this.namedItem(Material.NETHER_STAR, "&c&lBack"));
        for (int i = 0; i < items.size() && i < itemSlots.length; ++i) {
            inventory.setItem(itemSlots[i], this.shopItem(player, items.get(i)));
        }
        if (items.isEmpty()) {
            inventory.setItem(22, this.infoItem(Material.BARRIER, "&cEmpty", List.of("&7This category has not been", "&7configured yet.")));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.0f);
        player.openInventory(inventory);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof BaseHolder holder)) {
            return;
        }
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            event.setCancelled(true);
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (!this.featureToggleService.checkEnabled(player, FeatureToggleService.Feature.SHOP)) {
            return;
        }
        int slot = event.getRawSlot();
        if (holder instanceof RootHolder) {
            this.handleRootClick(player, slot);
            return;
        }
        if (holder instanceof PagedCategoryHolder pagedHolder) {
            this.handlePagedCategoryClick(player, pagedHolder, slot, event.getClick());
            return;
        }
        if (holder instanceof CategoryHolder categoryHolder) {
            this.handleCategoryClick(player, categoryHolder.category, slot, event.getClick());
        }
    }

    private void handleRootClick(Player player, int slot) {
        for (int i = 0; i < CATEGORY_SLOTS.length && i < Category.values().length; ++i) {
            if (CATEGORY_SLOTS[i] != slot) continue;
            this.openCategory(player, Category.values()[i]);
            return;
        }
    }

    private void handleCategoryClick(Player player, Category category, int slot, ClickType click) {
        List<ShopItem> items = this.itemsByCategory.getOrDefault(category, List.of());
        int[] itemSlots = this.itemSlots(category);
        if (items.size() > itemSlots.length) {
            this.openPagedCategory(player, category, 0, itemSlots);
            return;
        }
        if (slot == this.backSlot(category)) {
            this.open(player);
            return;
        }
        for (int i = 0; i < items.size() && i < itemSlots.length; ++i) {
            if (itemSlots[i] != slot) continue;
            this.handleShopItemClick(player, items.get(i), click);
            return;
        }
    }

    private void handleShopItemClick(Player player, ShopItem shopItem, ClickType click) {
        if (this.purchasePrice(player, shopItem) > 0.0 && click.isLeftClick()) {
            this.handlePurchase(player, shopItem);
            return;
        }
        if (click.isLeftClick()) {
            player.sendMessage(Text.color("&cThis item can not be purchased."));
            return;
        }
        if (!click.isRightClick()) {
            return;
        }
        if (!shopItem.sellable) {
            player.sendMessage(Text.color("&cThis item can not be sold."));
            return;
        }
        double worth = this.economyService.getWorth(shopItem.material);
        if (worth <= 0.0) {
            player.sendMessage(Text.color("&cThis item can not be sold right now."));
            return;
        }
        int amount = click.isShiftClick() ? this.countItems(player, shopItem.material) : this.countItems(player, shopItem.material) > 0 ? 1 : 0;
        if (amount <= 0) {
            player.sendMessage(Text.color("&cYou do not have any " + this.prettyName(shopItem.material) + "&c to sell."));
            return;
        }
        int removed = this.removeItems(player, shopItem.material, amount);
        if (removed <= 0) {
            player.sendMessage(Text.color("&cYou do not have any " + this.prettyName(shopItem.material) + "&c to sell."));
            return;
        }
        double total = worth * (double)removed;
        total = this.economyService.applySellBoost(player, total);
        this.economyService.deposit(player, total);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(Text.color("&aSold " + removed + "x " + this.prettyName(shopItem.material) + " &afor &2" + this.economyService.format(total)));
    }

    private void handlePurchase(Player player, ShopItem shopItem) {
        if (shopItem.pickaxeTypeId == null && shopItem.doorType == null && shopItem.gearMaterial == null && shopItem.guardTier == null && shopItem.generatorTier == null && shopItem.refinedTier == null && shopItem.satchelMaterial == null && shopItem.purchasePrice <= 0.0) {
            player.sendMessage(Text.color("&cThis item can not be purchased."));
            return;
        }
        double price = this.purchasePrice(player, shopItem);
        if (price <= 0.0) {
            player.sendMessage(Text.color("&cThis item can not be purchased."));
            return;
        }
        if (this.economyService.getBalance(player) < price) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
            player.sendMessage(Text.color("&cYou need &f" + this.economyService.format(price) + " &cto buy this item."));
            return;
        }
        if (!this.economyService.withdraw(player, price)) {
            player.sendMessage(Text.color("&cPurchase failed."));
            return;
        }
        if (shopItem.pickaxeTypeId != null) {
            PickaxeType type = this.pickaxeManager.getType(shopItem.pickaxeTypeId);
            if (type == null) {
                this.economyService.deposit(player, price);
                player.sendMessage(Text.color("&cThat pickaxe is not configured."));
                return;
            }
            ItemStack pickaxe = this.pickaxeManager.createPickaxe(type, 0);
            if (this.pickaxeManager.getPlugin().getStashService() != null) {
                this.pickaxeManager.getPlugin().getStashService().giveOrStash(player, pickaxe);
            } else {
                player.getInventory().addItem(pickaxe).values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
            }
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aPurchased " + Text.strip(type.getDisplayName()) + " &afor &2" + this.economyService.format(price)));
            return;
        }
        if (shopItem.doorType != null) {
            player.getInventory().addItem(this.cellService.createDoorItem(shopItem.doorType, 1));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aPurchased " + shopItem.doorType.name() + " Cell Door &afor &2" + this.economyService.format(price)));
            return;
        }
        if (shopItem.guardTier != null) {
            player.getInventory().addItem(this.cellGuardService.createGuardAnchor(shopItem.guardTier, 1));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aPurchased " + shopItem.guardTier.name() + " Cell Guard &afor &2" + this.economyService.format(price)));
            return;
        }
        if (shopItem.generatorTier != null) {
            player.getInventory().addItem(this.generatorService.createGeneratorItem(shopItem.generatorTier));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aPurchased " + shopItem.generatorTier.name() + " Generator &afor &2" + this.economyService.format(price)));
            return;
        }
        if (shopItem.refinedTier != null) {
            player.getInventory().addItem(this.generatorService.createRefinedItem(shopItem.refinedTier));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aPurchased " + shopItem.refinedTier.name() + " Refined Ore &afor &2" + this.economyService.format(price)));
            return;
        }
        if (shopItem.satchelMaterial != null) {
            player.getInventory().addItem(this.satchelManager.createSatchel(shopItem.satchelMaterial));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aPurchased " + this.prettyName(shopItem.satchelMaterial) + " Satchel &afor &2" + this.economyService.format(price)));
            return;
        }
        if (shopItem.gearMaterial != null) {
            player.getInventory().addItem(this.gearManager.wrap(new ItemStack(shopItem.gearMaterial), shopItem.gearMaterial.name().toLowerCase()));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aPurchased " + this.prettyName(shopItem.gearMaterial) + " &afor &2" + this.economyService.format(price)));
            return;
        }
        player.getInventory().addItem(new ItemStack(shopItem.material));
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(Text.color("&aPurchased " + this.prettyName(shopItem.material) + " &afor &2" + this.economyService.format(price)));
    }

    private int countItems(Player player, Material material) {
        int total = 0;
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack == null || stack.getType() != material) continue;
            total += stack.getAmount();
        }
        return total;
    }

    private int removeItems(Player player, Material material, int amount) {
        int remaining = amount;
        for (int slot = 0; slot < player.getInventory().getSize() && remaining > 0; ++slot) {
            ItemStack stack = player.getInventory().getItem(slot);
            if (stack == null || stack.getType() != material) continue;
            int remove = Math.min(remaining, stack.getAmount());
            remaining -= remove;
            if (remove == stack.getAmount()) {
                player.getInventory().setItem(slot, null);
            } else {
                stack.setAmount(stack.getAmount() - remove);
                player.getInventory().setItem(slot, stack);
            }
        }
        return amount - remaining;
    }

    private void loadItems() {
        this.itemsByCategory.clear();
        this.itemsByCategory.put(Category.ORES, this.oresItems());
        this.itemsByCategory.put(Category.PICKAXES, this.pickaxesItems());
        this.itemsByCategory.put(Category.GEAR_WEAPONS, this.gearWeaponsItems());
        this.itemsByCategory.put(Category.DOORS, this.doorsItems());
        this.itemsByCategory.put(Category.GENERATORS, this.generatorsItems());
        this.itemsByCategory.put(Category.GENERAL, this.generalItems());
        this.itemsByCategory.put(Category.WOODWORK, this.woodworkItems());
        this.itemsByCategory.put(Category.STONECRAFTER, this.stonecrafterItems());
        this.itemsByCategory.put(Category.GLASSWORK, this.glassworkItems());
        this.itemsByCategory.put(Category.WEAVER, this.weaverItems());
    }

    private List<ShopItem> oresItems() {
        return List.of(
                ShopItem.sellable(Material.COAL_ORE),
                ShopItem.sellable(Material.COAL),
                ShopItem.sellable(Material.IRON_ORE),
                ShopItem.sellable(Material.IRON_INGOT),
                ShopItem.sellable(Material.LAPIS_ORE),
                ShopItem.sellable(Material.LAPIS_LAZULI),
                ShopItem.sellable(Material.GOLD_ORE),
                ShopItem.sellable(Material.GOLD_INGOT),
                ShopItem.sellable(Material.REDSTONE_ORE),
                ShopItem.sellable(Material.REDSTONE),
                ShopItem.sellable(Material.DIAMOND_ORE),
                ShopItem.sellable(Material.DIAMOND),
                ShopItem.sellable(Material.EMERALD_ORE),
                ShopItem.sellable(Material.EMERALD)
        );
    }

    private List<ShopItem> pickaxesItems() {
        return List.of(
                ShopItem.pickaxe("wooden", 100.0, this.pickaxeManager.getType("wooden")),
                ShopItem.pickaxe("stone", 1000.0, this.pickaxeManager.getType("stone")),
                ShopItem.pickaxe("iron", 3000.0, this.pickaxeManager.getType("iron")),
                ShopItem.pickaxe("golden", 5000.0, this.pickaxeManager.getType("golden")),
                ShopItem.pickaxe("diamond", 10000.0, this.pickaxeManager.getType("diamond")),
                ShopItem.satchel(Material.COAL_ORE),
                ShopItem.satchel(Material.IRON_ORE),
                ShopItem.satchel(Material.GOLD_ORE),
                ShopItem.satchel(Material.LAPIS_ORE),
                ShopItem.satchel(Material.REDSTONE_ORE),
                ShopItem.satchel(Material.DIAMOND_ORE),
                ShopItem.satchel(Material.EMERALD_ORE)
        );
    }

    private List<ShopItem> gearWeaponsItems() {
        return List.of(
                ShopItem.gear(Material.CHAINMAIL_HELMET, 500.0),
                ShopItem.gear(Material.CHAINMAIL_CHESTPLATE, 500.0),
                ShopItem.gear(Material.CHAINMAIL_LEGGINGS, 500.0),
                ShopItem.gear(Material.CHAINMAIL_BOOTS, 500.0),
                ShopItem.gear(Material.STONE_SWORD, 500.0),
                ShopItem.gear(Material.STONE_AXE, 500.0),
                ShopItem.gear(Material.GOLDEN_HELMET, 1000.0),
                ShopItem.gear(Material.GOLDEN_CHESTPLATE, 1000.0),
                ShopItem.gear(Material.GOLDEN_LEGGINGS, 1000.0),
                ShopItem.gear(Material.GOLDEN_BOOTS, 1000.0),
                ShopItem.gear(Material.GOLDEN_SWORD, 1000.0),
                ShopItem.gear(Material.GOLDEN_AXE, 1000.0),
                ShopItem.gear(Material.IRON_HELMET, 2000.0),
                ShopItem.gear(Material.IRON_CHESTPLATE, 2000.0),
                ShopItem.gear(Material.IRON_LEGGINGS, 2000.0),
                ShopItem.gear(Material.IRON_BOOTS, 2000.0),
                ShopItem.gear(Material.IRON_SWORD, 2000.0),
                ShopItem.gear(Material.IRON_AXE, 2000.0),
                ShopItem.gear(Material.DIAMOND_HELMET, 5000.0),
                ShopItem.gear(Material.DIAMOND_CHESTPLATE, 5000.0),
                ShopItem.gear(Material.DIAMOND_LEGGINGS, 5000.0),
                ShopItem.gear(Material.DIAMOND_BOOTS, 5000.0),
                ShopItem.gear(Material.DIAMOND_SWORD, 5000.0),
                ShopItem.gear(Material.DIAMOND_AXE, 5000.0)
        );
    }

    private List<ShopItem> doorsItems() {
        return List.of(
                ShopItem.door(CellDoorType.BASIC, 2000.0),
                ShopItem.door(CellDoorType.ELITE, 8000.0),
                ShopItem.door(CellDoorType.LEGENDARY, 10000.0),
                ShopItem.guard(CellGuardTier.BASIC, 3000.0),
                ShopItem.guard(CellGuardTier.UNIQUE, 4500.0),
                ShopItem.guard(CellGuardTier.RARE, 6000.0),
                ShopItem.guard(CellGuardTier.ELITE, 9000.0),
                ShopItem.guard(CellGuardTier.LEGENDARY, 12000.0)
        );
    }

    private List<ShopItem> generatorsItems() {
        return List.of(
                ShopItem.generator(GeneratorService.GeneratorTier.BASIC, 7500.0),
                ShopItem.generator(GeneratorService.GeneratorTier.UNCOMMON, 12500.0),
                ShopItem.generator(GeneratorService.GeneratorTier.UNIQUE, 20000.0),
                ShopItem.generator(GeneratorService.GeneratorTier.RARE, 30000.0),
                ShopItem.generator(GeneratorService.GeneratorTier.ELITE, 42500.0),
                ShopItem.generator(GeneratorService.GeneratorTier.LEGENDARY, 60000.0),
                ShopItem.generator(GeneratorService.GeneratorTier.MYTHICAL, 87500.0),
                ShopItem.refined(GeneratorService.RefinedTier.BASIC, 4000.0),
                ShopItem.refined(GeneratorService.RefinedTier.UNCOMMON, 6000.0),
                ShopItem.refined(GeneratorService.RefinedTier.UNIQUE, 9000.0),
                ShopItem.refined(GeneratorService.RefinedTier.RARE, 12500.0),
                ShopItem.refined(GeneratorService.RefinedTier.ELITE, 17500.0),
                ShopItem.refined(GeneratorService.RefinedTier.LEGENDARY, 25000.0),
                ShopItem.refined(GeneratorService.RefinedTier.MYTHICAL, 37500.0)
        );
    }

    private List<ShopItem> generalItems() {
        return List.of();
    }

    private List<ShopItem> woodworkItems() {
        ArrayList<ShopItem> items = new ArrayList<>();
        this.addBuyItems(items, 6.0, "OAK_PLANKS", "SPRUCE_PLANKS", "BIRCH_PLANKS", "JUNGLE_PLANKS", "ACACIA_PLANKS", "CHERRY_PLANKS", "DARK_OAK_PLANKS", "MANGROVE_PLANKS", "CRIMSON_PLANKS", "WARPED_PLANKS", "BAMBOO_PLANKS");
        this.addBuyItems(items, 8.0, "OAK_LOG", "SPRUCE_LOG", "BIRCH_LOG", "JUNGLE_LOG", "ACACIA_LOG", "CHERRY_LOG", "DARK_OAK_LOG", "MANGROVE_LOG", "CRIMSON_STEM", "WARPED_STEM", "BAMBOO_BLOCK", "STRIPPED_OAK_LOG", "STRIPPED_SPRUCE_LOG", "STRIPPED_BIRCH_LOG", "STRIPPED_JUNGLE_LOG", "STRIPPED_ACACIA_LOG", "STRIPPED_CHERRY_LOG", "STRIPPED_DARK_OAK_LOG", "STRIPPED_MANGROVE_LOG", "STRIPPED_CRIMSON_STEM", "STRIPPED_WARPED_STEM", "STRIPPED_BAMBOO_BLOCK", "OAK_WOOD", "SPRUCE_WOOD", "BIRCH_WOOD", "JUNGLE_WOOD", "ACACIA_WOOD", "CHERRY_WOOD", "DARK_OAK_WOOD", "MANGROVE_WOOD", "CRIMSON_HYPHAE", "WARPED_HYPHAE", "STRIPPED_OAK_WOOD", "STRIPPED_SPRUCE_WOOD", "STRIPPED_BIRCH_WOOD", "STRIPPED_JUNGLE_WOOD", "STRIPPED_ACACIA_WOOD", "STRIPPED_CHERRY_WOOD", "STRIPPED_DARK_OAK_WOOD", "STRIPPED_MANGROVE_WOOD", "STRIPPED_CRIMSON_HYPHAE", "STRIPPED_WARPED_HYPHAE");
        this.addBuyItems(items, 10.0, "OAK_STAIRS", "SPRUCE_STAIRS", "BIRCH_STAIRS", "JUNGLE_STAIRS", "ACACIA_STAIRS", "CHERRY_STAIRS", "DARK_OAK_STAIRS", "MANGROVE_STAIRS", "CRIMSON_STAIRS", "WARPED_STAIRS", "BAMBOO_STAIRS");
        this.addBuyItems(items, 8.0, "OAK_SLAB", "SPRUCE_SLAB", "BIRCH_SLAB", "JUNGLE_SLAB", "ACACIA_SLAB", "CHERRY_SLAB", "DARK_OAK_SLAB", "MANGROVE_SLAB", "CRIMSON_SLAB", "WARPED_SLAB", "BAMBOO_SLAB");
        this.addBuyItems(items, 10.0, "OAK_FENCE", "SPRUCE_FENCE", "BIRCH_FENCE", "JUNGLE_FENCE", "ACACIA_FENCE", "CHERRY_FENCE", "DARK_OAK_FENCE", "MANGROVE_FENCE", "CRIMSON_FENCE", "WARPED_FENCE", "BAMBOO_FENCE");
        this.addBuyItems(items, 10.0, "OAK_FENCE_GATE", "SPRUCE_FENCE_GATE", "BIRCH_FENCE_GATE", "JUNGLE_FENCE_GATE", "ACACIA_FENCE_GATE", "CHERRY_FENCE_GATE", "DARK_OAK_FENCE_GATE", "MANGROVE_FENCE_GATE", "CRIMSON_FENCE_GATE", "WARPED_FENCE_GATE", "BAMBOO_FENCE_GATE");
        this.addBuyItems(items, 12.0, "OAK_TRAPDOOR", "SPRUCE_TRAPDOOR", "BIRCH_TRAPDOOR", "JUNGLE_TRAPDOOR", "ACACIA_TRAPDOOR", "CHERRY_TRAPDOOR", "DARK_OAK_TRAPDOOR", "MANGROVE_TRAPDOOR", "CRIMSON_TRAPDOOR", "WARPED_TRAPDOOR", "BAMBOO_TRAPDOOR");
        this.addBuyItems(items, 6.0, "OAK_SIGN", "SPRUCE_SIGN", "BIRCH_SIGN", "JUNGLE_SIGN", "ACACIA_SIGN", "CHERRY_SIGN", "DARK_OAK_SIGN", "MANGROVE_SIGN", "CRIMSON_SIGN", "WARPED_SIGN", "BAMBOO_SIGN", "OAK_HANGING_SIGN", "SPRUCE_HANGING_SIGN", "BIRCH_HANGING_SIGN", "JUNGLE_HANGING_SIGN", "ACACIA_HANGING_SIGN", "CHERRY_HANGING_SIGN", "DARK_OAK_HANGING_SIGN", "MANGROVE_HANGING_SIGN", "CRIMSON_HANGING_SIGN", "WARPED_HANGING_SIGN", "BAMBOO_HANGING_SIGN");
        this.addBuyItem(items, "CHEST", 18.0);
        return items;
    }

    private List<ShopItem> stonecrafterItems() {
        ArrayList<ShopItem> items = new ArrayList<>();
        this.addBuyItems(items, 8.0, "STONE", "COBBLESTONE", "MOSSY_COBBLESTONE", "SMOOTH_STONE", "STONE_BRICKS", "CRACKED_STONE_BRICKS", "MOSSY_STONE_BRICKS", "CHISELED_STONE_BRICKS", "SANDSTONE", "CUT_SANDSTONE", "CHISELED_SANDSTONE", "SMOOTH_SANDSTONE", "RED_SANDSTONE", "CUT_RED_SANDSTONE", "CHISELED_RED_SANDSTONE", "SMOOTH_RED_SANDSTONE");
        this.addBuyItems(items, 10.0, "STONE_SLAB", "STONE_STAIRS", "STONE_BRICK_SLAB", "STONE_BRICK_STAIRS", "STONE_BRICK_WALL", "COBBLESTONE_SLAB", "COBBLESTONE_STAIRS", "COBBLESTONE_WALL", "MOSSY_COBBLESTONE_SLAB", "MOSSY_COBBLESTONE_STAIRS", "MOSSY_COBBLESTONE_WALL", "SANDSTONE_SLAB", "SANDSTONE_STAIRS", "SANDSTONE_WALL", "RED_SANDSTONE_SLAB", "RED_SANDSTONE_STAIRS", "RED_SANDSTONE_WALL");
        this.addBuyItems(items, 10.0, "ANDESITE", "POLISHED_ANDESITE", "ANDESITE_SLAB", "ANDESITE_STAIRS", "ANDESITE_WALL", "DIORITE", "POLISHED_DIORITE", "DIORITE_SLAB", "DIORITE_STAIRS", "DIORITE_WALL", "GRANITE", "POLISHED_GRANITE", "GRANITE_SLAB", "GRANITE_STAIRS", "GRANITE_WALL");
        this.addBuyItems(items, 12.0, "DEEPSLATE", "COBBLED_DEEPSLATE", "POLISHED_DEEPSLATE", "DEEPSLATE_BRICKS", "CRACKED_DEEPSLATE_BRICKS", "DEEPSLATE_TILES", "CHISELED_DEEPSLATE", "DEEPSLATE_SLAB", "DEEPSLATE_STAIRS", "DEEPSLATE_WALL", "COBBLED_DEEPSLATE_SLAB", "COBBLED_DEEPSLATE_STAIRS", "COBBLED_DEEPSLATE_WALL", "POLISHED_DEEPSLATE_SLAB", "POLISHED_DEEPSLATE_STAIRS", "POLISHED_DEEPSLATE_WALL", "DEEPSLATE_BRICK_SLAB", "DEEPSLATE_BRICK_STAIRS", "DEEPSLATE_BRICK_WALL", "DEEPSLATE_TILE_SLAB", "DEEPSLATE_TILE_STAIRS", "DEEPSLATE_TILE_WALL");
        this.addBuyItems(items, 12.0, "TUFF", "POLISHED_TUFF", "CHISELED_TUFF", "TUFF_BRICKS", "TUFF_SLAB", "TUFF_STAIRS", "TUFF_WALL", "POLISHED_TUFF_SLAB", "POLISHED_TUFF_STAIRS", "POLISHED_TUFF_WALL", "TUFF_BRICK_SLAB", "TUFF_BRICK_STAIRS", "TUFF_BRICK_WALL");
        this.addBuyItems(items, 14.0, "QUARTZ_BLOCK", "SMOOTH_QUARTZ", "CHISELED_QUARTZ_BLOCK", "QUARTZ_BRICKS", "QUARTZ_SLAB", "QUARTZ_STAIRS", "QUARTZ_PILLAR", "PRISMARINE", "PRISMARINE_BRICKS", "DARK_PRISMARINE", "BLACKSTONE", "POLISHED_BLACKSTONE", "POLISHED_BLACKSTONE_BRICKS", "POLISHED_BLACKSTONE_SLAB", "POLISHED_BLACKSTONE_STAIRS", "POLISHED_BLACKSTONE_WALL");
        return items;
    }

    private List<ShopItem> glassworkItems() {
        ArrayList<ShopItem> items = new ArrayList<>();
        this.addBuyItems(items, 4.0, "GLASS", "GLASS_PANE", "TINTED_GLASS");
        this.addBuyItems(items, 5.0, "WHITE_STAINED_GLASS", "ORANGE_STAINED_GLASS", "MAGENTA_STAINED_GLASS", "LIGHT_BLUE_STAINED_GLASS", "YELLOW_STAINED_GLASS", "LIME_STAINED_GLASS", "PINK_STAINED_GLASS", "GRAY_STAINED_GLASS", "LIGHT_GRAY_STAINED_GLASS", "CYAN_STAINED_GLASS", "PURPLE_STAINED_GLASS", "BLUE_STAINED_GLASS", "BROWN_STAINED_GLASS", "GREEN_STAINED_GLASS", "RED_STAINED_GLASS", "BLACK_STAINED_GLASS");
        this.addBuyItems(items, 4.0, "WHITE_STAINED_GLASS_PANE", "ORANGE_STAINED_GLASS_PANE", "MAGENTA_STAINED_GLASS_PANE", "LIGHT_BLUE_STAINED_GLASS_PANE", "YELLOW_STAINED_GLASS_PANE", "LIME_STAINED_GLASS_PANE", "PINK_STAINED_GLASS_PANE", "GRAY_STAINED_GLASS_PANE", "LIGHT_GRAY_STAINED_GLASS_PANE", "CYAN_STAINED_GLASS_PANE", "PURPLE_STAINED_GLASS_PANE", "BLUE_STAINED_GLASS_PANE", "BROWN_STAINED_GLASS_PANE", "GREEN_STAINED_GLASS_PANE", "RED_STAINED_GLASS_PANE", "BLACK_STAINED_GLASS_PANE");
        return items;
    }

    private List<ShopItem> weaverItems() {
        ArrayList<ShopItem> items = new ArrayList<>();
        this.addBuyItems(items, 6.0, "WHITE_WOOL", "ORANGE_WOOL", "MAGENTA_WOOL", "LIGHT_BLUE_WOOL", "YELLOW_WOOL", "LIME_WOOL", "PINK_WOOL", "GRAY_WOOL", "LIGHT_GRAY_WOOL", "CYAN_WOOL", "PURPLE_WOOL", "BLUE_WOOL", "BROWN_WOOL", "GREEN_WOOL", "RED_WOOL", "BLACK_WOOL");
        this.addBuyItems(items, 3.0, "WHITE_CARPET", "ORANGE_CARPET", "MAGENTA_CARPET", "LIGHT_BLUE_CARPET", "YELLOW_CARPET", "LIME_CARPET", "PINK_CARPET", "GRAY_CARPET", "LIGHT_GRAY_CARPET", "CYAN_CARPET", "PURPLE_CARPET", "BLUE_CARPET", "BROWN_CARPET", "GREEN_CARPET", "RED_CARPET", "BLACK_CARPET");
        return items;
    }

    private void addBuyItem(List<ShopItem> items, String materialName, double price) {
        Material material = Material.matchMaterial(materialName);
        if (material != null) {
            items.add(ShopItem.buy(material, price));
        }
    }

    private void addBuyItems(List<ShopItem> items, double price, String... materialNames) {
        for (String materialName : materialNames) {
            this.addBuyItem(items, materialName, price);
        }
    }

    private ItemStack categoryItem(Category category) {
        String plainName = Text.strip(category.displayName);
        return this.infoItem(category.icon, category.color + category.displayName, List.of("&7Click to view the &7" + plainName + " items"));
    }

    private ItemStack shopItem(Player player, ShopItem shopItem) {
        ItemStack item = shopItem.displayItem(this.pickaxeManager, this.cellService, this.cellGuardService, this.generatorService, this.gearManager, this.satchelManager);
        if (shopItem.purchasePrice > 0.0 || shopItem.pickaxeTypeId != null || shopItem.doorType != null || shopItem.gearMaterial != null || shopItem.guardTier != null || shopItem.generatorTier != null || shopItem.refinedTier != null || shopItem.satchelMaterial != null) {
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
                lore.add(Text.componentNoItalics(""));
                lore.add(Text.componentNoItalics("&eLeft-Click &7to purchase"));
                lore.add(Text.componentNoItalics("&7Buy Price: &a" + this.economyService.format(this.purchasePrice(player, shopItem))));
                meta.lore(lore);
                item.setItemMeta(meta);
            }
            return item;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics("&f" + this.prettyName(shopItem.material)));
            List<Component> lore = new ArrayList<>();
            double worth = this.economyService.applySellBoost(player, this.economyService.getWorth(shopItem.material));
            lore.add(Text.componentNoItalics(""));
            lore.add(Text.componentNoItalics("&eRight-Click &7to sell"));
            lore.add(Text.componentNoItalics("&7Sell Price: " + (worth > 0.0 ? "&a" + this.economyService.format(worth) : "&cNot set")));
            meta.lore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private double purchasePrice(Player player, ShopItem shopItem) {
        double base;
        if (shopItem.satchelMaterial == null) {
            base = shopItem.purchasePrice;
        } else {
            double worth = this.economyService.getWorth(shopItem.satchelMaterial);
            int capacity = this.satchelManager.getConfiguredCapacity(shopItem.satchelMaterial);
            if (worth <= 0.0 || capacity <= 0) {
                return 0.0;
            }
            base = worth * (double)capacity * 50.0;
        }
        return this.economyService.applyPurchaseDiscount(player, base);
    }

    private void fillBackground(Inventory inventory) {
        ItemStack pane = this.namedItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, pane);
        }
    }

    private int inventorySize(Category category) {
        if (category == Category.GEAR_WEAPONS) {
            return GEAR_CATEGORY_INVENTORY_SIZE;
        }
        if (category == Category.GENERATORS) {
            return GENERATOR_CATEGORY_INVENTORY_SIZE;
        }
        return CATEGORY_INVENTORY_SIZE;
    }

    private void openPagedCategory(Player player, Category category, int page, int[] itemSlots) {
        List<ShopItem> items = this.itemsByCategory.getOrDefault(category, List.of());
        int pageSize = PAGED_ITEM_SLOTS.length;
        int totalPages = Math.max(1, (items.size() + pageSize - 1) / pageSize);
        int clampedPage = Math.max(0, Math.min(page, totalPages - 1));
        PagedCategoryHolder holder = new PagedCategoryHolder(category, clampedPage);
        String title = "&8" + Text.strip(category.displayName) + " &7(" + (clampedPage + 1) + "/" + totalPages + ")";
        Inventory inventory = Bukkit.createInventory(holder, PAGED_INVENTORY_SIZE, Text.color(title));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        int start = clampedPage * pageSize;
        int end = Math.min(items.size(), start + pageSize);
        int slotIndex = 0;
        for (int i = start; i < end; ++i) {
            inventory.setItem(PAGED_ITEM_SLOTS[slotIndex++], this.shopItem(player, items.get(i)));
        }
        if (clampedPage > 0) {
            inventory.setItem(PAGED_PREV_SLOT, this.namedItem(Material.ARROW, "&ePrevious Page"));
        }
        inventory.setItem(PAGED_BACK_SLOT, this.namedItem(Material.NETHER_STAR, "&c&lBack"));
        if (clampedPage < totalPages - 1) {
            inventory.setItem(PAGED_NEXT_SLOT, this.namedItem(Material.ARROW, "&eNext Page"));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.0f);
        player.openInventory(inventory);
    }

    private void handlePagedCategoryClick(Player player, PagedCategoryHolder holder, int slot, ClickType click) {
        List<ShopItem> items = this.itemsByCategory.getOrDefault(holder.category, List.of());
        if (slot == PAGED_BACK_SLOT) {
            this.open(player);
            return;
        }
        if (slot == PAGED_PREV_SLOT && holder.page > 0) {
            this.openPagedCategory(player, holder.category, holder.page - 1, this.itemSlots(holder.category));
            return;
        }
        if (slot == PAGED_NEXT_SLOT) {
            this.openPagedCategory(player, holder.category, holder.page + 1, this.itemSlots(holder.category));
            return;
        }
        int index = holder.page * PAGED_ITEM_SLOTS.length + this.indexOf(PAGED_ITEM_SLOTS, slot);
        if (index >= 0 && index < items.size()) {
            this.handleShopItemClick(player, items.get(index), click);
        }
    }

    private int indexOf(int[] values, int slot) {
        for (int i = 0; i < values.length; ++i) {
            if (values[i] == slot) {
                return i;
            }
        }
        return -1;
    }

    private int[] itemSlots(Category category) {
        if (category == Category.GEAR_WEAPONS) {
            return GEAR_ITEM_SLOTS;
        }
        if (category == Category.GENERATORS) {
            return GENERATOR_ITEM_SLOTS;
        }
        return DEFAULT_ITEM_SLOTS;
    }

    private int backSlot(Category category) {
        return category == Category.GEAR_WEAPONS || category == Category.GENERATORS ? 40 : 31;
    }

    private ItemStack infoItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(name));
            List<Component> lines = new ArrayList<>();
            for (String line : lore) {
                lines.add(Text.componentNoItalics(line));
            }
            meta.lore(lines);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack namedItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(name));
            item.setItemMeta(meta);
        }
        return item;
    }

    private String prettyName(Material material) {
        String[] words = material.name().toLowerCase().split("_");
        StringBuilder builder = new StringBuilder();
        for (String word : words) {
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return builder.toString();
    }

    private enum Category {
        ORES("&6&lOres", Material.COAL_ORE, ""),
        PICKAXES("&6&lPickaxes", Material.DIAMOND_PICKAXE, ""),
        GEAR_WEAPONS("&6&lGear", Material.DIAMOND_SWORD, ""),
        DOORS("&6&lCell Protection", Material.IRON_DOOR, ""),
        GENERATORS("&6&lGenerators", Material.SPAWNER, ""),
        GENERAL("&6&lGeneral", Material.CHEST, ""),
        WOODWORK("&6&lWoodwork", Material.OAK_LOG, ""),
        STONECRAFTER("&6&lStonecrafter", Material.STONE, ""),
        GLASSWORK("&6&lGlasswork", Material.GLASS, ""),
        WEAVER("&6&lWeaver", Material.WHITE_WOOL, "");

        private final String displayName;
        private final Material icon;
        private final String color;

        Category(String displayName, Material icon, String color) {
            this.displayName = displayName;
            this.icon = icon;
            this.color = color;
        }
    }

    private record ShopItem(Material material, boolean sellable, double purchasePrice, String pickaxeTypeId, CellDoorType doorType, Material gearMaterial, CellGuardTier guardTier, GeneratorService.GeneratorTier generatorTier, GeneratorService.RefinedTier refinedTier, Material satchelMaterial) {
        private static ShopItem buy(Material material, double purchasePrice) {
            return new ShopItem(material, false, purchasePrice, null, null, null, null, null, null, null);
        }

        private static ShopItem sellable(Material material) {
            return new ShopItem(material, true, 0.0, null, null, null, null, null, null, null);
        }

        private static ShopItem pickaxe(String typeId, double purchasePrice, PickaxeType type) {
            Material material = type != null ? type.getMaterial() : Material.WOODEN_PICKAXE;
            return new ShopItem(material, false, purchasePrice, typeId, null, null, null, null, null, null);
        }

        private static ShopItem satchel(Material material) {
            return new ShopItem(material, false, 0.0, null, null, null, null, null, null, material);
        }

        private static ShopItem door(CellDoorType doorType, double purchasePrice) {
            return new ShopItem(doorType.getMaterial(), false, purchasePrice, null, doorType, null, null, null, null, null);
        }

        private static ShopItem gear(Material material, double purchasePrice) {
            return new ShopItem(material, false, purchasePrice, null, null, material, null, null, null, null);
        }

        private static ShopItem guard(CellGuardTier tier, double purchasePrice) {
            return new ShopItem(Material.ARMOR_STAND, false, purchasePrice, null, null, null, tier, null, null, null);
        }

        private static ShopItem generator(GeneratorService.GeneratorTier tier, double purchasePrice) {
            return new ShopItem(tier.generatorBlock, false, purchasePrice, null, null, null, null, tier, null, null);
        }

        private static ShopItem refined(GeneratorService.RefinedTier tier, double purchasePrice) {
            return new ShopItem(tier.refinedBlock, false, purchasePrice, null, null, null, null, null, tier, null);
        }

        private ItemStack displayItem(PickaxeManager pickaxeManager, CellService cellService, CellGuardService cellGuardService, GeneratorService generatorService, GearManager gearManager, SatchelManager satchelManager) {
            if (this.pickaxeTypeId == null && this.doorType == null && this.gearMaterial == null && this.guardTier == null && this.generatorTier == null && this.refinedTier == null && this.satchelMaterial == null) {
                return new ItemStack(this.material);
            }
            if (this.pickaxeTypeId != null) {
                PickaxeType type = pickaxeManager.getType(this.pickaxeTypeId);
                if (type == null) {
                    return new ItemStack(this.material);
                }
                return pickaxeManager.createPickaxe(type, 0);
            }
            if (this.doorType != null) {
                return cellService.createDoorItem(this.doorType, 1);
            }
            if (this.guardTier != null) {
                return cellGuardService.createGuardAnchor(this.guardTier, 1);
            }
            if (this.generatorTier != null) {
                return generatorService.createGeneratorItem(this.generatorTier);
            }
            if (this.refinedTier != null) {
                return generatorService.createRefinedItem(this.refinedTier);
            }
            if (this.satchelMaterial != null) {
                return satchelManager.createSatchel(this.satchelMaterial);
            }
            return this.gearMaterial != null ? gearManager.wrap(new ItemStack(this.gearMaterial), this.gearMaterial.name().toLowerCase()) : new ItemStack(this.material);
        }
    }

    private abstract static class BaseHolder implements InventoryHolder {
        Inventory inventory;

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class RootHolder extends BaseHolder {
    }

    private static final class CategoryHolder extends BaseHolder {
        private final Category category;

        private CategoryHolder(Category category) {
            this.category = category;
        }
    }

    private static final class PagedCategoryHolder extends BaseHolder {
        private final Category category;
        private final int page;

        private PagedCategoryHolder(Category category, int page) {
            this.category = category;
            this.page = page;
        }
    }
}
