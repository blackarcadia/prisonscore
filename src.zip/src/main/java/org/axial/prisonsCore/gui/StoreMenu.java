package org.axial.prisonsCore.gui;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.ContrabandService;
import org.axial.prisonsCore.service.PrisonCoinService;
import org.axial.prisonsCore.service.PowerboxService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class StoreMenu implements Listener {
    private static final int SIZE = 45;
    private static final int[] ITEM_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};
    private static final int[] RANK_ITEM_SLOTS = new int[]{22};
    private static final int[] LOOTBOX_ITEM_SLOTS = new int[]{22};
    private static final int[] CONTRABAND_ITEM_SLOTS = new int[]{20, 21, 23, 24};
    private static final int[] GKIT_FLARE_SLOTS = new int[]{20, 22, 24};
    private static final int[] ROOT_CATEGORY_SLOTS = new int[]{11, 15, 22, 29, 33};
    private static final int[] COIN_PACK_SLOTS = new int[]{11, 12, 13, 14, 15};
    private static final long[] COIN_PACK_AMOUNTS = new long[]{10000L, 25000L, 45000L, 55000L, 75000L};
    private static final int PREV_SLOT = 39;
    private static final int BACK_SLOT = 40;
    private static final int BALANCE_SLOT = 4;
    private static final int NEXT_SLOT = 41;
    private final PrisonsCore plugin;
    private final PrisonCoinService prisonCoinService;
    private final ContrabandService contrabandService;
    private PowerboxService powerboxService;
    private final List<StoreEntry> entries = new ArrayList<>();
    private final java.util.EnumMap<Category, List<StoreEntry>> entriesByCategory = new java.util.EnumMap<>(Category.class);
    private String title = "&8Prison Store";
    private String balanceName = "&6&lPrison Coins";
    private List<String> balanceLore = List.of("&7Your balance: &f{balance}", "&7", "&eLeft-click items to buy them.");

    public StoreMenu(PrisonsCore plugin, PrisonCoinService prisonCoinService, ContrabandService contrabandService) {
        this(plugin, prisonCoinService, contrabandService, null);
    }

    public StoreMenu(PrisonsCore plugin, PrisonCoinService prisonCoinService, ContrabandService contrabandService, PowerboxService powerboxService) {
        this.plugin = plugin;
        this.prisonCoinService = prisonCoinService;
        this.contrabandService = contrabandService;
        this.powerboxService = powerboxService;
        this.reload();
    }

    public void setPowerboxService(PowerboxService powerboxService) {
        this.powerboxService = powerboxService;
    }

    public void reload() {
        File file = new File(this.plugin.getDataFolder(), "prison-coins.yml");
        if (!file.exists()) {
            this.plugin.saveResource("prison-coins.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        this.title = cfg.getString("store.title", this.title);
        this.balanceName = cfg.getString("store.balance-item.display-name", this.balanceName);
        List<String> configuredLore = cfg.getStringList("store.balance-item.lore");
        if (configuredLore != null && !configuredLore.isEmpty()) {
            this.balanceLore = configuredLore;
        }
        this.entries.clear();
        this.entriesByCategory.clear();
        ConfigurationSection items = cfg.getConfigurationSection("store.items");
        if (items != null) {
            for (String key : items.getKeys(false)) {
                ConfigurationSection section = items.getConfigurationSection(key);
                if (section == null) {
                    continue;
                }
                Material icon = Material.matchMaterial(section.getString("material", "PAPER"));
                if (icon == null) {
                    icon = Material.PAPER;
                }
                long price = Math.max(0L, section.getLong("price", 0L));
                if (price <= 0L) {
                    continue;
                }
                int amount = Math.max(1, section.getInt("amount", 1));
                String displayName = section.getString("name", null);
                List<String> lore = section.getStringList("lore");
                List<String> commands = section.getStringList("commands");
                Category category = Category.fromConfig(section.getString("category", "ranks"));
                if (category == null || category == Category.COIN_BALANCE) {
                    category = Category.RANKS;
                }
                if (category == Category.CONTRABAND) {
                    continue;
                }
                this.registerEntry(new StoreEntry(key, category, icon, amount, price, displayName, lore == null ? List.of() : lore, commands == null ? List.of() : commands));
            }
        }
        this.ensureDefaultContrabandEntries();
        this.ensureDefaultLootboxEntries();
        this.ensureDefaultRankEntries();
        this.ensureDefaultGKitFlareEntries();
    }

    public void open(Player player) {
        RootHolder holder = new RootHolder();
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color(this.title));
        holder.inventory = inventory;
        this.fillRootBackground(inventory);
        inventory.setItem(BALANCE_SLOT, this.balanceItem(player));
        for (int i = 0; i < Category.ROOT_ORDER.length && i < ROOT_CATEGORY_SLOTS.length; ++i) {
            Category category = Category.ROOT_ORDER[i];
            inventory.setItem(ROOT_CATEGORY_SLOTS[i], this.categoryItem(category, player));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.0f);
        player.openInventory(inventory);
    }

    private void open(Player player, int page) {
        this.openCategory(player, Category.RANKS, page);
    }

    private void openCategory(Player player, Category category, int page) {
        if (category == Category.COIN_BALANCE) {
            this.openBalance(player);
            return;
        }
        List<StoreEntry> items = new ArrayList<>(this.entriesByCategory.getOrDefault(category, List.of()));
        if (category == Category.CONTRABAND) {
            items.sort(Comparator.comparingInt(entry -> this.contrabandOrder(entry.id)));
        }
        int[] slots = category == Category.RANKS ? RANK_ITEM_SLOTS : (category == Category.LOOTBOXES ? LOOTBOX_ITEM_SLOTS : (category == Category.CONTRABAND ? CONTRABAND_ITEM_SLOTS : (category == Category.GKIT_FLARES ? GKIT_FLARE_SLOTS : ITEM_SLOTS)));
        int totalPages = Math.max(1, (items.size() + slots.length - 1) / slots.length);
        int clampedPage = Math.max(0, Math.min(page, totalPages - 1));
        CategoryHolder holder = new CategoryHolder(category, clampedPage);
        String titleText = totalPages > 1 ? Text.strip(category.displayName) + " &7(" + (clampedPage + 1) + "/" + totalPages + ")" : Text.strip(category.displayName);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8" + titleText));
        holder.inventory = inventory;
        this.fillRootBackground(inventory);
        inventory.setItem(BALANCE_SLOT, this.balanceItem(player));
        inventory.setItem(BACK_SLOT, this.navItem(Material.NETHER_STAR, "&c&lBack", List.of("&7Return to the main menu.")));
        if (clampedPage > 0) {
            inventory.setItem(PREV_SLOT, this.navItem(Material.ARROW, "&ePrevious Page", List.of("&7Go back one page.")));
        }
        if (clampedPage < totalPages - 1) {
            inventory.setItem(NEXT_SLOT, this.navItem(Material.ARROW, "&eNext Page", List.of("&7Go forward one page.")));
        }
        int start = clampedPage * slots.length;
        int end = Math.min(items.size(), start + slots.length);
        int slotIndex = 0;
        for (int i = start; i < end; ++i) {
            if (slotIndex < slots.length) {
                inventory.setItem(slots[slotIndex++], this.entryItem(items.get(i)));
            }
        }
        if (items.isEmpty()) {
            inventory.setItem(22, this.infoItem(Material.BARRIER, "&cNo Store Items", List.of(Lang.msg("prisoncoins.store.empty", "&7No prison coin store items are configured."))));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.0f);
        player.openInventory(inventory);
    }

    private void openBalance(Player player) {
        BalanceHolder holder = new BalanceHolder();
        Inventory inventory = Bukkit.createInventory(holder, 27, Text.color("&8Coin Balance"));
        holder.inventory = inventory;
        this.fillInfoBackground(inventory);
        for (int i = 0; i < COIN_PACK_SLOTS.length && i < COIN_PACK_AMOUNTS.length; ++i) {
            inventory.setItem(COIN_PACK_SLOTS[i], this.coinPackItem(COIN_PACK_AMOUNTS[i]));
        }
        inventory.setItem(22, this.navItem(Material.NETHER_STAR, "&c&lBack", List.of("&7Return to the main store.")));
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.0f);
        player.openInventory(inventory);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof CategoryHolder categoryHolder) {
            this.handleCategoryClick(event, categoryHolder);
            return;
        }
        if (holder instanceof RootHolder) {
            this.handleRootClick(event);
            return;
        }
        if (holder instanceof BalanceHolder) {
            this.handleBalanceClick(event);
            return;
        }
    }

    private void handleRootClick(InventoryClickEvent event) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int slot = event.getRawSlot();
        if (slot == BALANCE_SLOT) {
            this.openBalance(player);
            return;
        }
        for (int i = 0; i < ROOT_CATEGORY_SLOTS.length && i < Category.ROOT_ORDER.length; ++i) {
            if (ROOT_CATEGORY_SLOTS[i] != slot) {
                continue;
            }
            this.openCategory(player, Category.ROOT_ORDER[i], 0);
            return;
        }
    }

    private void handleCategoryClick(InventoryClickEvent event, CategoryHolder holder) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int slot = event.getRawSlot();
        if (slot == BALANCE_SLOT) {
            this.openBalance(player);
            return;
        }
        if (slot == PREV_SLOT && holder.page > 0) {
            this.openCategory(player, holder.category, holder.page - 1);
            return;
        }
        if (slot == NEXT_SLOT) {
            this.openCategory(player, holder.category, holder.page + 1);
            return;
        }
        if (slot == BACK_SLOT) {
            this.open(player);
            return;
        }
        int[] slots = holder.category == Category.RANKS ? RANK_ITEM_SLOTS : (holder.category == Category.LOOTBOXES ? LOOTBOX_ITEM_SLOTS : (holder.category == Category.CONTRABAND ? CONTRABAND_ITEM_SLOTS : (holder.category == Category.GKIT_FLARES ? GKIT_FLARE_SLOTS : ITEM_SLOTS)));
        int index = holder.page * slots.length + this.indexOf(slots, slot);
        List<StoreEntry> items = this.entriesByCategory.getOrDefault(holder.category, List.of());
        if (index >= 0 && index < items.size()) {
            this.purchase(player, items.get(index));
        }
    }

    private void handleBalanceClick(InventoryClickEvent event) {
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int slot = event.getRawSlot();
        if (slot == 22) {
            this.open(player);
            return;
        }
        for (int i = 0; i < COIN_PACK_SLOTS.length && i < COIN_PACK_AMOUNTS.length; ++i) {
            if (COIN_PACK_SLOTS[i] != slot) {
                continue;
            }
            this.showCoinPackLink(player, COIN_PACK_AMOUNTS[i]);
            return;
        }
    }

    private void purchase(Player player, StoreEntry entry) {
        if (!this.prisonCoinService.withdraw(player, entry.price)) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
            player.sendMessage(Lang.msg("prisoncoins.store.not-enough", "&cYou need {amount} to buy this item.").replace("{amount}", this.prisonCoinService.format(entry.price)));
            return;
        }
        if (entry.commands.isEmpty()) {
            this.prisonCoinService.addCoins(player.getUniqueId(), entry.price);
            player.sendMessage(Text.color("&cThat store item is not configured."));
            return;
        }
        for (String command : entry.commands) {
            String resolved = this.resolvePlaceholders(command, player, entry);
            if (resolved == null || resolved.isBlank()) {
                continue;
            }
            if (resolved.startsWith("console:")) {
                resolved = resolved.substring("console:".length()).trim();
            }
            if (resolved.startsWith("/")) {
                resolved = resolved.substring(1);
            }
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), resolved);
        }
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(Lang.msg("prisoncoins.store.purchased", "&aPurchased {item} &afor &2{amount}")
                .replace("{item}", this.prettyName(entry))
                .replace("{amount}", this.prisonCoinService.format(entry.price)));
    }

    private String resolvePlaceholders(String command, Player player, StoreEntry entry) {
        if (command == null) {
            return null;
        }
        String balance = String.valueOf(this.prisonCoinService.getBalance(player));
        return command
                .replace("%player%", player.getName())
                .replace("%uuid%", player.getUniqueId().toString())
                .replace("%amount%", String.valueOf(entry.amount))
                .replace("%price%", String.valueOf(entry.price))
                .replace("%balance%", balance)
                .replace("%item%", this.prettyName(entry))
                .replace("%id%", entry.id)
                .replace("%display_name%", Text.strip(this.prettyName(entry)));
    }

    private ItemStack entryItem(StoreEntry entry) {
        if (entry.category == Category.CONTRABAND && this.contrabandService != null) {
            ItemStack contraband = this.resolveContrabandItem(entry.id);
            if (contraband != null) {
                ItemMeta meta = contraband.getItemMeta();
                if (meta != null) {
                    List<Component> lore = new ArrayList<>(meta.lore() == null ? List.of() : meta.lore());
                    lore.add(Text.componentNoItalics(""));
                    lore.add(Text.componentNoItalics("&eLeft-Click &7to purchase"));
                    lore.add(Text.componentNoItalics("&7Price: &6" + this.prisonCoinService.format(entry.price)));
                    meta.lore(lore);
                    contraband.setItemMeta(meta);
                }
                return contraband;
            }
        }
        if (entry.category == Category.LOOTBOXES && this.powerboxService != null) {
            String powerboxId = this.resolvePowerboxId(entry.id);
            ItemStack powerbox = powerboxId == null ? null : this.powerboxService.createPowerbox(powerboxId, Math.max(1, entry.amount));
            if (powerbox != null) {
                ItemMeta meta = powerbox.getItemMeta();
                if (meta != null) {
                    List<Component> lore = new ArrayList<>(meta.lore() == null ? List.of() : meta.lore());
                    lore.add(Text.componentNoItalics(""));
                    lore.add(Text.componentNoItalics("&eLeft-Click &7to purchase"));
                    lore.add(Text.componentNoItalics("&7Price: &6" + this.prisonCoinService.format(entry.price)));
                    meta.lore(lore);
                    powerbox.setItemMeta(meta);
                }
                return powerbox;
            }
        }
        ItemStack item = new ItemStack(entry.material, Math.max(1, entry.amount));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        String displayName = entry.displayName != null && !entry.displayName.isBlank() ? entry.displayName : this.prettyName(entry);
        meta.displayName(Text.componentNoItalics(displayName));
        List<Component> lore = new ArrayList<>();
        for (String line : entry.lore) {
            lore.add(Text.componentNoItalics(line.replace("{price}", this.prisonCoinService.format(entry.price))));
        }
        lore.add(Text.componentNoItalics(""));
        lore.add(Text.componentNoItalics("&eLeft-Click &7to purchase"));
        lore.add(Text.componentNoItalics("&7Price: &6" + this.prisonCoinService.format(entry.price)));
        meta.lore(lore);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        return item;
    }

    private String resolvePowerboxId(String entryId) {
        if (entryId == null || entryId.isBlank()) {
            return null;
        }
        String normalized = entryId.toLowerCase(java.util.Locale.ROOT);
        if (normalized.endsWith("-lootbox")) {
            normalized = normalized.substring(0, normalized.length() - "-lootbox".length());
        }
        normalized = normalized.replace('-', '_');
        return this.powerboxService != null && this.powerboxService.hasPowerbox(normalized) ? normalized : null;
    }

    private ItemStack resolveContrabandItem(String entryId) {
        if (entryId == null) {
            return null;
        }
        return this.contrabandService.createContraband(entryId);
    }

    private int contrabandOrder(String entryId) {
        if (entryId == null) {
            return Integer.MAX_VALUE;
        }
        return switch (entryId.toLowerCase(java.util.Locale.ROOT)) {
            case "basic_cont" -> 0;
            case "rare_cont" -> 1;
            case "elite_cont" -> 2;
            case "legendary_cont" -> 3;
            default -> Integer.MAX_VALUE - 1;
        };
    }

    private ItemStack balanceItem(Player player) {
        ItemStack item = new ItemStack(Material.SUNFLOWER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.displayName(Text.componentNoItalics("&6&lCoin Balance"));
        List<Component> lore = new ArrayList<>();
        for (String line : this.balanceLore) {
            String resolved = line.replace("{balance}", this.prisonCoinService.format(this.prisonCoinService.getBalance(player)));
            lore.add(Text.componentNoItalics(resolved));
        }
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack balanceShowcaseItem(Player player) {
        ItemStack item = new ItemStack(Material.SUNFLOWER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.displayName(Text.componentNoItalics("&6&lCoin Balance"));
        List<Component> lore = new ArrayList<>();
        lore.add(Text.componentNoItalics("&7You have &f" + this.prisonCoinService.format(this.prisonCoinService.getBalance(player))));
        lore.add(Text.componentNoItalics(""));
        lore.add(Text.componentNoItalics("&7Purchase prison coins at /buy or unlock randomly from mining, contraband or lootboxes."));
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack coinPackItem(long amount) {
        ItemStack item = new ItemStack(Material.SUNFLOWER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        String formatted = Text.formatNumber(amount);
        meta.displayName(Text.componentNoItalics("&6&n" + formatted + " &6&lPrison Coins"));
        meta.lore(List.of(
                Text.componentNoItalics("&7Click to view the purchase link."),
                Text.componentNoItalics("&7"),
                Text.componentNoItalics("&eClicking this will show the store link.")
        ));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        item.setItemMeta(meta);
        return item;
    }

    private void showCoinPackLink(Player player, long amount) {
        player.closeInventory();
        player.sendMessage(Text.color("&6&n" + Text.formatNumber(amount) + " &6&lPrison Coins Purchase Link:"));
        player.sendMessage(Text.color("&e&nhttps://store.axialprisons.com"));
    }

    private ItemStack categoryItem(Category category, Player player) {
        ItemStack item = new ItemStack(category.icon);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        meta.displayName(Text.componentNoItalics(category.displayName));
        List<Component> lore = new ArrayList<>();
        if (category == Category.COIN_BALANCE) {
            lore.add(Text.componentNoItalics("&7You have &f" + this.prisonCoinService.format(this.prisonCoinService.getBalance(player))));
            lore.add(Text.componentNoItalics(""));
            lore.add(Text.componentNoItalics("&7Purchase prison coins at /buy or unlock randomly from mining, contraband or lootboxes."));
        } else {
            int count = this.entriesByCategory.getOrDefault(category, List.of()).size();
            lore.add(Text.componentNoItalics("&7Items available: &f" + count));
            lore.add(Text.componentNoItalics(""));
            lore.add(Text.componentNoItalics("&eLeft-click &7to view items."));
        }
        meta.lore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private void ensureDefaultContrabandEntries() {
        if (this.contrabandService == null) {
            return;
        }
        this.addContrabandEntry("basic_cont", 2500L, "contraband give basic_cont %player% %amount%");
        this.addContrabandEntry("rare_cont", 5000L, "contraband give rare_cont %player% %amount%");
        this.addContrabandEntry("elite_cont", 10000L, "contraband give elite_cont %player% %amount%");
        this.addContrabandEntry("legendary_cont", 20000L, "contraband give legendary_cont %player% %amount%");
    }

    private void ensureDefaultLootboxEntries() {
        if (this.powerboxService == null) {
            return;
        }
        this.addDefaultEntry("frozen-wastelands-lootbox", Category.LOOTBOXES, Material.BEACON, 1, 45000L, this.powerboxService.displayName("frozen_wastelands"), List.of(
                "&7A frozen lootbox containing",
                "&75 random rewards."
        ), List.of("powerbox give frozen_wastelands %player% %amount%"));
        this.addDefaultEntry("heatwave-lootbox", Category.LOOTBOXES, Material.RED_GLAZED_TERRACOTTA, 1, 45000L, this.powerboxService.displayName("heatwave"), List.of(
                "&7A heated lootbox containing",
                "&75 random rewards."
        ), List.of("powerbox give heatwave %player% %amount%"));
    }

    private void ensureDefaultRankEntries() {
        this.addDefaultEntry("vanguard-rank-token", Category.RANKS, Material.TRIAL_KEY, 1, 75000L, "&6&lRank: &e&lVanguard", List.of(
                "&7Right-Click to unlock the",
                "&e&l&nVanguard &7Rank on this planet.",
                "&7",
                "&e&lVanguard Perks:",
                "&e&l* &7Access to /fix",
                "&e&l* &7Access to /tpa",
                "&e&l* &7Access to /sell",
                "&e&l* &7Access to /nick",
                "&e&l* &7Access to /feed",
                "&e&l* &7Access to /tpahere",
                "&e&l* &7Access to /jet",
                "&e&l* &7Access to /near (200 Blocks)",
                "&e&l* &75% /sell tax",
                "&e&l* &710 Private Vaults (/pv)",
                "&e&l* &7Access to 6 homes"
        ), List.of("ranktoken give %player% %amount%"));
    }

    private void addContrabandEntry(String tierId, long price, String command) {
        ItemStack preview = this.contrabandService.tierPreview(tierId);
        Material icon = preview == null ? Material.CHEST : preview.getType();
        String displayName = this.contrabandService.displayName(tierId);
        this.addDefaultEntry(tierId, Category.CONTRABAND, icon, 1, price, displayName, List.of(), List.of(command));
    }

    private void ensureDefaultGKitFlareEntries() {
        this.addDefaultEntry("deepforge-gkit-flare", Category.GKIT_FLARES, Material.REDSTONE_TORCH, 1, 7500L, "&3&lDeep Forge &3Gkit Flare", List.of(
                "&7Spawns a Gkit Meteor",
                "&7from the sky!",
                "&7",
                "&c&lDrops the Gkit Gem",
                "&c&l100% of the time."
        ), List.of("gkit flare %player% deepforge %amount%"));
        this.addDefaultEntry("ironhide-gkit-flare", Category.GKIT_FLARES, Material.REDSTONE_TORCH, 1, 7500L, "&b&lIronhide &bGkit Flare", List.of(
                "&7Spawns a Gkit Meteor",
                "&7from the sky!",
                "&7",
                "&c&lDrops the Gkit Gem",
                "&c&l100% of the time."
        ), List.of("gkit flare %player% ironhide %amount%"));
        this.addDefaultEntry("stormstride-gkit-flare", Category.GKIT_FLARES, Material.REDSTONE_TORCH, 1, 7500L, "&9&lStormstride &9Gkit Flare", List.of(
                "&7Spawns a Gkit Meteor",
                "&7from the sky!",
                "&7",
                "&c&lDrops the Gkit Gem",
                "&c&l100% of the time."
        ), List.of("gkit flare %player% stormstride %amount%"));
    }

    private void addDefaultEntry(String id, Category category, Material material, int amount, long price, String displayName, List<String> lore, List<String> commands) {
        if (this.hasEntry(id)) {
            return;
        }
        this.registerEntry(new StoreEntry(id, category, material, amount, price, displayName, lore, commands));
    }

    private void registerEntry(StoreEntry entry) {
        this.entries.add(entry);
        this.entriesByCategory.computeIfAbsent(entry.category, ignored -> new ArrayList<>()).add(entry);
    }

    private boolean hasEntry(String id) {
        for (StoreEntry entry : this.entries) {
            if (entry.id.equalsIgnoreCase(id)) {
                return true;
            }
        }
        return false;
    }

    private ItemStack navItem(Material material, String name, List<String> lore) {
        return this.infoItem(material, name, lore);
    }

    private ItemStack infoItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(name));
            List<Component> lines = new ArrayList<>();
            for (String line : lore) {
                lines.add(Text.componentNoItalics(line));
            }
            meta.lore(lines);
            item.setItemMeta(meta);
        }
        return item;
    }

    private void fillBackground(Inventory inventory) {
        this.fillInfoBackground(inventory);
    }

    private void fillRootBackground(Inventory inventory) {
        ItemStack border = this.pane(Material.ORANGE_STAINED_GLASS_PANE);
        ItemStack inner = this.pane(Material.PURPLE_STAINED_GLASS_PANE);
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            int row = slot / 9;
            int col = slot % 9;
            boolean isBorder = row == 0 || row == 4 || col == 0 || col == 8;
            inventory.setItem(slot, isBorder ? border : inner);
        }
    }

    private void fillPageBackground(Inventory inventory) {
        this.fillRootBackground(inventory);
    }

    private void fillInfoBackground(Inventory inventory) {
        ItemStack pane = this.pane(Material.PURPLE_STAINED_GLASS_PANE);
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, pane);
        }
    }

    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(" "));
            item.setItemMeta(meta);
        }
        return item;
    }

    private int indexOf(int[] values, int slot) {
        for (int i = 0; i < values.length; ++i) {
            if (values[i] == slot) {
                return i;
            }
        }
        return -1;
    }

    private String prettyName(StoreEntry entry) {
        if (entry.displayName != null && !entry.displayName.isBlank()) {
            return Text.color(entry.displayName);
        }
        String base = entry.id == null ? entry.material.name() : entry.id;
        String[] parts = base.split("[_\\- ]+");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isBlank()) {
                continue;
            }
            if (!builder.isEmpty()) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) {
                builder.append(part.substring(1).toLowerCase());
            }
        }
        return builder.toString();
    }

    private static final class StoreHolder implements InventoryHolder {
        private final int page;
        private Inventory inventory;

        private StoreHolder(int page) {
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class RootHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class BalanceHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class CategoryHolder implements InventoryHolder {
        private final Category category;
        private final int page;
        private Inventory inventory;

        private CategoryHolder(Category category, int page) {
            this.category = category;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }

    private enum Category {
        RANKS("ranks", "&6&lRanks", Material.OMINOUS_TRIAL_KEY),
        CONTRABAND("contraband", "&6&lContraband", Material.ENDER_CHEST),
        LOOTBOXES("lootboxes", "&6&lLootboxes", Material.BEACON),
        GKIT_FLARES("gkit-flares", "&6&lGkit Flares", Material.REDSTONE_TORCH),
        PLAYER_TITLES("player-titles", "&6&lPlayer Titles", Material.PAPER),
        COIN_BALANCE("coin-balance", "&6&lCoin Balance", Material.SUNFLOWER);

        private static final Category[] ROOT_ORDER = new Category[]{RANKS, CONTRABAND, LOOTBOXES, GKIT_FLARES, PLAYER_TITLES};
        private final String configKey;
        private final String displayName;
        private final Material icon;

        Category(String configKey, String displayName, Material icon) {
            this.configKey = configKey;
            this.displayName = displayName;
            this.icon = icon;
        }

        private static Category fromConfig(String input) {
            if (input == null || input.isBlank()) {
                return null;
            }
            String normalized = input.toLowerCase(java.util.Locale.ROOT).replace('_', '-').replace(' ', '-');
            for (Category category : values()) {
                if (category.configKey.equals(normalized)) {
                    return category;
                }
            }
            return null;
        }
    }

    private static final class StoreEntry {
        private final String id;
        private final Category category;
        private final Material material;
        private final int amount;
        private final long price;
        private final String displayName;
        private final List<String> lore;
        private final List<String> commands;

        private StoreEntry(String id, Category category, Material material, int amount, long price, String displayName, List<String> lore, List<String> commands) {
            this.id = id;
            this.category = category;
            this.material = material;
            this.amount = amount;
            this.price = price;
            this.displayName = displayName;
            this.lore = lore == null ? Collections.emptyList() : lore;
            this.commands = commands == null ? Collections.emptyList() : commands;
        }
    }
}
