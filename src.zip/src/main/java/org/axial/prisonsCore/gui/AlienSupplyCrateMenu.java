package org.axial.prisonsCore.gui;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.AlienSupplyCrateService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class AlienSupplyCrateMenu implements Listener {
    private static final int INVENTORY_SIZE = 27;
    private static final int REWARD_SLOT = 13;
    private static final int TASK_PERIOD_TICKS = 1;
    private static final int SPIN_DURATION_TICKS = 80;
    private final PrisonsCore plugin;
    private final AlienSupplyCrateService service;
    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();

    public AlienSupplyCrateMenu(PrisonsCore plugin, AlienSupplyCrateService service) {
        this.plugin = plugin;
        this.service = service;
    }

    public void open(Player player) {
        Session existing = this.sessions.remove(player.getUniqueId());
        if (existing != null) {
            existing.cancel();
        }
        Session session = new Session(player.getUniqueId());
        Inventory inventory = Bukkit.createInventory(session, INVENTORY_SIZE, Text.color("&8Alien Supply Crate"));
        session.inventory = inventory;
        this.fillBackground(inventory);
        inventory.setItem(REWARD_SLOT, this.namedPane(Material.CHEST, "&7Rolling reward..."));
        player.openInventory(inventory);
        this.startSpin(player, session);
        this.sessions.put(player.getUniqueId(), session);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Session)) {
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof Session session)) {
            return;
        }
        if (session.completed) {
            this.sessions.remove(session.owner);
            return;
        }
        if (event.getPlayer() instanceof Player player) {
            this.finalizeReward(player, session);
        }
    }

    private void startSpin(Player player, Session session) {
        final BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            if (session.completed) {
                if (taskHolder[0] != null) {
                    taskHolder[0].cancel();
                }
                return;
            }
            if (session.ticks >= SPIN_DURATION_TICKS) {
                this.finalizeReward(player, session);
                if (taskHolder[0] != null) {
                    taskHolder[0].cancel();
                }
                return;
            }
            AlienSupplyCrateService.RewardRoll roll = this.service.rollReward();
            if (roll != null) {
                session.preview = roll;
                session.inventory.setItem(REWARD_SLOT, this.service.previewItem(roll));
                player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.6f, 1.4f);
            }
            session.ticks += TASK_PERIOD_TICKS;
        }, 0L, TASK_PERIOD_TICKS);
        session.task = taskHolder[0];
    }

    private void finalizeReward(Player player, Session session) {
        if (session.completed) {
            return;
        }
        session.completed = true;
        if (session.task != null) {
            session.task.cancel();
        }
        AlienSupplyCrateService.RewardRoll roll = session.preview != null ? session.preview : this.service.rollReward();
        if (roll == null) {
            player.sendMessage(Text.color("&cThis crate has no rewards configured."));
            this.sessions.remove(player.getUniqueId());
            return;
        }
        session.inventory.setItem(REWARD_SLOT, this.service.previewItem(roll));
        this.service.award(player, roll);
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
        player.sendTitle(Text.color("&a&lAlien Supply Crate"), Text.color("&7Reward claimed"), 5, 30, 10);
        player.sendMessage(Text.color("&aYou opened an Alien Supply Crate and received:"));
        player.sendMessage(Text.color("&8• &r" + this.service.rewardSummary(roll)));
        this.sessions.remove(player.getUniqueId());
    }

    private void fillBackground(Inventory inventory) {
        ItemStack filler = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
    }

    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack namedPane(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(name));
            item.setItemMeta(meta);
        }
        return item;
    }

    private static final class Session implements InventoryHolder {
        private final UUID owner;
        private Inventory inventory;
        private BukkitTask task;
        private int ticks;
        private boolean completed;
        private AlienSupplyCrateService.RewardRoll preview;

        private Session(UUID owner) {
            this.owner = owner;
        }

        private void cancel() {
            if (this.task != null) {
                this.task.cancel();
            }
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
