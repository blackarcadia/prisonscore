package org.axial.prisonsCore.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import net.kyori.adventure.text.Component;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.model.EnchantRarity;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class EnchantsMenu implements Listener {
    private static final int SIZE = 54;
    private static final int[] LIST_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private static final int ROOT_PICKAXE_SLOT = 20;
    private static final int ROOT_GEAR_SLOT = 24;
    private static final int ROOT_INFO_SLOT = 4;
    private static final int ROOT_NOTE_SLOT = 40;
    private static final int GEAR_HELMET_SLOT = 10;
    private static final int GEAR_CHEST_SLOT = 12;
    private static final int GEAR_LEG_SLOT = 14;
    private static final int GEAR_BOOT_SLOT = 16;
    private static final int GEAR_WEAPON_SLOT = 22;
    private static final int BACK_SLOT = 49;
    private static final int EXIT_SLOT = 45;
    private static final int PREV_SLOT = 48;
    private static final int NEXT_SLOT = 50;
    private static final int PAGE_SLOT = 52;

    private final CustomEnchantService enchantService;
    private final GearEnchantService gearEnchantService;

    public EnchantsMenu(CustomEnchantService enchantService, GearEnchantService gearEnchantService) {
        this.enchantService = enchantService;
        this.gearEnchantService = gearEnchantService;
    }

    public void open(Player player) {
        this.openRoot(player);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof Holder holder)) {
            return;
        }
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        event.setCancelled(true);
        if (event.getCurrentItem() == null || event.getCurrentItem().getType().isAir()) {
            return;
        }
        switch (holder.screen) {
            case ROOT -> this.handleRootClick(player, event.getRawSlot());
            case PICKAXES -> this.handlePickaxeClick(player, holder, event.getRawSlot());
            case GEAR_ROOT -> this.handleGearRootClick(player, event.getRawSlot());
            case GEAR_CATEGORY -> this.handleGearCategoryClick(player, holder, event.getRawSlot());
        }
    }

    private void handleRootClick(Player player, int slot) {
        if (slot == ROOT_PICKAXE_SLOT) {
            this.openPickaxeMenu(player);
        } else if (slot == ROOT_GEAR_SLOT) {
            this.openGearRoot(player);
        }
    }

    private void handlePickaxeClick(Player player, Holder holder, int slot) {
        if (slot == PREV_SLOT) {
            this.openPickaxeMenu(player, Math.max(0, holder.page - 1));
            return;
        }
        if (slot == NEXT_SLOT) {
            this.openPickaxeMenu(player, holder.page + 1);
            return;
        }
        if (slot == BACK_SLOT) {
            this.openRoot(player);
        } else if (slot == EXIT_SLOT) {
            this.openGearRoot(player);
        }
    }

    private void handleGearRootClick(Player player, int slot) {
        switch (slot) {
            case GEAR_HELMET_SLOT -> this.openGearCategory(player, GearTab.HELMET);
            case GEAR_CHEST_SLOT -> this.openGearCategory(player, GearTab.CHESTPLATE);
            case GEAR_LEG_SLOT -> this.openGearCategory(player, GearTab.LEGGINGS);
            case GEAR_BOOT_SLOT -> this.openGearCategory(player, GearTab.BOOTS);
            case GEAR_WEAPON_SLOT -> this.openGearCategory(player, GearTab.WEAPON);
            case BACK_SLOT -> this.openRoot(player);
            default -> {
            }
        }
    }

    private void handleGearCategoryClick(Player player, Holder holder, int slot) {
        GearTab tab = holder.gearTab;
        if (tab == null) {
            return;
        }
        if (slot == PREV_SLOT) {
            this.openGearCategory(player, tab, Math.max(0, holder.page - 1));
            return;
        }
        if (slot == NEXT_SLOT) {
            this.openGearCategory(player, tab, holder.page + 1);
            return;
        }
        if (slot == BACK_SLOT) {
            this.openGearRoot(player);
        } else if (slot == EXIT_SLOT) {
            this.openRoot(player);
        }
    }

    private void openRoot(Player player) {
        Holder holder = new Holder(Screen.ROOT, null, 0);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Enchant Index"));
        holder.inventory = inventory;
        this.fillRootFrame(inventory);
        inventory.setItem(ROOT_PICKAXE_SLOT, this.card(
                Material.DIAMOND_PICKAXE,
                "&b&lPickaxe Enchants",
                List.of(
                        "&7All mining enchants in one place.",
                        "&7Charge, proc, and block-breaking bonuses.",
                        "",
                        "&f" + this.pickaxeEnchantCount() + " &7enchants"
                )));
        inventory.setItem(ROOT_GEAR_SLOT, this.card(
                Material.DIAMOND_CHESTPLATE,
                "&a&lGear Enchants",
                List.of(
                        "&7Armor and weapon enchants.",
                        "&7Browse helmets, chestplates, leggings, boots,",
                        "&7swords, and axes.",
                        "",
                        "&f" + this.gearEnchantCount() + " &7enchants"
                )));
        inventory.setItem(ROOT_INFO_SLOT, this.info(
                Material.BOOK,
                "&f&lGuide",
                List.of(
                        "&7Select a category to drill down.",
                        "&7Gear enchants that do not specify a target",
                        "&7appear in every matching gear menu."
                )));
        inventory.setItem(ROOT_NOTE_SLOT, this.info(
                Material.COMPASS,
                "&d&lMenu Layout",
                List.of(
                        "&7Pickaxe enchants are separated from gear enchants.",
                        "&7Gear enchants are then grouped by equipment type."
                )));
        player.openInventory(inventory);
    }

    private void openPickaxeMenu(Player player) {
        this.openPickaxeMenu(player, 0);
    }

    private void openPickaxeMenu(Player player, int page) {
        Holder holder = new Holder(Screen.PICKAXES, null, Math.max(0, page));
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Pickaxe Enchants"));
        holder.inventory = inventory;
        this.fillListFrame(inventory, "&b&lPickaxe Enchant Library", "&7These enchants apply to prison pickaxes.");
        List<CustomEnchant> enchants = this.getPickaxeEnchants();
        if (enchants.isEmpty()) {
            inventory.setItem(31, this.info(Material.BARRIER, "&cNo Pickaxe Enchants", List.of("&7No pickaxe enchants are loaded.")));
        } else {
            this.placeEnchantList(inventory, enchants, holder.page, this::pickaxeLore);
        }
        inventory.setItem(BACK_SLOT, this.nav(Material.ARROW, "&7Back", List.of("&7Return to the enchant index.")));
        inventory.setItem(EXIT_SLOT, this.nav(Material.BOOK, "&dGear Index", List.of("&7Jump to the gear enchant categories.")));
        player.openInventory(inventory);
    }

    private void openGearRoot(Player player) {
        Holder holder = new Holder(Screen.GEAR_ROOT, null, 0);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Gear Enchants"));
        holder.inventory = inventory;
        this.fillListFrame(inventory, "&a&lGear Enchant Categories", "&7Choose which equipment type you want to inspect.");
        inventory.setItem(GEAR_HELMET_SLOT, this.categoryCard(GearTab.HELMET, this.categoryCount(GearTab.HELMET)));
        inventory.setItem(GEAR_CHEST_SLOT, this.categoryCard(GearTab.CHESTPLATE, this.categoryCount(GearTab.CHESTPLATE)));
        inventory.setItem(GEAR_LEG_SLOT, this.categoryCard(GearTab.LEGGINGS, this.categoryCount(GearTab.LEGGINGS)));
        inventory.setItem(GEAR_BOOT_SLOT, this.categoryCard(GearTab.BOOTS, this.categoryCount(GearTab.BOOTS)));
        inventory.setItem(GEAR_WEAPON_SLOT, this.categoryCard(GearTab.WEAPON, this.categoryCount(GearTab.WEAPON)));
        inventory.setItem(ROOT_INFO_SLOT, this.info(
                Material.FILLED_MAP,
                "&f&lCoverage",
                List.of(
                        "&7Armor enchants appear in every armor menu they fit.",
                        "&7Unspecified gear enchants appear in all matching menus.",
                        "&7Weapon enchants appear under swords and axes."
                )));
        inventory.setItem(BACK_SLOT, this.nav(Material.ARROW, "&7Back", List.of("&7Return to the enchant index.")));
        player.openInventory(inventory);
    }

    private void openGearCategory(Player player, GearTab tab) {
        this.openGearCategory(player, tab, 0);
    }

    private void openGearCategory(Player player, GearTab tab, int page) {
        if (tab == null) {
            this.openGearRoot(player);
            return;
        }
        Holder holder = new Holder(Screen.GEAR_CATEGORY, tab, Math.max(0, page));
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color(tab.title()));
        holder.inventory = inventory;
        this.fillListFrame(inventory, tab.header(), tab.subHeader());
        List<CustomEnchant> enchants = this.getGearEnchants(tab);
        if (enchants.isEmpty()) {
            inventory.setItem(31, this.info(Material.BARRIER, "&cNo Enchants", List.of("&7No enchants currently fit this category.")));
        } else {
            this.placeEnchantList(inventory, enchants, holder.page, enchant -> this.gearLore(enchant, tab));
        }
        inventory.setItem(BACK_SLOT, this.nav(Material.ARROW, "&7Back", List.of("&7Return to gear categories.")));
        inventory.setItem(EXIT_SLOT, this.nav(Material.BOOK, "&dEnchant Index", List.of("&7Return to the main enchant index.")));
        player.openInventory(inventory);
    }

    private void fillRootFrame(Inventory inventory) {
        ItemStack pane = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack accent = this.pane(Material.MAGENTA_STAINED_GLASS_PANE);
        for (int slot = 0; slot < SIZE; ++slot) {
            inventory.setItem(slot, pane);
        }
        inventory.setItem(0, accent);
        inventory.setItem(8, accent);
        inventory.setItem(45, accent);
        inventory.setItem(53, accent);
        inventory.setItem(2, accent);
        inventory.setItem(6, accent);
        inventory.setItem(47, accent);
        inventory.setItem(51, accent);
    }

    private void fillListFrame(Inventory inventory, String header, String subtitle) {
        ItemStack pane = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        ItemStack accent = this.pane(Material.PURPLE_STAINED_GLASS_PANE);
        ItemStack soft = this.pane(Material.GRAY_STAINED_GLASS_PANE);
        for (int slot = 0; slot < SIZE; ++slot) {
            inventory.setItem(slot, pane);
        }
        for (int slot : LIST_SLOTS) {
            inventory.setItem(slot, null);
        }
        inventory.setItem(1, this.info(Material.NETHER_STAR, header, List.of(subtitle)));
        inventory.setItem(7, this.info(Material.BOOK, "&f&lRarity Order", List.of(
                "&fBasic &7-> &bUncommon &7-> &3Unique",
                "&7-> &aRare &7-> &eElite &7-> &6Legendary"
        )));
        inventory.setItem(4, accent);
        inventory.setItem(49, accent);
        inventory.setItem(45, soft);
        inventory.setItem(53, soft);
    }

    private void placeEnchantList(Inventory inventory, List<CustomEnchant> enchants, int page, LoreBuilder builder) {
        List<CustomEnchant> ordered = enchants.stream()
                .sorted(Comparator.comparingInt((CustomEnchant enchant) -> this.rarityOrder(enchant.getRarity()))
                        .thenComparing(enchant -> Text.strip(enchant.getDisplayName()), String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
        int maxPage = this.maxPage(ordered.size());
        int clampedPage = Math.max(0, Math.min(page, maxPage));
        int start = clampedPage * LIST_SLOTS.length;
        int end = Math.min(ordered.size(), start + LIST_SLOTS.length);
        for (int i = start; i < end; ++i) {
            CustomEnchant enchant = ordered.get(i);
            inventory.setItem(LIST_SLOTS[i - start], this.enchantCard(enchant, builder.build(enchant)));
        }
        if (ordered.size() > LIST_SLOTS.length) {
            inventory.setItem(PREV_SLOT, this.nav(clampedPage > 0 ? Material.ARROW : Material.GRAY_DYE, "&ePrevious Page", List.of("&7Go to the previous page.")));
            inventory.setItem(NEXT_SLOT, this.nav(clampedPage < maxPage ? Material.ARROW : Material.GRAY_DYE, "&eNext Page", List.of("&7Go to the next page.")));
            inventory.setItem(PAGE_SLOT, this.info(Material.PAPER, "&fPage &7" + (clampedPage + 1) + "&8/&7" + (maxPage + 1), List.of("&7Entries: &f" + ordered.size())));
        }
    }

    private ItemStack enchantCard(CustomEnchant enchant, List<String> extraLore) {
        Material material = enchant.getRarity() == null ? Material.GRAY_DYE : enchant.getRarity().getDisplayMaterial();
        String displayName = (enchant.getRarity() == null ? "" : enchant.getRarity().getColorCode()) + enchant.getDisplayName();
        ArrayList<String> lore = new ArrayList<String>();
        if (enchant.getDescription() != null && !enchant.getDescription().isBlank()) {
            lore.add("&7" + enchant.getDescription());
        }
        if (extraLore != null && !extraLore.isEmpty()) {
            if (!lore.isEmpty()) {
                lore.add("");
            }
            lore.addAll(extraLore);
        }
        lore.add("");
        lore.add("&7Rarity: " + (enchant.getRarity() == null ? "&fUNKNOWN" : enchant.getRarity().getColorCode() + enchant.getRarity().name()));
        lore.add("&7Max Level: &f" + this.roman(enchant.getMaxLevel()) + " &7(" + enchant.getMaxLevel() + ")");
        return this.info(material, displayName, lore);
    }

    private ItemStack categoryCard(GearTab tab, int count) {
        return this.card(tab.icon(), tab.displayName(), List.of(
                tab.description(),
                "",
                "&f" + count + " &7enchants",
                "&7Click to browse"
        ));
    }

    private ItemStack card(Material material, String name, List<String> lore) {
        return this.info(material, name, lore);
    }

    private ItemStack nav(Material material, String name, List<String> lore) {
        return this.info(material, name, lore);
    }

    private ItemStack info(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(name));
            ArrayList<Component> components = new ArrayList<Component>();
            if (lore != null) {
                for (String line : lore) {
                    components.add(Text.componentNoItalics(line));
                }
            }
            meta.lore(components);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.componentNoItalics(" "));
            item.setItemMeta(meta);
        }
        return item;
    }

    private List<CustomEnchant> getPickaxeEnchants() {
        if (this.enchantService == null) {
            return List.of();
        }
        return this.enchantService.getAll().stream()
                .filter(enchant -> enchant != null && !enchant.getId().equalsIgnoreCase("buster_efficiency"))
                .collect(Collectors.toList());
    }

    private List<CustomEnchant> getGearEnchants(GearTab tab) {
        if (this.gearEnchantService == null || tab == null) {
            return List.of();
        }
        return this.gearEnchantService.getAll().stream()
                .filter(enchant -> enchant != null && this.supports(tab, enchant))
                .collect(Collectors.toList());
    }

    private int pickaxeEnchantCount() {
        return this.getPickaxeEnchants().size();
    }

    private int gearEnchantCount() {
        if (this.gearEnchantService == null) {
            return 0;
        }
        return this.gearEnchantService.getAll().size();
    }

    private int categoryCount(GearTab tab) {
        return this.getGearEnchants(tab).size();
    }

    private boolean supports(GearTab tab, CustomEnchant enchant) {
        if (tab == null || enchant == null) {
            return false;
        }
        if (enchant.getApplicableTypes().isEmpty()) {
            return true;
        }
        return switch (tab) {
            case HELMET -> enchant.isApplicableTo(Material.DIAMOND_HELMET);
            case CHESTPLATE -> enchant.isApplicableTo(Material.DIAMOND_CHESTPLATE);
            case LEGGINGS -> enchant.isApplicableTo(Material.DIAMOND_LEGGINGS);
            case BOOTS -> enchant.isApplicableTo(Material.DIAMOND_BOOTS);
            case WEAPON -> enchant.isApplicableTo(Material.DIAMOND_SWORD) || enchant.isApplicableTo(Material.DIAMOND_AXE);
        };
    }

    private List<String> pickaxeLore(CustomEnchant enchant) {
        return List.of(
                "&7Applies to: &fAll Pickaxes",
                "&7Type: &fMining enchant"
        );
    }

    private List<String> gearLore(CustomEnchant enchant, GearTab tab) {
        return List.of(
                "&7Applies to: &f" + this.describeTargets(enchant),
                "&7Category: &f" + tab.displayNamePlain()
        );
    }

    private String describeTargets(CustomEnchant enchant) {
        if (enchant == null) {
            return "Unknown";
        }
        Set<String> types = enchant.getApplicableTypes();
        if (types.isEmpty()) {
            return "All Gear";
        }
        if (types.contains("ARMOR")) {
            return "All Armor";
        }
        if (types.contains("WEAPON")) {
            return "Swords & Axes";
        }
        ArrayList<String> labels = new ArrayList<String>();
        if (types.contains("HELMET")) {
            labels.add("Helmets");
        }
        if (types.contains("CHESTPLATE")) {
            labels.add("Chestplates");
        }
        if (types.contains("LEGGINGS")) {
            labels.add("Leggings");
        }
        if (types.contains("BOOTS")) {
            labels.add("Boots");
        }
        if (types.contains("SWORD")) {
            labels.add("Swords");
        }
        if (types.contains("AXE")) {
            labels.add("Axes");
        }
        if (types.contains("HOE")) {
            labels.add("Hoes");
        }
        if (types.contains("SHOVEL")) {
            labels.add("Shovels");
        }
        if (types.contains("TRIDENT")) {
            labels.add("Tridents");
        }
        if (types.contains("SHIELD")) {
            labels.add("Shields");
        }
        if (types.contains("BOW")) {
            labels.add("Bows");
        }
        if (types.contains("CROSSBOW")) {
            labels.add("Crossbows");
        }
        if (labels.isEmpty()) {
            labels.addAll(types.stream().map(value -> value.substring(0, 1) + value.substring(1).toLowerCase(Locale.ROOT)).collect(Collectors.toList()));
        }
        if (labels.size() == 2 && labels.contains("Swords") && labels.contains("Axes")) {
            return "Swords & Axes";
        }
        if (labels.size() == 4 && labels.contains("Helmets") && labels.contains("Chestplates") && labels.contains("Leggings") && labels.contains("Boots")) {
            return "All Armor";
        }
        return String.join(", ", labels);
    }

    private int rarityOrder(EnchantRarity rarity) {
        if (rarity == null) {
            return Integer.MAX_VALUE;
        }
        return switch (rarity) {
            case BASIC -> 0;
            case UNIQUE, UNCOMMON -> 1;
            case RARE -> 2;
            case ELITE -> 3;
            case LEGENDARY -> 4;
        };
    }

    private int maxPage(int count) {
        if (count <= 0) {
            return 0;
        }
        return (count - 1) / LIST_SLOTS.length;
    }

    private String roman(int number) {
        int n = Math.max(1, number);
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                sb.append(numerals[i]);
                n -= values[i];
            }
        }
        return sb.toString();
    }

    private enum Screen {
        ROOT,
        PICKAXES,
        GEAR_ROOT,
        GEAR_CATEGORY
    }

    private enum GearTab {
        HELMET(Material.DIAMOND_HELMET, "&b&lHelmets", "&7Armor enchants for helmets."),
        CHESTPLATE(Material.DIAMOND_CHESTPLATE, "&a&lChestplates", "&7Armor enchants for chestplates."),
        LEGGINGS(Material.DIAMOND_LEGGINGS, "&d&lLeggings", "&7Armor enchants for leggings."),
        BOOTS(Material.DIAMOND_BOOTS, "&6&lBoots", "&7Armor enchants for boots."),
        WEAPON(Material.DIAMOND_SWORD, "&c&lSwords & Axes", "&7Weapon enchants for swords and axes.");

        private final Material icon;
        private final String displayName;
        private final String description;

        GearTab(Material icon, String displayName, String description) {
            this.icon = icon;
            this.displayName = displayName;
            this.description = description;
        }

        public Material icon() {
            return this.icon;
        }

        public String displayName() {
            return this.displayName;
        }

        public String displayNamePlain() {
            return Text.strip(this.displayName);
        }

        public String description() {
            return this.description;
        }

        public String title() {
            return "&8" + this.displayNamePlain();
        }

        public String header() {
            return this.displayName;
        }

        public String subHeader() {
            return "&7Browse the enchants that fit this equipment type.";
        }
    }

    private interface LoreBuilder {
        List<String> build(CustomEnchant enchant);
    }

    private static class Holder implements InventoryHolder {
        private final Screen screen;
        private final GearTab gearTab;
        private final int page;
        private Inventory inventory;

        private Holder(Screen screen, GearTab gearTab, int page) {
            this.screen = screen;
            this.gearTab = gearTab;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
