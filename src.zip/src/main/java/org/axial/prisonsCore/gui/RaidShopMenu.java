package org.axial.prisonsCore.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.ContrabandService;
import org.axial.prisonsCore.service.EnergyItemService;
import org.axial.prisonsCore.service.RaidPointService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class RaidShopMenu implements Listener {
    private static final int SIZE = 27;
    private static final int RAW_ENERGY_SLOT = 11;
    private static final int[] ITEM_SLOTS = new int[]{12, 13, 14, 15};
    private final PrisonsCore plugin;
    private final RaidPointService raidPointService;
    private final EnergyItemService energyItemService;
    private final ContrabandService contrabandService;

    public RaidShopMenu(PrisonsCore plugin, RaidPointService raidPointService, EnergyItemService energyItemService, ContrabandService contrabandService) {
        this.plugin = plugin;
        this.raidPointService = raidPointService;
        this.energyItemService = energyItemService;
        this.contrabandService = contrabandService;
    }

    public void open(Player player) {
        RaidShopHolder holder = new RaidShopHolder();
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Raid Shop"));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        inventory.setItem(4, this.balanceItem(player));
        inventory.setItem(RAW_ENERGY_SLOT, this.shopItem(50, () -> this.energyItemService.createEnergyItem(50000)));
        inventory.setItem(ITEM_SLOTS[0], this.shopItem(15, () -> this.contrabandService.createContraband("basic_cont")));
        inventory.setItem(ITEM_SLOTS[1], this.shopItem(20, () -> this.contrabandService.createContraband("rare_cont")));
        inventory.setItem(ITEM_SLOTS[2], this.shopItem(25, () -> this.contrabandService.createContraband("elite_cont")));
        inventory.setItem(ITEM_SLOTS[3], this.shopItem(50, () -> this.contrabandService.createContraband("legendary_cont")));
        player.playSound(player.getLocation(), Sound.ENTITY_BAT_TAKEOFF, 1.0f, 1.0f);
        player.openInventory(inventory);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof RaidShopHolder)) {
            return;
        }
        if (event.getClickedInventory() == null || event.getClickedInventory() != event.getView().getTopInventory()) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        int slot = event.getRawSlot();
        ShopEntry entry = this.entryForSlot(slot);
        if (entry == null) {
            return;
        }
        if (!this.raidPointService.withdrawPoints(player, entry.cost)) {
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
            player.sendMessage(Lang.msg("raidshop.not-enough", "&cYou need {amount} raid points.").replace("{amount}", this.raidPointService.format(entry.cost)));
            return;
        }
        ItemStack reward = entry.createReward(this);
        if (reward == null) {
            this.raidPointService.addPoints(player, entry.cost);
            player.sendMessage(Text.color("&cThat item is not configured."));
            return;
        }
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, reward);
        } else {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(reward);
            leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(Lang.msg("raidshop.purchased", "&aPurchased {item} &afor &f{amount} raid points.")
                .replace("{item}", Text.color(entry.name))
                .replace("{amount}", this.raidPointService.format(entry.cost)));
        player.getOpenInventory().getTopInventory().setItem(4, this.balanceItem(player));
    }

    private ShopEntry entryForSlot(int slot) {
        for (ShopEntry entry : ShopEntry.values()) {
            if (entry.slot == slot) {
                return entry;
            }
        }
        return null;
    }

    private ItemStack balanceItem(Player player) {
        ItemStack item = new ItemStack(Material.PAPER);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Text.color("&c&lRaid Points"));
        List<String> lore = new ArrayList<String>();
        lore.add(Text.color("&7Your balance: &f" + this.raidPointService.format(this.raidPointService.getBalance(player))));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Redeem raid point notes to"));
        lore.add(Text.color("&7increase your balance."));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack shopItem(int cost, java.util.function.Supplier<ItemStack> outputSupplier) {
        ItemStack output = outputSupplier == null ? null : outputSupplier.get();
        ItemStack item = output != null ? output.clone() : new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return item;
        }
        ArrayList<String> lines = new ArrayList<String>();
        if (meta.hasLore()) {
            lines.addAll(meta.getLore());
        }
        lines.add(Text.color("&7"));
        lines.add(Text.color("&7Current Price: &f" + this.raidPointService.format(cost) + " raid points"));
        lines.add(Text.color("&eLeft-Click &7to purchase"));
        meta.setLore(lines);
        item.setItemMeta(meta);
        return item;
    }

    private void fillBackground(Inventory inventory) {
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        meta.setDisplayName(" ");
        filler.setItemMeta(meta);
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
    }

    private enum ShopEntry {
        RAW_ENERGY(RaidShopMenu.RAW_ENERGY_SLOT, 50, "50,000 Raw Charge"),
        BASIC_CONTRABAND(RaidShopMenu.ITEM_SLOTS[0], 15, "Basic Contraband"),
        RARE_CONTRABAND(RaidShopMenu.ITEM_SLOTS[1], 20, "Rare Contraband"),
        ELITE_CONTRABAND(RaidShopMenu.ITEM_SLOTS[2], 25, "Elite Contraband"),
        LEGENDARY_CONTRABAND(RaidShopMenu.ITEM_SLOTS[3], 50, "Legendary Contraband");

        private final int slot;
        private final int cost;
        private final String name;

        ShopEntry(int slot, int cost, String name) {
            this.slot = slot;
            this.cost = cost;
            this.name = name;
        }

        private ItemStack createReward(RaidShopMenu menu) {
            return switch (this) {
                case RAW_ENERGY -> menu.energyItemService.createEnergyItem(50000);
                case BASIC_CONTRABAND -> menu.contrabandService.createContraband("basic_cont");
                case RARE_CONTRABAND -> menu.contrabandService.createContraband("rare_cont");
                case ELITE_CONTRABAND -> menu.contrabandService.createContraband("elite_cont");
                case LEGENDARY_CONTRABAND -> menu.contrabandService.createContraband("legendary_cont");
            };
        }
    }

    private final class RaidShopHolder implements InventoryHolder {
        private Inventory inventory;

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
