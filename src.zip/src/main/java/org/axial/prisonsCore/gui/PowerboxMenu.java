package org.axial.prisonsCore.gui;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PowerboxService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class PowerboxMenu implements Listener {
    private static final int INVENTORY_SIZE = 27;
    private static final int[] REWARD_SLOTS = new int[]{11, 12, 13, 14, 15};
    private static final int TASK_PERIOD_TICKS = 1;
    private static final int SLOT_SPIN_DURATION_TICKS = 140;
    private static final int SLOT_START_STAGGER_TICKS = 140;
    private static final int SLOT_REROLL_PERIOD_TICKS = 1;
    private static final int TOTAL_DURATION_TICKS = ((REWARD_SLOTS.length - 1) * SLOT_START_STAGGER_TICKS) + SLOT_SPIN_DURATION_TICKS;
    private final PrisonsCore plugin;
    private final PowerboxService powerboxService;
    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();

    public PowerboxMenu(PrisonsCore plugin, PowerboxService powerboxService) {
        this.plugin = plugin;
        this.powerboxService = powerboxService;
    }

    public void open(Player player, String powerboxId) {
        Session existing = this.sessions.remove(player.getUniqueId());
        if (existing != null) {
            existing.cancel();
        }
        Session session = new Session(player.getUniqueId(), powerboxId);
        Inventory inventory = Bukkit.createInventory(session, INVENTORY_SIZE, Text.color(this.powerboxService.menuTitle(powerboxId)));
        session.inventory = inventory;
        this.fillBackground(inventory);
        for (int slot : REWARD_SLOTS) {
            inventory.setItem(slot, this.namedPane(Material.CHEST, "&7Rolling reward..."));
        }
        player.openInventory(inventory);
        this.startSpin(player, session);
        this.sessions.put(player.getUniqueId(), session);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Session)) {
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof Session session)) {
            return;
        }
        if (session.completed) {
            this.sessions.remove(session.owner);
            return;
        }
        Player player = (Player)event.getPlayer();
        this.finalizeReward(player, session);
    }

    private void startSpin(Player player, Session session) {
        final BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            if (session.completed) {
                if (taskHolder[0] != null) {
                    taskHolder[0].cancel();
                }
                return;
            }
            if (session.elapsedTicks >= TOTAL_DURATION_TICKS) {
                this.finalizeReward(player, session);
                if (taskHolder[0] != null) {
                    taskHolder[0].cancel();
                }
                return;
            }
            for (int index = 0; index < REWARD_SLOTS.length; ++index) {
                if (session.locked[index]) {
                    continue;
                }
                int slot = REWARD_SLOTS[index];
                int slotStart = index * SLOT_START_STAGGER_TICKS;
                int slotEnd = slotStart + SLOT_SPIN_DURATION_TICKS;
                if (session.elapsedTicks < slotStart) {
                    continue;
                }
                if (!session.started[index]) {
                    session.started[index] = true;
                    player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.7f, 1.5f);
                }
                if ((session.elapsedTicks - slotStart) % SLOT_REROLL_PERIOD_TICKS == 0L || !session.livePreviews.containsKey(slot)) {
                    PowerboxService.RewardRoll roll = this.powerboxService.rollReward(session.powerboxId);
                    if (roll != null) {
                        session.livePreviews.put(slot, roll);
                        session.inventory.setItem(slot, this.powerboxService.previewItem(roll));
                    }
                }
                if (session.elapsedTicks >= slotEnd) {
                    this.lockReward(player, session, slot, index);
                }
            }
            session.elapsedTicks += TASK_PERIOD_TICKS;
        }, 0L, TASK_PERIOD_TICKS);
        session.task = taskHolder[0];
    }

    private void finalizeReward(Player player, Session session) {
        if (session.completed) {
            return;
        }
        session.completed = true;
        if (session.task != null) {
            session.task.cancel();
        }
        boolean foundReward = false;
        for (int slot : REWARD_SLOTS) {
            PowerboxService.RewardRoll roll = session.rewards.get(slot);
            if (roll == null) {
                roll = session.livePreviews.get(slot);
            }
            if (roll == null) {
                roll = this.powerboxService.rollReward(session.powerboxId);
            }
            if (roll == null) {
                session.inventory.setItem(slot, this.namedPane(Material.BARRIER, "&cNo rewards configured"));
                continue;
            }
            foundReward = true;
            session.rewards.put(slot, roll);
            session.inventory.setItem(slot, this.powerboxService.previewItem(roll));
            this.powerboxService.award(player, roll);
        }
        if (!foundReward) {
            player.sendMessage(Text.color("&cThis powerbox has no configured rewards."));
            this.sessions.remove(player.getUniqueId());
            return;
        }
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
        player.sendTitle(Text.color("&6&lPowerbox Opened"), "", 5, 30, 10);
        Bukkit.broadcastMessage(Text.color("&f&l(!) &f&n" + player.getName() + "&f Has opened a " + this.powerboxService.displayName(session.powerboxId) + "&f and received:"));
        for (int slot : REWARD_SLOTS) {
            PowerboxService.RewardRoll reward = session.rewards.get(slot);
            if (reward == null) {
                continue;
            }
            Bukkit.broadcastMessage(Text.color("&6&l* " + this.powerboxService.rewardSummary(reward)));
        }
        this.sessions.remove(player.getUniqueId());
    }

    private void lockReward(Player player, Session session, int slot, int index) {
        if (session.locked[index]) {
            return;
        }
        PowerboxService.RewardRoll roll = session.livePreviews.get(slot);
        if (roll == null) {
            roll = this.powerboxService.rollReward(session.powerboxId);
        }
        if (roll == null) {
            return;
        }
        session.locked[index] = true;
        session.rewards.put(slot, roll);
        session.livePreviews.remove(slot);
        session.inventory.setItem(slot, this.powerboxService.previewItem(roll));
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 0.8f, 1.35f);
    }

    private void fillBackground(Inventory inventory) {
        ItemStack filler = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
    }

    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack namedPane(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(name));
            item.setItemMeta(meta);
        }
        return item;
    }

    private static final class Session implements InventoryHolder {
        private final UUID owner;
        private final String powerboxId;
        private final Map<Integer, PowerboxService.RewardRoll> rewards = new HashMap<Integer, PowerboxService.RewardRoll>();
        private final Map<Integer, PowerboxService.RewardRoll> livePreviews = new HashMap<Integer, PowerboxService.RewardRoll>();
        private final boolean[] locked = new boolean[REWARD_SLOTS.length];
        private final boolean[] started = new boolean[REWARD_SLOTS.length];
        private Inventory inventory;
        private BukkitTask task;
        private int elapsedTicks;
        private boolean completed;

        private Session(UUID owner, String powerboxId) {
            this.owner = owner;
            this.powerboxId = powerboxId;
        }

        private void cancel() {
            if (this.task != null) {
                this.task.cancel();
            }
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
