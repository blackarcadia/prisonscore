package org.axial.prisonsCore.gui;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.CustomBlockService;
import org.axial.prisonsCore.service.LockboxService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class LockboxMenu implements Listener {
    private static final int SIZE = 27;
    private static final int TASK_SLOT = 11;
    private static final int CENTER_SLOT = 13;
    private static final int PROGRESS_SLOT = 15;
    private final PrisonsCore plugin;
    private final LockboxService lockboxService;
    private final Map<UUID, Session> sessions = new HashMap<UUID, Session>();

    public LockboxMenu(PrisonsCore plugin, LockboxService lockboxService) {
        this.plugin = plugin;
        this.lockboxService = lockboxService;
    }

    public void open(Player player, CustomBlockService.BlockPos pos) {
        Session existing = this.sessions.remove(player.getUniqueId());
        if (existing != null) {
            existing.cancel();
        }
        LockboxService.LockboxState state = this.lockboxService.getState(pos);
        if (state == null) {
            player.sendMessage(Text.color("&cThat lockbox could not be loaded."));
            return;
        }
        Session holder = new Session(player.getUniqueId(), pos);
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Lockbox"));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        this.populate(inventory, state);
        player.openInventory(inventory);
        this.sessions.put(player.getUniqueId(), holder);
    }

    public void refresh(CustomBlockService.BlockPos pos) {
        if (pos == null) {
            return;
        }
        for (Session session : this.sessions.values()) {
            if (!session.pos.equals(pos) || session.inventory == null) {
                continue;
            }
            LockboxService.LockboxState state = this.lockboxService.getState(pos);
            if (state == null) {
                continue;
            }
            this.populate(session.inventory, state);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Session)) {
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof Session session)) {
            return;
        }
        this.sessions.remove(session.owner);
        session.cancel();
    }

    private void populate(Inventory inventory, LockboxService.LockboxState state) {
        if (inventory == null || state == null) {
            return;
        }
        inventory.setItem(TASK_SLOT, this.taskItem(state));
        inventory.setItem(CENTER_SLOT, this.centerItem(state));
        inventory.setItem(PROGRESS_SLOT, this.progressItem(state));
    }

    private ItemStack centerItem(LockboxService.LockboxState state) {
        ItemStack item = new ItemStack(Material.NOTE_BLOCK);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&6&lLockbox"));
            meta.setCustomModelData(105);
            meta.setLore(java.util.List.of(
                    Text.color("&7Owned by &f" + this.ownerName(state.owner())),
                    Text.color("&7Completed tasks: &f" + Math.min(10, state.completedTasks()) + "&7/&f10"),
                    Text.color("&7Daily progress bonus: &f15%")
            ));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack taskItem(LockboxService.LockboxState state) {
        ItemStack item = new ItemStack(Material.WRITABLE_BOOK);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&eCurrent Task"));
            java.util.ArrayList<String> lore = new java.util.ArrayList<String>();
            if (state.isCompleted()) {
                lore.add(Text.color("&aAll tasks complete."));
            } else {
                LockboxService.LockboxTask task = state.currentTask();
                if (task == null) {
                    lore.add(Text.color("&cTask data unavailable."));
                } else {
                    lore.add(Text.color("&7" + task.displayName()));
                    lore.add(Text.color("&7Progress: &f" + state.activeProgress() + "&7/&f" + task.required()));
                }
                lore.add(Text.color("&7Resets in: &f" + this.lockboxService.formatDuration(Math.max(0L, state.activeDueAt() - System.currentTimeMillis()))));
            }
            meta.setLore(lore);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack progressItem(LockboxService.LockboxState state) {
        ItemStack item = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            double progress = Math.max(0.0D, Math.min(100.0D, state.progress()));
            meta.setDisplayName(Text.color("&aProgress: &f" + Text.formatPercent(progress)));
            java.util.ArrayList<String> lore = new java.util.ArrayList<String>();
            lore.add(Text.color("&7" + this.lockboxService.progressBar(progress)));
            lore.add(Text.color("&7" + Text.formatPercent(progress) + " complete"));
            if (!state.isCompleted()) {
                lore.add(Text.color("&7Next daily gain in &f" + this.lockboxService.formatDuration(Math.max(0L, state.nextDailyAwardAt() - System.currentTimeMillis()))));
            }
            meta.setLore(lore);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    private void fillBackground(Inventory inventory) {
        ItemStack pane = this.backgroundPane();
        for (int i = 0; i < inventory.getSize(); ++i) {
            inventory.setItem(i, pane);
        }
    }

    private ItemStack backgroundPane() {
        ItemStack item = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            item.setItemMeta(meta);
        }
        return item;
    }

    private String ownerName(UUID owner) {
        if (owner == null) {
            return "Unknown";
        }
        Player online = Bukkit.getPlayer(owner);
        if (online != null) {
            return online.getName();
        }
        String name = Bukkit.getOfflinePlayer(owner).getName();
        return name != null ? name : owner.toString();
    }

    private static final class Session implements InventoryHolder {
        private final UUID owner;
        private final CustomBlockService.BlockPos pos;
        private Inventory inventory;

        private Session(UUID owner, CustomBlockService.BlockPos pos) {
            this.owner = owner;
            this.pos = pos;
        }

        private void cancel() {
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
