package org.axial.prisonsCore.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public class PrestigeMenu implements Listener {
    private static final int SIZE = 9;
    private static final int[] PRESTIGE_SLOTS = new int[]{2, 3, 4, 5, 6};
    private static final String[] PRESTIGE_REWARDS = new String[]{
            "15 Legendary Contraband",
            "10 Elite Contraband",
            "64 Legendary Fragments"
    };
    private static final String[] PRESTIGE_LABELS = new String[]{
            "Prestige &d&l<&6&lI&d&l>",
            "Prestige &d&l<&6&lII&d&l>",
            "Prestige &d&l<&6&lIII&d&l>",
            "Prestige &d&l<&6&lIV&d&l>",
            "Prestige &d&l<&6&lV&d&l>"
    };
    private final PlayerLevelService levelService;

    public PrestigeMenu(PlayerLevelService levelService) {
        this.levelService = levelService;
    }

    public void open(Player player) {
        PrestigeHolder holder = new PrestigeHolder(player.getUniqueId());
        Inventory inventory = Bukkit.createInventory(holder, SIZE, Text.color("&8Prestige"));
        holder.inventory = inventory;
        this.fillSides(inventory);
        this.renderPrestiges(inventory, player);
        player.openInventory(inventory);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getInventory().getHolder() instanceof PrestigeHolder holder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (!player.getUniqueId().equals(holder.owner)) {
            return;
        }
        int slot = event.getRawSlot();
        int prestigeIndex = this.prestigeIndexForSlot(slot);
        if (prestigeIndex < 0) {
            return;
        }
        int prestigeRank = prestigeIndex + 1;
        int currentPrestige = this.levelService.getPrestigeLevel(player);
        if (currentPrestige >= prestigeRank) {
            return;
        }
        int requiredLevel = this.levelService.getConfig().getPrestigeStart() + currentPrestige;
        if (this.levelService.getLevel(player) < requiredLevel) {
            player.sendMessage(Text.color("&cReach level " + requiredLevel + " to claim Prestige " + this.levelService.getPrestigeRomanNumeral(prestigeRank) + "."));
            return;
        }
        if (this.levelService.claimPrestige(player)) {
            player.closeInventory();
        }
    }

    private void renderPrestiges(Inventory inventory, Player player) {
        int currentPrestige = this.levelService.getPrestigeLevel(player);
        int currentLevel = this.levelService.getLevel(player);
        for (int i = 0; i < PRESTIGE_SLOTS.length; ++i) {
            int rank = i + 1;
            PrestigeState state = this.stateFor(rank, currentPrestige, currentLevel);
            inventory.setItem(PRESTIGE_SLOTS[i], this.createPrestigeItem(rank, state));
        }
    }

    private ItemStack createPrestigeItem(int rank, PrestigeState state) {
        Material material = switch (state) {
            case CLAIMED -> Material.LIME_STAINED_GLASS_PANE;
            case UNLOCKED -> Material.WHITE_STAINED_GLASS_PANE;
            case LOCKED -> Material.RED_STAINED_GLASS_PANE;
        };
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String color = state == PrestigeState.LOCKED ? "&c&l" : "&a&l";
            List<net.kyori.adventure.text.Component> lore = new ArrayList<net.kyori.adventure.text.Component>();
            int requiredLevel = this.requiredLevel(rank);
            long requiredExp = this.levelService.getTotalExpRequiredForLevel(requiredLevel);
            int unlockLevel = requiredLevel + 1;
            lore.add(Text.componentNoItalics(this.statusLine(state)));
            lore.add(Text.componentNoItalics(""));
            lore.add(Text.componentNoItalics(state == PrestigeState.LOCKED ? "&c&lREQUIREMENTS" : "&a&lREQUIREMENTS"));
            lore.add(Text.componentNoItalics(color + "* &7Level &f&l" + requiredLevel + " &7(" + Text.formatNumber(requiredExp) + " XP)"));
            lore.add(Text.componentNoItalics(""));
            lore.add(Text.componentNoItalics(state == PrestigeState.LOCKED ? "&c&lUNLOCKS" : "&a&lUNLOCKS"));
            lore.add(Text.componentNoItalics(color + "* &7Level &f&l" + unlockLevel));
            lore.add(Text.componentNoItalics(""));
            for (String reward : PRESTIGE_REWARDS) {
                lore.add(Text.componentNoItalics(color + "* &7" + reward));
            }
            meta.displayName(Text.componentNoItalics(color + PRESTIGE_LABELS[rank - 1]));
            meta.lore(lore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private PrestigeState stateFor(int rank, int currentPrestige, int currentLevel) {
        if (currentPrestige >= rank) {
            return PrestigeState.CLAIMED;
        }
        int requiredLevel = this.requiredLevel(rank);
        return currentLevel >= requiredLevel ? PrestigeState.UNLOCKED : PrestigeState.LOCKED;
    }

    private int requiredLevel(int rank) {
        return this.levelService.getConfig().getPrestigeStart() + rank - 1;
    }

    private String statusLine(PrestigeState state) {
        return switch (state) {
            case LOCKED -> "&c&lLOCKED";
            case UNLOCKED -> "&a&lUNLOCKED";
            case CLAIMED -> "&a&lCLAIMED";
        };
    }

    private void fillSides(Inventory inventory) {
        ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = pane.getItemMeta();
        if (meta != null) {
            meta.displayName(Text.component(""));
            pane.setItemMeta(meta);
        }
        inventory.setItem(0, pane);
        inventory.setItem(1, pane);
        inventory.setItem(7, pane);
        inventory.setItem(8, pane);
    }

    private int prestigeIndexForSlot(int slot) {
        for (int i = 0; i < PRESTIGE_SLOTS.length; ++i) {
            if (PRESTIGE_SLOTS[i] == slot) {
                return i;
            }
        }
        return -1;
    }

    private static final class PrestigeHolder implements InventoryHolder {
        private final UUID owner;
        private Inventory inventory;

        private PrestigeHolder(UUID owner) {
            this.owner = owner;
        }

        @Override
        public @NotNull Inventory getInventory() {
            return this.inventory;
        }
    }

    private enum PrestigeState {
        LOCKED,
        UNLOCKED,
        CLAIMED
    }
}
