/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.NamespacedKey
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore;

import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.NamespacedKey;
import org.bukkit.plugin.Plugin;

public final class Keys {
    public static NamespacedKey pickaxeType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-type");
    }

    public static NamespacedKey pickaxeEnergy(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-energy");
    }

    public static NamespacedKey pickaxeEnchants(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-enchants");
    }

    public static NamespacedKey pickaxeLevel(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-level");
    }

    public static NamespacedKey playerLevel(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "player-level");
    }

    public static NamespacedKey playerExp(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "player-exp");
    }

    public static NamespacedKey playerExpTotal(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "player-exp-total");
    }

    public static NamespacedKey tutorialQuestPickaxe(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "tutorial-quest-pickaxe");
    }

    public static NamespacedKey playerPrestige(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "player-prestige");
    }

    public static NamespacedKey pickaxeChargeSlots(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-charge-slots");
    }

    public static NamespacedKey pickaxeChargePercents(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-charge-percents");
    }

    public static NamespacedKey pickaxeIronBroken(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-iron-broken");
    }

    public static NamespacedKey pickaxeDiamondBroken(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-diamond-broken");
    }

    public static NamespacedKey pickaxeEmeraldBroken(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-emerald-broken");
    }

    public static NamespacedKey pickaxeCustomName(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-custom-name");
    }

    public static NamespacedKey renameScroll(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "rename-scroll");
    }

    public static NamespacedKey protectionScroll(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "protection-scroll");
    }

    public static NamespacedKey destructionScroll(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "destruction-scroll");
    }

    public static NamespacedKey protectedItem(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "protected-item");
    }

    public static NamespacedKey pickaxePrestige(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige");
    }

    public static NamespacedKey pickaxePrestigeToken(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-token");
    }

    public static NamespacedKey pickaxePrestigeIntensity(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-intensity");
    }

    public static NamespacedKey pickaxePrestigeDrill(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-drill");
    }

    public static NamespacedKey pickaxePrestigeXp(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-xp");
    }

    public static NamespacedKey pickaxePrestigeVanish(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-vanish");
    }

    public static NamespacedKey pickaxePrestigeHoarder(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-hoarder");
    }

    public static NamespacedKey pickaxePrestigeFragmentFinder(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-fragment-finder");
    }

    public static NamespacedKey pickaxePrestigePitRecharge(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-prestige-pit-recharge");
    }

    public static NamespacedKey pickaxeDrillBuff(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-drill-buff");
    }

    public static NamespacedKey pickaxeXpBuff(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "pickaxe-xp-buff");
    }

    public static NamespacedKey gearType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "gear-type");
    }

    public static NamespacedKey gearEnergy(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "gear-energy");
    }

    public static NamespacedKey gearLevel(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "gear-level");
    }

    public static NamespacedKey gearEnchants(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "gear-enchants");
    }

    public static NamespacedKey chargeSlotToken(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "charge-slot-token");
    }

    public static NamespacedKey chargeOrbPercent(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "charge-orb-percent");
    }

    public static NamespacedKey energyItemAmount(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "energy-item-amount");
    }

    public static NamespacedKey energyExtractor(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "energy-extractor");
    }

    public static NamespacedKey bankNoteAmount(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "bank-note-amount");
    }

    public static NamespacedKey prisonCoinTokenAmount(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "prison-coin-token-amount");
    }

    public static NamespacedKey raidPointVoucher(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "raid-point-voucher");
    }

    public static NamespacedKey gangPointVoucher(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "gang-point-voucher");
    }

    public static NamespacedKey boosterType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "booster-type");
    }

    public static NamespacedKey boosterMultiplier(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "booster-multiplier");
    }

    public static NamespacedKey boosterDurationSeconds(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "booster-duration-seconds");
    }

    public static NamespacedKey contrabandTier(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "contraband-tier");
    }

    public static NamespacedKey contrabandMarker(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "contraband");
    }

    public static NamespacedKey contrabandType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "contraband-type");
    }

    public static NamespacedKey powerboxType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "powerbox-type");
    }

    public static NamespacedKey gkitFlareType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "gkit-flare-type");
    }

    public static NamespacedKey gkitTokenType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "gkit-token-type");
    }

    public static NamespacedKey rankTokenType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "rank-token-type");
    }

    public static NamespacedKey cellMenuId(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-menu-id");
    }

    public static NamespacedKey cellBuster(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-buster");
    }

    public static NamespacedKey cellWand(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-wand");
    }

    public static NamespacedKey cellDoorId(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-door-id");
    }

    public static NamespacedKey cellDoorType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-door-type");
    }

    public static NamespacedKey cellGuardTier(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-guard-tier");
    }

    public static NamespacedKey cellGuardPlacement(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-guard-placement");
    }

    public static NamespacedKey cellGuardHealthStand(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-guard-health-stand");
    }

    public static NamespacedKey cellGuardHealthStandOwner(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-guard-health-stand-owner");
    }

    public static NamespacedKey cellBusterEnergy(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-buster-energy");
    }

    public static NamespacedKey cellBusterLevel(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-buster-level");
    }

    public static NamespacedKey cellBusterEnchants(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "cell-buster-enchants");
    }

    public static NamespacedKey grapplingHookCharge(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "grappling-hook-charge");
    }

    public static NamespacedKey customBlockId(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "custom-block-id");
    }

    public static NamespacedKey tutorialStage(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "tutorial-stage");
    }

    public static NamespacedKey tutorialRewardBooster(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "tutorial-reward-booster");
    }

    public static NamespacedKey safezoneWand(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "safezone-wand");
    }

    public static NamespacedKey invasionWand(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "invasion-wand");
    }

    public static NamespacedKey invasionAlien(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "invasion-alien");
    }

    public static NamespacedKey invasionAlienZone(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "invasion-alien-zone");
    }

    public static NamespacedKey invasionAlienTier(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "invasion-alien-tier");
    }

    public static NamespacedKey alienSupplyCrate(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "alien-supply-crate");
    }

    public static NamespacedKey alienSupplyCrateState(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "alien-supply-crate-state");
    }

    public static NamespacedKey alienSupplyCrateId(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "alien-supply-crate-id");
    }

    public static NamespacedKey alienKey(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "alien-key");
    }

    public static NamespacedKey trackedItemId(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "tracked-item-id");
    }

    public static NamespacedKey dupedItem(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "duped-item");
    }

    public static NamespacedKey guardMarker(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-marker");
    }

    public static NamespacedKey guardTemplate(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-template");
    }

    public static NamespacedKey guardHome(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-home");
    }

    public static NamespacedKey guardCustomName(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-custom-name");
    }

    public static NamespacedKey guardHealthStand(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-health-stand");
    }

    public static NamespacedKey guardHealthStandOwner(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-health-stand-owner");
    }

    public static NamespacedKey guardChasing(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-chasing");
    }

    public static NamespacedKey guardSpawner(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-spawner");
    }

    public static NamespacedKey guardSpawnerType(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "guard-spawner-type");
    }

    public static NamespacedKey harbourerBoss(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "harbourer-boss");
    }

    public static NamespacedKey harbourerRing(PrisonsCore plugin) {
        return new NamespacedKey((Plugin)plugin, "harbourer-ring");
    }

    private Keys() {
    }
}
