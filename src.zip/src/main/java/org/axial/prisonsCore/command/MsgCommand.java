package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.List;
import org.axial.prisonsCore.service.PrivateMessageService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class MsgCommand implements CommandExecutor, TabCompleter {
    private final PrivateMessageService privateMessageService;

    public MsgCommand(PrivateMessageService privateMessageService) {
        this.privateMessageService = privateMessageService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " <player> <message>"));
            return true;
        }
        Player target = this.resolveOnlinePlayer(args[0]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        if (target.equals(player)) {
            sender.sendMessage(Text.color("&cYou cannot message yourself."));
            return true;
        }
        String message = this.joinMessage(args, 1);
        this.privateMessageService.sendMessage(player, target, message);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> suggestions = new ArrayList<String>();
        if (args.length != 1) {
            return suggestions;
        }
        String prefix = args[0].toLowerCase();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName() != null && player.getName().toLowerCase().startsWith(prefix)) {
                suggestions.add(player.getName());
            }
        }
        return suggestions;
    }

    private Player resolveOnlinePlayer(String lookup) {
        if (lookup == null || lookup.isBlank()) {
            return null;
        }
        for (Player candidate : Bukkit.getOnlinePlayers()) {
            if (candidate.getName() != null && candidate.getName().equalsIgnoreCase(lookup)) {
                return candidate;
            }
        }
        return null;
    }

    private String joinMessage(String[] args, int startIndex) {
        StringBuilder builder = new StringBuilder();
        for (int i = startIndex; i < args.length; ++i) {
            if (i > startIndex) {
                builder.append(' ');
            }
            builder.append(args[i]);
        }
        return builder.toString();
    }
}
