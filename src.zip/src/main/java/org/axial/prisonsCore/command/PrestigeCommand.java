/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.axial.prisonsCore.command;

import org.axial.prisonsCore.gui.PrestigeMenu;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PrestigeCommand
implements CommandExecutor {
    private final PlayerLevelService playerLevelService;
    private final PrestigeMenu prestigeMenu;

    public PrestigeCommand(PlayerLevelService playerLevelService, PrestigeMenu prestigeMenu) {
        this.playerLevelService = playerLevelService;
        this.prestigeMenu = prestigeMenu;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can prestige.");
            return true;
        }
        Player player = (Player)sender;
        int requiredLevel = this.playerLevelService.getRequiredLevelForPrestige(player);
        if (this.playerLevelService.getLevel(player) < requiredLevel) {
            player.sendMessage(Text.color("&cReach level " + requiredLevel + " before using /prestige."));
            return true;
        }
        this.prestigeMenu.open(player);
        return true;
    }
}
