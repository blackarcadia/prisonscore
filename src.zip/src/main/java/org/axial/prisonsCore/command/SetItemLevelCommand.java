package org.axial.prisonsCore.command;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class SetItemLevelCommand implements CommandExecutor {
    private final PickaxeManager pickaxeManager;
    private final GearManager gearManager;

    public SetItemLevelCommand(PickaxeManager pickaxeManager, GearManager gearManager) {
        this.pickaxeManager = pickaxeManager;
        this.gearManager = gearManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!player.hasPermission("prisons.itemlevel")) {
            player.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length != 1) {
            player.sendMessage(Text.color("&cUsage: /" + label + " <level>"));
            return true;
        }
        int level;
        try {
            level = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            player.sendMessage(Text.color("&cInvalid level."));
            return true;
        }
        level = Math.max(1, level);

        ItemStack held = player.getInventory().getItemInMainHand();
        if (held == null || held.getType().isAir()) {
            player.sendMessage(Text.color("&cHold a pickaxe or gear item."));
            return true;
        }

        if (this.pickaxeManager.isPrisonPickaxe(held)) {
            int oldLevel = this.pickaxeManager.getLevel(held);
            int appliedLevel = Math.min(level, this.pickaxeManager.getMaxLevel());
            this.pickaxeManager.setLevel(held, appliedLevel);
            int energy = this.pickaxeManager.getEnergy(held);
            String maxDisplay = appliedLevel >= this.pickaxeManager.getMaxLevel() ? "MAX" : String.valueOf(this.pickaxeManager.getMaxEnergy(held));
            player.sendMessage(Text.color("&aSet pickaxe level from &f" + oldLevel + " &ato &f" + appliedLevel + "&a."));
            player.sendMessage(Text.color("&7Charge is now &f" + energy + "&7/&f" + maxDisplay + "&7."));
            return true;
        }

        if (this.gearManager.isGear(held)) {
            int oldLevel = this.gearManager.getLevel(held);
            this.gearManager.setLevel(held, level);
            int newMax = this.gearManager.getMaxEnergy(held);
            int energy = this.gearManager.getEnergy(held);
            player.sendMessage(Text.color("&aSet gear level from &f" + oldLevel + " &ato &f" + level + "&a."));
            player.sendMessage(Text.color("&7Charge is now &f" + energy + "&7/&f" + newMax + "&7."));
            return true;
        }

        player.sendMessage(Text.color("&cHold a prison pickaxe or gear item."));
        return true;
    }
}
