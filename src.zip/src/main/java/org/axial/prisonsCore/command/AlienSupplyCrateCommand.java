package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.AlienSupplyCrateService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class AlienSupplyCrateCommand implements CommandExecutor, TabCompleter {
    private final PrisonsCore plugin;
    private final AlienSupplyCrateService alienSupplyCrateService;

    public AlienSupplyCrateCommand(PrisonsCore plugin, AlienSupplyCrateService alienSupplyCrateService) {
        this.plugin = plugin;
        this.alienSupplyCrateService = alienSupplyCrateService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.aliencrate.give")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length < 1 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <player> [amount]"));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <player> [amount]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Math.max(1, Integer.parseInt(args[2]));
            } catch (NumberFormatException ex) {
                sender.sendMessage(Text.color("&cInvalid amount."));
                return true;
            }
        }
        for (int i = 0; i < amount; ++i) {
            ItemStack stack = this.alienSupplyCrateService.createCrate(false);
            if (stack == null) {
                sender.sendMessage(Text.color("&cFailed to create Alien Supply Crate."));
                return true;
            }
            if (this.plugin.getStashService() != null) {
                this.plugin.getStashService().giveOrStash(target, stack);
            } else {
                target.getInventory().addItem(stack).values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
            }
        }
        sender.sendMessage(Text.color("&aGave &f" + amount + " &aAlien Supply Crate(s) to &f" + target.getName() + "&a."));
        if (!sender.equals(target)) {
            target.sendMessage(Text.color("&dYou received &f" + amount + " &dAlien Supply Crate(s)."));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<>();
        if (!sender.hasPermission("prisons.aliencrate.give")) {
            return completions;
        }
        if (args.length == 1) {
            if ("give".startsWith(args[0].toLowerCase(Locale.ENGLISH))) {
                completions.add("give");
            }
            return completions;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ENGLISH).startsWith(args[1].toLowerCase(Locale.ENGLISH))) {
                    completions.add(player.getName());
                }
            }
        }
        return completions;
    }
}
