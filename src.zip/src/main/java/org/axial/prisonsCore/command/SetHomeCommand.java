package org.axial.prisonsCore.command;

import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.service.TeleportService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetHomeCommand implements CommandExecutor {
    private final TeleportService teleportService;
    private final PlayerDataService playerDataService;

    public SetHomeCommand(TeleportService teleportService, PlayerDataService playerDataService) {
        this.teleportService = teleportService;
        this.playerDataService = playerDataService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        if (!this.playerDataService.canUseHomes(player)) {
            player.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(Text.color("&cUsage: /sethome <name>"));
            return true;
        }
        String name = String.join(" ", args).trim();
        if (name.isEmpty()) {
            player.sendMessage(Text.color("&cUsage: /sethome <name>"));
            return true;
        }
        int limit = this.playerDataService.getHomeLimit(player);
        boolean exists = this.playerDataService.getHome(player.getUniqueId(), name) != null;
        if (!exists && this.playerDataService.getHomeCount(player.getUniqueId()) >= limit) {
            player.sendMessage(Text.color("&cYou have reached your home limit."));
            return true;
        }
        if (!this.playerDataService.setHome(player.getUniqueId(), name, player.getLocation())) {
            player.sendMessage(Text.color("&cUnable to set home."));
            return true;
        }
        player.sendMessage(Text.color("&aHome &f" + Text.strip(name) + " &aset."));
        return true;
    }
}
