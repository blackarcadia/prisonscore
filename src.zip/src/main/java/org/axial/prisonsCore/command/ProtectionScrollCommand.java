package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.List;
import org.axial.prisonsCore.service.ProtectionScrollService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class ProtectionScrollCommand implements CommandExecutor, TabCompleter {
    private final ProtectionScrollService protectionScrollService;

    public ProtectionScrollCommand(ProtectionScrollService protectionScrollService) {
        this.protectionScrollService = protectionScrollService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <player> <amount>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException ignored) {
                amount = 1;
            }
        }
        if (amount <= 0) {
            amount = 1;
        }
        ItemStack scroll = this.protectionScrollService.createScroll();
        scroll.setAmount(amount);
        if (this.protectionScrollService.getPlugin().getStashService() != null) {
            this.protectionScrollService.getPlugin().getStashService().giveOrStash(target, scroll);
        } else {
            target.getInventory().addItem(scroll).values().forEach(stack -> target.getWorld().dropItemNaturally(target.getLocation(), stack));
        }
        sender.sendMessage(Text.color("&aGave &f" + amount + " &aProtection Scroll(s) to &f" + target.getName() + "&a."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        if (args.length == 1) {
            list.add("give");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                list.add(p.getName());
            }
        }
        return list;
    }
}
