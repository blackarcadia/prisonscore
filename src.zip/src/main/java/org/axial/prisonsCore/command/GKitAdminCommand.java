package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;
import org.axial.prisonsCore.service.KitService;
import org.axial.prisonsCore.service.MeteorService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class GKitAdminCommand implements CommandExecutor, TabCompleter {
    private final KitService kitService;
    private final MeteorService meteorService;

    public GKitAdminCommand(KitService kitService, MeteorService meteorService) {
        this.kitService = kitService;
        this.meteorService = meteorService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.gkit.admin")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length == 0) {
            this.sendUsage(sender, label);
            return true;
        }
        String action = args[0].toLowerCase(Locale.ROOT);
        switch (action) {
            case "flare", "giveflare" -> {
                if (args.length < 3) {
                    sender.sendMessage(Text.color("&cUsage: /" + label + " flare <player> <deepforge|ironhide|stormstride> [amount]"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(Text.color("&cPlayer not found."));
                    return true;
                }
                KitService.GKitType gkitType = this.kitService.parseGKit(args[2]);
                if (gkitType == null) {
                    sender.sendMessage(Text.color("&cInvalid gkit. Use deepforge, ironhide, or stormstride."));
                    return true;
                }
                int amount = this.parseAmount(args.length >= 4 ? args[3] : null, 1);
                target.getInventory().addItem(this.meteorService.createGKitFlareItem(gkitType, amount));
                sender.sendMessage(Text.color("&aGave &f" + amount + " &a" + gkitType.plainName() + " Flare(s) to &f" + target.getName() + "&a."));
                if (!sender.equals(target)) {
                    target.sendMessage(Text.color("&dYou received &f" + amount + " &d" + gkitType.plainName() + " Flare(s)!"));
                }
                return true;
            }
            case "grant", "give", "unlock" -> {
                if (args.length < 3) {
                    sender.sendMessage(Text.color("&cUsage: /" + label + " grant <player> <deepforge|ironhide|stormstride>"));
                    return true;
                }
                OfflinePlayer target = this.resolveTarget(args[1]);
                if (target == null) {
                    sender.sendMessage(Text.color("&cPlayer not found."));
                    return true;
                }
                KitService.GKitType gkitType = this.kitService.parseGKit(args[2]);
                if (gkitType == null) {
                    sender.sendMessage(Text.color("&cInvalid gkit. Use deepforge, ironhide, or stormstride."));
                    return true;
                }
                this.kitService.unlockGKit(target, gkitType).whenComplete((success, throwable) -> Bukkit.getScheduler().runTask(this.kitService.getPlugin(), () -> {
                    if (throwable != null || !Boolean.TRUE.equals(success)) {
                        sender.sendMessage(Text.color("&cFailed to grant gkit access."));
                        return;
                    }
                    sender.sendMessage(Text.color("&aGranted &f" + gkitType.plainName() + " &agkit access to &f" + this.targetName(target, args[1]) + "&a."));
                    if (target.isOnline() && target.getPlayer() != null) {
                        target.getPlayer().sendMessage(Text.color("&aYou now have access to the &f" + gkitType.plainName() + " &agkit."));
                    }
                }));
                return true;
            }
            case "remove", "revoke", "lock" -> {
                if (args.length < 3) {
                    sender.sendMessage(Text.color("&cUsage: /" + label + " remove <player> <deepforge|ironhide|stormstride>"));
                    return true;
                }
                OfflinePlayer target = this.resolveTarget(args[1]);
                if (target == null) {
                    sender.sendMessage(Text.color("&cPlayer not found."));
                    return true;
                }
                KitService.GKitType gkitType = this.kitService.parseGKit(args[2]);
                if (gkitType == null) {
                    sender.sendMessage(Text.color("&cInvalid gkit. Use deepforge, ironhide, or stormstride."));
                    return true;
                }
                this.kitService.revokeGKit(target, gkitType).whenComplete((success, throwable) -> Bukkit.getScheduler().runTask(this.kitService.getPlugin(), () -> {
                    if (throwable != null || !Boolean.TRUE.equals(success)) {
                        sender.sendMessage(Text.color("&cFailed to remove gkit access."));
                        return;
                    }
                    sender.sendMessage(Text.color("&aRemoved &f" + gkitType.plainName() + " &agkit access from &f" + this.targetName(target, args[1]) + "&a."));
                    if (target.isOnline() && target.getPlayer() != null) {
                        target.getPlayer().sendMessage(Text.color("&cYour access to the &f" + gkitType.plainName() + " &cgkit has been removed."));
                    }
                }));
                return true;
            }
            default -> {
                this.sendUsage(sender, label);
                return true;
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("prisons.gkit.admin")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            return this.filter(List.of("flare", "grant", "remove"), args[0]);
        }
        if (args.length == 2) {
            if (args[0].equalsIgnoreCase("flare")) {
                return this.filter(this.onlinePlayerNames(), args[1]);
            }
            return this.filter(this.knownPlayerNames(), args[1]);
        }
        if (args.length == 3) {
            return this.filter(List.of("deepforge", "ironhide", "stormstride"), args[2]);
        }
        return Collections.emptyList();
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(Text.color("&cUsage: /" + label + " flare <player> <deepforge|ironhide|stormstride> [amount]"));
        sender.sendMessage(Text.color("&cUsage: /" + label + " grant <player> <deepforge|ironhide|stormstride>"));
        sender.sendMessage(Text.color("&cUsage: /" + label + " remove <player> <deepforge|ironhide|stormstride>"));
    }

    private int parseAmount(String raw, int fallback) {
        if (raw == null || raw.isBlank()) {
            return fallback;
        }
        try {
            return Math.max(1, Integer.parseInt(raw.replace(",", "").trim()));
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    private OfflinePlayer resolveTarget(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player online = Bukkit.getPlayerExact(input);
        if (online != null) {
            return online;
        }
        for (OfflinePlayer candidate : Bukkit.getOfflinePlayers()) {
            if (candidate.getName() != null && candidate.getName().equalsIgnoreCase(input)) {
                return candidate;
            }
        }
        try {
            UUID uuid = UUID.fromString(input);
            return Bukkit.getOfflinePlayer(uuid);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    private String targetName(OfflinePlayer target, String fallback) {
        return target.getName() != null ? target.getName() : fallback;
    }

    private List<String> knownPlayerNames() {
        ArrayList<String> names = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName() != null) {
                names.add(player.getName());
            }
        }
        for (OfflinePlayer player : Bukkit.getOfflinePlayers()) {
            if (player.getName() != null) {
                names.add(player.getName());
            }
        }
        return names.stream().distinct().collect(Collectors.toList());
    }

    private List<String> onlinePlayerNames() {
        ArrayList<String> names = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName() != null) {
                names.add(player.getName());
            }
        }
        return names;
    }

    private List<String> filter(List<String> values, String partial) {
        String normalized = partial == null ? "" : partial.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value != null && value.toLowerCase(Locale.ROOT).startsWith(normalized)).collect(Collectors.toList());
    }
}
