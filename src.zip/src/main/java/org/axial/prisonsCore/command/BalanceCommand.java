/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 */
package org.axial.prisonsCore.command;

import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

public class BalanceCommand
implements CommandExecutor {
    private final EconomyService economyService;

    public BalanceCommand(EconomyService economyService) {
        this.economyService = economyService;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(Lang.msg("common.players-only", "Only players can use this command."));
            return true;
        }
        Player player = (Player)sender;
        OfflinePlayer target = player;
        if (args.length >= 1) {
            String lookup = args[0];
            Player onlineTarget = null;
            for (Player candidate : Bukkit.getOnlinePlayers()) {
                if (candidate.getName() != null && candidate.getName().equalsIgnoreCase(lookup)) {
                    onlineTarget = candidate;
                    break;
                }
            }
            if (onlineTarget != null) {
                target = onlineTarget;
            } else {
                OfflinePlayer offlineTarget = null;
                for (OfflinePlayer candidate : Bukkit.getOfflinePlayers()) {
                    if (candidate.getName() != null && candidate.getName().equalsIgnoreCase(lookup)) {
                        offlineTarget = candidate;
                        break;
                    }
                }
                if (offlineTarget == null || (!offlineTarget.isOnline() && !offlineTarget.hasPlayedBefore())) {
                    player.sendMessage(Text.color("&cPlayer not found."));
                    return true;
                }
                target = offlineTarget;
            }
        }
        double bal = this.economyService.getBalance(target);
        String name = target.getName() != null ? target.getName() : (args.length >= 1 ? args[0] : player.getName());
        String message = Lang.msg("economy.balance", "&6&l(!) {player}'s Balance:\n&f{balance}")
                .replace("{player}", name)
                .replace("{balance}", this.economyService.format(bal));
        player.sendMessage(Text.color(message));
        return true;
    }
}
