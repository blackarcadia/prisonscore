package org.axial.prisonsCore.command;

import java.util.Map;
import org.axial.prisonsCore.service.BankNoteService;
import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class BankNoteCommand implements CommandExecutor {
    private final EconomyService economyService;
    private final BankNoteService bankNoteService;

    public BankNoteCommand(EconomyService economyService, BankNoteService bankNoteService) {
        this.economyService = economyService;
        this.bankNoteService = bankNoteService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.banknote.give")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }

        if (args.length < 1 || args.length > 2) {
            sender.sendMessage(Lang.msg("economy.banknote-usage", "&cUsage: /" + label + " <amount> [player]"));
            return true;
        }

        Double parsed = this.economyService.parseAmount(args[0]);
        if (parsed == null || parsed <= 0.0) {
            sender.sendMessage(Lang.msg("economy.banknote-invalid", "&cInvalid amount."));
            return true;
        }

        double amount = parsed;
        Player target;
        if (args.length == 1) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Lang.msg("economy.banknote-usage", "&cUsage: /" + label + " <amount> [player]"));
                return true;
            }
            target = player;
        } else {
            target = Bukkit.getPlayerExact(args[1]);
            if (target == null || !target.isOnline()) {
                sender.sendMessage(Lang.msg("economy.banknote-no-player", "&cPlayer not found."));
                return true;
            }
        }

        ItemStack note = this.bankNoteService.createBankNote(amount);
        if (this.economyService.getPlugin().getStashService() != null) {
            this.economyService.getPlugin().getStashService().giveOrStash(target, note);
        } else {
            Map<Integer, ItemStack> leftover = target.getInventory().addItem(note);
            for (ItemStack stack : leftover.values()) {
                target.getWorld().dropItemNaturally(target.getLocation(), stack);
            }
        }

        String formatted = this.economyService.format(amount);
        sender.sendMessage(Lang.msg("economy.banknote-given", "&aGave &2{amount} &abank note to {player}.")
                .replace("{amount}", formatted)
                .replace("{player}", target.getName()));
        if (!sender.equals(target)) {
            target.sendMessage(Lang.msg("economy.banknote-received", "&aYou received a bank note worth &2{amount}&a from {player}.")
                    .replace("{amount}", formatted)
                    .replace("{player}", sender.getName()));
        }
        return true;
    }
}
