package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.stream.Collectors;
import org.axial.prisonsCore.service.PrisonCoinService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class PrisonCoinAdminCommand implements CommandExecutor, TabCompleter {
    private final PrisonCoinService prisonCoinService;

    public PrisonCoinAdminCommand(PrisonCoinService prisonCoinService) {
        this.prisonCoinService = prisonCoinService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.prisoncoins.admin")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " <give|add|set|remove|reset|token> <player|uuid> [amount]"));
            return true;
        }
        String action = args[0].toLowerCase(Locale.ROOT);
        OfflinePlayer target = this.resolveTarget(args[1]);
        if (target == null) {
            sender.sendMessage(Lang.msg("common.player-not-found", "&cPlayer not found."));
            return true;
        }
        String targetName = target.getName() != null ? target.getName() : args[1];
        switch (action) {
            case "reset" -> {
                this.prisonCoinService.setCoins(target.getUniqueId(), 0L);
                sender.sendMessage(Lang.msg("prisoncoins.admin.reset", "&aReset {player}'s Prison Coins to 0.").replace("{player}", targetName));
                return true;
            }
            case "token" -> {
                if (args.length < 3) {
                    sender.sendMessage(Text.color("&cAmount required."));
                    return true;
                }
                Long amount = this.parseAmount(args[2]);
                if (amount == null || amount <= 0L) {
                    sender.sendMessage(Text.color("&cInvalid amount."));
                    return true;
                }
                Player online = target.getPlayer();
                if (online == null) {
                    sender.sendMessage(Text.color("&cThat player must be online to receive a physical Prison Coins token."));
                    return true;
                }
                this.prisonCoinService.giveCoinToken(online, amount);
                sender.sendMessage(Lang.msg("prisoncoins.admin.token", "&aGave {amount} Prison Coins token to {player}.")
                        .replace("{player}", targetName)
                        .replace("{amount}", this.prisonCoinService.format(amount)));
                return true;
            }
            case "give", "add", "set", "remove" -> {
                if (args.length < 3) {
                    sender.sendMessage(Text.color("&cAmount required."));
                    return true;
                }
                Long amount = this.parseAmount(args.length >= 3 ? args[2] : "0");
                if (amount == null) {
                    sender.sendMessage(Text.color("&cInvalid amount."));
                    return true;
                }
                if (amount < 0L) {
                    sender.sendMessage(Text.color("&cAmount must be non-negative."));
                    return true;
                }
                long current = this.prisonCoinService.getBalance(target.getUniqueId());
                long updated = switch (action) {
                    case "set" -> amount;
                    case "remove" -> Math.max(0L, current - amount);
                    default -> current + amount;
                };
                this.prisonCoinService.setCoins(target.getUniqueId(), updated);
                sender.sendMessage(Lang.msg("prisoncoins.admin." + action, "&aUpdated Prison Coins.").replace("{player}", targetName).replace("{amount}", this.prisonCoinService.format(amount)).replace("{balance}", this.prisonCoinService.format(updated)));
                return true;
            }
            default -> {
                sender.sendMessage(Text.color("&cUnknown action."));
                return true;
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("prisons.prisoncoins.admin")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            return this.filter(List.of("give", "add", "set", "remove", "reset", "token"), args[0]);
        }
        if (args.length == 2) {
            return this.filter(this.knownPlayers(), args[1]);
        }
        return Collections.emptyList();
    }

    private OfflinePlayer resolveTarget(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        Player online = Bukkit.getPlayerExact(input);
        if (online != null) {
            return online;
        }
        for (OfflinePlayer candidate : Bukkit.getOfflinePlayers()) {
            if (candidate.getName() != null && candidate.getName().equalsIgnoreCase(input)) {
                return candidate;
            }
        }
        try {
            UUID uuid = UUID.fromString(input);
            return Bukkit.getOfflinePlayer(uuid);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    private Long parseAmount(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return Long.parseLong(raw.replace(",", "").trim());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private List<String> knownPlayers() {
        ArrayList<String> names = new ArrayList<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName() != null) {
                names.add(player.getName());
            }
        }
        for (OfflinePlayer player : Bukkit.getOfflinePlayers()) {
            if (player.getName() != null) {
                names.add(player.getName());
            }
        }
        return names.stream().distinct().collect(Collectors.toList());
    }

    private List<String> filter(List<String> values, String partial) {
        String normalized = partial == null ? "" : partial.toLowerCase(Locale.ROOT);
        return values.stream().filter(value -> value != null && value.toLowerCase(Locale.ROOT).startsWith(normalized)).collect(Collectors.toList());
    }
}
