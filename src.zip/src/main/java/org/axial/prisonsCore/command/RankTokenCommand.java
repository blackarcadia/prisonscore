package org.axial.prisonsCore.command;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.axial.prisonsCore.service.RankTokenService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;

public class RankTokenCommand implements CommandExecutor {
    private final RankTokenService rankTokenService;

    public RankTokenCommand(RankTokenService rankTokenService) {
        this.rankTokenService = rankTokenService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.ranktoken.admin")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <player> [amount]"));
            return true;
        }
        String action = args[0].toLowerCase(Locale.ROOT);
        if (!action.equals("give") && !action.equals("grant")) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <player> [amount]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Math.max(1, Integer.parseInt(args[2]));
            } catch (NumberFormatException ignored) {
            }
        }
        ItemStack token = this.rankTokenService.createToken(RankTokenService.RankType.VANGUARD);
        if (token == null) {
            sender.sendMessage(Text.color("&cThat rank token is unavailable."));
            return true;
        }
        token.setAmount(amount);
        Map<Integer, ItemStack> leftovers = target.getInventory().addItem(token);
        leftovers.values().forEach(stack -> target.getWorld().dropItemNaturally(target.getLocation(), stack));
        sender.sendMessage(Text.color("&aGave &f" + amount + " &aVanguard Rank Token(s) to &f" + target.getName() + "&a."));
        target.sendMessage(Text.color("&dYou received &f" + amount + " &dVanguard Rank Token(s)."));
        return true;
    }
}
