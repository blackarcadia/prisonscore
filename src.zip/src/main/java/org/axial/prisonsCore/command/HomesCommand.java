package org.axial.prisonsCore.command;

import java.util.List;
import java.util.stream.Collectors;
import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomesCommand implements CommandExecutor {
    private final PlayerDataService playerDataService;

    public HomesCommand(PlayerDataService playerDataService) {
        this.playerDataService = playerDataService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        if (!this.playerDataService.canUseHomes(player)) {
            player.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        List<String> homes = this.playerDataService.getHomeNames(player.getUniqueId());
        if (homes.isEmpty()) {
            player.sendMessage(Text.color("&7You have no homes set."));
            return true;
        }
        player.sendMessage(Text.color("&6&lHomes: &f" + homes.stream().map(Text::strip).collect(Collectors.joining(", "))));
        return true;
    }
}
