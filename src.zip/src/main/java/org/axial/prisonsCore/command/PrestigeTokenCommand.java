/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.command;

import java.util.List;
import java.lang.reflect.Method;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.PickaxeManager.PrestigeTokenApplicationResult;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class PrestigeTokenCommand
implements CommandExecutor {
    private final PickaxeManager pickaxeManager;
    private final NamespacedKey tokenKey;

    public PrestigeTokenCommand(PickaxeManager pickaxeManager, NamespacedKey tokenKey) {
        this.pickaxeManager = pickaxeManager;
        this.tokenKey = tokenKey;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub;
        if (args.length < 1) {
            sender.sendMessage(Text.color("&cUsage: /prestigetoken give <player> [amount] | /prestigetoken apply"));
            return true;
        }
        switch (sub = args[0].toLowerCase()) {
            case "give": {
                if (args.length < 2) {
                    sender.sendMessage(Text.color("&cUsage: /prestigetoken give <player> [amount]"));
                    return true;
                }
                Player target = Bukkit.getPlayer((String)args[1]);
                if (target == null) {
                    sender.sendMessage(Text.color("&cPlayer not found."));
                    return true;
                }
                int amount = 1;
                if (args.length >= 3) {
                    try {
                        amount = Integer.parseInt(args[2]);
                    }
                    catch (NumberFormatException numberFormatException) {
                        // empty catch block
                    }
                }
                ItemStack token = this.createToken();
                token.setAmount(Math.max(1, amount));
                target.getInventory().addItem(new ItemStack[]{token});
                target.sendMessage(Text.color("&dYou received " + amount + " prestige token(s)."));
                return true;
            }
            case "apply": {
                if (!(sender instanceof Player)) {
                    sender.sendMessage("Players only.");
                    return true;
                }
                Player player = (Player)sender;
                ItemStack held = player.getInventory().getItemInMainHand();
                if (!this.pickaxeManager.isPrisonPickaxe(held)) {
                    player.sendMessage(Text.color("&cHold a prison pickaxe to apply the token."));
                    return true;
                }
                int slot = player.getInventory().first(this.createToken());
                if (slot == -1) {
                    player.sendMessage(Text.color("&cYou need a prestige token in your inventory."));
                    return true;
                }
                PrestigeTokenApplicationResult result = this.pickaxeManager.applyPrestigeToken(held);
                if (result != PrestigeTokenApplicationResult.SUCCESS) {
                    this.sendApplyFailure(player, result);
                    return true;
                }
                this.consumeOneToken(player, slot);
                player.sendMessage(Text.color("&aPrestige token applied to your pickaxe."));
                return true;
            }
        }
        sender.sendMessage(Text.color("&cUsage: /prestigetoken give <player> [amount] | /prestigetoken apply"));
        return true;
    }

    private void consumeOneToken(Player player, int slot) {
        ItemStack stack = player.getInventory().getItem(slot);
        if (stack == null) {
            return;
        }
        if (stack.getAmount() <= 1) {
            player.getInventory().setItem(slot, null);
            return;
        }
        stack.setAmount(stack.getAmount() - 1);
        player.getInventory().setItem(slot, stack);
    }

    private void sendApplyFailure(Player player, PrestigeTokenApplicationResult result) {
        switch (result) {
            case LEVEL_TOO_LOW: {
                player.sendMessage(Text.color("&c&lPickaxe Level To Low"));
                player.sendMessage(Text.color("&7Increase your pickaxe level to &a&l30 &7to apply this token!"));
                return;
            }
            case ORE_TOO_LOW: {
                player.sendMessage(Text.color("&c&lOre Count To Low"));
                player.sendMessage(Text.color("&7Mine the correct level of ores to apply this token!"));
                return;
            }
            case LEVEL_AND_ORE_TOO_LOW: {
                player.sendMessage(Text.color("&c&lPrestige Token"));
                player.sendMessage(Text.color("&7To apply a prestige token you must get your pickaxe to level &a&l30 &7and hit the ore quota displayed!"));
                return;
            }
            case ALREADY_APPLIED: {
                player.sendMessage(Text.color("&cThis pickaxe already has a prestige token applied."));
                return;
            }
            default: {
            }
        }
    }

    private ItemStack createToken() {
        ItemStack token = new ItemStack(Material.SUNFLOWER);
        ItemMeta meta = token.getItemMeta();
        meta.setDisplayName(Text.color("&6&lPickaxe Prestige Token"));
        meta.setLore(List.of(
                Text.color("&7Apply this token to a pickaxe that is both &f&lLevel &a&l30"),
                Text.color("&7and has hit its ore mining quota."),
                "",
                Text.color("&cOnly 1 token can be applied at one time.")
        ));
        this.applyGlint(meta);
        meta.getPersistentDataContainer().set(this.tokenKey, PersistentDataType.BYTE, (byte)1);
        token.setItemMeta(meta);
        return token;
    }

    private void applyGlint(ItemMeta meta) {
        if (meta == null) {
            return;
        }
        try {
            Method method = meta.getClass().getMethod("setEnchantmentGlintOverride", Boolean.class);
            method.invoke(meta, Boolean.TRUE);
            return;
        }
        catch (Exception exception) {
            // fall back to a hidden dummy enchant for older runtimes
        }
        Enchantment glint = Enchantment.getByName("UNBREAKING");
        if (glint == null) {
            glint = Enchantment.getByName("DURABILITY");
        }
        if (glint == null) {
            glint = Enchantment.getByName("PROTECTION_ENVIRONMENTAL");
        }
        if (glint != null && !meta.hasEnchant(glint)) {
            meta.addEnchant(glint, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
    }
}
