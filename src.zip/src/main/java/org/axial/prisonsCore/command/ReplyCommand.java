package org.axial.prisonsCore.command;

import org.axial.prisonsCore.service.PrivateMessageService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class ReplyCommand implements CommandExecutor {
    private final PrivateMessageService privateMessageService;

    public ReplyCommand(PrivateMessageService privateMessageService) {
        this.privateMessageService = privateMessageService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " <message>"));
            return true;
        }
        this.privateMessageService.reply(player, this.joinMessage(args));
        return true;
    }

    private String joinMessage(String[] args) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < args.length; ++i) {
            if (i > 0) {
                builder.append(' ');
            }
            builder.append(args[i]);
        }
        return builder.toString();
    }
}
