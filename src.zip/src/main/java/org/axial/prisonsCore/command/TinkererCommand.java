package org.axial.prisonsCore.command;

import org.axial.prisonsCore.gui.TinkererMenu;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class TinkererCommand implements CommandExecutor {
    private final TinkererMenu menu;

    public TinkererCommand(TinkererMenu menu) {
        this.menu = menu;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this command."));
            return true;
        }
        if (args.length > 0) {
            player.sendMessage(Text.color("&7/" + label));
            return true;
        }
        this.menu.open(player);
        return true;
    }
}
