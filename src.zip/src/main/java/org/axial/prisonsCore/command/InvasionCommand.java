package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import org.axial.prisonsCore.service.AlienInvasionService;
import org.axial.prisonsCore.service.AlienInvasionService.InvasionZone;
import org.axial.prisonsCore.service.AlienInvasionService.Selection;
import org.axial.prisonsCore.service.AlienInvasionService.Tier;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class InvasionCommand implements CommandExecutor, TabCompleter {
    private static final String PERMISSION = "prisons.invasion.admin";

    private final AlienInvasionService invasionService;

    public InvasionCommand(AlienInvasionService invasionService) {
        this.invasionService = invasionService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length == 0) {
            this.sendUsage(sender, label);
            return true;
        }

        String action = args[0].toLowerCase(Locale.ROOT);
        switch (action) {
            case "wand" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Text.color("&cOnly players can receive the invasion wand."));
                    return true;
                }
                player.getInventory().addItem(this.invasionService.createWand());
                player.sendMessage(Text.color("&aGiven an invasion wand. Left click = pos1, right click = pos2."));
                return true;
            }
            case "pos1" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Text.color("&cOnly players can set positions."));
                    return true;
                }
                this.invasionService.setPos1(player.getUniqueId(), player.getLocation());
                sender.sendMessage(Text.color("&aSet invasion pos1 at your location."));
                return true;
            }
            case "pos2" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Text.color("&cOnly players can set positions."));
                    return true;
                }
                this.invasionService.setPos2(player.getUniqueId(), player.getLocation());
                sender.sendMessage(Text.color("&aSet invasion pos2 at your location."));
                return true;
            }
            case "create" -> {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage(Text.color("&cOnly players can create invasion zones."));
                    return true;
                }
                if (args.length < 3) {
                    sender.sendMessage(Text.color("&cUsage: /" + label + " create <id> <iron|gold|diamond>"));
                    return true;
                }
                Tier tier = this.invasionService.getTier(args[2]);
                if (tier == null) {
                    sender.sendMessage(Text.color("&cUnknown tier. Use iron, gold, or diamond."));
                    return true;
                }
                Selection selection = this.invasionService.getSelection(player.getUniqueId());
                if (!selection.isComplete()) {
                    sender.sendMessage(Text.color("&cSet pos1 and pos2 first."));
                    return true;
                }
                if (this.invasionService.createZone(args[1], tier, selection)) {
                    sender.sendMessage(Text.color("&aCreated invasion zone &f" + args[1] + " &awith tier &f" + tier.id() + "&a."));
                } else {
                    sender.sendMessage(Text.color("&cFailed to create invasion zone."));
                }
                return true;
            }
            case "settier" -> {
                if (args.length < 3) {
                    sender.sendMessage(Text.color("&cUsage: /" + label + " settier <id> <iron|gold|diamond>"));
                    return true;
                }
                Tier tier = this.invasionService.getTier(args[2]);
                if (tier == null) {
                    sender.sendMessage(Text.color("&cUnknown tier. Use iron, gold, or diamond."));
                    return true;
                }
                if (this.invasionService.setTier(args[1], tier)) {
                    sender.sendMessage(Text.color("&aUpdated invasion zone &f" + args[1] + " &ato tier &f" + tier.id() + "&a."));
                } else {
                    sender.sendMessage(Text.color("&cInvasion zone not found."));
                }
                return true;
            }
            case "delete", "remove" -> {
                if (args.length < 2) {
                    sender.sendMessage(Text.color("&cUsage: /" + label + " delete <id>"));
                    return true;
                }
                if (this.invasionService.deleteZone(args[1])) {
                    sender.sendMessage(Text.color("&aDeleted invasion zone &f" + args[1] + "&a."));
                } else {
                    sender.sendMessage(Text.color("&cInvasion zone not found."));
                }
                return true;
            }
            case "list" -> {
                if (this.invasionService.getZones().isEmpty()) {
                    sender.sendMessage(Text.color("&7No invasion zones created."));
                    return true;
                }
                sender.sendMessage(Text.color("&bInvasion zones: &f" + this.invasionService.getZones().stream()
                        .map(zone -> zone.id() + "(" + zone.tierId() + ")")
                        .collect(Collectors.joining(", "))));
                return true;
            }
            case "reload" -> {
                this.invasionService.reload();
                sender.sendMessage(Text.color("&aReloaded invasion zones."));
                return true;
            }
            default -> {
                this.sendUsage(sender, label);
                return true;
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission(PERMISSION)) {
            return List.of();
        }
        if (args.length == 1) {
            return this.filter(List.of("wand", "pos1", "pos2", "create", "settier", "delete", "remove", "list", "reload"), args[0]);
        }
        if (args.length == 2 && ("delete".equalsIgnoreCase(args[0]) || "remove".equalsIgnoreCase(args[0]) || "settier".equalsIgnoreCase(args[0]))) {
            return this.filter(this.invasionService.getZones().stream().map(InvasionZone::id).collect(Collectors.toList()), args[1]);
        }
        if (args.length == 3 && ("create".equalsIgnoreCase(args[0]) || "settier".equalsIgnoreCase(args[0]))) {
            return this.filter(List.of("iron", "gold", "diamond"), args[2]);
        }
        return List.of();
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(Text.color("&e/" + label + " wand"));
        sender.sendMessage(Text.color("&e/" + label + " pos1"));
        sender.sendMessage(Text.color("&e/" + label + " pos2"));
        sender.sendMessage(Text.color("&e/" + label + " create <id> <iron|gold|diamond>"));
        sender.sendMessage(Text.color("&e/" + label + " settier <id> <iron|gold|diamond>"));
        sender.sendMessage(Text.color("&e/" + label + " delete <id>"));
        sender.sendMessage(Text.color("&e/" + label + " list"));
        sender.sendMessage(Text.color("&e/" + label + " reload"));
    }

    private List<String> filter(List<String> input, String partial) {
        String normalized = partial == null ? "" : partial.toLowerCase(Locale.ROOT);
        ArrayList<String> result = new ArrayList<>();
        for (String value : input) {
            if (value.toLowerCase(Locale.ROOT).startsWith(normalized)) {
                result.add(value);
            }
        }
        return result;
    }
}
