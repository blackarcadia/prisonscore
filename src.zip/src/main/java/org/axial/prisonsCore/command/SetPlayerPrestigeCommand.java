/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.command;

import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SetPlayerPrestigeCommand implements CommandExecutor {
    private static final int MAX_PRESTIGE_LEVEL = 5;
    private final PlayerLevelService playerLevelService;

    public SetPlayerPrestigeCommand(PlayerLevelService playerLevelService) {
        this.playerLevelService = playerLevelService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.setplayerprestige")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length != 2) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " <player> <level|remove>"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }

        String rawLevel = args[1];
        if (rawLevel.equalsIgnoreCase("remove")) {
            this.playerLevelService.setPrestigeLevel(target, 0);
            int currentLevel = this.playerLevelService.getLevel(target);
            if (currentLevel > this.playerLevelService.getConfig().getPrestigeStart()) {
                this.playerLevelService.setLevel(target, this.playerLevelService.getConfig().getPrestigeStart());
            }
            sender.sendMessage(Text.color("&aRemoved " + target.getName() + "'s prestige level."));
            return true;
        }

        int prestigeLevel;
        try {
            prestigeLevel = Integer.parseInt(rawLevel);
        }
        catch (NumberFormatException ex) {
            sender.sendMessage(Text.color("&cInvalid prestige level."));
            return true;
        }

        prestigeLevel = Math.max(0, Math.min(MAX_PRESTIGE_LEVEL, prestigeLevel));
        this.playerLevelService.setPrestigeLevel(target, prestigeLevel);
        int prestigeCap = this.playerLevelService.getPrestigeCap(target);
        if (this.playerLevelService.getLevel(target) > prestigeCap) {
            this.playerLevelService.setLevel(target, prestigeCap);
        }
        sender.sendMessage(Text.color("&aSet " + target.getName() + "'s prestige level to " + (prestigeLevel == 0 ? "none" : this.playerLevelService.getPrestigeRomanNumeral(prestigeLevel)) + "."));
        return true;
    }
}
