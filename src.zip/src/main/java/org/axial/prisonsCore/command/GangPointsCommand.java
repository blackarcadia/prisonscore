/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.command.Command
 *  org.bukkit.command.CommandExecutor
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.TabCompleter
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.command;

import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import org.axial.prisonsCore.service.GangPointService;
import org.axial.prisonsCore.util.Lang;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class GangPointsCommand implements CommandExecutor, TabCompleter {
    private final GangPointService gangPointService;

    public GangPointsCommand(GangPointService gangPointService) {
        this.gangPointService = gangPointService;
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.gangpoints.give")) {
            sender.sendMessage(Lang.msg("gangpoints.no-permission", "&cNo permission."));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(Lang.msg("gangpoints.usage", "&cUsage: /gangpoints give <player> <amount>"));
            return true;
        }
        if (!args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Lang.msg("gangpoints.unknown", "&cUnknown subcommand."));
            return true;
        }
        Player target = sender.getServer().getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(Lang.msg("gangpoints.player-not-found", "&cPlayer not found."));
            return true;
        }
        int amount;
        try {
            amount = Integer.parseInt(args.length >= 3 ? args[2] : "0");
        }
        catch (NumberFormatException ex) {
            sender.sendMessage(Lang.msg("gangpoints.invalid-amount", "&cInvalid amount."));
            return true;
        }
        if (amount <= 0) {
            sender.sendMessage(Lang.msg("gangpoints.invalid-amount", "&cAmount must be positive."));
            return true;
        }
        this.gangPointService.giveGangPointNote(target, amount);
        sender.sendMessage(Lang.msg("gangpoints.given", "&aGave {amount} gang points voucher to {player}").replace("{amount}", String.valueOf(amount)).replace("{player}", target.getName()));
        return true;
    }

    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("prisons.gangpoints.give")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            return List.of("give").stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        if (args.length == 2) {
            return sender.getServer().getOnlinePlayers().stream().map(Player::getName).filter(n -> n.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        }
        return Collections.emptyList();
    }
}
