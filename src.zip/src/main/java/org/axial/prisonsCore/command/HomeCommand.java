package org.axial.prisonsCore.command;

import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.service.TeleportService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomeCommand implements CommandExecutor {
    private final TeleportService teleportService;
    private final PlayerDataService playerDataService;

    public HomeCommand(TeleportService teleportService, PlayerDataService playerDataService) {
        this.teleportService = teleportService;
        this.playerDataService = playerDataService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        if (!this.playerDataService.canUseHomes(player)) {
            player.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(Text.color("&cUsage: /home <name>"));
            return true;
        }
        String name = String.join(" ", args).trim();
        if (name.isEmpty()) {
            player.sendMessage(Text.color("&cUsage: /home <name>"));
            return true;
        }
        Location home = this.playerDataService.getHome(player.getUniqueId(), name);
        if (home == null) {
            player.sendMessage(Text.color("&cHome not found."));
            return true;
        }
        this.teleportService.scheduleTeleport(player, home, Text.strip(name), null);
        return true;
    }
}
