package org.axial.prisonsCore.command;

import org.axial.prisonsCore.service.PlayerToggleService;
import org.axial.prisonsCore.service.PlayerToggleService.Toggle;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MsgToggleCommand implements CommandExecutor {
    private final PlayerToggleService toggleService;

    public MsgToggleCommand(PlayerToggleService toggleService) {
        this.toggleService = toggleService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        boolean enabled = this.toggleService.toggle(player, Toggle.PRIVATE_MESSAGES);
        player.sendMessage(Text.color(enabled ? "&aYou will now receive private messages." : "&cYou will no longer receive private messages."));
        return true;
    }
}
