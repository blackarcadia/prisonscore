package org.axial.prisonsCore.command;

import java.util.Arrays;
import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NickCommand implements CommandExecutor {
    private final PlayerDataService playerDataService;

    public NickCommand(PlayerDataService playerDataService) {
        this.playerDataService = playerDataService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        if (!player.hasPermission("prisons.nick")) {
            player.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(Text.color("&cUsage: /nick <name|reset>"));
            return true;
        }
        String value = String.join(" ", Arrays.copyOfRange(args, 0, args.length)).trim();
        if (value.equalsIgnoreCase("reset") || value.equalsIgnoreCase("off") || value.equalsIgnoreCase("clear")) {
            this.playerDataService.update(player.getUniqueId(), data -> data.setNickname(null));
            player.sendMessage(Text.color("&aYour chat name has been reset."));
            return true;
        }
        this.playerDataService.update(player.getUniqueId(), data -> data.setNickname(value));
        player.sendMessage(Text.color("&aYour chat name is now &f" + this.playerDataService.getChatName(player)));
        return true;
    }
}
