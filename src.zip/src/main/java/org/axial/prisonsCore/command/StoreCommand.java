package org.axial.prisonsCore.command;

import org.axial.prisonsCore.gui.StoreMenu;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.service.SafezoneService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StoreCommand implements CommandExecutor {
    private final StoreMenu storeMenu;
    private final SafezoneService safezoneService;
    private final CellService cellService;

    public StoreCommand(StoreMenu storeMenu, SafezoneService safezoneService, CellService cellService) {
        this.storeMenu = storeMenu;
        this.safezoneService = safezoneService;
        this.cellService = cellService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Lang.msg("common.players-only", "Only players can use this command."));
            return true;
        }
        if (!this.canUseCommand(player)) {
            return true;
        }
        if (this.storeMenu == null) {
            player.sendMessage(Lang.msg("prisoncoins.store.unavailable", "&cThat shop is currently unavailable."));
            return true;
        }
        this.storeMenu.open(player);
        return true;
    }

    private boolean canUseCommand(Player player) {
        Location location = player.getLocation();
        if (this.safezoneService != null && this.safezoneService.isInSafezone(location)) {
            return true;
        }
        if (this.cellService != null) {
            if (this.cellService.getCellAt(location) != null) {
                return true;
            }
            if (location != null && location.getWorld() != null && this.cellService.getCells().stream().anyMatch(cell -> cell != null && cell.getRegion() != null && cell.getRegion().getWorldName() != null && location.getWorld().getName().equalsIgnoreCase(cell.getRegion().getWorldName()))) {
                return true;
            }
        }
        player.sendMessage(Text.color("&cThat command can only be performed inside of a Safezone."));
        return false;
    }
}
