package org.axial.prisonsCore.command;

import org.axial.prisonsCore.gui.RaidShopMenu;
import org.axial.prisonsCore.util.Lang;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RaidShopCommand implements CommandExecutor {
    private final RaidShopMenu raidShopMenu;

    public RaidShopCommand(RaidShopMenu raidShopMenu) {
        this.raidShopMenu = raidShopMenu;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Lang.msg("common.players-only", "Only players can use this command."));
            return true;
        }
        if (this.raidShopMenu == null) {
            player.sendMessage(Lang.msg("common.unavailable", "&cThat shop is currently unavailable."));
            return true;
        }
        this.raidShopMenu.open(player);
        return true;
    }
}
