package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.gui.AdminEnchantMenu;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class GearEnchantGiveCommand implements CommandExecutor, TabCompleter {
    private final GearEnchantService gearEnchantService;
    private final AdminEnchantMenu adminEnchantMenu;

    public GearEnchantGiveCommand(GearEnchantService gearEnchantService, AdminEnchantMenu adminEnchantMenu) {
        this.gearEnchantService = gearEnchantService;
        this.adminEnchantMenu = adminEnchantMenu;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("menu")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(Text.color("&cOnly players can open the menu."));
                return true;
            }
            if (this.adminEnchantMenu != null) {
                this.adminEnchantMenu.open(player);
            }
            return true;
        }
        if (args.length < 4 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Text.color(command.getUsage()));
            return true;
        }
        String enchantId = args[1].toLowerCase(Locale.ROOT);
        int level;
        int percent;
        try {
            level = Integer.parseInt(args[2]);
            percent = Integer.parseInt(args[3]);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Text.color("&cInvalid level or percent."));
            return true;
        }
        CustomEnchant enchant = this.gearEnchantService.getById(enchantId);
        if (enchant == null) {
            sender.sendMessage(Text.color("&cUnknown gear enchant."));
            return true;
        }
        Player target = null;
        if (args.length >= 5) {
            target = Bukkit.getPlayerExact(args[4]);
        } else if (sender instanceof Player player) {
            target = player;
        }
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        ItemStack orb = this.gearEnchantService.createOrb(enchantId, level, percent);
        if (orb == null) {
            sender.sendMessage(Text.color("&cCould not create gear enchant orb."));
            return true;
        }
        target.getInventory().addItem(orb);
        sender.sendMessage(Text.color("&aGave " + target.getName() + " a gear enchant orb for " + enchantId + " level " + level + " (" + percent + "%)"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (args.length == 1) {
            completions.add("give");
            completions.add("menu");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            completions.addAll(this.gearEnchantService.getAll().stream().map(CustomEnchant::getId).collect(Collectors.toList()));
        } else if (args.length == 5 && args[0].equalsIgnoreCase("give")) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                completions.add(player.getName());
            }
        }
        return completions;
    }
}
