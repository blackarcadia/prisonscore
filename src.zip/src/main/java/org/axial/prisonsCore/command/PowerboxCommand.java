package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PowerboxService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class PowerboxCommand implements CommandExecutor, TabCompleter {
    private final PrisonsCore plugin;
    private final PowerboxService powerboxService;

    public PowerboxCommand(PrisonsCore plugin, PowerboxService powerboxService) {
        this.plugin = plugin;
        this.powerboxService = powerboxService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.powerbox.admin")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            sender.sendMessage(Text.color("&6Powerboxes &7(" + this.powerboxService.powerboxIds().size() + ")"));
            for (String id : this.powerboxService.powerboxIds()) {
                sender.sendMessage(Text.color("&8- &r" + this.powerboxService.displayName(id) + " &8(" + id + "&8)"));
            }
            return true;
        }
        if (!args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " list"));
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <powerbox> <player> <amount>"));
            return true;
        }
        if (args.length < 4) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <powerbox> <player> <amount>"));
            return true;
        }
        String id = args[1].toLowerCase(Locale.ENGLISH);
        if (!this.powerboxService.hasPowerbox(id)) {
            sender.sendMessage(Text.color("&cUnknown powerbox."));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        int amount;
        try {
            amount = Math.max(1, Integer.parseInt(args[3]));
        } catch (NumberFormatException ex) {
            sender.sendMessage(Text.color("&cInvalid amount."));
            return true;
        }
        int remaining = amount;
        while (remaining > 0) {
            ItemStack stack = this.powerboxService.createPowerbox(id, Math.min(remaining, 64));
            if (stack == null) {
                sender.sendMessage(Text.color("&cFailed to create powerbox item."));
                return true;
            }
            if (this.plugin.getStashService() != null) {
                this.plugin.getStashService().giveOrStash(target, stack);
            } else {
                target.getInventory().addItem(stack).values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
            }
            remaining -= stack.getAmount();
        }
        sender.sendMessage(Text.color("&aGave &f" + amount + " &a" + this.powerboxService.displayName(id) + " &ato &f" + target.getName() + "&a."));
        if (!sender.equals(target)) {
            target.sendMessage(Text.color("&dYou received &f" + amount + " &d" + this.powerboxService.displayName(id) + "&d."));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<String>();
        if (!sender.hasPermission("prisons.powerbox.admin")) {
            return completions;
        }
        if (args.length == 1) {
            if ("give".startsWith(args[0].toLowerCase(Locale.ENGLISH))) {
                completions.add("give");
            }
            if ("list".startsWith(args[0].toLowerCase(Locale.ENGLISH))) {
                completions.add("list");
            }
            return completions;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (String id : this.powerboxService.powerboxIds()) {
                if (id.startsWith(args[1].toLowerCase(Locale.ENGLISH))) {
                    completions.add(id);
                }
            }
            return completions;
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("give")) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ENGLISH).startsWith(args[2].toLowerCase(Locale.ENGLISH))) {
                    completions.add(player.getName());
                }
            }
            return completions;
        }
        return completions;
    }
}
