package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.List;
import org.axial.prisonsCore.service.DestructionScrollService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class DestructionScrollCommand implements CommandExecutor, TabCompleter {
    private final DestructionScrollService destructionScrollService;

    public DestructionScrollCommand(DestructionScrollService destructionScrollService) {
        this.destructionScrollService = destructionScrollService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 3 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Text.color("&cUsage: /" + label + " give <player> <percent> [amount]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        int percent;
        try {
            percent = Integer.parseInt(args[2]);
        } catch (NumberFormatException ex) {
            sender.sendMessage(Text.color("&cInvalid percent."));
            return true;
        }
        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Integer.parseInt(args[3]);
            } catch (NumberFormatException ignored) {
                amount = 1;
            }
        }
        if (amount <= 0) {
            amount = 1;
        }
        ItemStack scroll = this.destructionScrollService.createScroll(percent);
        scroll.setAmount(amount);
        if (this.destructionScrollService.getPlugin().getStashService() != null) {
            this.destructionScrollService.getPlugin().getStashService().giveOrStash(target, scroll);
        } else {
            target.getInventory().addItem(scroll).values().forEach(stack -> target.getWorld().dropItemNaturally(target.getLocation(), stack));
        }
        sender.sendMessage(Text.color("&aGave &f" + amount + " &aDestruction Scroll(s) at &f" + Math.max(0, Math.min(100, percent)) + "% &ato &f" + target.getName() + "&a."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> list = new ArrayList<String>();
        if (args.length == 1) {
            list.add("give");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                list.add(p.getName());
            }
        }
        return list;
    }
}
