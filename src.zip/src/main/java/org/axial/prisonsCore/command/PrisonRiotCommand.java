package org.axial.prisonsCore.command;

import org.axial.prisonsCore.gui.PrisonRiotMenu;
import org.axial.prisonsCore.service.PrisonRiotService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PrisonRiotCommand implements CommandExecutor {

    private final PrisonRiotService riotService;
    private final PrisonRiotMenu riotMenu;

    public PrisonRiotCommand(PrisonRiotService riotService, PrisonRiotMenu riotMenu) {
        this.riotService = riotService;
        this.riotMenu = riotMenu;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String alias = label == null ? "" : label.toLowerCase();
        if ("pr".equals(alias) || "riot".equals(alias)) {
            if (sender instanceof Player player) {
                this.riotMenu.openMain(player);
            } else {
                sender.sendMessage(Text.color("&cOnly players can open the Prison Riot menu."));
            }
            return true;
        }

        if (!(sender instanceof Player)) {
            return this.handleConsole(sender, args);
        }

        if (args.length == 0) {
            this.sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "start" -> {
                if (!this.requireAdmin(sender)) return true;
                if (this.riotService.startEventCycle()) {
                    sender.sendMessage(Text.color("&aPrison Riot queue started."));
                } else {
                    sender.sendMessage(Text.color("&cPrison Riot could not start. Make sure arena corner 1 and corner 2 are set."));
                }
            }
            case "end" -> {
                if (!this.requireAdmin(sender)) return true;
                this.riotService.endEventCycle();
                sender.sendMessage(Text.color("&cPrison Riot ended."));
            }
            case "setup" -> {
                if (!this.requireAdmin(sender)) return true;
                this.handleSetup(sender, args);
            }
            case "points" -> {
                if (!this.requireAdmin(sender)) return true;
                this.handlePoints(sender, args);
            }
            case "status" -> this.sendStatus(sender);
            default -> this.sendHelp(sender);
        }
        return true;
    }

    private boolean handleConsole(CommandSender sender, String[] args) {
        if (args.length == 0) {
            this.sendHelp(sender);
            return true;
        }
        String sub = args[0].toLowerCase();
        return switch (sub) {
            case "start" -> {
                if (this.riotService.startEventCycle()) {
                    sender.sendMessage(Text.color("&aPrison Riot queue started."));
                } else {
                    sender.sendMessage(Text.color("&cPrison Riot could not start. Make sure arena corner 1 and corner 2 are set."));
                }
                yield true;
            }
            case "end" -> {
                this.riotService.endEventCycle();
                sender.sendMessage(Text.color("&cPrison Riot ended."));
                yield true;
            }
            case "status" -> {
                this.sendStatus(sender);
                yield true;
            }
            default -> {
                this.sendHelp(sender);
                yield true;
            }
        };
    }

    private void handleSetup(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly a player can set arena positions."));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(Text.color("&cUsage: /prisonriot setup <pos1|pos2|spawn>"));
            return;
        }
        String target = args[1].toLowerCase();
        switch (target) {
            case "pos1", "corner1" -> {
                this.riotService.setArenaCorner1(player.getLocation());
                player.sendMessage(Text.color("&aSet Prison Riot corner 1."));
            }
            case "pos2", "corner2" -> {
                this.riotService.setArenaCorner2(player.getLocation());
                player.sendMessage(Text.color("&aSet Prison Riot corner 2."));
            }
            case "spawn" -> {
                this.riotService.setArenaSpawn(player.getLocation());
                player.sendMessage(Text.color("&aSet Prison Riot spawn."));
            }
            default -> player.sendMessage(Text.color("&cUsage: /prisonriot setup <pos1|pos2|spawn>"));
        }
        player.sendMessage(Text.color(this.riotService.describeArenaSetup()));
    }

    private void handlePoints(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(Text.color("&cUsage: /prisonriot points <add|remove|set|reset> <player> [amount]"));
            return;
        }
        String action = args[1].toLowerCase();
        Player target = sender.getServer().getPlayerExact(args[2]);
        if (target == null) {
            sender.sendMessage(Text.color("&cThat player is not online."));
            return;
        }
        switch (action) {
            case "add" -> {
                int amount = this.parseAmount(sender, args, 3);
                if (amount <= 0) return;
                this.riotService.addEventPoints(target.getUniqueId(), amount);
                sender.sendMessage(Text.color("&aAdded &f" + amount + " &ato " + target.getName() + "."));
            }
            case "remove" -> {
                int amount = this.parseAmount(sender, args, 3);
                if (amount <= 0) return;
                this.riotService.removeEventPoints(target.getUniqueId(), amount);
                sender.sendMessage(Text.color("&aRemoved &f" + amount + " &afrom " + target.getName() + "."));
            }
            case "set" -> {
                int amount = this.parseAmount(sender, args, 3);
                if (amount < 0) return;
                this.riotService.setEventPoints(target.getUniqueId(), amount);
                sender.sendMessage(Text.color("&aSet " + target.getName() + " to &f" + amount + " &apoints."));
            }
            case "reset" -> {
                this.riotService.resetEventPoints(target.getUniqueId());
                sender.sendMessage(Text.color("&aReset " + target.getName() + "'s Prison Riot points."));
            }
            default -> sender.sendMessage(Text.color("&cUsage: /prisonriot points <add|remove|set|reset> <player> [amount]"));
        }
    }

    private int parseAmount(CommandSender sender, String[] args, int index) {
        if (args.length <= index) {
            sender.sendMessage(Text.color("&cYou must provide an amount."));
            return -1;
        }
        try {
            return Math.max(0, Integer.parseInt(args[index]));
        } catch (NumberFormatException ex) {
            sender.sendMessage(Text.color("&cThat amount is not valid."));
            return -1;
        }
    }

    private boolean requireAdmin(CommandSender sender) {
        if (sender instanceof Player player && !this.riotService.isAdmin(player)) {
            player.sendMessage(Text.color("&cYou do not have permission to use that subcommand."));
            return false;
        }
        return true;
    }

    private void sendStatus(CommandSender sender) {
        sender.sendMessage(Text.color("&bPrison Riot Status: &f" + this.riotService.getStatusText()));
        sender.sendMessage(Text.color("&bArena: &f" + this.riotService.describeArenaSetup()));
        sender.sendMessage(Text.color("&bQueue: &f" + this.riotService.getQueuedPlayers().size() + " / " + this.riotService.getMaxPlayers()));
        sender.sendMessage(Text.color("&bRound: &f" + this.riotService.getRoundStatusText()));
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(Text.color("&bPrison Riot commands:"));
        sender.sendMessage(Text.color("&7/pr &7or &7/riot &7- open the riot menu"));
        sender.sendMessage(Text.color("&7/prisonriot start"));
        sender.sendMessage(Text.color("&7/prisonriot end"));
        sender.sendMessage(Text.color("&7/prisonriot setup <pos1|pos2|spawn>"));
        sender.sendMessage(Text.color("&7/prisonriot points <add|remove|set|reset> <player> [amount]"));
        sender.sendMessage(Text.color("&7/prisonriot status"));
    }
}
