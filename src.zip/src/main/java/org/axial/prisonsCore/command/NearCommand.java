package org.axial.prisonsCore.command;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NearCommand implements CommandExecutor {
    private static final double RADIUS = 200.0;

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this."));
            return true;
        }
        if (!player.hasPermission("prisons.near")) {
            player.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        Location origin = player.getLocation();
        double maxDistanceSquared = RADIUS * RADIUS;
        List<NearbyPlayer> nearby = new ArrayList<>();
        for (Player other : player.getWorld().getPlayers()) {
            if (other.equals(player)) {
                continue;
            }
            double distanceSquared = other.getLocation().distanceSquared(origin);
            if (distanceSquared <= maxDistanceSquared) {
                nearby.add(new NearbyPlayer(other.getName(), Math.sqrt(distanceSquared)));
            }
        }
        nearby.sort(Comparator.comparingDouble(NearbyPlayer::distance));
        if (nearby.isEmpty()) {
            player.sendMessage(Text.color("&7No players within &f" + (int)RADIUS + " &7blocks."));
            return true;
        }
        StringBuilder builder = new StringBuilder("&aNearby players: &f");
        for (int i = 0; i < nearby.size(); ++i) {
            NearbyPlayer entry = nearby.get(i);
            if (i > 0) {
                builder.append("&7, &f");
            }
            builder.append(entry.name()).append("&7(").append(String.format(Locale.ROOT, "%.1f", entry.distance())).append(")");
        }
        player.sendMessage(Text.color(builder.toString()));
        return true;
    }

    private record NearbyPlayer(String name, double distance) {
    }
}
