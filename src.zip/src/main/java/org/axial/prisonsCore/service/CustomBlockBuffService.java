package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public final class CustomBlockBuffService {
    private static final long BEACH_BALL_DURATION_MILLIS = 3600000L;
    private static final long MINI_PALM_TREE_DURATION_MILLIS = 3600000L;
    private static final long MINI_PALM_TREE_PROC_COOLDOWN_MILLIS = 1000L;
    private static final double BEACH_BALL_BUY_DISCOUNT = 0.75D;
    private static final double BEACH_BALL_SELL_BONUS = 1.25D;
    private static final double MINI_PALM_TREE_PROC_CHANCE = 0.25D;

    private final PrisonsCore plugin;
    private final File file;
    private final Map<UUID, BuffState> beachBallStates = new HashMap<UUID, BuffState>();
    private final Map<UUID, BuffState> miniPalmTreeStates = new HashMap<UUID, BuffState>();
    private final Map<UUID, Long> miniPalmTreeProcCooldowns = new HashMap<UUID, Long>();
    private YamlConfiguration cfg;

    public CustomBlockBuffService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "custom-block-buffs.yml");
        this.load();
    }

    public void reload() {
        this.load();
    }

    public void shutdown() {
        this.save();
    }

    public boolean activateBeachBall(Player player) {
        return this.activate(player, this.beachBallStates, BEACH_BALL_DURATION_MILLIS, "&e&lBEACH BALL", "&a25% off /shop purchases", "&a25% more /shop sell value");
    }

    public boolean activateMiniPalmTree(Player player) {
        return this.activate(player, this.miniPalmTreeStates, MINI_PALM_TREE_DURATION_MILLIS, "&e&lMINI PALM TREE", "&a25% chance for double charge, XP, and ores", null);
    }

    public boolean isBeachBallActive(Player player) {
        return this.isActive(this.beachBallStates, player);
    }

    public double applyBeachBallBuyDiscount(Player player, double base) {
        if (base <= 0.0D || !this.isBeachBallActive(player)) {
            return base;
        }
        return base * BEACH_BALL_BUY_DISCOUNT;
    }

    public double applyBeachBallSellBonus(Player player, double base) {
        if (base <= 0.0D || !this.isBeachBallActive(player)) {
            return base;
        }
        return base * BEACH_BALL_SELL_BONUS;
    }

    public boolean tryMiniPalmTreeProc(Player player) {
        if (!this.isActive(this.miniPalmTreeStates, player)) {
            return false;
        }
        UUID id = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long cooldownUntil = this.miniPalmTreeProcCooldowns.get(id);
        if (cooldownUntil != null) {
            if (cooldownUntil.longValue() > now) {
                return false;
            }
            this.miniPalmTreeProcCooldowns.remove(id);
        }
        if (Math.random() >= MINI_PALM_TREE_PROC_CHANCE) {
            return false;
        }
        this.miniPalmTreeProcCooldowns.put(id, now + MINI_PALM_TREE_PROC_COOLDOWN_MILLIS);
        return true;
    }

    private boolean activate(Player player, Map<UUID, BuffState> map, long durationMillis, String title, String primaryLine, String secondaryLine) {
        if (player == null) {
            return false;
        }
        UUID id = player.getUniqueId();
        long now = System.currentTimeMillis();
        BuffState current = this.state(map, id, false);
        if (current != null && current.activeUntil() > now) {
            return false;
        }
        long activeUntil = now + durationMillis;
        map.put(id, new BuffState(activeUntil, activeUntil));
        this.save();
        player.sendMessage(Text.color("&aActivated " + title + " &7for &b" + this.formatDuration(durationMillis) + "&7."));
        if (primaryLine != null && !primaryLine.isEmpty()) {
            player.sendMessage(Text.color("&7" + primaryLine));
        }
        if (secondaryLine != null && !secondaryLine.isEmpty()) {
            player.sendMessage(Text.color("&7" + secondaryLine));
        }
        return true;
    }

    private boolean isActive(Map<UUID, BuffState> map, Player player) {
        if (player == null) {
            return false;
        }
        BuffState state = this.state(map, player.getUniqueId(), true);
        return state != null && state.activeUntil() > System.currentTimeMillis();
    }

    private BuffState state(Map<UUID, BuffState> map, UUID id, boolean purgeExpired) {
        if (map == null || id == null) {
            return null;
        }
        BuffState state = map.get(id);
        if (state == null) {
            return null;
        }
        long now = System.currentTimeMillis();
        if (purgeExpired && state.activeUntil() <= now && state.cooldownUntil() <= now) {
            map.remove(id);
            this.save();
            return null;
        }
        return state;
    }

    private void load() {
        if (!this.file.exists()) {
            try {
                this.file.getParentFile().mkdirs();
                this.file.createNewFile();
            }
            catch (IOException ignored) {
                // empty catch block
            }
        }
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.beachBallStates.clear();
        this.miniPalmTreeStates.clear();
        this.loadSection("beach-ball", this.beachBallStates);
        this.loadSection("mini-palm-tree", this.miniPalmTreeStates);
    }

    private void loadSection(String key, Map<UUID, BuffState> map) {
        if (this.cfg == null) {
            return;
        }
        if (this.cfg.getConfigurationSection(key) == null) {
            return;
        }
        for (String raw : this.cfg.getConfigurationSection(key).getKeys(false)) {
            try {
                UUID id = UUID.fromString(raw);
                String base = key + "." + raw;
                long activeUntil = this.cfg.getLong(base + ".active-until", 0L);
                long cooldownUntil = this.cfg.getLong(base + ".cooldown-until", 0L);
                if (activeUntil <= 0L && cooldownUntil <= 0L) {
                    continue;
                }
                map.put(id, new BuffState(activeUntil, cooldownUntil));
            }
            catch (IllegalArgumentException ignored) {
                // empty catch block
            }
        }
    }

    private void save() {
        if (this.cfg == null) {
            this.cfg = new YamlConfiguration();
        }
        this.cfg.set("beach-ball", null);
        this.cfg.set("mini-palm-tree", null);
        this.saveSection("beach-ball", this.beachBallStates);
        this.saveSection("mini-palm-tree", this.miniPalmTreeStates);
        try {
            this.cfg.save(this.file);
        }
        catch (IOException ex) {
            this.plugin.getLogger().warning("Failed to save custom-block-buffs.yml: " + ex.getMessage());
        }
    }

    private void saveSection(String key, Map<UUID, BuffState> map) {
        for (Map.Entry<UUID, BuffState> entry : map.entrySet()) {
            String base = key + "." + entry.getKey().toString();
            BuffState state = entry.getValue();
            this.cfg.set(base + ".active-until", state.activeUntil());
            this.cfg.set(base + ".cooldown-until", state.cooldownUntil());
        }
    }

    private String formatDuration(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        long hours = totalSeconds / 3600L;
        long minutes = totalSeconds % 3600L / 60L;
        long seconds = totalSeconds % 60L;
        if (hours > 0L) {
            return hours + "h " + minutes + "m " + seconds + "s";
        }
        if (minutes > 0L) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }

    private record BuffState(long activeUntil, long cooldownUntil) {
    }
}
