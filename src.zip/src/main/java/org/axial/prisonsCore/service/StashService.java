package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

public final class StashService {
    private static final String FILE_NAME = "stash.yml";
    private static final long REMINDER_INTERVAL_TICKS = 600L;
    private static final int SIMULATED_STORAGE_SIZE = 36;

    private final PrisonsCore plugin;
    private final PlayerToggleService toggleService;
    private final File file;
    private final Map<UUID, List<ItemStack>> items = new HashMap<>();
    private YamlConfiguration cfg;
    private BukkitTask reminderTask;

    public StashService(PrisonsCore plugin, PlayerToggleService toggleService) {
        this.plugin = plugin;
        this.toggleService = toggleService;
        this.file = new File(plugin.getDataFolder(), FILE_NAME);
        this.load();
    }

    public void start() {
        if (this.reminderTask != null) {
            this.reminderTask.cancel();
        }
        this.reminderTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tickReminders, REMINDER_INTERVAL_TICKS, REMINDER_INTERVAL_TICKS);
    }

    public void stop() {
        if (this.reminderTask != null) {
            this.reminderTask.cancel();
            this.reminderTask = null;
        }
        this.save();
    }

    public void reload() {
        this.load();
    }

    public boolean isStashable(ItemStack stack) {
        if (stack == null || stack.getType().isAir()) {
            return false;
        }
        return this.plugin.getShardService() != null && this.plugin.getShardService().isShard(stack)
                || this.plugin.getContrabandService() != null && this.plugin.getContrabandService().isContraband(stack)
                || this.plugin.getEnergyItemService() != null && this.plugin.getEnergyItemService().isEnergyItem(stack)
                || this.plugin.getBankNoteService() != null && this.plugin.getBankNoteService().isBankNote(stack)
                || this.plugin.getPickaxeManager() != null && this.plugin.getPickaxeManager().isPrisonPickaxe(stack)
                || this.plugin.getChargeOrbService() != null && this.plugin.getChargeOrbService().isChargeOrb(stack)
                || this.plugin.getChargeOrbService() != null && this.plugin.getChargeOrbService().isSlotToken(stack)
                || this.plugin.getRenameScrollService() != null && this.plugin.getRenameScrollService().isRenameScroll(stack)
                || stack.getType() == Material.NAME_TAG;
    }

    public void giveOrStash(Player player, ItemStack item) {
        if (player == null || item == null || item.getType().isAir() || item.getAmount() <= 0) {
            return;
        }
        if (this.isRiotWorld(player)) {
            this.stash(player, item);
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(item.clone());
        for (ItemStack stack : leftover.values()) {
            this.routeOverflow(player, stack);
        }
    }

    public void giveOrStash(Player player, Collection<ItemStack> items) {
        if (player == null || items == null) {
            return;
        }
        for (ItemStack item : items) {
            this.giveOrStash(player, item);
        }
    }

    public void stash(Player player, ItemStack item) {
        if (player == null || item == null || item.getType().isAir() || item.getAmount() <= 0) {
            return;
        }
        this.addToStash(player.getUniqueId(), item.clone());
        this.save();
    }

    public List<ItemStack> getItems(UUID playerId) {
        List<ItemStack> list = this.items.get(playerId);
        if (list == null || list.isEmpty()) {
            return List.of();
        }
        ArrayList<ItemStack> copy = new ArrayList<>(list.size());
        for (ItemStack item : list) {
            copy.add(item.clone());
        }
        return copy;
    }

    public int getItemCount(UUID playerId) {
        List<ItemStack> list = this.items.get(playerId);
        return list == null ? 0 : list.size();
    }

    public ItemStack getItem(UUID playerId, int index) {
        List<ItemStack> list = this.items.get(playerId);
        if (list == null || index < 0 || index >= list.size()) {
            return null;
        }
        return list.get(index).clone();
    }

    public boolean removeItem(UUID playerId, int index) {
        List<ItemStack> list = this.items.get(playerId);
        if (list == null || index < 0 || index >= list.size()) {
            return false;
        }
        list.remove(index);
        if (list.isEmpty()) {
            this.items.remove(playerId);
        }
        this.save();
        return true;
    }

    public boolean removeItems(UUID playerId, Collection<Integer> indexes) {
        List<ItemStack> list = this.items.get(playerId);
        if (list == null || list.isEmpty() || indexes == null || indexes.isEmpty()) {
            return false;
        }
        ArrayList<Integer> sorted = new ArrayList<>(indexes);
        sorted.sort((a, b) -> Integer.compare(b, a));
        boolean changed = false;
        for (int index : sorted) {
            if (index < 0 || index >= list.size()) {
                continue;
            }
            list.remove(index);
            changed = true;
        }
        if (list.isEmpty()) {
            this.items.remove(playerId);
        }
        if (changed) {
            this.save();
        }
        return changed;
    }

    public boolean canFit(Player player, ItemStack item) {
        if (player == null || item == null || item.getType().isAir() || item.getAmount() <= 0) {
            return false;
        }
        Inventory sim = Bukkit.createInventory(null, SIMULATED_STORAGE_SIZE);
        sim.setContents(this.cloneContents(player.getInventory().getContents()));
        return sim.addItem(item.clone()).isEmpty();
    }

    public boolean canFitAll(Player player, Collection<ItemStack> stacks) {
        if (player == null || stacks == null) {
            return false;
        }
        Inventory sim = Bukkit.createInventory(null, SIMULATED_STORAGE_SIZE);
        sim.setContents(this.cloneContents(player.getInventory().getContents()));
        for (ItemStack item : stacks) {
            if (item == null || item.getType().isAir() || item.getAmount() <= 0) {
                continue;
            }
            if (!sim.addItem(item.clone()).isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public boolean claimItem(Player player, int index) {
        if (player == null) {
            return false;
        }
        ItemStack item = this.getItem(player.getUniqueId(), index);
        if (item == null) {
            return false;
        }
        if (!this.canFit(player, item)) {
            return false;
        }
        this.removeItem(player.getUniqueId(), index);
        player.getInventory().addItem(item);
        return true;
    }

    public boolean claimAll(Player player) {
        if (player == null) {
            return false;
        }
        List<ItemStack> stacks = this.getItems(player.getUniqueId());
        if (stacks.isEmpty() || !this.canFitAll(player, stacks)) {
            return false;
        }
        this.items.remove(player.getUniqueId());
        this.save();
        for (ItemStack item : stacks) {
            player.getInventory().addItem(item);
        }
        return true;
    }

    private void routeOverflow(Player player, ItemStack stack) {
        if (stack == null || stack.getType().isAir() || stack.getAmount() <= 0) {
            return;
        }
        if (this.isRiotWorld(player) || this.isStashable(stack)) {
            this.addToStash(player.getUniqueId(), stack);
            this.save();
            return;
        }
        player.getWorld().dropItemNaturally(player.getLocation(), stack);
    }

    private boolean isRiotWorld(Player player) {
        return player != null
                && this.plugin.getPrisonRiotService() != null
                && this.plugin.getPrisonRiotService().isRiotWorld(player.getWorld());
    }

    private void addToStash(UUID playerId, ItemStack item) {
        List<ItemStack> list = this.items.computeIfAbsent(playerId, ignored -> new ArrayList<>());
        if (this.plugin.getBankNoteService() != null && this.plugin.getBankNoteService().isBankNote(item)) {
            double combinedAmount = this.plugin.getBankNoteService().getTotalAmount(item);
            if (combinedAmount > 0.0D) {
                int insertIndex = list.size();
                for (int i = 0; i < list.size(); ++i) {
                    ItemStack existing = list.get(i);
                    if (existing == null || !this.plugin.getBankNoteService().isBankNote(existing)) {
                        continue;
                    }
                    if (insertIndex == list.size()) {
                        insertIndex = i;
                    }
                    combinedAmount += this.plugin.getBankNoteService().getTotalAmount(existing);
                    list.remove(i);
                    --i;
                }
                list.add(insertIndex, this.plugin.getBankNoteService().createBankNote(combinedAmount));
                return;
            }
        }
        if (this.plugin.getEnergyItemService() != null && this.plugin.getEnergyItemService().isEnergyItem(item)) {
            list.add(item.clone());
            this.compactEnergyItems(list);
            return;
        }
        list.add(item.clone());
    }

    private void compactEnergyItems(List<ItemStack> stacks) {
        if (stacks == null || stacks.isEmpty() || this.plugin.getEnergyItemService() == null) {
            return;
        }
        ArrayList<ItemStack> compacted = new ArrayList<>(stacks.size());
        long combinedAmount = 0L;
        int firstEnergyIndex = -1;
        for (ItemStack item : stacks) {
            if (item == null || item.getType() == Material.AIR || item.getAmount() <= 0) {
                continue;
            }
            if (!this.plugin.getEnergyItemService().isEnergyItem(item)) {
                compacted.add(item.clone());
                continue;
            }
            int amount = this.plugin.getEnergyItemService().getTotalAmount(item);
            if (amount <= 0) {
                continue;
            }
            if (firstEnergyIndex < 0) {
                firstEnergyIndex = compacted.size();
            }
            combinedAmount += amount;
        }
        if (firstEnergyIndex >= 0 && combinedAmount > 0L) {
            compacted.add(firstEnergyIndex, this.plugin.getEnergyItemService().createEnergyItem((int)combinedAmount));
        }
        stacks.clear();
        stacks.addAll(compacted);
    }

    private void compactBankNotes(List<ItemStack> stacks) {
        if (stacks == null || stacks.isEmpty() || this.plugin.getBankNoteService() == null) {
            return;
        }
        ArrayList<ItemStack> compacted = new ArrayList<>(stacks.size());
        double combinedAmount = 0.0D;
        int firstBankNoteIndex = -1;
        for (ItemStack item : stacks) {
            if (item == null || item.getType() == Material.AIR || item.getAmount() <= 0) {
                continue;
            }
            if (!this.plugin.getBankNoteService().isBankNote(item)) {
                compacted.add(item.clone());
                continue;
            }
            double amount = this.plugin.getBankNoteService().getTotalAmount(item);
            if (amount <= 0.0D) {
                continue;
            }
            if (firstBankNoteIndex < 0) {
                firstBankNoteIndex = compacted.size();
            }
            combinedAmount += amount;
        }
        if (firstBankNoteIndex >= 0 && combinedAmount > 0.0D) {
            compacted.add(firstBankNoteIndex, this.plugin.getBankNoteService().createBankNote(combinedAmount));
        }
        stacks.clear();
        stacks.addAll(compacted);
    }

    private void tickReminders() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (this.toggleService != null && !this.toggleService.isEnabled(player, PlayerToggleService.Toggle.STASH_NOTIFICATIONS)) {
                continue;
            }
            UUID id = player.getUniqueId();
            List<ItemStack> list = this.items.get(id);
            if (list == null || list.isEmpty()) {
                continue;
            }
            player.sendMessage(Text.color("&6&l(!) Stashed Items\n&7/stash to collect your stashed items."));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.2f);
        }
    }

    private void load() {
        if (!this.file.exists()) {
            this.file.getParentFile().mkdirs();
            this.saveDefaults();
        }
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.items.clear();
        if (this.cfg.getConfigurationSection("players") != null) {
            for (String key : this.cfg.getConfigurationSection("players").getKeys(false)) {
                try {
                    UUID id = UUID.fromString(key);
                    List<?> raw = this.cfg.getList("players." + key + ".items");
                    if (raw == null || raw.isEmpty()) {
                        continue;
                    }
                    ArrayList<ItemStack> stacks = new ArrayList<>();
                    for (Object value : raw) {
                        if (value instanceof ItemStack item && item.getType() != Material.AIR && item.getAmount() > 0) {
                            stacks.add(item.clone());
                        }
                    }
                    if (!stacks.isEmpty()) {
                        this.compactEnergyItems(stacks);
                        this.compactBankNotes(stacks);
                        this.items.put(id, stacks);
                    }
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        this.save();
    }

    private void saveDefaults() {
        this.cfg = new YamlConfiguration();
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to create " + FILE_NAME + ": " + e.getMessage());
        }
    }

    private void save() {
        if (this.cfg == null) {
            this.cfg = new YamlConfiguration();
        }
        this.cfg.set("players", null);
        for (Map.Entry<UUID, List<ItemStack>> entry : this.items.entrySet()) {
            if (entry.getValue() == null || entry.getValue().isEmpty()) {
                continue;
            }
            ArrayList<ItemStack> copy = new ArrayList<>();
            for (ItemStack item : entry.getValue()) {
                if (item != null && item.getType() != Material.AIR && item.getAmount() > 0) {
                    copy.add(item.clone());
                }
            }
            if (!copy.isEmpty()) {
                this.cfg.set("players." + entry.getKey() + ".items", copy);
            }
        }
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save " + FILE_NAME + ": " + e.getMessage());
        }
    }

    private ItemStack[] cloneContents(ItemStack[] contents) {
        ItemStack[] copy = new ItemStack[SIMULATED_STORAGE_SIZE];
        if (contents == null) {
            return copy;
        }
        for (int i = 0; i < contents.length && i < copy.length; ++i) {
            copy[i] = contents[i] == null ? null : contents[i].clone();
        }
        return copy;
    }
}
