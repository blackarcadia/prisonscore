package org.axial.prisonsCore.service;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.attribute.Attribute;
import com.github.retrooper.packetevents.protocol.attribute.Attributes;
import com.github.retrooper.packetevents.protocol.player.ClientVersion;
import com.github.retrooper.packetevents.protocol.potion.PotionTypes;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityEffect;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerRemoveEntityEffect;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerUpdateAttributes;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.cell.CellService;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class SlownessEffectService implements Listener {

    private static final String MOD_KEY_NS = "prisonscore";
    private static final String MOD_KEY_VALUE = "break_speed_zero";
    private static final NamespacedKey MODIFIER_KEY = new NamespacedKey(MOD_KEY_NS, MOD_KEY_VALUE);

    private final PrisonsCore plugin;
    private final CellService cellService;
    private final PickaxeManager pickaxeManager;
    private BukkitTask refreshTask;

    public SlownessEffectService(PrisonsCore plugin, CellService cellService, PickaxeManager pickaxeManager) {
        this.plugin = plugin;
        this.cellService = cellService;
        this.pickaxeManager = pickaxeManager;
    }

    public void start() {
        if (this.refreshTask != null) {
            this.refreshTask.cancel();
        }
        this.refreshTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::refreshAll, 1L, 20L);
        this.refreshAll();
    }

    public void stop() {
        if (this.refreshTask != null) {
            this.refreshTask.cancel();
            this.refreshTask = null;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.clearSlownessEffect(player);
        }
    }

    /**
     * Client-side "slowness" for mining:
     * - 1.21+: sets the player's {@code BLOCK_BREAK_SPEED} attribute to 0 via UpdateAttributes.
     * - older: applies Mining Fatigue via EntityEffect.
     *
     * This is packet-only; it does not add a real Bukkit potion effect when PacketEvents is available.
     */
    public void playSlownessEffect(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }

        if (this.isCellRaidExempt(player)) {
            this.clearSlownessEffect(player);
            return;
        }

        if (this.tryPlayViaPacketEvents(player)) {
            return;
        }

        AttributeInstance inst = player.getAttribute(org.bukkit.attribute.Attribute.BLOCK_BREAK_SPEED);
        if (inst != null) {
            if (!hasModifier(inst, MODIFIER_KEY)) {
                inst.addTransientModifier(new AttributeModifier(MODIFIER_KEY, -1.0D, AttributeModifier.Operation.MULTIPLY_SCALAR_1));
            }
            return;
        }

        player.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, Integer.MAX_VALUE, 4, false, false, false));
    }

    /**
     * Best-effort removal/reset for {@link #playSlownessEffect(Player)}.
     */
    public void clearSlownessEffect(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }

        if (this.tryClearViaPacketEvents(player)) {
            return;
        }

        player.removePotionEffect(PotionEffectType.MINING_FATIGUE);
        AttributeInstance inst = player.getAttribute(org.bukkit.attribute.Attribute.BLOCK_BREAK_SPEED);
        if (inst != null) {
            removeModifier(inst, MODIFIER_KEY);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        this.clearSlownessEffect(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onHeldItemChange(PlayerItemHeldEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwapHandItems(PlayerSwapHandItemsEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            this.refreshLater(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            this.refreshLater(player);
        }
    }

    private void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.playSlownessEffect(player);
        }
    }

    private void refreshLater(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.playSlownessEffect(player));
    }

    private boolean isCellRaidExempt(Player player) {
        if (this.cellService == null || player == null || !player.isOnline()) {
            return false;
        }
        if (this.cellService.getCellAt(player.getLocation()) != null) {
            return true;
        }
        if (this.cellService.isCellBuster(player.getInventory().getItemInMainHand()) || this.cellService.isCellBuster(player.getInventory().getItemInOffHand())) {
            return true;
        }
        Block target = player.getTargetBlockExact(6);
        return target != null && this.cellService.isCellDoor(target);
    }

    private boolean tryPlayViaPacketEvents(Player player) {
        if (!isPacketEventsEnabled()) {
            return false;
        }
        try {
            ClientVersion version = PacketEvents.getAPI().getPlayerManager().getClientVersion(player);
            if (version.isNewerThanOrEquals(ClientVersion.V_1_21)) {
                Attribute attribute = Attributes.BLOCK_BREAK_SPEED;
                double speedModifier = 0.0D;

                WrapperPlayServerUpdateAttributes.PropertyModifier propertyModifier =
                        new WrapperPlayServerUpdateAttributes.PropertyModifier(
                                UUID.randomUUID(),
                                speedModifier,
                                WrapperPlayServerUpdateAttributes.PropertyModifier.Operation.ADDITION
                        );
                WrapperPlayServerUpdateAttributes.Property property =
                        new WrapperPlayServerUpdateAttributes.Property(attribute, speedModifier, List.of(propertyModifier));
                WrapperPlayServerUpdateAttributes packet =
                        new WrapperPlayServerUpdateAttributes(player.getEntityId(), List.of(property));

                PacketEvents.getAPI().getPlayerManager().sendPacket(player, packet);
                return true;
            }

            byte flags = (byte) (0x02 | 0x04);
            WrapperPlayServerEntityEffect effect =
                    new WrapperPlayServerEntityEffect(player.getEntityId(), PotionTypes.MINING_FATIGUE, -1, Integer.MAX_VALUE, flags);
            PacketEvents.getAPI().getPlayerManager().sendPacket(player, effect);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean tryClearViaPacketEvents(Player player) {
        if (!isPacketEventsEnabled()) {
            return false;
        }
        try {
            ClientVersion version = PacketEvents.getAPI().getPlayerManager().getClientVersion(player);
            if (version.isNewerThanOrEquals(ClientVersion.V_1_21)) {
                return this.resendCurrentBreakSpeedAttributeViaPacketEvents(player);
            }

            WrapperPlayServerRemoveEntityEffect removePacket =
                    new WrapperPlayServerRemoveEntityEffect(player.getEntityId(), PotionTypes.MINING_FATIGUE);
            PacketEvents.getAPI().getPlayerManager().sendPacket(player, removePacket);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private boolean resendCurrentBreakSpeedAttributeViaPacketEvents(Player player) {
        try {
            AttributeInstance instance = player.getAttribute(org.bukkit.attribute.Attribute.BLOCK_BREAK_SPEED);
            double baseValue = instance != null ? instance.getBaseValue() : 1.0D;
            Collection<AttributeModifier> bukkitMods = instance != null ? instance.getModifiers() : List.of();

            List<WrapperPlayServerUpdateAttributes.PropertyModifier> modifiers = new ArrayList<>();
            for (AttributeModifier mod : bukkitMods) {
                WrapperPlayServerUpdateAttributes.PropertyModifier.Operation operation = switch (mod.getOperation()) {
                    case ADD_NUMBER -> WrapperPlayServerUpdateAttributes.PropertyModifier.Operation.ADDITION;
                    case ADD_SCALAR -> WrapperPlayServerUpdateAttributes.PropertyModifier.Operation.MULTIPLY_BASE;
                    case MULTIPLY_SCALAR_1 -> WrapperPlayServerUpdateAttributes.PropertyModifier.Operation.MULTIPLY_TOTAL;
                };
                modifiers.add(new WrapperPlayServerUpdateAttributes.PropertyModifier(mod.getUniqueId(), mod.getAmount(), operation));
            }

            WrapperPlayServerUpdateAttributes.Property property =
                    new WrapperPlayServerUpdateAttributes.Property(Attributes.BLOCK_BREAK_SPEED, baseValue, modifiers);
            WrapperPlayServerUpdateAttributes packet =
                    new WrapperPlayServerUpdateAttributes(player.getEntityId(), List.of(property));
            PacketEvents.getAPI().getPlayerManager().sendPacket(player, packet);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean isPacketEventsEnabled() {
        return isPluginEnabled("packetevents") || isPluginEnabled("PacketEvents");
    }

    private static boolean isPluginEnabled(String name) {
        return Bukkit.getPluginManager().getPlugin(name) != null && Bukkit.getPluginManager().isPluginEnabled(name);
    }

    private static boolean hasModifier(AttributeInstance inst, NamespacedKey key) {
        for (AttributeModifier mod : inst.getModifiers()) {
            if (key.equals(mod.getKey())) {
                return true;
            }
        }
        return false;
    }

    private static void removeModifier(AttributeInstance inst, NamespacedKey key) {
        for (AttributeModifier mod : List.copyOf(inst.getModifiers())) {
            if (key.equals(mod.getKey())) {
                inst.removeModifier(mod);
            }
        }
    }
}
