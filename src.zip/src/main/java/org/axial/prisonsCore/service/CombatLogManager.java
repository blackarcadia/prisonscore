/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.PlayerInventory
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package org.axial.prisonsCore.service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class CombatLogManager {
    private static final long COMBAT_DURATION_TICKS = 300L;
    private static final String ENTER_MESSAGE = "&c&l(!) &cYou are in now in combat do not log out";
    private static final String EXIT_MESSAGE = "&a&l(!) &aYou are no longer in combat you may log out";
    private final PrisonsCore plugin;
    private final Map<UUID, BukkitTask> expiryTasks = new HashMap<UUID, BukkitTask>();
    private final Set<UUID> inCombat = new HashSet<UUID>();

    public CombatLogManager(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public void tag(Player player) {
        if (player == null) {
            return;
        }
        UUID id = player.getUniqueId();
        boolean alreadyInCombat = this.inCombat.contains(id);
        this.cancelTask(id);
        BukkitTask task = this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            Player online;
            this.expiryTasks.remove(id);
            if (this.inCombat.remove(id) && (online = this.plugin.getServer().getPlayer(id)) != null && online.isOnline()) {
                online.sendMessage(Text.color(EXIT_MESSAGE));
            }
        }, 300L);
        this.expiryTasks.put(id, task);
        if (!alreadyInCombat) {
            this.inCombat.add(id);
            player.sendMessage(Text.color(ENTER_MESSAGE));
        } else {
            this.inCombat.add(id);
        }
    }

    public boolean isInCombat(Player player) {
        return player != null && this.inCombat.contains(player.getUniqueId());
    }

    public void clearCombat(Player player, boolean notify) {
        if (player == null) {
            return;
        }
        UUID id = player.getUniqueId();
        this.cancelTask(id);
        if (this.inCombat.remove(id) && notify) {
            player.sendMessage(Text.color(EXIT_MESSAGE));
        }
    }

    public void handleLogout(Player player) {
        if (player == null) {
            return;
        }
        UUID id = player.getUniqueId();
        if (!this.inCombat.contains(id)) {
            return;
        }
        this.dropInventory(player);
        this.cancelTask(id);
        this.inCombat.remove(id);
        try {
            player.setHealth(0.0);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void shutdown() {
        this.expiryTasks.values().forEach(BukkitTask::cancel);
        this.expiryTasks.clear();
        this.inCombat.clear();
    }

    private void cancelTask(UUID id) {
        BukkitTask task = this.expiryTasks.remove(id);
        if (task != null) {
            task.cancel();
        }
    }

    private void dropInventory(Player player) {
        Location location = player.getLocation();
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        PlayerInventory inv = player.getInventory();
        for (ItemStack item : inv.getContents()) {
            this.drop(world, location, item);
        }
        for (ItemStack armor : inv.getArmorContents()) {
            this.drop(world, location, armor);
        }
        this.drop(world, location, inv.getItemInOffHand());
        inv.clear();
        inv.setArmorContents(null);
        inv.setItemInOffHand(null);
    }

    private void drop(World world, Location location, ItemStack item) {
        if (item == null || item.getType().isAir()) {
            return;
        }
        world.dropItemNaturally(location, item);
    }
}

