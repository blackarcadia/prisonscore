/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.GeneratorService;
import org.axial.prisonsCore.service.MeteorService;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.plugin.Plugin;

public class OreRegenService
implements Listener {
    private final PrisonsCore plugin;
    private final GeneratorService generatorService;
    private final MeteorService meteorService;
    private final Map<Material, Integer> regenSeconds = new HashMap<Material, Integer>();
    private final Material placeholder;
    private final Map<BlockPos, Material> pending = new HashMap<BlockPos, Material>();
    private final Set<BlockPos> justScheduled = new HashSet<BlockPos>();
    private final File pendingFile;
    private YamlConfiguration pendingConfig;
    private boolean pendingDirty;
    private Integer pendingSaveTask;
    private static final Map<Material, Integer> DEFAULT_DELAYS = Map.of(
            Material.COAL_ORE, 30,
            Material.IRON_ORE, 45,
            Material.GOLD_ORE, 60,
            Material.LAPIS_ORE, 50,
            Material.REDSTONE_ORE, 70,
            Material.DIAMOND_ORE, 90,
            Material.EMERALD_ORE, 120
    );

    public OreRegenService(PrisonsCore plugin, GeneratorService generatorService, MeteorService meteorService) {
        Material ph;
        this.plugin = plugin;
        this.generatorService = generatorService;
        this.meteorService = meteorService;
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("ore-regen.ores");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                Material m = Material.matchMaterial((String)key);
                if (m == null) continue;
                this.regenSeconds.put(m, sec.getInt(key, 0));
            }
        }
        this.applyDefaults();
        this.placeholder = (ph = Material.matchMaterial((String)plugin.getConfig().getString("ore-regen.placeholder", "STONE"))) == null ? Material.STONE : ph;
        this.pendingFile = new File(plugin.getDataFolder(), "pending-ores.yml");
        this.pendingConfig = YamlConfiguration.loadConfiguration((File)this.pendingFile);
        this.restorePendingOres();
    }

    public boolean isRegenerating(Block block) {
        // Meteor blocks/ores should never be treated as pending regen.
        if (this.meteorService != null && (this.meteorService.isMeteorBlock(block) || this.meteorService.isMeteorOre(block) || this.meteorService.isGKitBlock(block))) {
            return false;
        }
        return this.pending.containsKey(BlockPos.of(block));
    }

    public void removePending(Block block) {
        this.pending.remove(BlockPos.of(block));
        this.savePendingState();
    }

    public boolean isManagedOre(Block block) {
        if (block == null) {
            return false;
        }
        return this.pending.containsKey(BlockPos.of(block)) || this.getDelay(block.getType()) != null;
    }

    public void removeOreForAdmin(Block block) {
        if (block == null) {
            return;
        }
        this.pending.remove(BlockPos.of(block));
        block.setType(Material.AIR, false);
        this.savePendingState();
    }

    public void handleMine(Block block) {
        this.handleMine(block, true);
    }

    public void handleMine(Block block, boolean saveImmediately) {
        if (this.meteorService != null && (this.meteorService.isMeteorBlock(block) || this.meteorService.isMeteorOre(block) || this.meteorService.isGKitBlock(block))) {
            // Meteor blocks/ores should deplete, never regenerate.
            this.pending.remove(BlockPos.of(block));
            return;
        }
        Material type = block.getType();
        Integer delay = this.getDelay(type);
        if (delay == null || delay <= 0) {
            return;
        }
        BlockPos pos = BlockPos.of(block);
        if (this.pending.containsKey(pos)) {
            return;
        }
        this.pending.put(pos, type);
        this.justScheduled.add(pos);
        this.pendingDirty = true;
        if (saveImmediately) {
            this.savePendingState();
        }
        this.schedulePendingSave();
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.justScheduled.remove(pos), 5L);
        // Apply placeholder immediately so the player sees the regen block, and reinforce it next tick.
        block.setType(this.placeholder, false);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            if (this.pending.containsKey(pos) && block.getType() != this.placeholder) {
                block.setType(this.placeholder, false);
            }
        });

        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, new Runnable(){
            @Override
            public void run() {
                Material original = OreRegenService.this.pending.get(pos);
                if (original == null) {
                    return;
                }
                if (!block.getWorld().isChunkLoaded(block.getX() >> 4, block.getZ() >> 4)) {
                    Bukkit.getScheduler().runTaskLater((Plugin)OreRegenService.this.plugin, this, 100L);
                    return;
                }
                OreRegenService.this.pending.remove(pos);
                OreRegenService.this.pendingDirty = true;
                OreRegenService.this.schedulePendingSave();
                block.setType(original, false);
            }
        }, (long)delay.intValue() * 20L);
    }

    public void flushPendingState() {
        if (!this.pendingDirty) {
            return;
        }
        this.savePendingState();
        this.pendingDirty = false;
        if (this.pendingSaveTask != null) {
            Bukkit.getScheduler().cancelTask(this.pendingSaveTask.intValue());
            this.pendingSaveTask = null;
        }
    }

    public void shutdown() {
        this.restoreTrackedPendingOres();
        this.pending.clear();
        this.savePendingState();
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        BlockPos pos = BlockPos.of(block);
        if (this.meteorService != null && (this.meteorService.isMeteorBlock(block) || this.meteorService.isMeteorOre(block) || this.meteorService.isGKitBlock(block))) {
            // Make sure meteors never get stuck flagged as pending regen.
            this.pending.remove(pos);
            this.savePendingState();
            return;
        }
        if (this.justScheduled.remove(pos)) {
            return;
        }
        if (this.pending.containsKey(pos)) {
            event.setCancelled(true);
            return;
        }
        if (this.generatorService != null && (this.generatorService.isGeneratedOre(block) || this.generatorService.isRefinedBase(block))) {
            return;
        }
        this.handleMine(block);
    }

    private Integer getDelay(Material type) {
        Integer delay = this.regenSeconds.get(type);
        if (delay != null) {
            return delay;
        }
        String name = type.name();
        if (name.startsWith("DEEPSLATE_")) {
            delay = this.regenSeconds.get(Material.matchMaterial(name.substring("DEEPSLATE_".length())));
        } else if (name.equals("NETHER_GOLD_ORE")) {
            delay = this.regenSeconds.get(Material.GOLD_ORE);
        }
        return delay;
    }

    private void applyDefaults() {
        for (Map.Entry<Material, Integer> entry : DEFAULT_DELAYS.entrySet()) {
            Material key = entry.getKey();
            Integer existing = this.regenSeconds.get(key);
            if (existing == null || existing <= 0) {
                this.regenSeconds.put(key, entry.getValue());
            }
        }
    }

    private void restorePendingOres() {
        List<?> stored = this.pendingConfig.getList("pending");
        if (stored == null || stored.isEmpty()) {
            return;
        }
        for (Object entry : stored) {
            if (!(entry instanceof Map<?, ?> raw)) {
                continue;
            }
            String worldName = String.valueOf(raw.get("world"));
            World world = Bukkit.getWorld((String)worldName);
            Material material = Material.matchMaterial(String.valueOf(raw.get("material")));
            Object xRaw = raw.get("x");
            Object yRaw = raw.get("y");
            Object zRaw = raw.get("z");
            if (world == null || material == null || !(xRaw instanceof Number) || !(yRaw instanceof Number) || !(zRaw instanceof Number)) {
                continue;
            }
            Block block = world.getBlockAt(((Number)xRaw).intValue(), ((Number)yRaw).intValue(), ((Number)zRaw).intValue());
            block.setType(material, false);
        }
        this.pendingConfig.set("pending", null);
        this.savePendingConfig();
    }

    private void restoreTrackedPendingOres() {
        for (Map.Entry<BlockPos, Material> entry : new HashMap<BlockPos, Material>(this.pending).entrySet()) {
            BlockPos pos = entry.getKey();
            Material material = entry.getValue();
            World world = Bukkit.getWorld((String)pos.world());
            if (world == null || material == null) {
                continue;
            }
            Block block = world.getBlockAt(pos.x(), pos.y(), pos.z());
            block.setType(material, false);
        }
    }

    private void savePendingState() {
        List<Map<String, Object>> stored = new ArrayList<Map<String, Object>>();
        for (Map.Entry<BlockPos, Material> entry : this.pending.entrySet()) {
            BlockPos pos = entry.getKey();
            Material material = entry.getValue();
            Map<String, Object> serialized = new HashMap<String, Object>();
            serialized.put("world", pos.world());
            serialized.put("x", pos.x());
            serialized.put("y", pos.y());
            serialized.put("z", pos.z());
            serialized.put("material", material.name());
            stored.add(serialized);
        }
        this.pendingConfig.set("pending", stored.isEmpty() ? null : stored);
        this.savePendingConfig();
    }

    private void savePendingConfig() {
        try {
            this.pendingConfig.save(this.pendingFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save pending ore regen state: " + e.getMessage());
        }
    }

    private void schedulePendingSave() {
        if (this.pendingSaveTask != null) {
            return;
        }
        this.pendingSaveTask = Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            this.pendingSaveTask = null;
            if (!this.pendingDirty) {
                return;
            }
            this.savePendingState();
            this.pendingDirty = false;
        }, 20L).getTaskId();
    }

    private record BlockPos(int x, int y, int z, String world) {
        static BlockPos of(Block block) {
            return new BlockPos(block.getX(), block.getY(), block.getZ(), Objects.requireNonNull(block.getWorld().getName()));
        }
    }
}
