package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class GlobalBoosterService implements Listener {
    private static final String FILE_NAME = "global-boosters.yml";

    private final PrisonsCore plugin;
    private final File file;
    private final Map<BoosterType, BoosterState> states = new EnumMap<>(BoosterType.class);
    private final Map<BoosterType, BossBar> bossBars = new EnumMap<>(BoosterType.class);
    private YamlConfiguration cfg;
    private BukkitTask task;

    public GlobalBoosterService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), FILE_NAME);
        this.load();
    }

    public void start() {
        if (this.task != null) {
            this.task.cancel();
        }
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::tick, 20L, 20L);
        this.tick();
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
        for (BossBar bar : this.bossBars.values()) {
            bar.removeAll();
            bar.setVisible(false);
        }
        this.save();
    }

    public void reload() {
        this.load();
        this.tick();
    }

    public void setMultiplier(BoosterType type, double multiplier) {
        if (type == null) {
            return;
        }
        BoosterState current = this.state(type);
        this.states.put(type, new BoosterState(Math.max(1.0, multiplier), current.active(), current.expiresAt(), current.durationMillis()));
        this.save();
        this.update(type);
    }

    public void startBooster(BoosterType type, long durationSeconds) {
        BoosterState current = this.state(type);
        if (durationSeconds <= 0L) {
            return;
        }
        long expiresAt = System.currentTimeMillis() + durationSeconds * 1000L;
        this.states.put(type, new BoosterState(current.multiplier(), true, expiresAt, durationSeconds * 1000L));
        this.save();
        this.update(type);
    }

    public void startBooster(BoosterType type, double multiplier, long durationSeconds) {
        this.setMultiplier(type, multiplier);
        this.startBooster(type, durationSeconds);
    }

    public void stopBooster(BoosterType type) {
        BoosterState current = this.state(type);
        this.states.put(type, new BoosterState(current.multiplier(), false, 0L, current.durationMillis()));
        this.save();
        this.update(type);
    }

    public boolean isActive(BoosterType type) {
        BoosterState state = this.states.get(type);
        if (state == null || !state.active()) {
            return false;
        }
        if (state.expiresAt() <= 0L) {
            return true;
        }
        if (state.expiresAt() <= System.currentTimeMillis()) {
            this.stopBooster(type);
            return false;
        }
        return true;
    }

    public double getMultiplier(BoosterType type) {
        return this.isActive(type) ? this.state(type).multiplier() : 1.0D;
    }

    public double getMiningXpMultiplier() {
        return this.getMultiplier(BoosterType.MINING_XP);
    }

    public double getChargeMultiplier() {
        return this.getMultiplier(BoosterType.CHARGE);
    }

    public double getSellMultiplier() {
        return this.getMultiplier(BoosterType.MONEY);
    }

    public double getShardChanceMultiplier() {
        return this.getMultiplier(BoosterType.SHARD);
    }

    public String getStatusLine(BoosterType type) {
        BoosterState state = this.state(type);
        boolean active = this.isActive(type);
        String status = active ? "Active" : "Inactive";
        String duration = active ? this.formatDuration(Math.max(0L, state.expiresAt() - System.currentTimeMillis())) : "0s";
        return Text.color("&f" + type.displayName() + " &7- &b" + this.formatMultiplier(state.multiplier()) + " &7- &" + (active ? "a" : "c") + status + " &7- &f" + duration);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.refreshViewer(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        for (BossBar bar : this.bossBars.values()) {
            bar.removePlayer(event.getPlayer());
        }
    }

    private void load() {
        if (!this.file.exists()) {
            this.file.getParentFile().mkdirs();
            this.saveDefaults();
        }
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.states.clear();
        for (BoosterType type : BoosterType.values()) {
            String base = "boosters." + type.key();
            double multiplier = Math.max(1.0, this.cfg.getDouble(base + ".multiplier", 1.0));
            boolean active = this.cfg.getBoolean(base + ".active", false);
            long expiresAt = this.cfg.getLong(base + ".expires-at", 0L);
            long durationMillis = Math.max(0L, this.cfg.getLong(base + ".duration-millis", 0L));
            if (active && expiresAt > 0L && expiresAt <= System.currentTimeMillis()) {
                active = false;
                expiresAt = 0L;
            }
            this.states.put(type, new BoosterState(multiplier, active, expiresAt, durationMillis));
        }
        this.save();
    }

    private void save() {
        if (this.cfg == null) {
            this.cfg = new YamlConfiguration();
        }
        for (BoosterType type : BoosterType.values()) {
            BoosterState state = this.state(type);
            String base = "boosters." + type.key();
            this.cfg.set(base + ".multiplier", state.multiplier());
            this.cfg.set(base + ".active", state.active());
            this.cfg.set(base + ".expires-at", state.expiresAt());
            this.cfg.set(base + ".duration-millis", state.durationMillis());
        }
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save " + FILE_NAME + ": " + e.getMessage());
        }
    }

    private void saveDefaults() {
        this.cfg = new YamlConfiguration();
        for (BoosterType type : BoosterType.values()) {
            String base = "boosters." + type.key();
            this.cfg.set(base + ".multiplier", 1.0);
            this.cfg.set(base + ".active", false);
            this.cfg.set(base + ".expires-at", 0L);
            this.cfg.set(base + ".duration-millis", 0L);
        }
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to create " + FILE_NAME + ": " + e.getMessage());
        }
    }

    private void tick() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        for (BoosterType type : BoosterType.values()) {
            BoosterState state = this.state(type);
            if (state.active() && state.expiresAt() > 0L && state.expiresAt() <= now) {
                this.states.put(type, new BoosterState(state.multiplier(), false, 0L, state.durationMillis()));
                changed = true;
            }
            this.update(type);
        }
        if (changed) {
            this.save();
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.refreshViewer(player);
        }
    }

    private void update(BoosterType type) {
        BossBar bar = this.bossBars.computeIfAbsent(type, t -> Bukkit.createBossBar("", t.color(), BarStyle.SOLID));
        BoosterState state = this.state(type);
        if (!state.active()) {
            bar.removeAll();
            bar.setVisible(false);
            return;
        }

        long now = System.currentTimeMillis();
        long remaining = Math.max(0L, state.expiresAt() - now);
        long durationMillis = Math.max(1L, state.durationMillis() > 0L ? state.durationMillis() : remaining);
        double progress = Math.max(0.0D, Math.min(1.0D, (double)remaining / (double)durationMillis));
        bar.setTitle(Text.color(this.formatBarTitle(type, state.multiplier(), remaining)));
        bar.setProgress(progress);
        bar.setVisible(true);
        for (Player player : Bukkit.getOnlinePlayers()) {
            bar.addPlayer(player);
        }
    }

    private void refreshViewer(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        for (BoosterType type : BoosterType.values()) {
            BossBar bar = this.bossBars.get(type);
            if (bar == null) {
                continue;
            }
            if (this.isActive(type)) {
                bar.addPlayer(player);
            } else {
                bar.removePlayer(player);
            }
        }
    }

    private BoosterState state(BoosterType type) {
        return this.states.getOrDefault(type, new BoosterState(1.0D, false, 0L, 0L));
    }

    private String formatMultiplier(double multiplier) {
        if (multiplier == (double)((int)multiplier)) {
            return String.valueOf((int)multiplier) + "x";
        }
        return String.format(Locale.ROOT, "%.2fx", multiplier);
    }

    private String formatDuration(long millis) {
        Duration duration = Duration.ofMillis(Math.max(0L, millis));
        long hours = duration.toHours();
        long minutes = duration.minusHours(hours).toMinutes();
        long seconds = duration.minusHours(hours).minusMinutes(minutes).getSeconds();
        if (hours > 0L) {
            return hours + "h " + minutes + "m " + seconds + "s";
        }
        if (minutes > 0L) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }

    private String formatBarTitle(BoosterType type, double multiplier, long remainingMillis) {
        String amount = this.formatMultiplier(multiplier);
        String time = this.formatDuration(remainingMillis);
        return switch (type) {
            case CHARGE -> "&d" + amount + " &d&lCharge Booster &7(&f" + time + "&7)";
            case MONEY -> "&a" + amount + " &a&lSell Multiplier &7(&f" + time + "&7)";
            case MINING_XP -> "&e" + amount + " &e&lMining XP Booster &7(&f" + time + "&7)";
            case SHARD -> "&b" + amount + " &b&lShard Booster &7(&f" + time + "&7)";
        };
    }

    public enum BoosterType {
        MINING_XP("miningxp", "Mining XP", BarColor.YELLOW),
        MONEY("money", "Money Sell", BarColor.GREEN),
        CHARGE("charge", "Pickaxe Charge", BarColor.PINK),
        SHARD("shard", "Shards", BarColor.BLUE);

        private final String key;
        private final String displayName;
        private final BarColor color;

        BoosterType(String key, String displayName, BarColor color) {
            this.key = key;
            this.displayName = displayName;
            this.color = color;
        }

        public String key() {
            return this.key;
        }

        public String displayName() {
            return this.displayName;
        }

        public BarColor color() {
            return this.color;
        }

        public static BoosterType parse(String input) {
            if (input == null) {
                return null;
            }
            String normalized = input.toLowerCase(Locale.ROOT).replace("-", "").replace("_", "");
            return switch (normalized) {
                case "xp", "exp", "miningxp", "minexp", "miningexperience" -> MINING_XP;
                case "money", "sell", "sells", "moneysell" -> MONEY;
                case "charge", "energy", "pickaxecharge", "chargeboost" -> CHARGE;
                case "shard", "shards", "fragment", "fragments" -> SHARD;
                default -> null;
            };
        }
    }

    private record BoosterState(double multiplier, boolean active, long expiresAt, long durationMillis) {
    }
}
