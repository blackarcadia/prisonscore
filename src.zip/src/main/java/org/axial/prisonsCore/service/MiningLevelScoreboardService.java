package org.axial.prisonsCore.service;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;
import org.bukkit.scoreboard.Team;
import org.axial.prisonsCore.service.AlienInvasionService;
import org.axial.prisonsCore.service.PlayerDataService;


public class MiningLevelScoreboardService {
    private static final String DEFAULT_LAYOUT_FILE = "scoreboard-default.yml";
    private static final String PICKAXE_LAYOUT_FILE = "scoreboard-pickaxe.yml";
    private static final String DEFAULT_LAYOUT_KEY = "default";
    private static final String PICKAXE_LAYOUT_KEY = "pickaxe";
    private static final String HEALTH_OBJECTIVE_NAME = "pc_health";
    private static final String SIDEBAR_OBJECTIVE_NAME = "prisons";
    private static final String TEAM_PREFIX = "pc_lv_";
    private static final String[] ENTRY_KEYS = new String[]{
            ChatColor.BLACK.toString(),
            ChatColor.DARK_BLUE.toString(),
            ChatColor.DARK_GREEN.toString(),
            ChatColor.DARK_AQUA.toString(),
            ChatColor.DARK_RED.toString(),
            ChatColor.DARK_PURPLE.toString(),
            ChatColor.GOLD.toString(),
            ChatColor.GRAY.toString(),
            ChatColor.DARK_GRAY.toString(),
            ChatColor.BLUE.toString(),
            ChatColor.GREEN.toString(),
            ChatColor.AQUA.toString(),
            ChatColor.RED.toString(),
            ChatColor.LIGHT_PURPLE.toString(),
            ChatColor.YELLOW.toString()
    };
    private final PrisonsCore plugin;
    private final PlayerLevelService levelService;
    private final PlayerDataService playerDataService;
    private final PickaxeManager pickaxeManager;
    private final EconomyService economyService;
    private final GuardService guardService;
    private final MeteorService meteorService;
    private final AlienInvasionService alienInvasionService;
    private final Map<UUID, PlayerBoardState> boards = new HashMap<UUID, PlayerBoardState>();
    private final Set<UUID> forcedMiningSidebar = new HashSet<UUID>();
    private final Map<UUID, Long> fistMiningUntil = new HashMap<UUID, Long>();
    private Method placeholderApiMethod;
    private boolean placeholderApiLookupAttempted;
    private ScoreboardLayout defaultLayout;
    private ScoreboardLayout pickaxeLayout;
    private ScoreboardLayout invasionLayout;
    private BukkitTask task;
    private String prisonWorldName = "world";
    private long fistMiningHoldMillis = 1500L;

    public MiningLevelScoreboardService(PrisonsCore plugin, PlayerLevelService levelService, PlayerDataService playerDataService, PickaxeManager pickaxeManager, EconomyService economyService, GuardService guardService, MeteorService meteorService, AlienInvasionService alienInvasionService) {
        this.plugin = plugin;
        this.levelService = levelService;
        this.playerDataService = playerDataService;
        this.pickaxeManager = pickaxeManager;
        this.economyService = economyService;
        this.guardService = guardService;
        this.meteorService = meteorService;
        this.alienInvasionService = alienInvasionService;
    }

    public void start() {
        this.reload();
        if (this.task != null) {
            this.task.cancel();
        }
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::refreshAll, 20L, 20L);
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
        Scoreboard main = this.mainScoreboard();
        for (Player player : Bukkit.getOnlinePlayers()) {
            PlayerBoardState state = this.boards.remove(player.getUniqueId());
            if (state != null && player.getScoreboard() == state.board && main != null) {
                player.setScoreboard(main);
            }
        }
        this.boards.clear();
    }

    public void reload() {
        this.prisonWorldName = this.plugin.getConfig().getString("mining-scoreboard.prison-world", "prisons");
        this.fistMiningHoldMillis = Math.max(250L, this.plugin.getConfig().getLong("mining-scoreboard.fist-mining-hold-ms", 1500L));
        this.defaultLayout = this.loadLayout(DEFAULT_LAYOUT_FILE, "&6&lPrisons", List.of(
                "&7%player_name%",
                "",
                "&fLevel: &e%prisons_level%",
                "&fBalance: &a%prisons_balance_formatted%",
                "",
                "&6&lPrison Coins",
                " &f%prisoncoinsbalance%",
                "",
                "&eplay.example.net"
        ));
        this.pickaxeLayout = this.loadLayout(PICKAXE_LAYOUT_FILE, "&b&lMining", List.of(
                "&7%player_name%",
                "",
                "&fLevel: &e%prisons_level%",
                "&fExp: &b%prisons_exp%&7/&3%prisons_exp_needed%",
                "&fBalance: &a%prisons_balance_formatted%",
                "",
                "&bPickaxe Equipped"
        ));
        this.invasionLayout = new ScoreboardLayout("&a&lInvasion Zone", List.of(
                "&f%alien_zone_tier%",
                "",
                "&2&lAlien Level",
                "&f%alien_level%",
                "",
                "&e&lProgress",
                "&f%alien_kills_left% &7to Level &f%alien_next_level%"
        ));
        this.refreshAll();
    }

    public void update(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        if (this.plugin.getPrisonRiotService() != null && this.plugin.getPrisonRiotService().isRiotWorld(player.getWorld())) {
            return;
        }
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) {
            return;
        }
        boolean invasionZone = this.isInvasionZone(player);
        String layoutKey = invasionZone ? "invasion" : (this.isHoldingPrisonPickaxe(player) ? PICKAXE_LAYOUT_KEY : DEFAULT_LAYOUT_KEY);
        ScoreboardLayout layout = invasionZone ? this.invasionLayout : (PICKAXE_LAYOUT_KEY.equals(layoutKey) ? this.pickaxeLayout : this.defaultLayout);
        if (layout == null) {
            return;
        }
        PlayerBoardState state = this.boards.get(player.getUniqueId());
        if (state == null || !layoutKey.equals(state.layoutKey)) {
            state = this.createBoardState(layoutKey, layout.title);
            this.boards.put(player.getUniqueId(), state);
        }
        this.render(state, player, layout);
    }

    public void updateLater(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        Bukkit.getScheduler().runTask(this.plugin, () -> this.update(player));
    }

    public void setForcedMiningSidebar(Player player, boolean forced) {
        if (player == null) {
            return;
        }
        if (forced) {
            this.forcedMiningSidebar.add(player.getUniqueId());
        } else {
            this.forcedMiningSidebar.remove(player.getUniqueId());
        }
        this.updateLater(player);
    }

    public void markFistMining(Player player) {
        if (player == null || player.getWorld() == null || !player.getWorld().getName().equalsIgnoreCase(this.prisonWorldName)) {
            return;
        }
        this.fistMiningUntil.put(player.getUniqueId(), System.currentTimeMillis() + this.fistMiningHoldMillis);
        this.updateLater(player);
    }

    public void remove(Player player) {
        if (player == null) {
            return;
        }
        this.forcedMiningSidebar.remove(player.getUniqueId());
        this.fistMiningUntil.remove(player.getUniqueId());
        PlayerBoardState state = this.boards.remove(player.getUniqueId());
        Scoreboard main = this.mainScoreboard();
        if (state != null && player.getScoreboard() == state.board && main != null) {
            player.setScoreboard(main);
        }
    }

    private void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.update(player);
        }
    }

    private PlayerBoardState createBoardState(String layoutKey, String title) {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) {
            throw new IllegalStateException("Scoreboard manager not available");
        }
        Scoreboard board = manager.getNewScoreboard();
        Objective objective = board.registerNewObjective(SIDEBAR_OBJECTIVE_NAME, "dummy", Text.color(title));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);
        Objective healthObjective = board.getObjective(HEALTH_OBJECTIVE_NAME);
        if (healthObjective != null) {
            healthObjective.unregister();
        }
        healthObjective = board.registerNewObjective(HEALTH_OBJECTIVE_NAME, "dummy", Text.color("&c❤"));
        healthObjective.setDisplaySlot(DisplaySlot.BELOW_NAME);
        return new PlayerBoardState(layoutKey, board, objective, healthObjective, 0);
    }

    private void render(PlayerBoardState state, Player player, ScoreboardLayout layout) {
        this.syncNameTags(state.board);
        this.syncHealthScores(state.board, state.healthObjective);
        state.objective.setDisplayName(Text.color(this.resolve(player, layout.title)));
        List<String> renderedLines = new ArrayList<String>();
        for (String line : layout.lines) {
            renderedLines.add(Text.color(this.resolve(player, line)));
            if (renderedLines.size() >= ENTRY_KEYS.length) {
                break;
            }
        }
        for (int i = 0; i < renderedLines.size(); ++i) {
            String entry = ENTRY_KEYS[i];
            Team team = state.board.getTeam("ln" + i);
            if (team == null) {
                team = state.board.registerNewTeam("ln" + i);
            }
            if (!team.hasEntry(entry)) {
                team.addEntry(entry);
            }
            team.setPrefix(this.clamp(renderedLines.get(i)));
            state.objective.getScore(entry).setScore(renderedLines.size() - i);
        }
        for (int i = renderedLines.size(); i < state.lineCount; ++i) {
            String entry = ENTRY_KEYS[i];
            Team team = state.board.getTeam("ln" + i);
            if (team != null) {
                team.unregister();
            }
            state.board.resetScores(entry);
        }
        state.lineCount = renderedLines.size();
        if (player.getScoreboard() != state.board) {
            player.setScoreboard(state.board);
        }
    }

    private ScoreboardLayout loadLayout(String fileName, String defaultTitle, List<String> defaultLines) {
        File file = new File(this.plugin.getDataFolder(), fileName);
        if (!file.exists()) {
            this.plugin.saveResource(fileName, false);
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration((File)file);
        String title = config.getString("title", defaultTitle);
        List<String> lines = config.getStringList("lines");
        if (lines == null || lines.isEmpty()) {
            lines = new ArrayList<String>(defaultLines);
        }
        return new ScoreboardLayout(title, lines);
    }

    private String resolve(Player player, String input) {
        String resolved = input == null ? "" : input;
        ItemStack heldPickaxe = this.getHeldPrisonPickaxe(player);
        int currentLevel = this.levelService.getLevel(player);
        int expNeeded = this.levelService.expNeededForNext(player);
        int currentExp = this.levelService.getExp(player);
        double expPercent = expNeeded <= 0 ? 100.0 : Math.min(100.0, (double)currentExp * 100.0 / (double)expNeeded);
        resolved = resolved.replace("%player_name%", player.getName());
        resolved = resolved.replace("%player_world%", player.getWorld().getName());
        resolved = resolved.replace("%prisons_level%", String.valueOf(currentLevel));
        resolved = resolved.replace("%prisons_next_level%", String.valueOf(expNeeded > 0 ? currentLevel + 1 : currentLevel));
        resolved = resolved.replace("%prisons_exp%", Text.formatNumber(currentExp));
        resolved = resolved.replace("%prisons_total_exp%", Text.formatNumber(this.levelService.getTotalExp(player)));
        resolved = resolved.replace("%prisons_exp_needed%", Text.formatNumber(expNeeded));
        resolved = resolved.replace("%prisons_exp_remaining%", Text.formatNumber(Math.max(0, expNeeded - currentExp)));
        resolved = resolved.replace("%prisons_exp_percent%", Text.formatPercent(expPercent));
        resolved = resolved.replace("%prisons_balance%", String.valueOf(this.economyService.getBalance(player)));
        resolved = resolved.replace("%prisons_balance_formatted%", this.economyService.format(this.economyService.getBalance(player)));
        resolved = resolved.replace("%prisoncoinsbalance%", String.valueOf(this.plugin.getPrisonCoinService() != null ? this.plugin.getPrisonCoinService().getBalance(player) : 0L));
        resolved = resolved.replace("%prisons_has_pickaxe%", heldPickaxe != null ? "yes" : "no");
        resolved = resolved.replace("%prisons_pickaxe_level%", String.valueOf(heldPickaxe != null ? this.pickaxeManager.getLevel(heldPickaxe) : 0));
        resolved = resolved.replace("%prisons_pickaxe_charge%", heldPickaxe != null ? Text.formatNumber(this.pickaxeManager.getEnergy(heldPickaxe)) : "0");
        resolved = resolved.replace("%prisons_pickaxe_max_charge%", this.formatHeldPickaxeMaxCharge(heldPickaxe));
        resolved = resolved.replace("%prisons_pickaxe_charge_display%", this.formatHeldPickaxeCharge(heldPickaxe));
        resolved = resolved.replace("%prisons_pickaxe_charge_percent%", this.formatHeldPickaxeChargePercent(heldPickaxe));
        resolved = resolved.replace("%prisons_guard_tax_percent%", this.formatGuardTaxPercent(player));
        resolved = resolved.replace("%prisons_meteor_time%", this.formatMeteorTime());
        resolved = resolved.replace("%alien_zone_tier%", this.resolveAlienZoneTier(player));
        resolved = resolved.replace("%alien_level%", String.valueOf(this.getAlienLevel(player)));
        resolved = resolved.replace("%alien_next_level%", String.valueOf(this.getAlienLevel(player) + 1));
        resolved = resolved.replace("%alien_kills_left%", String.valueOf(this.getAlienKillsLeft(player)));
        return this.applyPlaceholderApi(player, resolved);
    }

    private boolean isInvasionZone(Player player) {
        return this.alienInvasionService != null && player != null && this.alienInvasionService.getZoneAt(player.getLocation()) != null;
    }

    private String resolveAlienZoneTier(Player player) {
        if (this.alienInvasionService == null || player == null) {
            return "&fUnknown";
        }
        AlienInvasionService.InvasionZone zone = this.alienInvasionService.getZoneAt(player.getLocation());
        if (zone == null) {
            return "&fUnknown";
        }
        String tier = zone.tierId() == null ? "Iron" : zone.tierId().trim();
        if (tier.isEmpty()) {
            tier = "Iron";
        }
        return "&f" + tier.substring(0, 1).toUpperCase(java.util.Locale.ROOT) + tier.substring(1).toLowerCase(java.util.Locale.ROOT);
    }

    private int getAlienLevel(Player player) {
        if (this.playerDataService == null || player == null) {
            return 1;
        }
        return Math.max(1, this.playerDataService.get(player.getUniqueId()).getAlienLevel());
    }

    private int getAlienKillsLeft(Player player) {
        if (player == null || this.playerDataService == null) {
            return 0;
        }
        int level = this.getAlienLevel(player);
        PlayerDataService.PlayerData data = this.playerDataService.get(player.getUniqueId());
        int required = this.alienKillsForLevel(level);
        return Math.max(0, required - Math.max(0, data.getAlienProgress()));
    }

    private int alienKillsForLevel(int level) {
        int safeLevel = Math.max(1, level);
        return 15 + (safeLevel * 3);
    }

    private boolean isHoldingPrisonPickaxe(Player player) {
        return this.forcedMiningSidebar.contains(player.getUniqueId()) || this.isFistMiningActive(player) || this.getHeldPrisonPickaxe(player) != null;
    }

    private boolean isFistMiningActive(Player player) {
        if (player == null || player.getWorld() == null || !player.getWorld().getName().equalsIgnoreCase(this.prisonWorldName)) {
            return false;
        }
        Long until = this.fistMiningUntil.get(player.getUniqueId());
        if (until == null) {
            return false;
        }
        if (until < System.currentTimeMillis()) {
            this.fistMiningUntil.remove(player.getUniqueId());
            return false;
        }
        ItemStack held = player.getInventory().getItemInMainHand();
        return held == null || held.getType().isAir();
    }

    private ItemStack getHeldPrisonPickaxe(Player player) {
        ItemStack heldItem = player.getInventory().getItemInMainHand();
        return this.pickaxeManager.isPrisonPickaxe(heldItem) ? heldItem : null;
    }

    private String formatHeldPickaxeCharge(ItemStack heldPickaxe) {
        if (heldPickaxe == null) {
            return "0/0";
        }
        return Text.formatNumber(this.pickaxeManager.getEnergy(heldPickaxe)) + "/" + this.formatHeldPickaxeMaxCharge(heldPickaxe);
    }

    private String formatHeldPickaxeMaxCharge(ItemStack heldPickaxe) {
        if (heldPickaxe == null) {
            return "0";
        }
        if (this.pickaxeManager.getLevel(heldPickaxe) >= this.pickaxeManager.getMaxLevel()) {
            return "MAX";
        }
        return Text.formatNumber(this.pickaxeManager.getMaxEnergy(heldPickaxe));
    }

    private String formatHeldPickaxeChargePercent(ItemStack heldPickaxe) {
        if (heldPickaxe == null) {
            return "0%";
        }
        int maxCharge = this.pickaxeManager.getMaxEnergy(heldPickaxe);
        if (maxCharge <= 0) {
            return "0%";
        }
        double percent = (double)this.pickaxeManager.getEnergy(heldPickaxe) * 100.0 / (double)maxCharge;
        return String.format("%.1f%%", percent);
    }

    private String formatGuardTaxPercent(Player player) {
        if (this.guardService == null) {
            return "0.0%";
        }
        double maxDistance = GuardService.GUARD_PROTECTION_RANGE;
        double maxTax = 0.2;
        double nearest = this.guardService.nearestGuardDistance(player.getLocation(), maxDistance);
        if (nearest < 0.0) {
            return "0.0%";
        }
        double taxFraction = (maxDistance - nearest) / maxDistance * maxTax;
        return String.format("%.1f%%", taxFraction * 100.0);
    }

    private String formatMeteorTime() {
        if (this.meteorService == null) {
            return "tracking";
        }
        String text = this.meteorService.getNextMeteorTimeText();
        if (text == null || text.isBlank()) {
            return "tracking";
        }
        return text.replace("&f", "").replace("&c", "");
    }

    private String clamp(String input) {
        if (input == null) {
            return "";
        }
        return input.length() > 64 ? input.substring(0, 64) : input;
    }

    private String applyPlaceholderApi(Player player, String input) {
        if (!Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            return input;
        }
        try {
            if (!this.placeholderApiLookupAttempted) {
                Class<?> placeholderApiClass = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
                this.placeholderApiMethod = placeholderApiClass.getMethod("setPlaceholders", Player.class, String.class);
                this.placeholderApiLookupAttempted = true;
            }
            if (this.placeholderApiMethod == null) {
                return input;
            }
            Object result = this.placeholderApiMethod.invoke(null, player, input);
            return result instanceof String ? (String)result : input;
        }
        catch (ReflectiveOperationException ignored) {
            this.placeholderApiLookupAttempted = true;
            this.placeholderApiMethod = null;
            return input;
        }
    }

    private Scoreboard mainScoreboard() {
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        return manager == null ? null : manager.getMainScoreboard();
    }

    private void syncNameTags(Scoreboard board) {
        Set<String> activeTeams = new HashSet<String>();
        Set<String> activePlayerNames = new HashSet<String>();
        for (Player target : Bukkit.getOnlinePlayers()) {
            activePlayerNames.add(target.getName());
            String teamName = this.teamName(target.getUniqueId());
            if (this.applyNameTag(board, target)) {
                activeTeams.add(teamName);
            }
        }
        for (Team team : new ArrayList<Team>(board.getTeams())) {
            if (team.getName().startsWith(TEAM_PREFIX) && !activeTeams.contains(team.getName())) {
                team.unregister();
            }
        }
        this.pruneStaleNameTags(board, activePlayerNames, false);
        
        // Also sync to main scoreboard for players not using this service's boards
        Scoreboard main = this.mainScoreboard();
        if (main != null && main != board) {
            for (Player target : Bukkit.getOnlinePlayers()) {
                this.applyNameTag(main, target);
            }
            this.pruneStaleNameTags(main, activePlayerNames, true);
        }
    }

    private void pruneStaleNameTags(Scoreboard board, Set<String> activePlayerNames, boolean unregisterEmptyTeams) {
        if (board == null) {
            return;
        }
        Objective healthObjective = board.getObjective(HEALTH_OBJECTIVE_NAME);
        for (Team team : new ArrayList<Team>(board.getTeams())) {
            if (!team.getName().startsWith(TEAM_PREFIX)) {
                continue;
            }
            for (String entry : new HashSet<String>(team.getEntries())) {
                if (activePlayerNames.contains(entry)) {
                    continue;
                }
                team.removeEntry(entry);
                if (healthObjective != null) {
                    healthObjective.getScore(entry).resetScore();
                }
            }
            if (unregisterEmptyTeams && team.getEntries().isEmpty()) {
                team.unregister();
            }
        }
    }

    private boolean applyNameTag(Scoreboard board, Player target) {
        if (board == null || target == null) {
            return false;
        }
        String entry = target.getName();
        String teamName = this.teamName(target.getUniqueId());
        Team team = board.getTeam(teamName);
        if (team == null) {
            team = board.registerNewTeam(teamName);
        }
        if (!team.hasEntry(entry)) {
            team.addEntry(entry);
        }
        team.setPrefix(Text.color(this.prefixFor(target)));
        team.setColor(ChatColor.WHITE);
        team.setSuffix(Text.color(" " + this.formatLevel(this.levelService.getLevel(target))));
        return true;
    }

    private String prefixFor(Player player) {
        String group = this.resolvePrimaryGroup(player);
        if (group == null) {
            if (player.hasPermission("prisons.admin")) {
                group = "admin";
            } else if (player.hasPermission("prisons.dev")) {
                group = "dev";
            } else if (player.hasPermission("group.vanguard") || player.hasPermission("luckperms.group.vanguard")) {
                group = "vanguard";
            } else {
                group = "alpha";
            }
        }
        if ("admin".equalsIgnoreCase(group)) {
            return "&4Admin ";
        }
        if ("dev".equalsIgnoreCase(group)) {
            return "&4Dev ";
        }
        if ("vanguard".equalsIgnoreCase(group)) {
            return "&eVanguard ";
        }
        return "&3Alpha ";
    }

    private String resolvePrimaryGroup(Player player) {
        if (player == null) {
            return null;
        }
        try {
            Class<?> providerClass = Class.forName("net.luckperms.api.LuckPermsProvider");
            Object luckPerms = providerClass.getMethod("get").invoke(null);
            if (luckPerms == null) {
                return null;
            }
            Object userManager = luckPerms.getClass().getMethod("getUserManager").invoke(luckPerms);
            Object user = userManager.getClass().getMethod("getUser", UUID.class).invoke(userManager, player.getUniqueId());
            if (user == null) {
                return null;
            }
            Object group = user.getClass().getMethod("getPrimaryGroup").invoke(user);
            return group instanceof String ? (String)group : null;
        }
        catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
    }

    private void syncHealthScores(Scoreboard board, Objective healthObjective) {
        if (board == null || healthObjective == null) {
            return;
        }
        for (Player target : Bukkit.getOnlinePlayers()) {
            String entry = target.getName();
            healthObjective.getScore(entry).setScore((int)Math.ceil(Math.max(0.0, target.getHealth())));
        }
    }

    private String formatLevel(int lvl) {
        if (lvl < 20) {
            return "&8[&7" + lvl + "&8]";
        }
        if (lvl < 40) {
            return "&8[&9" + lvl + "&8]";
        }
        if (lvl < 60) {
            return "&8[&b" + lvl + "&8]";
        }
        if (lvl < 80) {
            return "&8[&e" + lvl + "&8]";
        }
        if (lvl < 100) {
            return "&8[&6" + lvl + "&8]";
        }
        return "&8[&c" + lvl + "&8]";
    }

    private String teamName(UUID uuid) {
        return (TEAM_PREFIX + uuid.toString().replace("-", "")).substring(0, 15);
    }

    private static class PlayerBoardState {
        private final String layoutKey;
        private final Scoreboard board;
        private final Objective objective;
        private final Objective healthObjective;
        private int lineCount;

        private PlayerBoardState(String layoutKey, Scoreboard board, Objective objective, Objective healthObjective, int lineCount) {
            this.layoutKey = layoutKey;
            this.board = board;
            this.objective = objective;
            this.healthObjective = healthObjective;
            this.lineCount = lineCount;
        }
    }

    private static class ScoreboardLayout {
        private final String title;
        private final List<String> lines;

        private ScoreboardLayout(String title, List<String> lines) {
            this.title = title;
            this.lines = lines;
        }
    }
}
