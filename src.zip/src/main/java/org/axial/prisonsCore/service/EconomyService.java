/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.milkbowl.vault.economy.Economy
 *  net.milkbowl.vault.economy.EconomyResponse
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.RegisteredServiceProvider
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.RegisteredServiceProvider;

public class EconomyService {
    private final PrisonsCore plugin;
    private Economy economy;
    private boolean usingVault = false;
    private boolean ready = false;
    private double defaultBalance = 0.0;
    private File worthFile;
    private YamlConfiguration worthConfig;
    private Map<Material, Double> worthMap = new HashMap<Material, Double>();
    private File balancesFile;
    private YamlConfiguration balancesConfig;
    private final NumberFormat commaFormat = new DecimalFormat("#,###.##");

    public EconomyService(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public boolean setup() {
        this.usingVault = this.setupVault();
        if (this.usingVault && this.economy != null) {
            this.plugin.getLogger().info("Hooked economy provider: " + this.economy.getName());
        } else {
            this.plugin.getLogger().warning("Vault economy provider not found. Using internal balances.");
        }
        this.loadWorth();
        this.loadConfig();
        this.loadBalances();
        this.ready = true;
        return true;
    }

    private boolean setupVault() {
        if (this.plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider rsp = this.plugin.getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        this.economy = (Economy)rsp.getProvider();
        return this.economy != null;
    }

    public void reload() {
        this.loadWorth();
        this.loadBalances();
    }

    private void loadWorth() {
        this.worthFile = new File(this.plugin.getDataFolder(), "worth.yml");
        if (!this.worthFile.exists()) {
            this.plugin.saveResource("worth.yml", false);
        }
        this.worthConfig = YamlConfiguration.loadConfiguration((File)this.worthFile);
        this.worthMap.clear();
        ConfigurationSection section = this.worthConfig.getConfigurationSection("worth");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Material mat = Material.matchMaterial((String)key);
                if (mat == null) continue;
                this.worthMap.put(mat, section.getDouble(key, -1.0));
            }
        }
    }

    private void loadBalances() {
        this.balancesFile = new File(this.plugin.getDataFolder(), "economyplayers.yml");
        if (!this.balancesFile.exists()) {
            try {
                this.balancesFile.getParentFile().mkdirs();
                this.balancesFile.createNewFile();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        this.balancesConfig = YamlConfiguration.loadConfiguration((File)this.balancesFile);
    }

    public void saveBalances() {
        try {
            this.balancesConfig.save(this.balancesFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save economyplayers.yml: " + e.getMessage());
        }
    }

    public boolean isReady() {
        return this.ready;
    }

    public boolean isUsingVault() {
        return this.usingVault;
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "economy.yml");
        if (!file.exists()) {
            this.plugin.saveResource("economy.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        this.defaultBalance = cfg.getDouble("default-balance", 0.0);
    }

    public double getWorth(Material material) {
        if (material == null) {
            return -1.0;
        }
        double base = this.worthMap.getOrDefault(material, -1.0);
        if (base < 0.0 || this.plugin.getSeasonService() == null) {
            return base;
        }
        return this.plugin.getSeasonService().scalePriceForCurrentDay(base);
    }

    public double getWorth(Material material, int day) {
        if (material == null) {
            return -1.0;
        }
        double base = this.worthMap.getOrDefault(material, -1.0);
        if (base < 0.0 || this.plugin.getSeasonService() == null) {
            return base;
        }
        return this.plugin.getSeasonService().scalePriceForDay(base, day);
    }

    public double getBaseWorth(Material material) {
        if (material == null) {
            return -1.0;
        }
        return this.worthMap.getOrDefault(material, -1.0);
    }

    public void setWorth(Material material, double price) {
        if (material == null) {
            return;
        }
        this.worthMap.put(material, price);
        this.worthConfig.set("worth." + material.name(), (Object)price);
        try {
            this.worthConfig.save(this.worthFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save worth.yml: " + e.getMessage());
        }
    }

    public boolean deposit(Player player, double amount) {
        if (!this.ready || player == null || amount <= 0.0) {
            return false;
        }
        return this.deposit((OfflinePlayer)player, amount);
    }

    public boolean withdraw(Player player, double amount) {
        if (!this.ready || player == null || amount <= 0.0) {
            return false;
        }
        return this.withdraw((OfflinePlayer)player, amount);
    }

    public boolean deposit(OfflinePlayer player, double amount) {
        if (!this.ready || player == null || amount <= 0.0) {
            return false;
        }
        if (this.usingVault) {
            EconomyResponse response = this.economy.depositPlayer(player, amount);
            if (response == null || !response.transactionSuccess()) {
                return false;
            }
            if (player.isOnline() && player.getPlayer() != null) {
                this.cacheBalance(player.getPlayer(), this.economy.getBalance(player));
            }
            return true;
        }
        UUID id = player.getUniqueId();
        double bal = this.balancesConfig.getDouble(id.toString(), 0.0);
        this.balancesConfig.set(id.toString(), (Object)(bal + amount));
        this.saveBalances();
        return true;
    }

    public boolean withdraw(OfflinePlayer player, double amount) {
        if (!this.ready || player == null || amount <= 0.0) {
            return false;
        }
        if (this.usingVault) {
            EconomyResponse response = this.economy.withdrawPlayer(player, amount);
            if (response == null || !response.transactionSuccess()) {
                return false;
            }
            if (player.isOnline() && player.getPlayer() != null) {
                this.cacheBalance(player.getPlayer(), this.economy.getBalance(player));
            }
            return true;
        }
        UUID id = player.getUniqueId();
        double bal = this.balancesConfig.getDouble(id.toString(), 0.0);
        if (bal < amount) {
            return false;
        }
        this.balancesConfig.set(id.toString(), (Object)(bal - amount));
        this.saveBalances();
        return true;
    }

    public double getBalance(Player player) {
        if (!this.ready || player == null) {
            return 0.0;
        }
        if (this.usingVault) {
            return this.getBalance((OfflinePlayer)player);
        }
        return this.balancesConfig.getDouble(player.getUniqueId().toString(), 0.0);
    }

    public double getBalance(OfflinePlayer player) {
        if (!this.ready || player == null) {
            return 0.0;
        }
        if (this.usingVault) {
            double bal = this.economy.getBalance(player);
            if (player.isOnline() && player.getPlayer() != null) {
                this.cacheBalance(player.getPlayer(), bal);
            }
            return bal;
        }
        UUID id = player.getUniqueId();
        return id == null ? 0.0 : this.balancesConfig.getDouble(id.toString(), 0.0);
    }

    public double getBalance(UUID uuid) {
        if (!this.ready || uuid == null) {
            return 0.0;
        }
        double bal = this.balancesConfig.getDouble(uuid.toString(), this.defaultBalance);
        return bal;
    }

    public String format(double amount) {
        return "$" + this.commaFormat.format(amount);
    }

    public Double parseAmount(String input) {
        if (input == null || input.isEmpty()) {
            return null;
        }
        String s = input.replace(",", "").trim().toLowerCase(Locale.ROOT);
        double multiplier = 1.0;
        if (s.endsWith("k")) {
            multiplier = 1000.0;
            s = s.substring(0, s.length() - 1);
        } else if (s.endsWith("m")) {
            multiplier = 1000000.0;
            s = s.substring(0, s.length() - 1);
        } else if (s.endsWith("b")) {
            multiplier = 1.0E9;
            s = s.substring(0, s.length() - 1);
        }
        if (s.isEmpty()) {
            return null;
        }
        try {
            double base = Double.parseDouble(s);
            return base * multiplier;
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    public SellResult sellItemStacks(Player player, Iterable<ItemStack> items) {
        return this.sellItemStacks(player, items, 1.0D);
    }

    public SellResult sellItemStacks(Player player, Iterable<ItemStack> items, double sellMultiplier) {
        double total = 0.0;
        int sold = 0;
        double multiplier = Math.max(0.0D, sellMultiplier);
        for (ItemStack stack : items) {
            double price;
            if (stack == null || stack.getType() == Material.AIR || (price = this.getWorth(stack.getType())) <= 0.0) continue;
            int amount = stack.getAmount();
            total += price * (double)amount;
            sold += amount;
            stack.setAmount(0);
        }
        if (total > 0.0) {
            total = this.applySellBoost(player, total * multiplier);
            this.deposit(player, total);
        }
        return new SellResult(total, sold);
    }

    public double estimateSellValue(Iterable<ItemStack> items) {
        double total = 0.0;
        if (items == null) {
            return 0.0;
        }
        for (ItemStack stack : items) {
            double price;
            if (stack == null || stack.getType() == Material.AIR || (price = this.getWorth(stack.getType())) <= 0.0) continue;
            total += price * (double)stack.getAmount();
        }
        return total;
    }

    public double applySellBoost(double base) {
        if (base <= 0.0) {
            return base;
        }
        if (this.plugin.getGlobalBoosterService() == null) {
            return base;
        }
        return base * this.plugin.getGlobalBoosterService().getSellMultiplier();
    }

    public double applySellBoost(Player player, double base) {
        double total = this.applySellBoost(base);
        if (total <= 0.0) {
            return total;
        }
        if (this.plugin.getCustomBlockBuffService() == null) {
            return total;
        }
        return this.plugin.getCustomBlockBuffService().applyBeachBallSellBonus(player, total);
    }

    public double applyPurchaseDiscount(Player player, double base) {
        if (base <= 0.0) {
            return base;
        }
        if (this.plugin.getCustomBlockBuffService() == null) {
            return base;
        }
        return this.plugin.getCustomBlockBuffService().applyBeachBallBuyDiscount(player, base);
    }

    public List<TopEntry> getTopBalances(int limit) {
        ArrayList<TopEntry> list = new ArrayList<TopEntry>();
        for (String key : this.balancesConfig.getKeys(false)) {
            double bal = this.balancesConfig.getDouble(key, 0.0);
            try {
                UUID id = UUID.fromString(key);
                list.add(new TopEntry(id, bal));
            }
            catch (IllegalArgumentException illegalArgumentException) {}
        }
        list.sort((a, b) -> Double.compare(b.balance(), a.balance()));
        if (limit > 0 && list.size() > limit) {
            return list.subList(0, limit);
        }
        return list;
    }

    private void cacheBalance(Player player, double balance) {
        if (player == null) {
            return;
        }
        this.balancesConfig.set(player.getUniqueId().toString(), (Object)balance);
        this.saveBalances();
    }

    public void setBalance(UUID uuid, double amount) {
        if (uuid == null) {
            return;
        }
        this.balancesConfig.set(uuid.toString(), (Object)Math.max(0.0, amount));
        this.saveBalances();
    }

    public double getDefaultBalance() {
        return this.defaultBalance;
    }

    public record SellResult(double total, int itemsSold) {
    }

    public record TopEntry(UUID playerId, double balance) {
    }
}
