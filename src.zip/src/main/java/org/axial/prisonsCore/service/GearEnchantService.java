/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.model.EnchantRarity;
import org.axial.prisonsCore.util.ConfigUpdater;
import org.axial.prisonsCore.util.Text;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class GearEnchantService {
    private final PrisonsCore plugin;
    private final List<CustomEnchant> enchants = new ArrayList<CustomEnchant>();
    private final Random random = new Random();
    private final NamespacedKey orbIdKey;
    private final NamespacedKey orbLevelKey;
    private final NamespacedKey orbPercentKey;

    public GearEnchantService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.orbIdKey = new NamespacedKey((Plugin)plugin, "gear-enchant-orb-id");
        this.orbLevelKey = new NamespacedKey((Plugin)plugin, "gear-enchant-orb-level");
        this.orbPercentKey = new NamespacedKey((Plugin)plugin, "gear-enchant-orb-percent");
        this.load();
    }

    public List<CustomEnchant> getAll() {
        return Collections.unmodifiableList(this.enchants);
    }

    public CustomEnchant getById(String id) {
        return this.enchants.stream().filter(e -> e.getId().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    public List<CustomEnchant> pickRandomOptions(int amount) {
        return this.pickRandomOptions(amount, this.enchants);
    }

    public List<CustomEnchant> pickRandomOptions(int amount, List<CustomEnchant> pool) {
        ArrayList<CustomEnchant> shuffled = new ArrayList<CustomEnchant>(pool);
        Collections.shuffle(shuffled, this.random);
        return shuffled.stream().limit(amount).collect(Collectors.toList());
    }

    public ItemStack createOptionItem(CustomEnchant enchant, int level, int successChance) {
        ItemStack item = new ItemStack(enchant.getRarity().getDisplayMaterial());
        ItemMeta meta = item.getItemMeta();
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setDisplayName(Text.color(enchant.getDisplayNameForLevel(level)));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(Text.color("&7" + enchant.getDescription()));
        int success = Math.max(0, Math.min(100, successChance));
        int fail = Math.max(0, 100 - success);
        lore.add(Text.color("&aSuccess: " + success + "%"));
        lore.add(Text.color("&cFail: " + fail + "%"));
        lore.add(Text.color("&7Rarity: " + enchant.getRarity().name()));
        lore.add(Text.color("&7Click to apply"));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack createOrb(String enchantId, int level, int percent) {
        CustomEnchant enchant = this.getById(enchantId);
        if (enchant == null) {
            return null;
        }
        ItemStack item = new ItemStack(enchant.getRarity().getOrbMaterial());
        ItemMeta meta = item.getItemMeta();
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setDisplayName(Text.color(enchant.getDisplayNameForLevel(level)));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(Text.color("&7" + enchant.getDescription()));
        lore.add(" ");
        int success = Math.max(0, Math.min(100, percent));
        int fail = Math.max(0, 100 - success);
        lore.add(Text.color("&aSuccess: " + success + "%"));
        lore.add(Text.color("&cFail: " + fail + "%"));
        lore.add(" ");
        lore.add(Text.color("&7Drag and Drop onto gear to enchant"));
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(this.orbIdKey, PersistentDataType.STRING, enchant.getId());
        meta.getPersistentDataContainer().set(this.orbLevelKey, PersistentDataType.INTEGER, level);
        meta.getPersistentDataContainer().set(this.orbPercentKey, PersistentDataType.INTEGER, percent);
        item.setItemMeta(meta);
        return item;
    }

    public int rollSuccess(int chancePercent) {
        int c = Math.max(0, Math.min(100, chancePercent));
        return this.random.nextInt(100) < c ? 1 : 0;
    }

    public boolean isGearEnchantOrb(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.orbIdKey, PersistentDataType.STRING);
    }

    public String getOrbEnchantId(ItemStack stack) {
        if (!this.isGearEnchantOrb(stack)) {
            return null;
        }
        return stack.getItemMeta().getPersistentDataContainer().get(this.orbIdKey, PersistentDataType.STRING);
    }

    public int getOrbLevel(ItemStack stack) {
        if (!this.isGearEnchantOrb(stack)) {
            return 0;
        }
        Integer level = stack.getItemMeta().getPersistentDataContainer().get(this.orbLevelKey, PersistentDataType.INTEGER);
        return level == null ? 0 : level;
    }

    public int getOrbPercent(ItemStack stack) {
        if (!this.isGearEnchantOrb(stack)) {
            return 0;
        }
        Integer percent = stack.getItemMeta().getPersistentDataContainer().get(this.orbPercentKey, PersistentDataType.INTEGER);
        return percent == null ? 0 : percent;
    }

    private String roman(int number) {
        return switch (number) {
            case 5 -> "V";
            case 4 -> "IV";
            case 3 -> "III";
            case 2 -> "II";
            default -> "I";
        };
    }

    public void reload() {
        this.load();
    }

    private void load() {
        YamlConfiguration cfg;
        ConfigurationSection section;
        this.enchants.clear();
        File file = new File(this.plugin.getDataFolder(), "gear-enchants.yml");
        if (!file.exists()) {
            this.plugin.saveResource("gear-enchants.yml", false);
        } else {
            ConfigUpdater.saveDefaultAndMerge(this.plugin, "gear-enchants.yml");
        }
        if ((section = (cfg = YamlConfiguration.loadConfiguration((File)file)).getConfigurationSection("gear-enchants")) == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection node = section.getConfigurationSection(key);
            if (node == null) continue;
            String name = node.getString("display-name", key);
            String desc = node.getString("description", "");
            int chance = Math.max(1, Math.min(100, node.getInt("success-chance", 50)));
            int maxLevel = Math.max(1, node.getInt("max-level", 1));
            EnchantRarity rarity = EnchantRarity.fromString(node.getString("rarity"), EnchantRarity.RARE);
            List<String> displayLevels = node.getStringList("display-name-levels");
            List<String> applicable = node.getStringList("applicable-to");
            this.enchants.add(new CustomEnchant(key, name, desc, chance, maxLevel, rarity, Collections.emptyList(), displayLevels, Collections.emptyList(), "&d{enchant} {level}", applicable));
        }
    }
}
