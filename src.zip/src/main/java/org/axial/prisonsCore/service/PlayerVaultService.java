package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class PlayerVaultService {
    public static final int VAULT_SIZE = 54;
    private final PrisonsCore plugin;
    private final File file;
    private final int maxVaults;
    private YamlConfiguration cfg;

    public PlayerVaultService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "player-vaults.yml");
        this.maxVaults = Math.max(1, plugin.getConfig().getInt("player-vaults.max-vaults", 10));
        this.load();
    }

    public void load() {
        if (!this.file.exists()) {
            try {
                this.file.getParentFile().mkdirs();
                this.file.createNewFile();
            } catch (IOException e) {
                this.plugin.getLogger().warning("Failed to create player-vaults.yml: " + e.getMessage());
            }
        }
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
    }

    public void save() {
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save player-vaults.yml: " + e.getMessage());
        }
    }

    public int maxVaults() {
        return this.maxVaults;
    }

    public boolean isValidVaultNumber(int vaultNumber) {
        return vaultNumber >= 1 && vaultNumber <= this.maxVaults;
    }

    public int accessibleVaults(Player player) {
        if (player == null) {
            return 0;
        }
        if (player.hasPermission("prisons.pv.unlimited") || player.hasPermission("prisons.pv.amount.*") || player.hasPermission("playervaults.amount.*")) {
            return this.maxVaults;
        }
        int accessible = player.hasPermission("prisons.pv") || player.hasPermission("playervaults") ? 1 : 0;
        for (int i = 1; i <= this.maxVaults; ++i) {
            if (!player.hasPermission("prisons.pv." + i) && !player.hasPermission("prisons.pv.amount." + i) && !player.hasPermission("playervaults.amount." + i)) {
                continue;
            }
            accessible = i;
        }
        return accessible;
    }

    public boolean canAccess(Player player, int vaultNumber) {
        return player != null && this.isValidVaultNumber(vaultNumber) && vaultNumber <= this.accessibleVaults(player);
    }

    public List<Integer> accessibleVaultNumbers(Player player) {
        int accessible = this.accessibleVaults(player);
        List<Integer> numbers = new ArrayList<Integer>();
        for (int i = 1; i <= accessible; ++i) {
            numbers.add(i);
        }
        return numbers;
    }

    public List<Integer> adminVaultNumbers(UUID ownerId, Player onlineOwner) {
        int upperBound = onlineOwner != null ? Math.max(1, this.accessibleVaults(onlineOwner)) : this.maxVaults;
        upperBound = Math.max(upperBound, this.highestStoredVault(ownerId));
        List<Integer> numbers = new ArrayList<Integer>();
        for (int i = 1; i <= upperBound; ++i) {
            numbers.add(i);
        }
        return numbers;
    }

    public ItemStack[] loadVault(UUID ownerId, int vaultNumber) {
        ItemStack[] contents = new ItemStack[VAULT_SIZE];
        if (ownerId == null || !this.isValidVaultNumber(vaultNumber)) {
            return contents;
        }
        String base = this.path(ownerId, vaultNumber);
        for (int slot = 0; slot < VAULT_SIZE; ++slot) {
            ItemStack item = this.cfg.getItemStack(base + "." + slot);
            contents[slot] = item == null ? null : item.clone();
        }
        return contents;
    }

    public void saveVault(UUID ownerId, int vaultNumber, ItemStack[] contents) {
        if (ownerId == null || !this.isValidVaultNumber(vaultNumber)) {
            return;
        }
        String base = this.path(ownerId, vaultNumber);
        this.cfg.set(base, null);
        if (contents != null) {
            int limit = Math.min(contents.length, VAULT_SIZE);
            for (int slot = 0; slot < limit; ++slot) {
                ItemStack item = contents[slot];
                if (item == null || item.getType().isAir()) {
                    continue;
                }
                this.cfg.set(base + "." + slot, item.clone());
            }
        }
        this.save();
    }

    public boolean hasAnyVaultData(UUID ownerId) {
        return ownerId != null && this.cfg.isConfigurationSection("vaults." + ownerId);
    }

    public boolean hasVaultData(UUID ownerId, int vaultNumber) {
        return ownerId != null && this.cfg.isConfigurationSection(this.path(ownerId, vaultNumber));
    }

    private int highestStoredVault(UUID ownerId) {
        if (ownerId == null) {
            return 0;
        }
        ConfigurationSection section = this.cfg.getConfigurationSection("vaults." + ownerId);
        if (section == null) {
            return 0;
        }
        return section.getKeys(false).stream().map(key -> {
            try {
                return Integer.parseInt(key);
            } catch (NumberFormatException e) {
                return 0;
            }
        }).max(Comparator.naturalOrder()).orElse(0);
    }

    private String path(UUID ownerId, int vaultNumber) {
        return "vaults." + ownerId + "." + vaultNumber;
    }

    public boolean isAdmin(CommandSender sender) {
        return sender != null && (sender.hasPermission("prisons.pv.admin") || sender.isOp());
    }

    public String formatVaultName(int vaultNumber) {
        return "PV " + vaultNumber;
    }

    public String normalizeLookup(String input) {
        return input == null ? "" : input.toLowerCase(Locale.ROOT);
    }
}
