/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package org.axial.prisonsCore.service;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public class ReputationService {
    private final PrisonsCore plugin;
    private final GuardService guardService;
    private final Map<UUID, Stage> stages = new ConcurrentHashMap<UUID, Stage>();
    private final Map<UUID, Long> lastChange = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, UUID> guardFollowers = new ConcurrentHashMap<UUID, UUID>();
    private BukkitTask decayTask;

    public ReputationService(PrisonsCore plugin, GuardService guardService) {
        this.plugin = plugin;
        this.guardService = guardService;
        this.startDecayTask();
    }

    private void startDecayTask() {
        this.decayTask = new BukkitRunnable() {
            @Override
            public void run() {
                long now = System.currentTimeMillis();
                for (UUID uuid : ReputationService.this.stages.keySet()) {
                    long limit;
                    Stage s = ReputationService.this.stages.get(uuid);
                    if (s == Stage.NEUTRAL) continue;
                    long changed = ReputationService.this.lastChange.getOrDefault(uuid, now);
                    if (now - changed < (limit = s == Stage.WARNED || s == Stage.WATCHED ? 300000L : 600000L)) continue;
                    ReputationService.this.setStage(uuid, Stage.NEUTRAL);
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 200L, 200L);
    }

    public Stage getStage(UUID player) {
        return this.stages.getOrDefault(player, Stage.NEUTRAL);
    }

    public String getStageDisplay(UUID player) {
        Stage s = this.getStage(player);
        if (s == Stage.NEUTRAL) {
            Player online = Bukkit.getPlayer((UUID)player);
            if (online != null && this.guardService != null && this.guardService.nearestGuardDistance(online.getLocation(), GuardService.GUARD_PROTECTION_RANGE) >= 0.0) {
                return Text.color("&eGuarded");
            }
        }
        return Lang.msg("reputation." + s.name().toLowerCase() + ".display", this.capitalize(s.name()));
    }

    public long getSecondsUntilDecay(UUID playerId) {
        Stage s = this.getStage(playerId);
        if (s == Stage.NEUTRAL) {
            return 0L;
        }
        long now = System.currentTimeMillis();
        long changed = this.lastChange.getOrDefault(playerId, now);
        long limit = s == Stage.WARNED || s == Stage.WATCHED ? 300000L : 600000L;
        long remaining = limit - (now - changed);
        return Math.max(0L, remaining / 1000L);
    }

    private String capitalize(String in) {
        String lower = in.toLowerCase();
        return Character.toUpperCase(lower.charAt(0)) + lower.substring(1);
    }

    public void setStage(UUID player, Stage stage) {
        this.stages.put(player, stage);
        this.lastChange.put(player, System.currentTimeMillis());
        Player online = Bukkit.getPlayer((UUID)player);
        if (online != null) {
            this.notifyStage(online, stage);
        }
        if (stage == Stage.NEUTRAL) {
            this.removeFollower(player);
            return;
        }
        if (stage == Stage.WATCHED) {
            this.ensureFollower(player, false);
        } else if (stage == Stage.WANTED) {
            this.ensureFollower(player, true);
        }
    }

    private void ensureFollower(UUID playerId, boolean aggressive) {
        Entity guard;
        Player p = Bukkit.getPlayer((UUID)playerId);
        if (p == null) {
            return;
        }
        UUID existing = this.guardFollowers.get(playerId);
        Entity entity = guard = existing != null ? Bukkit.getEntity((UUID)existing) : null;
        if (guard == null || guard.isDead()) {
            this.removeFollower(playerId);
            guard = this.guardService.spawnDefaultGuard(p.getLocation(), p.getName() + " Guard");
            if (guard == null) {
                return;
            }
            this.guardFollowers.put(playerId, guard.getUniqueId());
            this.startFollowTask(playerId, guard.getUniqueId());
        }
        if (guard instanceof LivingEntity) {
            LivingEntity living = (LivingEntity)guard;
            try {
                AttributeInstance max;
                Attribute attr;
                try {
                    attr = Attribute.valueOf((String)"GENERIC_MAX_HEALTH");
                }
                catch (IllegalArgumentException ex) {
                    try {
                        attr = Attribute.valueOf((String)"MAX_HEALTH");
                    }
                    catch (IllegalArgumentException ex2) {
                        attr = null;
                    }
                }
                AttributeInstance attributeInstance = max = attr == null ? null : living.getAttribute(attr);
                if (max != null) {
                    max.setBaseValue(1000.0);
                }
                living.setHealth(Math.min(1000.0, living.getMaxHealth()));
            }
            catch (Exception exception) {
                // empty catch block
            }
            living.setAI(true);
            living.setCanPickupItems(false);
        }
        if (aggressive) {
            this.guardService.commandAttack(guard, p);
        }
    }

    private void startFollowTask(UUID playerId, UUID guardId) {
        new BukkitRunnable() {
            @Override
            public void run() {
                Player p = Bukkit.getPlayer((UUID)playerId);
                Entity g = Bukkit.getEntity((UUID)guardId);
                if (p == null || g == null || g.isDead()) {
                    this.cancel();
                    return;
                }
                Location target = ReputationService.this.followLocation(p);
                double distanceSquared = g.getLocation().distanceSquared(p.getLocation());
                if (distanceSquared < 4.0 || distanceSquared > 36.0) {
                    g.teleport(target);
                }
            }
        }.runTaskTimer((Plugin)this.plugin, 0L, 20L);
    }

    public void removeFollower(UUID playerId) {
        UUID gid = this.guardFollowers.remove(playerId);
        if (gid == null) {
            return;
        }
        this.guardService.despawnGuard(gid);
    }

    public void clear(UUID playerId) {
        this.stages.remove(playerId);
        this.lastChange.remove(playerId);
        this.removeFollower(playerId);
    }

    private void notifyStage(Player player, Stage stage) {
        switch (stage.ordinal()) {
            case 0: {
                player.sendMessage(Lang.msg("reputation.neutral.message", "&aYour reputation has returned to neutral."));
                break;
            }
            case 1: {
                player.sendTitle(Lang.msg("reputation.warn.title", "&eYou have been warned!"), Lang.msg("reputation.warn.subtitle", "&fDo not hit another player within guard range"), 10, 60, 10);
                player.sendMessage(Lang.msg("reputation.warn.chat", "&e&l(!) &eYou have been warned."));
                this.playSound(player, this.cfg(this.plugin.getConfig().getConfigurationSection("reputation"), "warn.sound", "BLOCK_NOTE_BLOCK_BASS"));
                break;
            }
            case 2: {
                player.sendTitle(Lang.msg("reputation.watched.title", "&6You are being watched!"), Lang.msg("reputation.watched.subtitle", "&fA guard will now follow you!"), 10, 60, 10);
                player.sendMessage(Lang.msg("reputation.watched.chat", "&6&l(!) &6You are being watched by a guard!"));
                this.playSound(player, this.cfg(this.plugin.getConfig().getConfigurationSection("reputation"), "watched.sound", "BLOCK_NOTE_BLOCK_BASS"));
                break;
            }
            case 3: {
                player.sendTitle(Lang.msg("reputation.wanted.title", "&cYou are WANTED!"), Lang.msg("reputation.wanted.subtitle", "&fGuards will now attack you."), 10, 60, 10);
                player.sendMessage(Lang.msg("reputation.wanted.chat", "&c&l(!) &cGuards will now attack you!"));
                this.playSound(player, this.cfg(this.plugin.getConfig().getConfigurationSection("reputation"), "wanted.sound", "ENTITY_ENDER_DRAGON_GROWL"));
            }
        }
    }

    private String cfg(ConfigurationSection sec, String path, String def) {
        if (sec == null) {
            return def;
        }
        return sec.getString(path, def);
    }

    private String color(String input) {
        return Text.color(input);
    }

    private void playSound(Player player, String soundName) {
        if (player == null || soundName == null || soundName.isEmpty()) {
            return;
        }
        try {
            player.playSound(player.getLocation(), soundName, 1.0f, 1.0f);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private Location followLocation(Player player) {
        Location base = player.getLocation().clone();
        org.bukkit.util.Vector direction = base.getDirection();
        if (direction.lengthSquared() < 1.0E-4) {
            direction.setX(0);
            direction.setY(0);
            direction.setZ(1);
        }
        direction.setY(0).normalize().multiply(-2.0);
        base.add(direction);
        base.setYaw(player.getLocation().getYaw());
        base.setPitch(player.getLocation().getPitch());
        return base;
    }

    public static enum Stage {
        NEUTRAL,
        WARNED,
        WATCHED,
        WANTED;

    }
}
