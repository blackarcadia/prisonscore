/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.service;

import org.axial.prisonsCore.service.CellBusterManager;
import org.axial.prisonsCore.service.CustomEnchantService;

public class CellBusterEnchanterBridge {
    private final CellBusterManager busterManager;
    private final CustomEnchantService enchantService;

    public CellBusterEnchanterBridge(CellBusterManager busterManager, CustomEnchantService enchantService) {
        this.busterManager = busterManager;
        this.enchantService = enchantService;
    }

    public CellBusterManager getBusterManager() {
        return this.busterManager;
    }

    public CustomEnchantService getEnchantService() {
        return this.enchantService;
    }
}

