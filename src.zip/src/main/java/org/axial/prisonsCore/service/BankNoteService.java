package org.axial.prisonsCore.service;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class BankNoteService {
    private final PrisonsCore plugin;
    private final EconomyService economyService;
    private final NamespacedKey amountKey;
    private Material material = Material.PAPER;
    private String displayName = "&a&lBank Note";
    private List<String> lore = List.of(
            "&7Right-click to redeem this note.",
            "&7",
            "&f&lValue",
            "&a{amount}"
    );

    public BankNoteService(PrisonsCore plugin, EconomyService economyService) {
        this.plugin = plugin;
        this.economyService = economyService;
        this.amountKey = Keys.bankNoteAmount(plugin);
        this.reload();
    }

    public void reload() {
        File file = new File(this.plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = cfg.getConfigurationSection("items.bank-note");
        if (section == null) {
            return;
        }
        Material configured = Material.matchMaterial(section.getString("material", "PAPER"));
        if (configured != null) {
            this.material = configured;
        }
        this.displayName = section.getString("display-name", this.displayName);
        List<String> configuredLore = section.getStringList("lore");
        if (configuredLore != null && !configuredLore.isEmpty()) {
            this.lore = configuredLore;
        }
    }

    public ItemStack createBankNote(double amount) {
        ItemStack stack = new ItemStack(this.material);
        stack.setAmount(1);
        ItemMeta meta = stack.getItemMeta();
        String formatted = this.economyService.format(amount);
        meta.setDisplayName(Text.color(this.displayName.replace("{amount}", formatted)));
        meta.setLore(this.lore.stream().map(line -> line.replace("{amount}", formatted)).map(Text::color).collect(Collectors.toList()));
        meta.getPersistentDataContainer().set(this.amountKey, PersistentDataType.DOUBLE, amount);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isBankNote(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(this.amountKey, PersistentDataType.DOUBLE);
    }

    public double getAmount(ItemStack item) {
        if (!this.isBankNote(item)) {
            return 0.0;
        }
        Double amount = item.getItemMeta().getPersistentDataContainer().get(this.amountKey, PersistentDataType.DOUBLE);
        return amount == null ? 0.0 : Math.max(0.0, amount);
    }

    public double getTotalAmount(ItemStack item) {
        if (!this.isBankNote(item)) {
            return 0.0;
        }
        return this.getAmount(item) * Math.max(1, item.getAmount());
    }
}
