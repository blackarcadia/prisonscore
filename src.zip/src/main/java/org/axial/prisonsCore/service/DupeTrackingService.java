package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class DupeTrackingService {
    private static final String DUPED_LINE = "&c&nDuped Item";
    private final PrisonsCore plugin;
    private final NamespacedKey trackedItemIdKey;
    private final NamespacedKey dupedItemKey;
    private BukkitTask scanTask;
    private boolean scanQueued;

    public DupeTrackingService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.trackedItemIdKey = Keys.trackedItemId(plugin);
        this.dupedItemKey = Keys.dupedItem(plugin);
    }

    public void start() {
        if (this.scanTask != null) {
            return;
        }
        this.scanTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::scanAll, 40L, 200L);
        this.requestScan();
    }

    public void stop() {
        if (this.scanTask != null) {
            this.scanTask.cancel();
            this.scanTask = null;
        }
        this.scanQueued = false;
    }

    public void requestScan() {
        if (this.scanQueued) {
            return;
        }
        this.scanQueued = true;
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            this.scanQueued = false;
            this.scanAll();
        });
    }

    public void track(ItemStack stack) {
        this.ensureTrackingId(stack);
    }

    public void scanAll() {
        Map<String, List<ItemStack>> tracked = new HashMap<String, List<ItemStack>>();
        List<Item> groundItems = new ArrayList<Item>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.collectInventory(tracked, player.getInventory());
            this.collectInventory(tracked, player.getEnderChest());
            this.collectCursor(tracked, player);
        }
        for (World world : Bukkit.getWorlds()) {
            for (Item itemEntity : world.getEntitiesByClass(Item.class)) {
                ItemStack stack = itemEntity.getItemStack();
                if (!this.shouldTrack(stack)) {
                    continue;
                }
                String id = this.ensureTrackingId(stack);
                if (id == null) {
                    continue;
                }
                groundItems.add(itemEntity);
                tracked.computeIfAbsent(id, key -> new ArrayList<ItemStack>()).add(stack);
            }
        }
        this.applyDuplicateState(tracked);
        for (Item itemEntity : groundItems) {
            itemEntity.setItemStack(itemEntity.getItemStack());
        }
    }

    private void collectInventory(Map<String, List<ItemStack>> tracked, Inventory inventory) {
        if (inventory == null) {
            return;
        }
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            ItemStack stack = inventory.getItem(slot);
            if (!this.shouldTrack(stack)) {
                continue;
            }
            String id = this.ensureTrackingId(stack);
            if (id == null) {
                continue;
            }
            tracked.computeIfAbsent(id, key -> new ArrayList<ItemStack>()).add(stack);
            inventory.setItem(slot, stack);
        }
    }

    private void collectCursor(Map<String, List<ItemStack>> tracked, Player player) {
        ItemStack cursor = player.getItemOnCursor();
        if (!this.shouldTrack(cursor)) {
            return;
        }
        String id = this.ensureTrackingId(cursor);
        if (id == null) {
            return;
        }
        tracked.computeIfAbsent(id, key -> new ArrayList<ItemStack>()).add(cursor);
        player.setItemOnCursor(cursor);
    }

    private void applyDuplicateState(Map<String, List<ItemStack>> tracked) {
        for (List<ItemStack> items : tracked.values()) {
            boolean duplicate = items.size() > 1;
            for (ItemStack stack : items) {
                if (duplicate) {
                    this.markDuped(stack);
                    continue;
                }
                this.clearDuped(stack);
            }
        }
    }

    private String ensureTrackingId(ItemStack stack) {
        if (!this.shouldTrack(stack)) {
            return null;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        String id = (String)container.get(this.trackedItemIdKey, PersistentDataType.STRING);
        if (id == null || id.isBlank()) {
            id = UUID.randomUUID().toString();
            container.set(this.trackedItemIdKey, PersistentDataType.STRING, id);
            stack.setItemMeta(meta);
        }
        return id;
    }

    private boolean shouldTrack(ItemStack stack) {
        return stack != null && !stack.getType().isAir() && stack.getMaxStackSize() == 1;
    }

    private void markDuped(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return;
        }
        List<String> lore = meta.hasLore() ? new ArrayList<String>(meta.getLore()) : new ArrayList<String>();
        String duped = Text.color(DUPED_LINE);
        if (!lore.contains(duped)) {
            lore.add(duped);
        }
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(this.dupedItemKey, PersistentDataType.BYTE, (byte)1);
        stack.setItemMeta(meta);
    }

    private void clearDuped(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        boolean changed = false;
        if (meta.hasLore()) {
            List<String> lore = new ArrayList<String>(meta.getLore());
            if (lore.removeIf(line -> "Duped Item".equalsIgnoreCase(Text.strip(line)))) {
                meta.setLore(lore.isEmpty() ? null : lore);
                changed = true;
            }
        }
        if (container.has(this.dupedItemKey, PersistentDataType.BYTE)) {
            container.remove(this.dupedItemKey);
            changed = true;
        }
        if (changed) {
            stack.setItemMeta(meta);
        }
    }
}
