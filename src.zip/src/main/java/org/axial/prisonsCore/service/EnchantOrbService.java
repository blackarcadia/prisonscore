/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class EnchantOrbService {
    private final CustomEnchantService customEnchantService;
    private final NamespacedKey idKey;
    private final NamespacedKey levelKey;
    private final NamespacedKey percentKey;
    private Material material;
    private String display;
    private List<String> lore;

    public EnchantOrbService(PrisonsCore plugin, CustomEnchantService customEnchantService) {
        this.customEnchantService = customEnchantService;
        this.idKey = new NamespacedKey((Plugin)plugin, "enchant-orb-id");
        this.levelKey = new NamespacedKey((Plugin)plugin, "enchant-orb-level");
        this.percentKey = new NamespacedKey((Plugin)plugin, "enchant-orb-percent");
        this.load(plugin);
    }

    private void load(PrisonsCore plugin) {
        File file = new File(plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection sec = cfg.getConfigurationSection("items.enchant-orb");
        this.material = Material.matchMaterial((String)(sec != null ? sec.getString("material", "BOOK") : "BOOK"));
        if (this.material == null) {
            this.material = Material.BOOK;
        }
        this.display = sec != null ? sec.getString("display-name", "&dEnchant Orb") : "&dEnchant Orb";
        this.lore = sec != null ? sec.getStringList("lore") : List.of("&7{enchant} {level}", "&7Success: {percent}%");
    }

    public ItemStack createOrb(String enchantId, int level, int percent) {
        CustomEnchant enchant = this.customEnchantService.getById(enchantId);
        if (enchant == null) {
            return null;
        }
        Material orbMat = enchant.getRarity().getOrbMaterial();
        ItemStack stack = new ItemStack(orbMat);
        ItemMeta meta = stack.getItemMeta();
        String color = enchant.getRarity().getColorCode();
        meta.setDisplayName(Text.color(color + enchant.getDisplayNameForLevel(level)));
        ArrayList<String> loreLines = new ArrayList<String>();
        loreLines.add(Text.color("&7" + enchant.getDescription()));
        loreLines.add(" ");
        int success = Math.max(0, Math.min(100, percent));
        int fail = Math.max(0, 100 - success);
        loreLines.add(Text.color("&aSuccess: " + success + "%"));
        loreLines.add(Text.color("&cFail: " + fail + "%"));
        loreLines.add(" ");
        loreLines.add(Text.color("&7Drag and Drop onto pickaxe to enchant"));
        meta.setLore(loreLines);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(this.idKey, PersistentDataType.STRING, enchant.getId());
        pdc.set(this.levelKey, PersistentDataType.INTEGER, level);
        pdc.set(this.percentKey, PersistentDataType.INTEGER, percent);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isEnchantOrb(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.idKey, PersistentDataType.STRING);
    }

    public String getEnchantId(ItemStack stack) {
        if (!this.isEnchantOrb(stack)) {
            return null;
        }
        return (String)stack.getItemMeta().getPersistentDataContainer().get(this.idKey, PersistentDataType.STRING);
    }

    public int getLevel(ItemStack stack) {
        if (!this.isEnchantOrb(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.levelKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public int getPercent(ItemStack stack) {
        if (!this.isEnchantOrb(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.percentKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    private String roman(int number) {
        int n = Math.max(1, number);
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                sb.append(numerals[i]);
                n -= values[i];
            }
        }
        return sb.toString();
    }

    public void reload(PrisonsCore plugin) {
        this.load(plugin);
    }
}
