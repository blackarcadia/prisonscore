/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package org.axial.prisonsCore.service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class LevelDisplayService {
    private final PrisonsCore plugin;
    private final PlayerLevelService levelService;
    private final Map<UUID, ArmorStand> stands = new HashMap<UUID, ArmorStand>();
    private BukkitTask task;
    private static final double OFFSET = 0.35;

    public LevelDisplayService(PrisonsCore plugin, PlayerLevelService levelService) {
        this.plugin = plugin;
        this.levelService = levelService;
    }

    public void start() {
        if (this.task != null) {
            return;
        }
        this.clearAll();
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::tick, 0L, 1L);
        Bukkit.getOnlinePlayers().forEach(this::spawn);
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
        }
        this.task = null;
        this.clearAll();
    }

    public void spawn(Player player) {
        this.remove(player);
        World world = player.getWorld();
        ArmorStand levelStand = (ArmorStand)world.spawnEntity(player.getLocation().add(0.0, player.getHeight() + 0.35, 0.0), EntityType.ARMOR_STAND);
        levelStand.setVisible(false);
        levelStand.setMarker(true);
        levelStand.setGravity(false);
        levelStand.setSmall(true);
        levelStand.setCustomNameVisible(true);
        levelStand.setPersistent(true);
        levelStand.setCollidable(false);
        levelStand.setInvulnerable(true);
        this.stands.put(player.getUniqueId(), levelStand);
        this.update(player);
    }

    public void remove(Player player) {
        ArmorStand as = this.stands.remove(player.getUniqueId());
        if (as != null && !as.isDead()) {
            as.remove();
        }
    }

    public void update(Player player) {
        ArmorStand levelStand = this.stands.get(player.getUniqueId());
        if (levelStand == null || levelStand.isDead()) {
            return;
        }
        int lvl = this.levelService != null ? this.levelService.getLevel(player) : 0;
        levelStand.setCustomName(Text.color(this.formatLevel(lvl)));
        levelStand.teleport(player.getLocation().add(0.0, player.getHeight() + 0.35, 0.0));
    }

    private void tick() {
        this.stands.entrySet().removeIf(entry -> {
            boolean invalid;
            UUID uuid = (UUID)entry.getKey();
            ArmorStand as = (ArmorStand)entry.getValue();
            Player p = Bukkit.getPlayer((UUID)uuid);
            boolean bl = invalid = p == null || !p.isOnline() || as == null || as.isDead();
            if (invalid) {
                if (as != null && !as.isDead()) {
                    as.remove();
                }
                return true;
            }
            this.update(p);
            return false;
        });
    }

    private String formatLevel(int lvl) {
        if (lvl < 20) {
            return "&8[&7" + lvl + "&8]";
        }
        if (lvl < 40) {
            return "&8[&9" + lvl + "&8]";
        }
        if (lvl < 60) {
            return "&8[&b" + lvl + "&8]";
        }
        if (lvl < 80) {
            return "&8[&e" + lvl + "&8]";
        }
        if (lvl < 100) {
            return "&8[&6" + lvl + "&8]";
        }
        return "&8[&c" + lvl + "&8]";
    }

    private String format(double val) {
        if (val == (double)((int)val)) {
            return String.valueOf((int)val);
        }
        return String.format("%.1f", val);
    }

    private void clearAll() {
        this.stands.values().forEach(as -> {
            if (as != null && !as.isDead()) {
                as.remove();
            }
        });
        this.stands.clear();
    }
}

