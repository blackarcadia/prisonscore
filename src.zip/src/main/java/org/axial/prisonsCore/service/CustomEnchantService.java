/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.model.EnchantRarity;
import org.axial.prisonsCore.util.ConfigUpdater;
import org.axial.prisonsCore.util.Text;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class CustomEnchantService {
    private final PrisonsCore plugin;
    private final List<CustomEnchant> enchants = new ArrayList<CustomEnchant>();
    private final Random random = new Random();

    public CustomEnchantService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.load();
    }

    public List<CustomEnchant> getAll() {
        return Collections.unmodifiableList(this.enchants);
    }

    public CustomEnchant getById(String id) {
        return this.enchants.stream().filter(e -> e.getId().equalsIgnoreCase(id)).findFirst().orElse(null);
    }

    public List<CustomEnchant> pickRandomOptions(int amount) {
        return this.pickRandomOptions(amount, this.enchants);
    }

    public List<CustomEnchant> pickRandomOptions(int amount, List<CustomEnchant> pool) {
        ArrayList<CustomEnchant> shuffled = new ArrayList<CustomEnchant>(pool);
        Collections.shuffle(shuffled, this.random);
        return shuffled.stream().limit(amount).collect(Collectors.toList());
    }

    public ItemStack createOptionItem(CustomEnchant enchant, int level) {
        return this.createOptionItem(enchant, level, enchant.getSuccessChance());
    }

    public ItemStack createOptionItem(CustomEnchant enchant, int level, int successChance) {
        ItemStack item = new ItemStack(enchant.getRarity().getDisplayMaterial());
        ItemMeta meta = item.getItemMeta();
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setDisplayName(Text.color(enchant.getDisplayNameForLevel(level)));
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(Text.color("&7" + enchant.getDescription()));
        int success = Math.max(0, Math.min(100, successChance));
        int fail = Math.max(0, 100 - success);
        lore.add(Text.color("&aSuccess: " + success + "%"));
        lore.add(Text.color("&cFail: " + fail + "%"));
        lore.add(Text.color("&7Rarity: " + enchant.getRarity().name()));
        lore.add(Text.color("&7Click to apply"));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public int rollSuccess(CustomEnchant enchant) {
        return this.random.nextInt(100) < enchant.getSuccessChance() ? 1 : 0;
    }

    public int rollSuccess(int chancePercent) {
        int c = Math.max(0, Math.min(100, chancePercent));
        return this.random.nextInt(100) < c ? 1 : 0;
    }

    private String roman(int number) {
        int n = Math.max(1, number);
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                sb.append(numerals[i]);
                n -= values[i];
            }
        }
        return sb.toString();
    }

    private void load() {
        this.enchants.clear();
        File file = new File(this.plugin.getDataFolder(), "enchants.yml");
        if (!file.exists()) {
            this.plugin.saveResource("enchants.yml", false);
        } else {
            ConfigUpdater.saveDefaultAndMerge(this.plugin, "enchants.yml");
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        String defaultLore = cfg.getString("lore-format-default", "&d{enchant} {level}");
        ConfigurationSection section = cfg.getConfigurationSection("enchants");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection node = section.getConfigurationSection(key);
            if (node == null) continue;
            String name = node.getString("display-name", key);
            String desc = node.getString("description", "");
            int chance = Math.max(1, Math.min(100, node.getInt("success-chance", 50)));
            int maxLevel = Math.max(1, node.getInt("max-level", 1));
            EnchantRarity rarity = EnchantRarity.fromString(node.getString("rarity"), this.defaultRarityForId(key));
            List procChances = node.getDoubleList("proc-chances");
            List loreLevels = node.getStringList("lore-format-levels");
            String loreFormat = node.getString("lore-format", defaultLore);
            if (loreFormat == null || loreFormat.isEmpty()) {
                loreFormat = defaultLore;
            }
            this.enchants.add(new CustomEnchant(key, name, desc, chance, maxLevel, rarity, procChances, loreLevels, loreFormat, Collections.emptyList()));
        }
    }

    private EnchantRarity defaultRarityForId(String id) {
        return switch (id.toLowerCase()) {
            case "efficiency" -> EnchantRarity.BASIC;
            case "energycollector" -> EnchantRarity.RARE;
            case "momentum" -> EnchantRarity.LEGENDARY;
            case "haste" -> EnchantRarity.RARE;
            case "shatter" -> EnchantRarity.ELITE;
            case "feed" -> EnchantRarity.BASIC;
            case "fissure" -> EnchantRarity.RARE;
            case "fireball" -> EnchantRarity.LEGENDARY;
            case "luck" -> EnchantRarity.LEGENDARY;
            case "recharge" -> EnchantRarity.RARE;
            case "rocky" -> EnchantRarity.LEGENDARY;
            case "buster_efficiency" -> EnchantRarity.LEGENDARY;
            default -> EnchantRarity.BASIC;
        };
    }

    public void reload() {
        this.load();
    }

    public double getProcChancePercent(String id, int level, double defaultPerLevel) {
        CustomEnchant enchant = this.getById(id);
        double fallback = defaultPerLevel * (double)level;
        if (enchant == null) {
            return fallback;
        }
        return enchant.getProcChanceForLevel(level, fallback);
    }
}
