/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Chunk
 *  org.bukkit.Instrument
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.Note
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.block.data.type.NoteBlock
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Display$Billboard
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Item
 *  org.bukkit.entity.ItemDisplay
 *  org.bukkit.entity.ItemDisplay$ItemDisplayTransform
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.entity.EntityPickupItemEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.world.ChunkLoadEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.util.BoundingBox
 *  org.bukkit.util.Transformation
 *  org.jetbrains.annotations.NotNull
 *  org.jetbrains.annotations.Nullable
 *  org.joml.Quaternionf
 *  org.joml.Vector3f
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.BoosterService;
import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.service.EnergyItemService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.Instrument;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Note;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.NoteBlock;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Transformation;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class CustomBlockService
implements Listener {
    private final PrisonsCore plugin;
    private final EnergyItemService energyItemService;
    private final EconomyService economyService;
    private final BoosterService boosterService;
    private final LockboxService lockboxService;
    private final NamespacedKey itemKey;
    private final NamespacedKey itemNonceKey;
    private final NamespacedKey itemCooldownKey;
    private static final String ENTITY_TAG = "pc-customblock";
    private static final String HOLOGRAM_TAG = "pc-customblock-hologram";
    private static final String DISPLAY_TAG = "pc-customblock-display";
    private static final String STATUS_TAG = "pc-customblock-status";
    private static final String TASK_TAG = "pc-customblock-task";
    private static final String PROGRESS_TAG = "pc-customblock-progress";
    private final Map<String, CustomBlockDefinition> definitions = new HashMap<String, CustomBlockDefinition>();
    private final Map<BlockPos, String> placedBlocks = new ConcurrentHashMap<BlockPos, String>();
    private final Map<BlockPos, UUID> holograms = new ConcurrentHashMap<BlockPos, UUID>();
    private final Map<BlockPos, UUID> displays = new ConcurrentHashMap<BlockPos, UUID>();
    private final Map<BlockPos, UUID> statusLabels = new ConcurrentHashMap<BlockPos, UUID>();
    private final Map<BlockPos, UUID> taskLabels = new ConcurrentHashMap<BlockPos, UUID>();
    private final Map<BlockPos, UUID> progressLabels = new ConcurrentHashMap<BlockPos, UUID>();
    private final Map<BlockPos, Long> cooldowns = new ConcurrentHashMap<BlockPos, Long>();
    private final Map<BlockPos, Float> displayYaw = new ConcurrentHashMap<BlockPos, Float>();
    private final Map<UUID, Map<String, Long>> pendingCooldowns = new ConcurrentHashMap<UUID, Map<String, Long>>();
    private final Map<String, Long> nonceCooldowns = new ConcurrentHashMap<String, Long>();
    private Material defaultBlock = Material.NOTE_BLOCK;
    private double hologramOffset = 1.6;
    private String hologramFormat = "{name}";
    private double statusOffset = 1.35;
    private double lockboxProgressOffset = 1.1;
    private String statusReadyText = "&f(&aRight Click&f)";
    private String statusCooldownText = "&f(&cOn Cooldown&f)";
    private double displayOffset = 0.55;
    private boolean spawnDisplayByDefault = true;
    private boolean useNoteState = true;
    private int statusTaskId = -1;
    private final File dataFile;
    private final File configFile;

    public CustomBlockService(PrisonsCore plugin, EnergyItemService energyItemService, EconomyService economyService, BoosterService boosterService, LockboxService lockboxService) {
        this.plugin = plugin;
        this.energyItemService = energyItemService;
        this.economyService = economyService;
        this.boosterService = boosterService;
        this.lockboxService = lockboxService;
        this.itemKey = Keys.customBlockId(plugin);
        this.itemNonceKey = new NamespacedKey((Plugin)plugin, "custom-block-nonce");
        this.itemCooldownKey = new NamespacedKey((Plugin)plugin, "custom-block-cooldown-until");
        this.configFile = new File(plugin.getDataFolder(), "custom-blocks.yml");
        this.dataFile = new File(plugin.getDataFolder(), "custom-blocks-data.yml");
        this.loadConfig();
        this.purgeAllTaggedEntities();
        this.loadData();
        this.startStatusTask();
    }

    @EventHandler(ignoreCancelled=true, priority=EventPriority.MONITOR)
    public void onPickup(EntityPickupItemEvent event) {
        Object cached;
        String nonce;
        Item itemEntity = event.getItem();
        if (itemEntity == null) {
            return;
        }
        ItemStack stack = itemEntity.getItemStack();
        String id = this.getId(stack);
        if (id == null) {
            return;
        }
        Object cd = this.getItemCooldown(stack);
        if (cd == null && (nonce = this.getNonce(stack)) != null && (cached = this.nonceCooldowns.get(nonce)) != null && (Long)cached > System.currentTimeMillis()) {
            cd = cached;
        }
        if (cd != null && (Long)cd > System.currentTimeMillis() && (cached = event.getEntity()) instanceof Player) {
            Player player = (Player)cached;
            String nonce2 = this.getNonce(stack);
            if (nonce2 != null) {
                this.pendingCooldowns.computeIfAbsent(player.getUniqueId(), u -> new ConcurrentHashMap()).put(nonce2, cd);
            }
        }
        if (cd != null) {
            this.ensureStackHasCooldown(stack, (Long)cd);
            itemEntity.setItemStack(stack);
        }
    }

    private boolean breakCustomBlock(Block block, Player player, boolean removeBlockManually) {
        BlockPos pos = BlockPos.of(block);
        String id = this.placedBlocks.remove(pos);
        if (id == null) {
            return false;
        }
        CustomBlockDefinition def = this.definitions.get(id.toLowerCase(Locale.ROOT));
        Long existingCd = this.cooldowns.remove(pos);
        this.purgeVisuals(pos);
        this.displayYaw.remove(pos);
        if (removeBlockManually) {
            block.setType(Material.AIR, false);
        }
        if (def != null && def.dropOnBreak()) {
            Long carryCd = existingCd != null && existingCd > System.currentTimeMillis() ? existingCd : null;
            ItemStack drop = this.createItem(def.id(), carryCd);
            if (this.lockboxService != null && this.lockboxService.isLockboxId(def.id())) {
                drop = this.lockboxService.createDropItem(pos, drop);
            }
            String nonce = this.getNonce(drop);
            if (carryCd != null && nonce != null) {
                this.nonceCooldowns.put(nonce, carryCd);
            }
            this.giveOrDrop(player, drop, block.getLocation());
            if (carryCd != null && player != null) {
                if (nonce != null) {
                    this.pendingCooldowns.computeIfAbsent(player.getUniqueId(), u -> new ConcurrentHashMap()).put(nonce, carryCd);
                }
                this.reinforceInventoryCooldown(player, def.id(), nonce, carryCd);
            }
        }
        if (this.lockboxService != null && this.lockboxService.isLockboxId(id)) {
            this.lockboxService.remove(pos);
        }
        this.saveData();
        return true;
    }

    public void reload() {
        this.loadConfig();
        this.purgeAllTaggedEntities();
        this.refreshPlaced();
    }

    private void purgeVisuals(BlockPos pos) {
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null) {
            return;
        }
        this.removeHologram(pos);
        this.purgeHologramEntities(world, pos);
        this.removeDisplay(pos);
        this.purgeDisplayEntities(world, pos);
        UUID statusId = this.statusLabels.remove(pos);
        if (statusId != null) {
            world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(statusId)).forEach(Entity::remove);
        }
        UUID taskId = this.taskLabels.remove(pos);
        if (taskId != null) {
            world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(taskId)).forEach(Entity::remove);
        }
        UUID progressId = this.progressLabels.remove(pos);
        if (progressId != null) {
            world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(progressId)).forEach(Entity::remove);
        }
        this.removeStatusLabel(pos);
        this.removeTaskLabel(pos);
        this.removeProgressLabel(pos);
    }

    private void purgeAllTaggedEntities() {
        for (World world : Bukkit.getWorlds()) {
            world.getEntitiesByClasses(new Class[]{ArmorStand.class, ItemDisplay.class}).forEach(entity -> {
                if (entity.getPersistentDataContainer().has(this.itemKey, PersistentDataType.STRING) || entity.getScoreboardTags().contains(ENTITY_TAG)) {
                    entity.remove();
                }
            });
        }
    }

    public ItemStack createItem(String id) {
        return this.createItem(id, null);
    }

    private ItemStack createItem(String id, @Nullable Long cooldownUntil) {
        CustomBlockDefinition def = this.definitions.get(id.toLowerCase(Locale.ROOT));
        if (def == null) {
            return null;
        }
        ItemStack item = new ItemStack(def.itemMaterial());
        item.setAmount(1);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(def.displayName()));
            if (def.lore() != null && !def.lore().isEmpty()) {
                ArrayList<String> colored = new ArrayList<String>(def.lore().size());
                for (String line : def.lore()) {
                    colored.add(Text.color(line));
                }
                meta.setLore(colored);
            }
            if (def.customModelData() > 0) {
                meta.setCustomModelData(Integer.valueOf(def.customModelData()));
            }
            this.applyGlint(meta);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
            meta.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, def.id());
            meta.getPersistentDataContainer().set(this.itemNonceKey, PersistentDataType.STRING, UUID.randomUUID().toString());
            if (cooldownUntil != null && cooldownUntil > System.currentTimeMillis()) {
                meta.getPersistentDataContainer().set(this.itemCooldownKey, PersistentDataType.LONG, cooldownUntil);
            } else {
                meta.getPersistentDataContainer().remove(this.itemCooldownKey);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    public Set<String> getIds() {
        return this.definitions.keySet();
    }

    public int getGangPoints(org.axial.prisonsCore.cell.Cell cell) {
        if (cell == null || cell.getRegion() == null) {
            return 0;
        }
        int total = 0;
        for (Map.Entry<BlockPos, String> entry : this.placedBlocks.entrySet()) {
            Location location = this.locationOf(entry.getKey());
            if (location == null || !cell.isInside(location)) {
                continue;
            }
            total += this.pointsFor(entry.getValue());
        }
        return total;
    }

    @EventHandler(ignoreCancelled=true)
    public void onPlace(BlockPlaceEvent event) {
        Long fromNonce;
        String nonce;
        ItemStack hand = event.getItemInHand();
        String id = this.getId(hand);
        if (id == null) {
            return;
        }
        CustomBlockDefinition def = this.definitions.get(id);
        if (def == null) {
            return;
        }
        Block block = event.getBlockPlaced();
        Block below = block.getRelative(0, -1, 0);
        Block above = block.getRelative(0, 1, 0);
        if (this.isCustomBlock(below) || this.isCustomBlock(above)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Text.color("&cYou cannot place a custom block directly above or below another."));
            return;
        }
        block.setType(def.placedMaterial(), false);
        this.applyState(block, def);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.applyState(block, def));
        BlockPos pos = BlockPos.of(block);
        this.purgeVisuals(pos);
        this.placedBlocks.put(pos, def.id());
        Long carriedCooldown = this.getItemCooldown(hand);
        if (carriedCooldown == null && (nonce = this.getNonce(hand)) != null && (fromNonce = this.nonceCooldowns.remove(nonce)) != null && fromNonce > System.currentTimeMillis()) {
            carriedCooldown = fromNonce;
        }
        if (carriedCooldown == null) {
            nonce = this.getNonce(hand);
            Map<String, Long> pending = this.pendingCooldowns.get(event.getPlayer().getUniqueId());
            if (pending != null && nonce != null) {
                Long pendingCd = pending.remove(nonce);
                if (pendingCd != null && pendingCd > System.currentTimeMillis()) {
                    carriedCooldown = pendingCd;
                }
                if (pending.isEmpty()) {
                    this.pendingCooldowns.remove(event.getPlayer().getUniqueId());
                }
            }
        }
        if (carriedCooldown != null && carriedCooldown > System.currentTimeMillis()) {
            this.cooldowns.put(pos, carriedCooldown);
        }
        if (this.lockboxService != null && this.lockboxService.isLockboxId(def.id())) {
            this.lockboxService.place(pos, event.getPlayer(), hand);
        }
        this.spawnHologram(block, def);
        float yaw = this.normalizeYaw(event.getPlayer().getLocation().getYaw());
        this.displayYaw.put(pos, Float.valueOf(yaw));
        if (def.spawnDisplay()) {
            this.spawnDisplay(block, def, yaw);
        }
        this.updateVisualLabels(pos, def);
        this.saveData();
    }

    @EventHandler(ignoreCancelled=true)
    public void onBreak(BlockBreakEvent event) {
        if (this.breakCustomBlock(event.getBlock(), event.getPlayer(), false)) {
            event.setDropItems(false);
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        BlockPos pos = BlockPos.of(block);
        String id = this.placedBlocks.get(pos);
        if (id == null) {
            return;
        }
        CustomBlockDefinition def = this.definitions.get(id.toLowerCase(Locale.ROOT));
        if (def == null) {
            return;
        }
        if (action == Action.LEFT_CLICK_BLOCK) {
            event.setCancelled(true);
            this.breakCustomBlock(block, event.getPlayer(), true);
            return;
        }
        if (this.lockboxService != null && this.lockboxService.isLockboxId(def.id())) {
            event.setCancelled(true);
            Player player = event.getPlayer();
            if (!this.lockboxService.isOwner(pos, player.getUniqueId())) {
                player.sendMessage(Text.color("&cThis lockbox belongs to someone else."));
                return;
            }
            this.lockboxService.openMenu(player, pos);
            return;
        }
        if (!def.trigger().matches(action)) {
            return;
        }
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (this.isCooling(pos, player, def)) {
            return;
        }
        if (this.execute(def, player, block)) {
            this.startCooldown(pos, def);
        }
    }

    @EventHandler
    public void onChunkLoad(ChunkLoadEvent event) {
        Chunk chunk = event.getChunk();
        String worldName = event.getWorld().getName();
        this.placedBlocks.keySet().stream().filter(pos -> pos.world().equals(worldName) && pos.chunkX() == chunk.getX() && pos.chunkZ() == chunk.getZ()).forEach(pos -> {
            CustomBlockDefinition def = this.definitions.get(this.placedBlocks.get(pos).toLowerCase(Locale.ROOT));
            if (def != null) {
                this.purgeVisuals((BlockPos)pos);
                Block block = this.blockAt((BlockPos)pos);
                if (block != null && block.getType() != def.placedMaterial()) {
                    block.setType(def.placedMaterial(), false);
                }
                this.applyState(block, def);
                this.spawnHologram(block, def);
                float yaw = this.displayYaw.getOrDefault(pos, Float.valueOf(0.0f)).floatValue();
                if (def.spawnDisplay()) {
                    this.spawnDisplay(block, def, yaw);
                }
                this.updateVisualLabels((BlockPos)pos, def);
            }
        });
    }

    public void shutdown() {
        this.saveData();
        this.holograms.keySet().forEach(this::removeHologram);
        this.holograms.clear();
        this.displays.keySet().forEach(this::removeDisplay);
        this.displays.clear();
        this.displayYaw.clear();
        this.statusLabels.keySet().forEach(this::removeStatusLabel);
        this.statusLabels.clear();
        this.taskLabels.keySet().forEach(this::removeTaskLabel);
        this.taskLabels.clear();
        this.progressLabels.keySet().forEach(this::removeProgressLabel);
        this.progressLabels.clear();
        if (this.statusTaskId != -1) {
            Bukkit.getScheduler().cancelTask(this.statusTaskId);
            this.statusTaskId = -1;
        }
    }

    public void refreshPlaced() {
        this.placedBlocks.forEach((pos, id) -> {
            CustomBlockDefinition def = this.definitions.get(id);
            if (def == null) {
                return;
            }
            if (!this.isChunkLoaded((BlockPos)pos)) {
                return;
            }
            this.purgeVisuals((BlockPos)pos);
            Block block = this.blockAt((BlockPos)pos);
            if (block != null && block.getType() != def.placedMaterial()) {
                block.setType(def.placedMaterial(), false);
            }
            this.applyState(block, def);
            this.spawnHologram(block, def);
            float yaw = this.displayYaw.getOrDefault(pos, Float.valueOf(0.0f)).floatValue();
            if (def.spawnDisplay()) {
                this.spawnDisplay(block, def, yaw);
            }
            this.updateVisualLabels((BlockPos)pos, def);
        });
    }

    private int pointsFor(String id) {
        if (id == null) {
            return 0;
        }
        return switch (id.toLowerCase(Locale.ROOT)) {
            case "house_of_cards" -> 150;
            case "potofgold" -> 145;
            case "power_cell" -> 200;
            default -> 0;
        };
    }

    private Location locationOf(BlockPos pos) {
        World world = Bukkit.getWorld((String)pos.world());
        return world == null ? null : new Location(world, (double)pos.x(), (double)pos.y(), (double)pos.z());
    }

    private void loadConfig() {
        this.definitions.clear();
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)this.configFile);
        this.defaultBlock = this.parseMaterial(cfg.getString("default-block"), Material.NOTE_BLOCK);
        this.hologramOffset = cfg.getDouble("hologram.offset-y", 1.6);
        this.hologramFormat = cfg.getString("hologram.format", "{name}");
        this.statusOffset = cfg.getDouble("hologram.status-offset-y", this.hologramOffset - 0.25);
        this.lockboxProgressOffset = cfg.getDouble("hologram.lockbox-progress-offset-y", this.statusOffset - 0.25);
        this.statusReadyText = cfg.getString("hologram.status-ready", "&f(&aRight Click&f)");
        this.statusCooldownText = cfg.getString("hologram.status-cooldown", "&f(&cOn Cooldown&f)");
        this.displayOffset = cfg.getDouble("display.offset-y", 0.55);
        this.spawnDisplayByDefault = cfg.getBoolean("display.render-item-display", true);
        this.useNoteState = cfg.getBoolean("use-note-state", true);
        ConfigurationSection sec = cfg.getConfigurationSection("blocks");
        if (sec == null) {
            return;
        }
        for (String rawId : sec.getKeys(false)) {
            ConfigurationSection blockSec = sec.getConfigurationSection(rawId);
            if (blockSec == null) continue;
            String id = rawId.toLowerCase(Locale.ROOT);
            String name = blockSec.getString("name", rawId);
            Material blockMaterial = this.parseMaterial(blockSec.getString("block-material"), this.defaultBlock);
            Material placedMaterial = this.parseMaterial(blockSec.getString("placed-material"), blockMaterial);
            int cmd = blockSec.getInt("custom-model-data", -1);
            List lore = blockSec.getStringList("lore");
            String hologram = blockSec.getString("hologram", name);
            Trigger trigger = Trigger.from(blockSec.getString("trigger", "RIGHT_CLICK"));
            BlockAction action = this.parseAction(blockSec.getConfigurationSection("action"));
            long cooldownSeconds = blockSec.getLong("cooldown-seconds", 0L);
            String cooldownMessage = blockSec.getString("cooldown-message", "&cThis block is recharging for {time}.");
            boolean dropOnBreak = blockSec.getBoolean("drop-on-break", true);
            boolean renderDisplay = blockSec.getBoolean("render-item-display", this.spawnDisplayByDefault);
            Material displayItemMaterial = this.parseMaterial(blockSec.getString("display-item-material"), blockMaterial);
            int displayCmd = blockSec.getInt("display-item-custom-model-data", cmd);
            boolean applyNoteState = blockSec.getBoolean("apply-note-state", this.useNoteState);
            NoteState noteState = this.parseNoteState(blockSec.getConfigurationSection("state"));
            CustomBlockDefinition def = new CustomBlockDefinition(id, blockMaterial, placedMaterial, cmd, name, lore, hologram, trigger, action, cooldownSeconds, cooldownMessage, dropOnBreak, renderDisplay, displayItemMaterial, displayCmd, applyNoteState, noteState);
            this.definitions.put(id, def);
        }
    }

    private void loadData() {
        this.placedBlocks.clear();
        this.cooldowns.clear();
        if (!this.dataFile.exists()) {
            return;
        }
        YamlConfiguration data = YamlConfiguration.loadConfiguration(this.dataFile);
        List<Map<?, ?>> entries = data.getMapList("placed");
        for (Map<?, ?> raw : entries) {
            CustomBlockDefinition def;
            Long cd;
            String id = this.stringVal(raw.get("id"));
            String world = this.stringVal(raw.get("world"));
            Integer x = this.intVal(raw.get("x"));
            Integer y = this.intVal(raw.get("y"));
            Integer z = this.intVal(raw.get("z"));
            Float loadedYaw = this.floatVal(raw.get("yaw"));
            if (id == null || world == null || x == null || y == null || z == null) continue;
            BlockPos pos = new BlockPos(world, x, y, z);
            this.placedBlocks.put(pos, id.toLowerCase(Locale.ROOT));
            if (loadedYaw != null) {
                this.displayYaw.put(pos, loadedYaw);
            }
            if ((cd = this.longVal(raw.get("cooldown-until"))) != null) {
                this.cooldowns.put(pos, cd);
            }
            if ((def = this.definitions.get(id.toLowerCase(Locale.ROOT))) == null) continue;
            if (!this.isChunkLoaded(pos)) {
                continue;
            }
            this.purgeVisuals(pos);
            Block block = this.blockAt(pos);
            if (block != null && block.getType() != def.placedMaterial()) {
                block.setType(def.placedMaterial(), false);
            }
            this.applyState(block, def);
            this.spawnHologram(block, def);
            float yaw = this.displayYaw.getOrDefault(pos, Float.valueOf(0.0f)).floatValue();
            if (def.spawnDisplay()) {
                this.spawnDisplay(block, def, yaw);
            }
            this.updateVisualLabels(pos, def);
        }
    }

    private void saveData() {
        YamlConfiguration data = new YamlConfiguration();
        ArrayList out = new ArrayList();
        for (Map.Entry<BlockPos, String> entry : this.placedBlocks.entrySet()) {
            Long cd;
            BlockPos pos = entry.getKey();
            HashMap<String, Object> map = new HashMap<String, Object>();
            map.put("id", entry.getValue());
            map.put("world", pos.world());
            map.put("x", pos.x());
            map.put("y", pos.y());
            map.put("z", pos.z());
            Float savedYaw = this.displayYaw.get(pos);
            if (savedYaw != null) {
                map.put("yaw", savedYaw);
            }
            if ((cd = this.cooldowns.get(pos)) != null) {
                map.put("cooldown-until", cd);
            }
            out.add(map);
        }
        data.set("placed", out);
        try {
            data.save(this.dataFile);
        }
        catch (IOException ex) {
            this.plugin.getLogger().warning("Failed to save custom block data: " + ex.getMessage());
        }
    }

    private boolean execute(CustomBlockDefinition def, Player player, Block block) {
        if (def.action() == null || def.action().type() == null) {
            return false;
        }
        return switch (def.action().type()) {
            case GIVE_RAW_CHARGE -> {
                if (this.energyItemService == null) {
                    yield false;
                }
                this.energyItemService.giveEnergyItem(player, def.action().amount());
                player.sendMessage(Text.color("&aReceived &f" + def.action().amount() + " &dRaw Charge."));
                yield true;
            }
            case GIVE_MONEY -> {
                if (this.economyService == null) {
                    yield false;
                }
                boolean ok = this.economyService.deposit(player, def.action().amount());
                if (ok) {
                    player.sendMessage(Text.color("&aReceived &f$" + def.action().amount()));
                } else {
                    player.sendMessage(Text.color("&cFailed to process reward."));
                }
                yield ok;
            }
            case ACTIVATE_XP_BOOST -> {
                if (this.boosterService == null) {
                    yield false;
                }
                int duration = Math.max(1, def.action().amount());
                double mult = def.action().multiplier() > 0.0 ? def.action().multiplier() : 1.0;
                this.boosterService.activateBooster(player, BoosterService.BoosterType.XP, mult, duration);
                yield true;
            }
            case ACTIVATE_BEACH_BALL -> {
                if (this.plugin.getCustomBlockBuffService() == null) {
                    yield false;
                }
                yield this.plugin.getCustomBlockBuffService().activateBeachBall(player);
            }
            case ACTIVATE_MINI_PALM_TREE -> {
                if (this.plugin.getCustomBlockBuffService() == null) {
                    yield false;
                }
                yield this.plugin.getCustomBlockBuffService().activateMiniPalmTree(player);
            }
        };
    }

    private boolean isCooling(BlockPos pos, Player player, CustomBlockDefinition def) {
        Long until = this.effectiveCooldown(pos, def);
        if (until == null) {
            return false;
        }
        long remaining = until - System.currentTimeMillis();
        String msg = def.cooldownMessage() != null ? def.cooldownMessage() : "&cThis block is recharging for {time}.";
        player.sendMessage(Text.color(msg.replace("{time}", this.formatDuration(remaining))));
        return true;
    }

    private void startCooldown(BlockPos pos, CustomBlockDefinition def) {
        if (def.cooldownSeconds() <= 0L) {
            return;
        }
        long until = System.currentTimeMillis() + def.cooldownSeconds() * 1000L;
        this.cooldowns.put(pos, until);
        this.updateStatusLabel(pos, def);
        this.saveData();
    }

    private Long effectiveCooldown(BlockPos pos, CustomBlockDefinition def) {
        long until;
        long now = System.currentTimeMillis();
        Long posCd = this.cooldowns.get(pos);
        long l = until = posCd != null ? posCd : 0L;
        if (until <= now) {
            if (posCd != null && posCd <= now) {
                this.cooldowns.remove(pos);
            }
            return null;
        }
        return until;
    }

    private void spawnHologram(Block block, CustomBlockDefinition def) {
        if (block == null || def == null) {
            return;
        }
        BlockPos pos = BlockPos.of(block);
        this.removeHologram(pos);
        this.purgeHologramEntities(block.getWorld(), pos);
        Location loc = block.getLocation().add(0.5, this.hologramOffset, 0.5);
        ArmorStand stand = (ArmorStand)block.getWorld().spawn(loc, ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setMarker(true);
            as.setGravity(false);
            as.setSmall(true);
            as.setCustomNameVisible(true);
            String name = def.hologramText() != null ? def.hologramText() : def.displayName();
            String formatted = this.hologramFormat.replace("{name}", name);
            as.setCustomName(Text.color(formatted));
            as.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, def.id());
            as.addScoreboardTag(ENTITY_TAG);
            as.addScoreboardTag(HOLOGRAM_TAG);
        });
        this.holograms.put(pos, stand.getUniqueId());
    }

    private void removeHologram(BlockPos pos) {
        UUID id = this.holograms.remove(pos);
        if (id == null) {
            return;
        }
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null) {
            return;
        }
        world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(id)).forEach(Entity::remove);
    }

    private void spawnDisplay(Block block, CustomBlockDefinition def, float yawDegrees) {
        if (block == null || def == null) {
            return;
        }
        BlockPos pos = BlockPos.of(block);
        this.removeDisplay(pos);
        this.purgeDisplayEntities(block.getWorld(), pos);
        ItemStack displayItem = this.createDisplayItem(def);
        if (displayItem == null) {
            return;
        }
        Location loc = block.getLocation().add(0.5, this.displayOffset, 0.5);
        ItemDisplay display = (ItemDisplay)block.getWorld().spawn(loc, ItemDisplay.class, d -> {
            d.setItemStack(displayItem);
            d.setBillboard(Display.Billboard.FIXED);
            try {
                d.getClass().getMethod("setItemDisplayTransform", ItemDisplay.ItemDisplayTransform.class).invoke(d, ItemDisplay.ItemDisplayTransform.FIXED);
            }
            catch (Exception exception) {
                // empty catch block
            }
            float yawRad = (float)Math.toRadians(yawDegrees);
            Quaternionf rotation = new Quaternionf().rotateY(yawRad);
            d.setTransformation(new Transformation(new Vector3f(0.0f, 0.0f, 0.0f), rotation, new Vector3f(1.01f, 1.01f, 1.01f), new Quaternionf()));
            d.setPersistent(true);
            d.setInvulnerable(true);
            d.setGravity(false);
            d.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, def.id());
            d.addScoreboardTag(ENTITY_TAG);
            d.addScoreboardTag(DISPLAY_TAG);
        });
        try {
            Method h = display.getClass().getMethod("setInteractionHeight", Float.TYPE);
            Method w = display.getClass().getMethod("setInteractionWidth", Float.TYPE);
            h.invoke((Object)display, Float.valueOf(0.0f));
            w.invoke((Object)display, Float.valueOf(0.0f));
            try {
                Method c = display.getClass().getMethod("setCollidable", Boolean.TYPE);
                c.invoke((Object)display, false);
            }
            catch (NoSuchMethodException noSuchMethodException) {}
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.displays.put(pos, display.getUniqueId());
    }

    private void removeDisplay(BlockPos pos) {
        UUID id = this.displays.remove(pos);
        if (id == null) {
            return;
        }
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null) {
            return;
        }
        world.getEntitiesByClass(ItemDisplay.class).stream().filter(d -> d.getUniqueId().equals(id)).forEach(Entity::remove);
    }

    private void purgeHologramEntities(@Nullable World world, BlockPos pos) {
        if (world == null) {
            return;
        }
        double expectedY = pos.y() + this.hologramOffset;
        for (ArmorStand stand : world.getEntitiesByClass(ArmorStand.class)) {
            if (!this.isCustomBlockVisual(stand)) {
                continue;
            }
            if (!this.isVisualAt(stand.getLocation(), pos, expectedY)) {
                continue;
            }
            if (!stand.getScoreboardTags().contains(HOLOGRAM_TAG) && !this.hasCustomBlockId(stand)) {
                continue;
            }
            stand.remove();
        }
    }

    private void purgeDisplayEntities(@Nullable World world, BlockPos pos) {
        if (world == null) {
            return;
        }
        double expectedY = pos.y() + this.displayOffset;
        for (ItemDisplay display : world.getEntitiesByClass(ItemDisplay.class)) {
            if (!this.isCustomBlockVisual(display)) {
                continue;
            }
            if (!this.isVisualAt(display.getLocation(), pos, expectedY)) {
                continue;
            }
            if (!display.getScoreboardTags().contains(DISPLAY_TAG) && !this.hasCustomBlockId(display)) {
                continue;
            }
            display.remove();
        }
    }

    private boolean isCustomBlockVisual(Entity entity) {
        return entity != null && (entity.getScoreboardTags().contains(ENTITY_TAG) || this.hasCustomBlockId(entity));
    }

    private boolean hasCustomBlockId(Entity entity) {
        return entity != null && entity.getPersistentDataContainer().has(this.itemKey, PersistentDataType.STRING);
    }

    private boolean isVisualAt(@Nullable Location location, BlockPos pos, double expectedY) {
        if (location == null || location.getWorld() == null) {
            return false;
        }
        if (!location.getWorld().getName().equals(pos.world())) {
            return false;
        }
        if (location.getBlockX() != pos.x() || location.getBlockY() != pos.y() || location.getBlockZ() != pos.z()) {
            return false;
        }
        return Math.abs(location.getY() - expectedY) < 0.2;
    }

    private void updateVisualLabels(BlockPos pos, CustomBlockDefinition def) {
        if (this.lockboxService != null && this.lockboxService.isLockboxId(def.id())) {
            this.updateTaskLabel(pos, def);
            this.updateProgressLabel(pos, def);
        } else {
            this.updateStatusLabel(pos, def);
            this.removeTaskLabel(pos);
            this.removeProgressLabel(pos);
        }
    }

    private void updateStatusLabel(BlockPos pos, CustomBlockDefinition def) {
        Long until;
        Block block = this.loadedBlockAt(pos);
        if (block == null || def == null) {
            return;
        }
        UUID existingId = this.statusLabels.get(pos);
        ArmorStand stand = null;
        if (existingId != null) {
            World world = block.getWorld();
            for (ArmorStand as2 : world.getEntitiesByClass(ArmorStand.class)) {
                if (!as2.getUniqueId().equals(existingId)) continue;
                stand = as2;
                break;
            }
        }
        this.purgeStatusLabelEntities(block.getWorld(), pos, stand == null ? null : stand.getUniqueId());
        if (stand == null) {
            Location loc = block.getLocation().add(0.5, this.statusOffset, 0.5);
            stand = (ArmorStand)block.getWorld().spawn(loc, ArmorStand.class, as -> {
                as.setInvisible(true);
                as.setMarker(true);
                as.setGravity(false);
                as.setSmall(true);
                as.setCustomNameVisible(true);
                as.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, def.id());
                as.addScoreboardTag(ENTITY_TAG);
                as.addScoreboardTag(STATUS_TAG);
            });
            this.statusLabels.put(pos, stand.getUniqueId());
        }
        boolean ready = (until = this.effectiveCooldown(pos, def)) == null;
        stand.setCustomName(Text.color(ready ? this.statusReadyText : this.statusCooldownText));
    }

    private void updateTaskLabel(BlockPos pos, CustomBlockDefinition def) {
        Block block = this.loadedBlockAt(pos);
        if (block == null || def == null || this.lockboxService == null) {
            return;
        }
        UUID existingId = this.taskLabels.get(pos);
        ArmorStand stand = null;
        if (existingId != null) {
            World world = block.getWorld();
            for (ArmorStand as2 : world.getEntitiesByClass(ArmorStand.class)) {
                if (!as2.getUniqueId().equals(existingId)) continue;
                stand = as2;
                break;
            }
        }
        this.purgeTaskLabelEntities(block.getWorld(), pos, stand == null ? null : stand.getUniqueId());
        if (stand == null) {
            Location loc = block.getLocation().add(0.5, this.statusOffset, 0.5);
            stand = (ArmorStand)block.getWorld().spawn(loc, ArmorStand.class, as -> {
                as.setInvisible(true);
                as.setMarker(true);
                as.setGravity(false);
                as.setSmall(true);
                as.setCustomNameVisible(true);
                as.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, def.id());
                as.addScoreboardTag(ENTITY_TAG);
                as.addScoreboardTag(TASK_TAG);
            });
            this.taskLabels.put(pos, stand.getUniqueId());
        }
        stand.setCustomName(Text.color(this.lockboxService.taskText(pos)));
    }

    private void updateProgressLabel(BlockPos pos, CustomBlockDefinition def) {
        Block block = this.loadedBlockAt(pos);
        if (block == null || def == null || this.lockboxService == null) {
            return;
        }
        UUID existingId = this.progressLabels.get(pos);
        ArmorStand stand = null;
        if (existingId != null) {
            World world = block.getWorld();
            for (ArmorStand as2 : world.getEntitiesByClass(ArmorStand.class)) {
                if (!as2.getUniqueId().equals(existingId)) continue;
                stand = as2;
                break;
            }
        }
        this.purgeProgressLabelEntities(block.getWorld(), pos, stand == null ? null : stand.getUniqueId());
        if (stand == null) {
            Location loc = block.getLocation().add(0.5, this.lockboxProgressOffset, 0.5);
            stand = (ArmorStand)block.getWorld().spawn(loc, ArmorStand.class, as -> {
                as.setInvisible(true);
                as.setMarker(true);
                as.setGravity(false);
                as.setSmall(true);
                as.setCustomNameVisible(true);
                as.getPersistentDataContainer().set(this.itemKey, PersistentDataType.STRING, def.id());
                as.addScoreboardTag(ENTITY_TAG);
                as.addScoreboardTag(PROGRESS_TAG);
            });
            this.progressLabels.put(pos, stand.getUniqueId());
        }
        stand.setCustomName(Text.color(this.lockboxService.progressText(pos)));
    }

    private void removeStatusLabel(BlockPos pos) {
        UUID id = this.statusLabels.remove(pos);
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null) {
            return;
        }
        this.purgeStatusLabelEntities(world, pos);
        if (id != null) {
            world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(id)).forEach(Entity::remove);
        }
    }

    private void removeTaskLabel(BlockPos pos) {
        UUID id = this.taskLabels.remove(pos);
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null) {
            return;
        }
        this.purgeTaskLabelEntities(world, pos);
        if (id != null) {
            world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(id)).forEach(Entity::remove);
        }
    }

    private void removeProgressLabel(BlockPos pos) {
        UUID id = this.progressLabels.remove(pos);
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null) {
            return;
        }
        this.purgeProgressLabelEntities(world, pos);
        if (id != null) {
            world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(id)).forEach(Entity::remove);
        }
    }

    private void purgeStatusLabelEntities(@Nullable World world, BlockPos pos) {
        this.purgeStatusLabelEntities(world, pos, null);
    }

    private void purgeTaskLabelEntities(@Nullable World world, BlockPos pos) {
        this.purgeTaskLabelEntities(world, pos, null);
    }

    private void purgeProgressLabelEntities(@Nullable World world, BlockPos pos) {
        this.purgeProgressLabelEntities(world, pos, null);
    }

    private void purgeStatusLabelEntities(@Nullable World world, BlockPos pos, @Nullable UUID keepId) {
        this.purgeLabelEntities(world, pos, this.statusOffset, STATUS_TAG, keepId);
    }

    private void purgeTaskLabelEntities(@Nullable World world, BlockPos pos, @Nullable UUID keepId) {
        this.purgeLabelEntities(world, pos, this.statusOffset, TASK_TAG, keepId);
    }

    private void purgeProgressLabelEntities(@Nullable World world, BlockPos pos, @Nullable UUID keepId) {
        this.purgeLabelEntities(world, pos, this.lockboxProgressOffset, PROGRESS_TAG, keepId);
    }

    private void purgeLabelEntities(@Nullable World world, BlockPos pos, double expectedY, String tag, @Nullable UUID keepId) {
        if (world == null) {
            return;
        }
        for (ArmorStand stand : world.getEntitiesByClass(ArmorStand.class)) {
            if (!this.isCustomBlockVisual(stand)) {
                continue;
            }
            if (!this.isVisualAt(stand.getLocation(), pos, expectedY)) {
                continue;
            }
            if (keepId != null && keepId.equals(stand.getUniqueId())) {
                continue;
            }
            if (!stand.getScoreboardTags().contains(tag) && !this.hasCustomBlockId(stand)) {
                continue;
            }
            stand.remove();
        }
    }

    private void applyState(Block block, CustomBlockDefinition def) {
        if (!this.useNoteState || !def.applyNoteState()) {
            return;
        }
        if (block == null || def == null) {
            return;
        }
        if (def.placedMaterial() != Material.NOTE_BLOCK) {
            return;
        }
        NoteState state = def.noteState();
        if (state == null && def.customModelData() >= 0) {
            state = this.derivedStateFromModel(def.customModelData());
        }
        if (state == null) {
            return;
        }
        try {
            NoteBlock data = (NoteBlock)Bukkit.createBlockData((Material)Material.NOTE_BLOCK);
            data.setInstrument(state.instrument());
            data.setNote(new Note(Math.max(0, Math.min(24, state.note()))));
            data.setPowered(state.powered());
            block.setBlockData((BlockData)data, false);
            block.getState().update(true, false);
        }
        catch (ClassCastException classCastException) {
            // empty catch block
        }
    }

    private NoteState derivedStateFromModel(int customModelData) {
        Instrument[] instruments = (Instrument[])Arrays.stream(Instrument.values()).filter(i -> i != Instrument.CUSTOM_HEAD).toArray(Instrument[]::new);
        if (instruments.length == 0) {
            return null;
        }
        int idx = Math.max(0, customModelData);
        Instrument instrument = instruments[idx / 25 % instruments.length];
        int note = idx % 25;
        return new NoteState(instrument, note, false);
    }

    private void startStatusTask() {
        this.statusTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this.plugin, () -> {
            for (Map.Entry<BlockPos, String> entry : this.placedBlocks.entrySet()) {
                BlockPos pos = entry.getKey();
                CustomBlockDefinition def = this.definitions.get(entry.getValue());
                if (def == null) continue;
                if (!this.isChunkLoaded(pos)) continue;
                this.effectiveCooldown(pos, def);
                this.updateVisualLabels(pos, def);
            }
        }, 20L, 20L);
    }

    private String formatDuration(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        long days = totalSeconds / 86400L;
        long hours = totalSeconds % 86400L / 3600L;
        long minutes = totalSeconds % 3600L / 60L;
        long seconds = totalSeconds % 60L;
        StringBuilder sb = new StringBuilder();
        if (days > 0L) {
            sb.append(days).append("d ");
        }
        if (hours > 0L || days > 0L) {
            sb.append(hours).append("h ");
        }
        if (minutes > 0L || hours > 0L || days > 0L) {
            sb.append(minutes).append("m ");
        }
        sb.append(seconds).append("s");
        return sb.toString().trim();
    }

    private void giveOrDrop(Player player, ItemStack item, Location dropLoc) {
        if (item == null || dropLoc == null) {
            return;
        }
        dropLoc.getWorld().dropItemNaturally(dropLoc, item);
    }

    private void reinforceInventoryCooldown(Player player, String id, String nonce, long cooldownUntil) {
        if (player == null) {
            return;
        }
        this.ensureInventoryItemHasCooldownNow(player, id, nonce, cooldownUntil);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.ensureInventoryItemHasCooldownNow(player, id, nonce, cooldownUntil));
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.ensureInventoryItemHasCooldownNow(player, id, nonce, cooldownUntil), 2L);
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.ensureInventoryItemHasCooldownNow(player, id, nonce, cooldownUntil), 5L);
    }

    private void ensureInventoryItemHasCooldownNow(Player player, String id, String nonce, long cooldownUntil) {
        if (player == null) {
            return;
        }
        for (ItemStack stack : player.getInventory().getContents()) {
            Long existing;
            String stackId;
            if (stack == null || (stackId = this.getId(stack)) == null || !stackId.equalsIgnoreCase(id)) continue;
            String stackNonce = this.getNonce(stack);
            if (nonce != null && stackNonce != null && !stackNonce.equals(nonce) || (existing = this.getItemCooldown(stack)) != null && existing >= cooldownUntil) continue;
            this.ensureStackHasCooldown(stack, cooldownUntil);
        }
    }

    private void ensureStackHasCooldown(ItemStack stack, Long cooldownUntil) {
        if (stack == null || cooldownUntil == null) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return;
        }
        meta.getPersistentDataContainer().set(this.itemCooldownKey, PersistentDataType.LONG, cooldownUntil);
        if (!meta.getPersistentDataContainer().has(this.itemNonceKey, PersistentDataType.STRING)) {
            meta.getPersistentDataContainer().set(this.itemNonceKey, PersistentDataType.STRING, UUID.randomUUID().toString());
        }
        this.applyGlint(meta);
        stack.setItemMeta(meta);
    }

    private void applyGlint(ItemMeta meta) {
        if (meta == null) {
            return;
        }
        boolean applied = false;
        try {
            Method method = meta.getClass().getMethod("setEnchantmentGlintOverride", Boolean.class);
            method.invoke((Object)meta, Boolean.TRUE);
            applied = true;
        }
        catch (Exception method) {
            // empty catch block
        }
        if (!applied) {
            Enchantment glint = Enchantment.getByName((String)"UNBREAKING");
            if (glint == null) {
                glint = Enchantment.getByName((String)"DURABILITY");
            }
            if (glint == null) {
                glint = Enchantment.getByName((String)"PROTECTION_ENVIRONMENTAL");
            }
            if (glint != null && !meta.hasEnchant(glint)) {
                meta.addEnchant(glint, 1, true);
            }
        }
    }

    private Material parseMaterial(String raw, Material fallback) {
        if (raw == null) {
            return fallback;
        }
        Material mat = Material.matchMaterial((String)raw);
        return mat == null ? fallback : mat;
    }

    private String getId(ItemStack stack) {
        if (stack == null) {
            return null;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        return (String)meta.getPersistentDataContainer().get(this.itemKey, PersistentDataType.STRING);
    }

    private Long getItemCooldown(ItemStack stack) {
        if (stack == null) {
            return null;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        Long val = (Long)meta.getPersistentDataContainer().get(this.itemCooldownKey, PersistentDataType.LONG);
        if (val == null) {
            return null;
        }
        return val > 0L ? val : null;
    }

    private String getNonce(ItemStack stack) {
        if (stack == null) {
            return null;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        return (String)meta.getPersistentDataContainer().get(this.itemNonceKey, PersistentDataType.STRING);
    }

    private ItemStack createDisplayItem(CustomBlockDefinition def) {
        Material mat;
        Material material = mat = def.displayItemMaterial() != null ? def.displayItemMaterial() : def.itemMaterial();
        if (mat == null) {
            return null;
        }
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            int cmd;
            meta.setDisplayName(Text.color(def.displayName()));
            int n = cmd = def.displayCustomModelData() >= 0 ? def.displayCustomModelData() : def.customModelData();
            if (cmd > 0) {
                meta.setCustomModelData(Integer.valueOf(cmd));
            }
            this.applyGlint(meta);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
            item.setItemMeta(meta);
        }
        return item;
    }

    private BlockAction parseAction(@Nullable ConfigurationSection section) {
        if (section == null) {
            return null;
        }
        ActionType type = ActionType.from(section.getString("type"));
        if (type == null) {
            return null;
        }
        int amount = section.getInt("amount", 0);
        double multiplier = section.getDouble("multiplier", 1.0);
        return new BlockAction(type, amount, multiplier);
    }

    private NoteState parseNoteState(@Nullable ConfigurationSection section) {
        if (section == null) {
            return null;
        }
        String rawInstr = section.getString("instrument");
        Integer rawNote = section.getInt("note", 0);
        boolean powered = section.getBoolean("powered", false);
        Instrument instr = null;
        if (rawInstr != null) {
            try {
                instr = Instrument.valueOf((String)rawInstr.toUpperCase(Locale.ROOT));
            }
            catch (IllegalArgumentException illegalArgumentException) {
                // empty catch block
            }
        }
        if (instr == null) {
            instr = Instrument.PIANO;
        }
        int note = Math.max(0, Math.min(24, rawNote));
        return new NoteState(instr, note, powered);
    }

    private Block blockAt(BlockPos pos) {
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null) {
            return null;
        }
        return world.getBlockAt(pos.x(), pos.y(), pos.z());
    }

    private Block loadedBlockAt(BlockPos pos) {
        World world = Bukkit.getWorld((String)pos.world());
        if (world == null || !world.isChunkLoaded(pos.chunkX(), pos.chunkZ())) {
            return null;
        }
        return world.getBlockAt(pos.x(), pos.y(), pos.z());
    }

    private boolean isChunkLoaded(BlockPos pos) {
        World world = Bukkit.getWorld((String)pos.world());
        return world != null && world.isChunkLoaded(pos.chunkX(), pos.chunkZ());
    }

    private String stringVal(Object obj) {
        String s;
        return obj instanceof String ? (s = (String)obj) : null;
    }

    private Integer intVal(Object obj) {
        Integer n;
        if (obj instanceof Number) {
            Number n2 = (Number)obj;
            n = n2.intValue();
        } else {
            n = null;
        }
        return n;
    }

    private Long longVal(Object obj) {
        Long l;
        if (obj instanceof Number) {
            Number n = (Number)obj;
            l = n.longValue();
        } else {
            l = null;
        }
        return l;
    }

    private Float floatVal(Object obj) {
        Float f;
        if (obj instanceof Number) {
            Number n = (Number)obj;
            f = Float.valueOf(n.floatValue());
        } else {
            f = null;
        }
        return f;
    }

    private float normalizeYaw(float yaw) {
        float snapped;
        float norm = yaw % 360.0f;
        if (norm < 0.0f) {
            norm += 360.0f;
        }
        if ((snapped = (float)Math.round(norm / 90.0f) * 90.0f) >= 360.0f) {
            snapped -= 360.0f;
        }
        return snapped;
    }

    private boolean isCustomBlock(Block block) {
        if (block == null) {
            return false;
        }
        return this.placedBlocks.containsKey(BlockPos.of(block));
    }

    public record BlockPos(String world, int x, int y, int z) {
        static BlockPos of(@NotNull Block block) {
            return new BlockPos(block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
        }

        int chunkX() {
            return this.x >> 4;
        }

        int chunkZ() {
            return this.z >> 4;
        }
    }

    public record CustomBlockDefinition(String id, Material itemMaterial, Material placedMaterial, int customModelData, String displayName, List<String> lore, String hologramText, Trigger trigger, BlockAction action, long cooldownSeconds, String cooldownMessage, boolean dropOnBreak, boolean spawnDisplay, Material displayItemMaterial, int displayCustomModelData, boolean applyNoteState, NoteState noteState) {
    }

    public static enum Trigger {
        RIGHT_CLICK,
        LEFT_CLICK;


        public boolean matches(Action action) {
            return this == RIGHT_CLICK && action == Action.RIGHT_CLICK_BLOCK || this == LEFT_CLICK && action == Action.LEFT_CLICK_BLOCK;
        }

        public static Trigger from(String raw) {
            if (raw == null) {
                return RIGHT_CLICK;
            }
            try {
                return Trigger.valueOf(raw.toUpperCase(Locale.ROOT));
            }
            catch (IllegalArgumentException ex) {
                return RIGHT_CLICK;
            }
        }
    }

    public record BlockAction(ActionType type, int amount, double multiplier) {
    }

    public record NoteState(Instrument instrument, int note, boolean powered) {
    }

    public static enum ActionType {
        GIVE_RAW_CHARGE,
        GIVE_MONEY,
        ACTIVATE_XP_BOOST,
        ACTIVATE_BEACH_BALL,
        ACTIVATE_MINI_PALM_TREE;


        @Nullable
        public static ActionType from(String raw) {
            if (raw == null) {
                return null;
            }
            try {
                return ActionType.valueOf(raw.toUpperCase(Locale.ROOT));
            }
            catch (IllegalArgumentException ex) {
                return null;
            }
        }
    }
}
