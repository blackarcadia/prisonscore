package org.axial.prisonsCore.service;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class RaidPointService {
    private final PrisonsCore plugin;
    private final PlayerDataService playerDataService;
    private final NamespacedKey voucherKey;
    private Material voucherMaterial = Material.PAPER;
    private String voucherDisplay = "&c&lRaid Points";
    private List<String> voucherLore = List.of(
            "&7Right-click to redeem these raid points.",
            "",
            "&f&lValue",
            "&c{amount}"
    );

    public RaidPointService(PrisonsCore plugin, PlayerDataService playerDataService) {
        this.plugin = plugin;
        this.playerDataService = playerDataService;
        this.voucherKey = Keys.raidPointVoucher(plugin);
        this.reload();
    }

    public void reload() {
        File file = new File(this.plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = cfg.getConfigurationSection("items.raid-points");
        if (section == null) {
            return;
        }
        Material configured = Material.matchMaterial(section.getString("material", "PAPER"));
        if (configured != null) {
            this.voucherMaterial = configured;
        }
        this.voucherDisplay = section.getString("display-name", this.voucherDisplay);
        List<String> configuredLore = section.getStringList("lore");
        if (configuredLore != null && !configuredLore.isEmpty()) {
            this.voucherLore = configuredLore;
        }
    }

    public ItemStack createRaidPointNote(int amount) {
        ItemStack stack = new ItemStack(this.voucherMaterial);
        ItemMeta meta = stack.getItemMeta();
        String formatted = String.format(Locale.ENGLISH, "%,d", Math.max(1, amount));
        meta.setDisplayName(Text.color(this.voucherDisplay.replace("{amount}", formatted)));
        meta.setLore(this.voucherLore.stream().map(line -> line.replace("{amount}", formatted)).map(Text::color).collect(Collectors.toList()));
        meta.getPersistentDataContainer().set(this.voucherKey, PersistentDataType.INTEGER, Math.max(1, amount));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isRaidPointNote(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(this.voucherKey, PersistentDataType.INTEGER);
    }

    public int getAmount(ItemStack item) {
        if (!this.isRaidPointNote(item)) {
            return 0;
        }
        Integer amount = item.getItemMeta().getPersistentDataContainer().get(this.voucherKey, PersistentDataType.INTEGER);
        return amount == null ? 0 : Math.max(0, amount);
    }

    public int getBalance(Player player) {
        if (player == null) {
            return 0;
        }
        return this.playerDataService.get(player.getUniqueId()).getRaidPoints();
    }

    public boolean hasPoints(Player player, int amount) {
        return player != null && amount > 0 && this.getBalance(player) >= amount;
    }

    public void addPoints(Player player, int amount) {
        if (player == null || amount <= 0) {
            return;
        }
        this.playerDataService.update(player.getUniqueId(), data -> data.addRaidPoints(amount));
    }

    public boolean withdrawPoints(Player player, int amount) {
        if (!this.hasPoints(player, amount)) {
            return false;
        }
        this.playerDataService.update(player.getUniqueId(), data -> data.setRaidPoints(data.getRaidPoints() - amount));
        return true;
    }

    public void giveRaidPointNote(Player player, int amount) {
        if (player == null || amount <= 0) {
            return;
        }
        ItemStack note = this.createRaidPointNote(amount);
        PlayerInventory inventory = player.getInventory();
        Map<Integer, ItemStack> leftover = inventory.addItem(note);
        if (this.plugin.getStashService() != null) {
            leftover.values().forEach(stack -> this.plugin.getStashService().giveOrStash(player, stack));
            return;
        }
        leftover.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
    }

    public String format(int amount) {
        return String.format(Locale.ENGLISH, "%,d", Math.max(0, amount));
    }
}
