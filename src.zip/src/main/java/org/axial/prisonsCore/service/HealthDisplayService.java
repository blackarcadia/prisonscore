/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.scoreboard.DisplaySlot
 *  org.bukkit.scoreboard.Objective
 *  org.bukkit.scoreboard.Scoreboard
 */
package org.axial.prisonsCore.service;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;

public class HealthDisplayService {
    private final PrisonsCore plugin;
    private Scoreboard board;
    private Objective healthObj;

    public HealthDisplayService(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        this.board = Bukkit.getScoreboardManager().getMainScoreboard();
        this.healthObj = this.board.getObjective("pc_health");
        if (this.healthObj != null) {
            this.healthObj.unregister();
        }
        this.healthObj = this.board.registerNewObjective("pc_health", "health", Text.color("&c\u2764"));
        this.healthObj.setDisplaySlot(DisplaySlot.BELOW_NAME);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.setScoreboard(this.board);
        }
    }

    public void stop() {
        if (this.healthObj != null) {
            this.healthObj.unregister();
            this.healthObj = null;
        }
    }
}

