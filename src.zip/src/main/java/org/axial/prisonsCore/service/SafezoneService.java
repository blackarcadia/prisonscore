package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class SafezoneService {
    private final PrisonsCore plugin;
    private final Map<String, Safezone> safezones = new LinkedHashMap<>();
    private final Map<UUID, Selection> selections = new LinkedHashMap<>();
    private File file;
    private YamlConfiguration cfg;

    public SafezoneService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.reload();
    }

    public void reload() {
        this.safezones.clear();
        this.file = new File(this.plugin.getDataFolder(), "safezones.yml");
        if (!this.file.exists()) {
            this.cfg = new YamlConfiguration();
            this.save();
        } else {
            this.cfg = YamlConfiguration.loadConfiguration(this.file);
        }
        ConfigurationSection section = this.cfg.getConfigurationSection("safezones");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection node = section.getConfigurationSection(key);
            if (node == null) {
                continue;
            }
            String worldName = node.getString("world");
            Location pos1 = new Location(null, node.getDouble("x1"), node.getDouble("y1"), node.getDouble("z1"));
            Location pos2 = new Location(null, node.getDouble("x2"), node.getDouble("y2"), node.getDouble("z2"));
            this.safezones.put(key.toLowerCase(Locale.ROOT), new Safezone(key, worldName, pos1, pos2));
        }
    }

    public void save() {
        if (this.cfg == null) {
            this.cfg = new YamlConfiguration();
        }
        this.cfg.set("safezones", null);
        for (Safezone safezone : this.safezones.values()) {
            String base = "safezones." + safezone.id();
            this.cfg.set(base + ".world", safezone.world());
            this.cfg.set(base + ".x1", safezone.minX());
            this.cfg.set(base + ".y1", safezone.minY());
            this.cfg.set(base + ".z1", safezone.minZ());
            this.cfg.set(base + ".x2", safezone.maxX());
            this.cfg.set(base + ".y2", safezone.maxY());
            this.cfg.set(base + ".z2", safezone.maxZ());
        }
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save safezones.yml: " + e.getMessage());
        }
    }

    public Selection getSelection(UUID uuid) {
        return this.selections.computeIfAbsent(uuid, ignored -> new Selection());
    }

    public void setPos1(UUID uuid, Location loc) {
        this.getSelection(uuid).setPos1(this.toBlockLocation(loc));
    }

    public void setPos2(UUID uuid, Location loc) {
        this.getSelection(uuid).setPos2(this.toBlockLocation(loc));
    }

    public boolean createSafezone(String id, Selection selection) {
        if (id == null || id.isBlank() || selection == null || !selection.isComplete()) {
            return false;
        }
        this.safezones.put(id.toLowerCase(Locale.ROOT), new Safezone(id, selection.getPos1(), selection.getPos2()));
        this.save();
        return true;
    }

    public boolean deleteSafezone(String id) {
        if (id == null) {
            return false;
        }
        Safezone removed = this.safezones.remove(id.toLowerCase(Locale.ROOT));
        if (removed == null) {
            return false;
        }
        this.save();
        return true;
    }

    public Collection<Safezone> getSafezones() {
        return this.safezones.values();
    }

    public boolean isInSafezone(Location location) {
        return this.getSafezoneAt(location) != null;
    }

    public Safezone getSafezoneAt(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        for (Safezone safezone : this.safezones.values()) {
            if (safezone.contains(location)) {
                return safezone;
            }
        }
        return null;
    }

    public ItemStack createWand() {
        ItemStack item = new ItemStack(Material.GOLDEN_HOE);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&b&lSafezone Wand"));
            meta.setLore(java.util.List.of(
                    Text.color("&7Left click a block to set &fpos1"),
                    Text.color("&7Right click a block to set &fpos2"),
                    Text.color("&7Use &f/safezone create <id> &7to save")
            ));
            meta.getPersistentDataContainer().set(Keys.safezoneWand(this.plugin), PersistentDataType.BYTE, (byte)1);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isWand(ItemStack stack) {
        return stack != null
                && stack.hasItemMeta()
                && stack.getItemMeta().getPersistentDataContainer().has(Keys.safezoneWand(this.plugin), PersistentDataType.BYTE);
    }

    private Location toBlockLocation(Location location) {
        return location == null ? null : location.getBlock().getLocation();
    }

    public static class Selection {
        private Location pos1;
        private Location pos2;

        public Location getPos1() {
            return this.pos1;
        }

        public Location getPos2() {
            return this.pos2;
        }

        public void setPos1(Location pos1) {
            this.pos1 = pos1;
        }

        public void setPos2(Location pos2) {
            this.pos2 = pos2;
        }

        public boolean isComplete() {
            return this.pos1 != null && this.pos2 != null;
        }
    }

    public static class Safezone {
        private final String id;
        private final String world;
        private final int minX;
        private final int minY;
        private final int minZ;
        private final int maxX;
        private final int maxY;
        private final int maxZ;

        public Safezone(String id, Location pos1, Location pos2) {
            this(id, pos1 != null && pos1.getWorld() != null ? pos1.getWorld().getName() : pos2 != null && pos2.getWorld() != null ? pos2.getWorld().getName() : null, pos1, pos2);
        }

        public Safezone(String id, String world, Location pos1, Location pos2) {
            this.id = id;
            this.world = world;
            this.minX = Math.min(pos1.getBlockX(), pos2.getBlockX());
            this.minY = Math.min(pos1.getBlockY(), pos2.getBlockY());
            this.minZ = Math.min(pos1.getBlockZ(), pos2.getBlockZ());
            this.maxX = Math.max(pos1.getBlockX(), pos2.getBlockX());
            this.maxY = Math.max(pos1.getBlockY(), pos2.getBlockY());
            this.maxZ = Math.max(pos1.getBlockZ(), pos2.getBlockZ());
        }

        public boolean contains(Location location) {
            return location != null
                    && location.getWorld() != null
                    && this.world != null
                    && this.world.equals(location.getWorld().getName())
                    && location.getBlockX() >= this.minX && location.getBlockX() <= this.maxX
                    && location.getBlockY() >= this.minY && location.getBlockY() <= this.maxY
                    && location.getBlockZ() >= this.minZ && location.getBlockZ() <= this.maxZ;
        }

        public String id() {
            return this.id;
        }

        public String world() {
            return this.world;
        }

        public int minX() {
            return this.minX;
        }

        public int minY() {
            return this.minY;
        }

        public int minZ() {
            return this.minZ;
        }

        public int maxX() {
            return this.maxX;
        }

        public int maxY() {
            return this.maxY;
        }

        public int maxZ() {
            return this.maxZ;
        }
    }
}
