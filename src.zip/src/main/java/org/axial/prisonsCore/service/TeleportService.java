/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Particle
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class TeleportService {
    private final PrisonsCore plugin;
    private final PlayerLevelService playerLevelService;
    private final Map<UUID, TeleportRequest> pendingTpa = new ConcurrentHashMap<UUID, TeleportRequest>();
    private final Map<UUID, TeleportTask> pendingTeleports = new ConcurrentHashMap<UUID, TeleportTask>();
    private final Set<UUID> tpaToggled = ConcurrentHashMap.newKeySet();
    private int delaySeconds;

    public TeleportService(PrisonsCore plugin, PlayerLevelService playerLevelService) {
        this.plugin = plugin;
        this.playerLevelService = playerLevelService;
        this.load();
    }

    public void load() {
        this.loadConfig();
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "teleport.yml");
        if (!file.exists()) {
            this.plugin.saveResource("teleport.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        this.delaySeconds = cfg.getInt("delay-seconds", 20);
    }

    public void save() {
    }

    public void setWarp(String name, Location loc) {
    }

    public Location getWarp(String name) {
        return FixedTeleportLocations.getWarp(name);
    }

    public Set<String> getWarpNames() {
        return FixedTeleportLocations.getWarpNames();
    }

    public void setSpawn(Location loc) {
    }

    public Location getSpawn() {
        return FixedTeleportLocations.getSpawn();
    }

    public boolean isTpaToggled(UUID playerId) {
        return this.tpaToggled.contains(playerId);
    }

    public void toggleTpa(UUID playerId) {
        if (!this.tpaToggled.add(playerId)) {
            this.tpaToggled.remove(playerId);
        }
    }

    public boolean sendTpa(Player from, Player to) {
        if (from == null || to == null || !to.isOnline()) {
            return false;
        }
        if (this.isTpaToggled(to.getUniqueId())) {
            return false;
        }
        this.pendingTpa.put(to.getUniqueId(), new TeleportRequest(from.getUniqueId(), System.currentTimeMillis() + 60000L));
        to.sendMessage(Text.color("&e" + from.getName() + " &7has requested to teleport to you. &a/tpaccept &7or &c/tpdeny"));
        from.sendMessage(Text.color("&7TPA request sent to &e" + to.getName() + "&7."));
        return true;
    }

    public boolean accept(Player target) {
        TeleportRequest req = this.pendingTpa.remove(target.getUniqueId());
        if (req == null || System.currentTimeMillis() > req.expiresAt()) {
            target.sendMessage(Text.color("&cNo pending request."));
            return false;
        }
        Player requester = Bukkit.getPlayer((UUID)req.sender());
        if (requester == null || !requester.isOnline()) {
            target.sendMessage(Text.color("&cRequester is no longer online."));
            return false;
        }
        this.scheduleTeleport(requester, target.getLocation(), target.getName(), target.getName());
        target.sendMessage(Text.color("&aAccepted teleport request from " + requester.getName()));
        return true;
    }

    public boolean deny(Player target) {
        TeleportRequest req = this.pendingTpa.remove(target.getUniqueId());
        if (req == null || System.currentTimeMillis() > req.expiresAt()) {
            target.sendMessage(Text.color("&cNo pending request."));
            return false;
        }
        Player requester = Bukkit.getPlayer((UUID)req.sender());
        if (requester != null) {
            requester.sendMessage(Text.color("&cYour teleport request was denied."));
        }
        target.sendMessage(Text.color("&aDenied teleport request."));
        return true;
    }

    public void scheduleTeleport(Player player, Location dest) {
        this.scheduleTeleport(player, dest, null, null);
    }

    public void scheduleTeleport(Player player, Location dest, String destinationName, String targetPlayerName) {
        this.cancelTeleport(player.getUniqueId());
        TeleportTask task = new TeleportTask(player.getUniqueId(), dest, this.resolveDelaySeconds(player), destinationName, targetPlayerName);
        this.pendingTeleports.put(player.getUniqueId(), task);
        task.start();
    }

    public void cancelTeleport(UUID uuid) {
        TeleportTask t = this.pendingTeleports.remove(uuid);
        if (t != null) {
            t.cancel();
        }
    }

    public boolean hasPendingTeleport(UUID uuid) {
        return this.pendingTeleports.containsKey(uuid);
    }

    public void handleMove(UUID uuid) {
        Player p;
        TeleportTask t = this.pendingTeleports.get(uuid);
        if (t != null && (p = Bukkit.getPlayer((UUID)uuid)) != null && t.moved(p)) {
            p.sendMessage(Text.color("&cTeleport cancelled because you moved."));
            this.cancelTeleport(uuid);
        }
    }

    private String formatLocation(Location loc) {
        if (loc == null) {
            return "unknown";
        }
        return (loc.getWorld() != null ? loc.getWorld().getName() : "world") + " " + loc.getBlockX() + " " + loc.getBlockY() + " " + loc.getBlockZ();
    }

    private String templateDelay() {
        return Lang.msg("teleport.delay", "&6Teleporting you to {target} in &c{seconds}&e seconds. Don't move!");
    }

    private String templateCountdown() {
        return Lang.msg("teleport.countdown", "&eTeleporting to {target} in &c{seconds}&e seconds...");
    }

    private String templateSuccess() {
        return Lang.msg("teleport.success", "&7Teleported to &6{target}&7.");
    }

    private String templatePlayerDelay() {
        return Lang.msg("teleport.player.delay", "&eTeleporting to player {player} in &c{seconds}s. Don't move!");
    }

    private String templatePlayerCountdown() {
        return Lang.msg("teleport.player.countdown", "&eTeleporting to player {player} in &c{seconds}s...");
    }

    private String templatePlayerSuccess() {
        return Lang.msg("teleport.player.success", "&aTeleported to {player}.");
    }

    private int resolveDelaySeconds(Player player) {
        int baseDelay = Math.max(1, this.delaySeconds);
        if (player == null || this.playerLevelService == null) {
            return baseDelay;
        }
        int level = Math.max(1, this.playerLevelService.getLevel(player));
        int maxLevel = Math.max(level, this.playerLevelService.getCurrentLevelCap());
        if (maxLevel <= 1) {
            return baseDelay;
        }
        double progress = (double)(level - 1) / (double)(maxLevel - 1);
        double minimumDelay = Math.max(2.0, (double)baseDelay * 0.5);
        double resolved = (double)baseDelay - ((double)baseDelay - minimumDelay) * progress;
        return Math.max(1, (int)Math.round(resolved));
    }

    private record TeleportRequest(UUID sender, long expiresAt) {
    }

    private class TeleportTask {
        private final UUID playerId;
        private final Location target;
        private final int delay;
        private int secondsLeft;
        private BukkitTask timerTask;
        private BukkitTask particleTask;
        private Location startLoc;
        private double spiralAngle = 0.0;
        private final String destinationName;
        private final String targetPlayerName;
        private final String locString;

        TeleportTask(UUID playerId, Location target, int delay, String destinationName, String targetPlayerName) {
            this.playerId = playerId;
            this.target = target.clone();
            this.secondsLeft = this.delay = Math.max(1, delay);
            this.destinationName = destinationName;
            this.targetPlayerName = targetPlayerName;
            this.locString = TeleportService.this.formatLocation(target);
        }

        void start() {
            Player player = Bukkit.getPlayer((UUID)this.playerId);
            if (player == null) {
                return;
            }
            this.startLoc = player.getLocation().clone();
            boolean toPlayer = this.targetPlayerName != null;
            player.sendMessage(Text.color(this.applyMessage(toPlayer ? TeleportService.this.templatePlayerDelay() : TeleportService.this.templateDelay(), this.secondsLeft)));
            this.timerTask = Bukkit.getScheduler().runTaskTimer((Plugin)TeleportService.this.plugin, () -> {
                Player p = Bukkit.getPlayer((UUID)this.playerId);
                if (p == null) {
                    this.cancel();
                    return;
                }
                --this.secondsLeft;
                if (this.secondsLeft <= 0) {
                    p.teleport(this.target);
                    p.sendMessage(Text.color(this.applyMessage(toPlayer ? TeleportService.this.templatePlayerSuccess() : TeleportService.this.templateSuccess(), 0)));
                    this.cancel();
                    TeleportService.this.pendingTeleports.remove(this.playerId);
                    return;
                }
                p.sendMessage(Text.color(this.applyMessage(toPlayer ? TeleportService.this.templatePlayerCountdown() : TeleportService.this.templateCountdown(), this.secondsLeft)));
            }, 20L, 20L);
            this.particleTask = Bukkit.getScheduler().runTaskTimer((Plugin)TeleportService.this.plugin, () -> {
                Player p = Bukkit.getPlayer((UUID)this.playerId);
                if (p == null) {
                    return;
                }
                this.spiralAngle += 0.2617993877991494;
                double radius = 0.8;
                double y = 0.2 + this.spiralAngle / (Math.PI * 2) * 0.2;
                double x = radius * Math.cos(this.spiralAngle);
                double z = radius * Math.sin(this.spiralAngle);
                Location loc = p.getLocation().clone().add(x, y, z);
                p.getWorld().spawnParticle(Particle.FLAME, loc, 1, 0.0, 0.0, 0.0, 0.0);
            }, 0L, 2L);
        }

        boolean moved(Player player) {
            if (this.startLoc == null) {
                return false;
            }
            return this.startLoc.distanceSquared(player.getLocation()) > 0.04;
        }

        void cancel() {
            if (this.timerTask != null) {
                this.timerTask.cancel();
            }
            if (this.particleTask != null) {
                this.particleTask.cancel();
            }
        }

        private String applyMessage(String template, int seconds) {
            if (template == null) {
                return "";
            }
            String msg = template.replace("{seconds}", String.valueOf(Math.max(0, seconds)));
            String targetName = this.destinationName != null ? this.destinationName : this.locString;
            msg = msg.replace("{target}", targetName);
            if (this.targetPlayerName != null) {
                msg = msg.replace("{player}", this.targetPlayerName);
            }
            msg = msg.replace("{x}", String.valueOf(this.target.getBlockX())).replace("{y}", String.valueOf(this.target.getBlockY())).replace("{z}", String.valueOf(this.target.getBlockZ())).replace("{world}", this.target.getWorld() != null ? this.target.getWorld().getName() : "world").replace("{location}", this.locString);
            return msg;
        }
    }
}
