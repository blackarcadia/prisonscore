package org.axial.prisonsCore.service;

import com.github.retrooper.packetevents.PacketEvents;
import com.github.retrooper.packetevents.protocol.entity.data.EntityData;
import com.github.retrooper.packetevents.protocol.entity.data.EntityDataTypes;
import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes;
import com.github.retrooper.packetevents.protocol.player.Equipment;
import com.github.retrooper.packetevents.protocol.player.EquipmentSlot;
import com.github.retrooper.packetevents.protocol.player.User;
import com.github.retrooper.packetevents.protocol.world.BlockFace;
import com.github.retrooper.packetevents.util.Vector3d;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDestroyEntities;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityEquipment;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityMetadata;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerEntityTeleport;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity;
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerUpdateAttributes;
import io.github.retrooper.packetevents.util.SpigotConversionUtil;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

public final class ItemAnimationService {
    private static final AtomicInteger ENTITY_ID_COUNTER = new AtomicInteger(Integer.MAX_VALUE - 100000);
    private static final double SCALE = 0.80D;

    private final PrisonsCore plugin;

    public ItemAnimationService(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public void play(Player player, Location blockLocation, Material material, BlockFace clickedFace) {
        if (player == null || blockLocation == null || material == null || clickedFace == null) {
            return;
        }
        if (!player.isOnline() || player.getWorld() == null || blockLocation.getWorld() == null) {
            return;
        }
        if (!player.getWorld().equals(blockLocation.getWorld())) {
            return;
        }
        if (!isPacketEventsEnabled()) {
            return;
        }

        new ItemAnimation(player, blockLocation, material, clickedFace).start();
    }

    public void play(Player player, Location blockLocation, Material material, org.bukkit.block.BlockFace clickedFace) {
        BlockFace packetFace = this.toPacketFace(clickedFace);
        this.play(player, blockLocation, material, packetFace);
    }

    private boolean isPacketEventsEnabled() {
        return PacketEvents.getAPI() != null
                && (this.plugin.getServer().getPluginManager().getPlugin("packetevents") != null
                || this.plugin.getServer().getPluginManager().getPlugin("PacketEvents") != null);
    }

    private BlockFace toPacketFace(org.bukkit.block.BlockFace clickedFace) {
        if (clickedFace == null) {
            return BlockFace.UP;
        }
        try {
            return BlockFace.valueOf(clickedFace.name());
        } catch (IllegalArgumentException ex) {
            return BlockFace.UP;
        }
    }

    private final class ItemAnimation {
        private final Material material;
        private final Player player;
        private final int armorStandId;
        private final UUID armorStandUUID;
        private final Vector faceDirection;
        private float yaw = 0.0f;
        private int ticks = 0;
        private Location location;

        private ItemAnimation(Player player, Location blockLocation, Material material, BlockFace clickedFace) {
            this.player = player;
            this.material = material;

            double offsetY = switch (clickedFace) {
                case UP -> -0.2D * SCALE;
                case DOWN -> -0.7D * SCALE;
                default -> -0.4D * SCALE;
            };
            offsetY += (1.0D - SCALE) * 0.5D;
            this.location = blockLocation.clone().add(0.5D, offsetY, 0.5D);

            this.armorStandUUID = UUID.randomUUID();
            this.armorStandId = ENTITY_ID_COUNTER.getAndDecrement();
            this.faceDirection = new Vector(clickedFace.getModX(), clickedFace.getModY(), clickedFace.getModZ());
        }

        private void start() {
            this.spawn();
            double speed = 1.5D;
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (ticks >= 20 || !player.isOnline() || player.getWorld() == null || !player.getWorld().equals(location.getWorld())) {
                        destroy();
                        cancel();
                        return;
                    }

                    Location target = player.getLocation().clone().add(0.0D, -0.4D, 0.0D);

                    if (ticks < 8) {
                        yaw += 13.0f;
                        location = location.clone().add(faceDirection.clone().multiply(0.1286D * speed * 0.90D));
                    } else if (ticks < 10) {
                        yaw += 8.0f;
                        Vector inward = faceDirection.clone().multiply(-0.175D * speed * 2.0D);
                        location = location.clone().add(inward);
                    } else {
                        yaw += 6.0f;
                        Vector toTarget = target.toVector().subtract(location.toVector());
                        double distance = toTarget.length();
                        if (distance < 0.5D) {
                            destroy();
                            cancel();
                            return;
                        }
                        Vector motion = toTarget.normalize().multiply(Math.min(0.4788D, distance * 1.008D) * speed * 1.5D);
                        location = location.clone().add(motion);
                    }

                    location.setYaw(yaw);
                    teleport();
                    ticks++;
                }
            }.runTaskTimer(ItemAnimationService.this.plugin, 0L, 1L);
        }

        private void spawn() {
            WrapperPlayServerSpawnEntity spawnPacket = new WrapperPlayServerSpawnEntity(
                    this.armorStandId,
                    this.armorStandUUID,
                    EntityTypes.ARMOR_STAND,
                    SpigotConversionUtil.fromBukkitLocation(this.location),
                    0.0f,
                    0,
                    Vector3d.zero()
            );

            List<EntityData> metadata = new ArrayList<>();
            metadata.add(new EntityData(0, EntityDataTypes.BYTE, (byte) 0x20));
            metadata.add(new EntityData(15, EntityDataTypes.BYTE, (byte) (0x04 | 0x10 | 0x01)));

            WrapperPlayServerEntityMetadata metaPacket = new WrapperPlayServerEntityMetadata(this.armorStandId, metadata);

            com.github.retrooper.packetevents.protocol.item.ItemStack nmsItem = com.github.retrooper.packetevents.protocol.item.ItemStack.builder()
                    .type(SpigotConversionUtil.fromBukkitItemMaterial(this.material))
                    .amount(1)
                    .build();

            List<Equipment> equipmentList = List.of(new Equipment(EquipmentSlot.HELMET, nmsItem));
            WrapperPlayServerEntityEquipment equipPacket = new WrapperPlayServerEntityEquipment(this.armorStandId, equipmentList);

            WrapperPlayServerUpdateAttributes.Property size = new WrapperPlayServerUpdateAttributes.Property(
                    com.github.retrooper.packetevents.protocol.attribute.Attributes.SCALE,
                    SCALE,
                    List.of()
            );
            WrapperPlayServerUpdateAttributes updateAttributesPacket = new WrapperPlayServerUpdateAttributes(
                    this.armorStandId,
                    List.of(size)
            );

            User user = PacketEvents.getAPI().getPlayerManager().getUser(this.player);
            if (user == null) {
                return;
            }
            user.sendPacket(spawnPacket);
            user.sendPacket(equipPacket);
            user.sendPacket(metaPacket);
            user.sendPacket(updateAttributesPacket);
        }

        private void teleport() {
            WrapperPlayServerEntityTeleport teleportPacket = new WrapperPlayServerEntityTeleport(
                    this.armorStandId,
                    SpigotConversionUtil.fromBukkitLocation(this.location),
                    false
            );
            User user = PacketEvents.getAPI().getPlayerManager().getUser(this.player);
            if (user != null) {
                user.sendPacket(teleportPacket);
            }
        }

        private void destroy() {
            WrapperPlayServerDestroyEntities destroyPacket = new WrapperPlayServerDestroyEntities(this.armorStandId);
            User user = PacketEvents.getAPI().getPlayerManager().getUser(this.player);
            if (user != null) {
                user.sendPacket(destroyPacket);
            }
            this.player.playSound(this.player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 10.0f, 1.5f);
        }
    }
}
