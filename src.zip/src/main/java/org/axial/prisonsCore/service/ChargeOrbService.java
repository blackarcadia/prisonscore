/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.service;

import java.util.List;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class ChargeOrbService {
    private static final String DEFAULT_ORB_NAME = "&a&l+{percent}% &6&lCharge Orb";
    private static final List<String> DEFAULT_ORB_LORE = List.of(
            "&6Apply this charge orb to your pickaxe to",
            "&6gain energy &a+{percent}% &6faster.",
            "&6This will remove 1 slot from your pickaxe,",
            "&6if all slots are full nothing will happen."
    );
    private final PrisonsCore plugin;
    private final NamespacedKey percentKey;
    private final NamespacedKey slotKey;
    private Material material;
    private String display;
    private List<String> lore;
    private int maxSlots;
    private Material slotMaterial = Material.NETHER_STAR;
    private String slotDisplay = "&dCharge Slot Token";
    private List<String> slotLore = List.of("&7Adds &e+1 &7charge orb slot", "&7Max 8 slots");

    public ChargeOrbService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.percentKey = Keys.chargeOrbPercent(plugin);
        this.slotKey = Keys.chargeSlotToken(plugin);
        this.loadConfig();
    }

    public ItemStack createOrb(int percent) {
        ItemStack stack = new ItemStack(this.material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(Text.color(this.display.replace("{percent}", String.valueOf(percent))));
        if (this.lore != null) {
            meta.setLore(this.lore.stream().map(l -> l.replace("{percent}", String.valueOf(percent))).map(Text::color).collect(Collectors.toList()));
        }
        meta.getPersistentDataContainer().set(this.percentKey, PersistentDataType.INTEGER, percent);
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemStack createSlotToken() {
        ItemStack stack = new ItemStack(this.slotMaterial);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(Text.color(this.slotDisplay));
        if (this.slotLore != null) {
            meta.setLore(this.slotLore.stream().map(Text::color).collect(Collectors.toList()));
        }
        meta.getPersistentDataContainer().set(this.slotKey, PersistentDataType.BYTE, (byte)1);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isChargeOrb(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.percentKey, PersistentDataType.INTEGER);
    }

    public boolean isSlotToken(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.slotKey, PersistentDataType.BYTE);
    }

    public int getPercent(ItemStack stack) {
        if (!this.isChargeOrb(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.percentKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public int getTotalPercent(ItemStack stack) {
        if (!this.isChargeOrb(stack)) {
            return 0;
        }
        return this.getPercent(stack) * Math.max(1, stack.getAmount());
    }

    public int getMaxSlots() {
        return this.maxSlots;
    }

    public Material getMaterial() {
        return this.material;
    }

    public void reload() {
        this.loadConfig();
    }

    private void loadConfig() {
        ConfigurationSection sec = this.plugin.getConfig().getConfigurationSection("charge-orb");
        if (sec != null) {
            this.material = Material.matchMaterial((String)sec.getString("material", "FIRE_CHARGE"));
            if (this.material == null) {
                this.material = Material.FIRE_CHARGE;
            }
            this.display = sec.getString("display-name", DEFAULT_ORB_NAME);
            this.lore = sec.getStringList("lore");
            if (this.lore == null || this.lore.isEmpty()) {
                this.lore = DEFAULT_ORB_LORE;
            }
            this.maxSlots = sec.getInt("max-slots", 5);
        } else {
            this.material = Material.FIRE_CHARGE;
            this.display = DEFAULT_ORB_NAME;
            this.lore = DEFAULT_ORB_LORE;
            this.maxSlots = 5;
        }
    }
}
