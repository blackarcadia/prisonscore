/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package org.axial.prisonsCore.service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class BoosterService {
    private final PrisonsCore plugin;
    private final NamespacedKey typeKey;
    private final NamespacedKey multKey;
    private final NamespacedKey durationKey;
    private final Map<UUID, ActiveBooster> xpBoosters = new HashMap<UUID, ActiveBooster>();
    private final Map<UUID, ActiveBooster> energyBoosters = new HashMap<UUID, ActiveBooster>();
    private BukkitTask cleanupTask;

    public BoosterService(PrisonsCore plugin, PlayerLevelService levelService) {
        this.plugin = plugin;
        this.typeKey = Keys.boosterType(plugin);
        this.multKey = Keys.boosterMultiplier(plugin);
        this.durationKey = Keys.boosterDurationSeconds(plugin);
    }

    public void start() {
        if (this.cleanupTask != null) {
            return;
        }
        this.cleanupTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::cleanup, 20L, 20L);
    }

    public void stop() {
        if (this.cleanupTask != null) {
            this.cleanupTask.cancel();
        }
        this.cleanupTask = null;
        this.xpBoosters.clear();
        this.energyBoosters.clear();
    }

    public ItemStack createBoosterItem(BoosterType type, int durationSeconds, double multiplier, int amount) {
        Material mat = Material.EMERALD;
        ItemStack stack = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(this.displayName(type)));
            meta.setLore(this.lore(type, multiplier, durationSeconds));
            meta.getPersistentDataContainer().set(this.typeKey, PersistentDataType.STRING, type.name());
            meta.getPersistentDataContainer().set(this.multKey, PersistentDataType.INTEGER, (int)Math.round(multiplier * 100.0));
            meta.getPersistentDataContainer().set(this.durationKey, PersistentDataType.INTEGER, durationSeconds);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public boolean isBooster(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        ItemMeta meta = stack.getItemMeta();
        return meta != null && meta.getPersistentDataContainer().has(this.typeKey, PersistentDataType.STRING);
    }

    public void activateBooster(Player player, BoosterType type, double multiplier, int durationSeconds) {
        this.activateBooster(player, type, multiplier, durationSeconds, true);
    }

    public void activateBooster(Player player, BoosterType type, double multiplier, int durationSeconds, boolean announce) {
        long expiresAt = System.currentTimeMillis() + (long)durationSeconds * 1000L;
        ActiveBooster booster = new ActiveBooster(multiplier, expiresAt);
        if (type == BoosterType.XP) {
            this.xpBoosters.put(player.getUniqueId(), booster);
        } else {
            this.energyBoosters.put(player.getUniqueId(), booster);
        }
        if (announce) {
            player.sendMessage(Text.color("&aActivated " + this.typeName(type) + " Booster &f" + this.formatMultiplier(multiplier) + " &7for &b" + this.formatDuration(durationSeconds) + "&7."));
        }
    }

    public void deactivateBooster(Player player, BoosterType type, boolean announce) {
        if (type == BoosterType.XP) {
            this.xpBoosters.remove(player.getUniqueId());
        } else {
            this.energyBoosters.remove(player.getUniqueId());
        }
        if (announce) {
            player.sendMessage(Text.color("&cYour " + this.typeName(type) + " Booster has ended."));
        }
    }

    public double getXpMultiplier(Player player) {
        return this.multiplierFor(this.xpBoosters, player);
    }

    public double getEnergyMultiplier(Player player) {
        return this.multiplierFor(this.energyBoosters, player);
    }

    public int applyXpBoost(Player player, int base) {
        double mult = this.getXpMultiplier(player);
        if (this.plugin.getGlobalBoosterService() != null) {
            mult *= this.plugin.getGlobalBoosterService().getMiningXpMultiplier();
        }
        return (int)Math.round((double)base * mult);
    }

    public int applyEnergyBoost(Player player, int base) {
        double mult = this.getEnergyMultiplier(player);
        if (this.plugin.getGlobalBoosterService() != null) {
            mult *= this.plugin.getGlobalBoosterService().getChargeMultiplier();
        }
        return (int)Math.round((double)base * mult);
    }

    public BoosterType parseType(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        String type = (String)meta.getPersistentDataContainer().get(this.typeKey, PersistentDataType.STRING);
        if (type == null) {
            return null;
        }
        try {
            return BoosterType.valueOf(type);
        }
        catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    public double readMultiplier(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return 1.0;
        }
        Integer val = (Integer)meta.getPersistentDataContainer().get(this.multKey, PersistentDataType.INTEGER);
        if (val == null) {
            return 1.0;
        }
        return (double)val.intValue() / 100.0;
    }

    public int readDuration(ItemStack stack) {
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return 0;
        }
        Integer val = (Integer)meta.getPersistentDataContainer().get(this.durationKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    private double multiplierFor(Map<UUID, ActiveBooster> map, Player player) {
        ActiveBooster booster = map.get(player.getUniqueId());
        if (booster == null) {
            return 1.0;
        }
        if (booster.expiresAt < System.currentTimeMillis()) {
            map.remove(player.getUniqueId());
            return 1.0;
        }
        return booster.multiplier;
    }

    private void cleanup() {
        long now = System.currentTimeMillis();
        this.xpBoosters.entrySet().removeIf(e -> ((ActiveBooster)e.getValue()).expiresAt < now);
        this.energyBoosters.entrySet().removeIf(e -> ((ActiveBooster)e.getValue()).expiresAt < now);
    }

    private String typeName(BoosterType type) {
        return type == BoosterType.XP ? "XP" : "Charge";
    }

    private String displayName(BoosterType type) {
        return type == BoosterType.XP ? "&r&a&lXP Booster &7(Right-Click)" : "&r&b&lCharge Booster &7(Right-Click)";
    }

    private List<String> lore(BoosterType type, double multiplier, int durationSeconds) {
        String color = type == BoosterType.XP ? "&a" : "&b";
        List<String> lore = new ArrayList<String>();
        lore.add(Text.color("&7Increase your " + (type == BoosterType.XP ? "MINING XP" : "CHARGE gain")));
        lore.add(Text.color("&7for a fixed amount of time."));
        lore.add("");
        lore.add(Text.color(color + "&lMultiplier"));
        lore.add(Text.color("&7" + this.formatMultiplier(multiplier)));
        lore.add("");
        lore.add(Text.color(color + "&lDuration"));
        lore.add(Text.color("&7" + this.formatDuration(durationSeconds)));
        return lore;
    }

    private String formatMultiplier(double mult) {
        if (mult == (double)((int)mult)) {
            return String.valueOf((int)mult) + "x";
        }
        return String.format("%.1fx", mult);
    }

    private String formatDuration(int seconds) {
        Duration d = Duration.ofSeconds(seconds);
        long mins = d.toMinutes();
        long secs = d.minusMinutes(mins).getSeconds();
        if (mins > 0L && secs == 0L) {
            return mins + "m";
        }
        if (mins > 0L) {
            return mins + "m " + secs + "s";
        }
        return secs + "s";
    }

    public static enum BoosterType {
        XP,
        ENERGY;

    }

    private record ActiveBooster(double multiplier, long expiresAt) {
    }
}
