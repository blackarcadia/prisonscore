package org.axial.prisonsCore.service;

import java.io.File;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class PrisonCoinService {
    private final PrisonsCore plugin;
    private final PlayerDataService playerDataService;
    private final org.bukkit.NamespacedKey tokenAmountKey;
    private double miningDropChance = 0.0002D;
    private int miningDropMin = 1;
    private int miningDropMax = 1;
    private boolean miningDropOresOnly = true;
    private Material tokenMaterial = Material.SUNFLOWER;
    private String tokenName = "&6{amount} &6&LPRISON COINS";
    private java.util.List<String> tokenLore = java.util.List.of(
            "&7Right-Click to redeem these coins.",
            "&7",
            "&c&lNOTE: &7These coins will be applied",
            "&7directly to your account."
    );

    public PrisonCoinService(PrisonsCore plugin, PlayerDataService playerDataService) {
        this.plugin = plugin;
        this.playerDataService = playerDataService;
        this.tokenAmountKey = Keys.prisonCoinTokenAmount(plugin);
        this.reload();
    }

    public void reload() {
        File file = new File(this.plugin.getDataFolder(), "prison-coins.yml");
        if (!file.exists()) {
            this.plugin.saveResource("prison-coins.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        this.miningDropChance = Math.max(0.0D, cfg.getDouble("mining-drop.chance", this.miningDropChance));
        this.miningDropMin = Math.max(1, cfg.getInt("mining-drop.min-amount", this.miningDropMin));
        this.miningDropMax = Math.max(this.miningDropMin, cfg.getInt("mining-drop.max-amount", this.miningDropMax));
        this.miningDropOresOnly = cfg.getBoolean("mining-drop.ores-only", this.miningDropOresOnly);
        ConfigurationSection token = cfg.getConfigurationSection("token");
        if (token != null) {
            Material configured = Material.matchMaterial(token.getString("material", this.tokenMaterial.name()));
            if (configured != null) {
                this.tokenMaterial = configured;
            }
            this.tokenName = token.getString("display-name", this.tokenName);
            java.util.List<String> configuredLore = token.getStringList("lore");
            if (configuredLore != null && !configuredLore.isEmpty()) {
                this.tokenLore = configuredLore;
            }
        }
    }

    public long getBalance(Player player) {
        return player == null ? 0L : this.playerDataService.get(player.getUniqueId()).getPrisonCoins();
    }

    public long getBalance(OfflinePlayer player) {
        return player == null ? 0L : this.playerDataService.get(player.getUniqueId()).getPrisonCoins();
    }

    public long getBalance(java.util.UUID uuid) {
        return uuid == null ? 0L : this.playerDataService.get(uuid).getPrisonCoins();
    }

    public void addCoins(java.util.UUID uuid, long amount) {
        if (uuid == null || amount <= 0L) {
            return;
        }
        this.playerDataService.update(uuid, data -> data.addPrisonCoins(amount));
    }

    public void setCoins(java.util.UUID uuid, long amount) {
        if (uuid == null) {
            return;
        }
        this.playerDataService.update(uuid, data -> data.setPrisonCoins(amount));
    }

    public boolean withdraw(Player player, long amount) {
        if (player == null || amount <= 0L || this.getBalance(player) < amount) {
            return false;
        }
        this.playerDataService.update(player.getUniqueId(), data -> data.setPrisonCoins(data.getPrisonCoins() - amount));
        return true;
    }

    public boolean hasCoins(Player player, long amount) {
        return player != null && amount > 0L && this.getBalance(player) >= amount;
    }

    public String format(long amount) {
        return Text.formatNumber(Math.max(0L, amount)) + " Prison Coins";
    }

    public boolean attemptMiningReward(Player player, Material minedType) {
        if (player == null || minedType == null || this.miningDropChance <= 0.0D) {
            return false;
        }
        if (this.miningDropOresOnly && !this.isOre(minedType)) {
            return false;
        }
        if (ThreadLocalRandom.current().nextDouble() >= this.miningDropChance) {
            return false;
        }
        int min = Math.max(1, this.miningDropMin);
        int max = Math.max(min, this.miningDropMax);
        long amount = ThreadLocalRandom.current().nextInt(min, max + 1);
        this.giveCoinToken(player, amount);
        player.sendMessage(Text.color("&6&l(!) &eYou found &f" + this.format(amount) + " &ein a Prison Coin token."));
        return true;
    }

    public ItemStack createCoinToken(long amount) {
        long sanitized = Math.max(1L, amount);
        ItemStack stack = new ItemStack(this.tokenMaterial);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        String formattedAmount = Text.formatNumber(sanitized);
        meta.displayName(Text.componentNoItalics(this.tokenName.replace("{amount}", formattedAmount)));
        java.util.List<net.kyori.adventure.text.Component> lore = new java.util.ArrayList<>();
        for (String line : this.tokenLore) {
            lore.add(Text.componentNoItalics(line.replace("{amount}", formattedAmount)));
        }
        meta.lore(lore);
        meta.getPersistentDataContainer().set(this.tokenAmountKey, PersistentDataType.LONG, sanitized);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isCoinToken(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(this.tokenAmountKey, PersistentDataType.LONG);
    }

    public long getTokenAmount(ItemStack item) {
        if (!this.isCoinToken(item)) {
            return 0L;
        }
        Long amount = item.getItemMeta().getPersistentDataContainer().get(this.tokenAmountKey, PersistentDataType.LONG);
        return amount == null ? 0L : Math.max(0L, amount);
    }

    public void giveCoinToken(Player player, long amount) {
        if (player == null || amount <= 0L) {
            return;
        }
        ItemStack token = this.createCoinToken(amount);
        java.util.Map<Integer, ItemStack> leftover = player.getInventory().addItem(token);
        for (ItemStack stack : leftover.values()) {
            if (stack != null && stack.getType() != Material.AIR) {
                player.getWorld().dropItemNaturally(player.getLocation(), stack);
            }
        }
    }

    public boolean redeemCoinToken(Player player, ItemStack item) {
        if (player == null || !this.isCoinToken(item)) {
            return false;
        }
        long amount = this.getTokenAmount(item);
        if (amount <= 0L) {
            return false;
        }
        this.addCoins(player.getUniqueId(), amount);
        player.sendMessage(Text.color("&aRedeemed &f" + this.format(amount) + " &ainto your Prison Coin balance."));
        return true;
    }

    private boolean isOre(Material type) {
        return type != null && switch (type) {
            case COAL_ORE, DEEPSLATE_COAL_ORE,
                 IRON_ORE, DEEPSLATE_IRON_ORE,
                 GOLD_ORE, DEEPSLATE_GOLD_ORE,
                 LAPIS_ORE, DEEPSLATE_LAPIS_ORE,
                 REDSTONE_ORE, DEEPSLATE_REDSTONE_ORE,
                 DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE,
                 EMERALD_ORE, DEEPSLATE_EMERALD_ORE,
                 COPPER_ORE, DEEPSLATE_COPPER_ORE,
                 NETHER_QUARTZ_ORE, NETHER_GOLD_ORE,
                 ANCIENT_DEBRIS -> true;
            default -> false;
        };
    }
}
