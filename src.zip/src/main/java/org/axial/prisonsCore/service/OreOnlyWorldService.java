package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.World;

public class OreOnlyWorldService {
    private static final String CONFIG_PATH = "ore-only-worlds";
    private final PrisonsCore plugin;
    private final Set<String> restrictedWorlds = new LinkedHashSet<String>();

    public OreOnlyWorldService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.reload();
    }

    public void reload() {
        this.restrictedWorlds.clear();
        for (String worldName : this.plugin.getConfig().getStringList(CONFIG_PATH)) {
            if (worldName == null || worldName.isBlank()) {
                continue;
            }
            this.restrictedWorlds.add(worldName);
        }
    }

    public boolean addWorld(String worldName) {
        if (this.findWorldName(worldName) != null) {
            return false;
        }
        this.restrictedWorlds.add(worldName);
        this.save();
        return true;
    }

    public boolean removeWorld(String worldName) {
        String matchedWorldName = this.findWorldName(worldName);
        if (matchedWorldName == null) {
            return false;
        }
        this.restrictedWorlds.remove(matchedWorldName);
        this.save();
        return true;
    }

    public boolean isRestricted(World world) {
        return world != null && this.findWorldName(world.getName()) != null;
    }

    public List<String> getWorldNames() {
        return new ArrayList<String>(this.restrictedWorlds);
    }

    private String findWorldName(String worldName) {
        String needle = worldName.toLowerCase(Locale.ROOT);
        for (String existing : this.restrictedWorlds) {
            if (!existing.toLowerCase(Locale.ROOT).equals(needle)) {
                continue;
            }
            return existing;
        }
        return null;
    }

    private void save() {
        this.plugin.getConfig().set(CONFIG_PATH, new ArrayList<String>(this.restrictedWorlds));
        this.plugin.saveConfig();
    }
}
