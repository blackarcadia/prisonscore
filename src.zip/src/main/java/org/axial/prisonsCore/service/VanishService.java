package org.axial.prisonsCore.service;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class VanishService implements Listener {
    private final PrisonsCore plugin;
    private final Set<UUID> vanished = new HashSet<UUID>();
    private final Set<UUID> temporaryVanished = new HashSet<UUID>();
    private BukkitTask actionBarTask;

    public VanishService(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public void start() {
        if (this.actionBarTask != null) {
            this.actionBarTask.cancel();
        }
        this.actionBarTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::sendActionBars, 1L, 20L);
        this.refreshAllVisibility();
    }

    public void stop() {
        if (this.actionBarTask != null) {
            this.actionBarTask.cancel();
            this.actionBarTask = null;
        }
        this.temporaryVanished.clear();
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            for (Player target : Bukkit.getOnlinePlayers()) {
                viewer.showPlayer(this.plugin, target);
            }
        }
    }

    public void toggle(Player player) {
        if (player == null) {
            return;
        }
        if (this.vanished.remove(player.getUniqueId())) {
            this.showToOthers(player);
            player.sendMessage(Text.color("&cVanish disabled."));
            return;
        }
        this.vanished.add(player.getUniqueId());
        this.hideFromOthers(player);
        player.sendMessage(Text.color("&aVanish enabled."));
        player.sendActionBar(Text.color("&aYou Are Vanished"));
    }

    public boolean isVanished(Player player) {
        return player != null && (this.vanished.contains(player.getUniqueId()) || this.temporaryVanished.contains(player.getUniqueId()));
    }

    public void vanishTemporarily(Player player, long durationTicks) {
        if (player == null || durationTicks <= 0L) {
            return;
        }
        UUID id = player.getUniqueId();
        if (this.vanished.contains(id)) {
            return;
        }
        this.temporaryVanished.add(id);
        this.hideFromOthers(player);
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            if (!this.temporaryVanished.remove(id)) {
                return;
            }
            if (player.isOnline() && !this.vanished.contains(id)) {
                this.showToOthers(player);
            }
        }, durationTicks);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.applyVisibilityFor(player), 1L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.applyVisibilityFor(player), 1L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        this.temporaryVanished.remove(player.getUniqueId());
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            for (Player viewer : Bukkit.getOnlinePlayers()) {
                viewer.showPlayer(this.plugin, player);
            }
        }, 1L);
    }

    private void refreshAllVisibility() {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            this.applyVisibilityFor(viewer);
        }
    }

    private void applyVisibilityFor(Player viewer) {
        if (viewer == null || !viewer.isOnline()) {
            return;
        }
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (viewer.equals(target)) {
                continue;
            }
            if (this.isVanished(target)) {
                viewer.hidePlayer(this.plugin, target);
            } else {
                viewer.showPlayer(this.plugin, target);
            }
        }
        if (this.isVanished(viewer)) {
            this.hideFromOthers(viewer);
        }
    }

    private void hideFromOthers(Player target) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (viewer.equals(target)) {
                continue;
            }
            viewer.hidePlayer(this.plugin, target);
        }
    }

    private void showToOthers(Player target) {
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (viewer.equals(target)) {
                continue;
            }
            viewer.showPlayer(this.plugin, target);
        }
    }

    private void sendActionBars() {
        for (UUID playerId : this.vanished) {
            Player player = Bukkit.getPlayer(playerId);
            if (player == null || !player.isOnline()) {
                continue;
            }
            player.sendActionBar(Text.color("&aYou Are Vanished"));
        }
        for (UUID playerId : this.temporaryVanished) {
            if (this.vanished.contains(playerId)) {
                continue;
            }
            Player player = Bukkit.getPlayer(playerId);
            if (player == null || !player.isOnline()) {
                continue;
            }
            player.sendActionBar(Text.color("&aYou Are Vanished"));
        }
    }
}
