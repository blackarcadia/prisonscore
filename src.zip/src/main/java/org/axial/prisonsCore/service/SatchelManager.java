/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.config.EnergyBarConfig;
import org.axial.prisonsCore.util.Text;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class SatchelManager {
    private final PrisonsCore plugin;
    private final NamespacedKey typeKey;
    private final NamespacedKey amountKey;
    private final NamespacedKey energyKey;
    private final NamespacedKey maxEnergyKey;
    private final NamespacedKey capacityBonusKey;
    private final NamespacedKey levelKey;
    private final EnergyBarConfig barConfig;
    private Map<Material, Integer> capacityMap = new HashMap<Material, Integer>();
    private Map<Material, String> displayMap = new HashMap<Material, String>();

    public SatchelManager(PrisonsCore plugin, EnergyBarConfig barConfig) {
        this.plugin = plugin;
        this.barConfig = barConfig;
        this.typeKey = new NamespacedKey((Plugin)plugin, "satchel-type");
        this.amountKey = new NamespacedKey((Plugin)plugin, "satchel-amount");
        this.energyKey = new NamespacedKey((Plugin)plugin, "satchel-energy");
        this.maxEnergyKey = new NamespacedKey((Plugin)plugin, "satchel-max-energy");
        this.capacityBonusKey = new NamespacedKey((Plugin)plugin, "satchel-capacity-bonus");
        this.levelKey = new NamespacedKey((Plugin)plugin, "satchel-level");
        this.reload();
    }

    public ItemStack createSatchel(Material dropType) {
        if (dropType == null) {
            return null;
        }
        ItemStack satchel = new ItemStack(dropType);
        ItemMeta meta = satchel.getItemMeta();
        meta.getPersistentDataContainer().set(this.typeKey, PersistentDataType.STRING, dropType.name());
        meta.getPersistentDataContainer().set(this.amountKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(this.maxEnergyKey, PersistentDataType.INTEGER, this.plugin.getConfig().getInt("satchel-energy.max", 1000));
        meta.getPersistentDataContainer().set(this.capacityBonusKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, 1);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setDisplayName(Text.color(this.buildName(dropType, 1)));
        satchel.setItemMeta(meta);
        this.updateLore(satchel);
        return satchel;
    }

    public void reload() {
        File file = new File(this.plugin.getDataFolder(), "satchels.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        this.capacityMap.clear();
        this.displayMap.clear();
        int baseCap = cfg.getInt("default-capacity", 256);
        ConfigurationSection section = cfg.getConfigurationSection("satchels");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                Material mat = Material.matchMaterial((String)key);
                if (mat == null) continue;
                int cap = section.getInt(key + ".capacity", baseCap);
                String name = section.getString(key + ".display-name", "&e" + this.pretty(mat) + " Satchel");
                this.capacityMap.put(mat, cap);
                this.displayMap.put(mat, name);
            }
        }
    }

    public boolean isSatchel(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.typeKey, PersistentDataType.STRING);
    }

    public Material getType(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return null;
        }
        String s = (String)satchel.getItemMeta().getPersistentDataContainer().get(this.typeKey, PersistentDataType.STRING);
        return s == null ? null : Material.matchMaterial((String)s);
    }

    public Set<Material> getConfiguredTypes() {
        return this.capacityMap.keySet();
    }

    public Material getConfiguredMaterial(String name) {
        if (name == null) {
            return null;
        }
        Material m = Material.matchMaterial((String)name);
        if (m != null && this.capacityMap.containsKey(m)) {
            return m;
        }
        return null;
    }

    public int getConfiguredCapacity(Material type) {
        if (type == null) {
            return 0;
        }
        return this.capacityMap.getOrDefault(type, 0);
    }

    public int getAmount(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return 0;
        }
        this.ensureBaseKeys(satchel);
        Integer val = (Integer)satchel.getItemMeta().getPersistentDataContainer().get(this.amountKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public int getCapacity(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return 0;
        }
        this.ensureBaseKeys(satchel);
        int base = this.capacityMap.getOrDefault(this.getType(satchel), 256);
        Integer bonus = satchel.getItemMeta().getPersistentDataContainer().get(this.capacityBonusKey, PersistentDataType.INTEGER);
        if (bonus == null) {
            bonus = 0;
        }
        return base + bonus;
    }

    public int getEnergy(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return 0;
        }
        this.ensureBaseKeys(satchel);
        Integer val = satchel.getItemMeta().getPersistentDataContainer().get(this.energyKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public int getMaxEnergy(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return 0;
        }
        this.ensureBaseKeys(satchel);
        Integer val = satchel.getItemMeta().getPersistentDataContainer().get(this.maxEnergyKey, PersistentDataType.INTEGER);
        return val == null ? this.plugin.getConfig().getInt("satchel-energy.max", 1000) : val;
    }

    public int addEnergy(ItemStack satchel, int amount) {
        if (!this.isSatchel(satchel) || amount <= 0) {
            return 0;
        }
        this.ensureBaseKeys(satchel);
        ItemMeta meta = satchel.getItemMeta();
        Integer currentVal = meta.getPersistentDataContainer().get(this.energyKey, PersistentDataType.INTEGER);
        int current = currentVal == null ? 0 : currentVal;
        int newEnergy = current + amount;
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, newEnergy);
        satchel.setItemMeta(meta);
        this.updateLore(satchel);
        return newEnergy;
    }

    public int addToSatchel(ItemStack satchel, int incoming) {
        if (!this.isSatchel(satchel) || incoming <= 0) {
            return incoming;
        }
        this.ensureBaseKeys(satchel);
        int current = this.getAmount(satchel);
        int capacity = this.getCapacity(satchel);
        int space = Math.max(0, capacity - current);
        int toStore = Math.min(space, incoming);
        this.setAmount(satchel, current + toStore);
        return incoming - toStore;
    }

    public void clear(ItemStack satchel) {
        this.setAmount(satchel, 0);
    }

    private void setAmount(ItemStack satchel, int amount) {
        if (!this.isSatchel(satchel)) {
            return;
        }
        this.ensureBaseKeys(satchel);
        ItemMeta meta = satchel.getItemMeta();
        meta.getPersistentDataContainer().set(this.amountKey, PersistentDataType.INTEGER, Math.max(0, amount));
        satchel.setItemMeta(meta);
        this.updateLore(satchel);
    }

    public boolean isFull(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return false;
        }
        this.ensureBaseKeys(satchel);
        return this.getEnergy(satchel) >= this.getMaxEnergy(satchel);
    }

    public void setEnergy(ItemStack satchel, int amount) {
        if (!this.isSatchel(satchel)) {
            return;
        }
        this.ensureBaseKeys(satchel);
        ItemMeta meta = satchel.getItemMeta();
        int maxEnergy = this.getMaxEnergy(satchel);
        int clamped = Math.max(0, Math.min(amount, maxEnergy));
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, clamped);
        satchel.setItemMeta(meta);
        this.updateLore(satchel);
    }

    public void setEnergyOverflow(ItemStack satchel, int amount) {
        if (!this.isSatchel(satchel)) {
            return;
        }
        this.ensureBaseKeys(satchel);
        ItemMeta meta = satchel.getItemMeta();
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, Math.max(0, amount));
        satchel.setItemMeta(meta);
        this.updateLore(satchel);
    }

    public int getLevel(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return 0;
        }
        this.ensureBaseKeys(satchel);
        Integer lvl = (Integer)satchel.getItemMeta().getPersistentDataContainer().get(this.levelKey, PersistentDataType.INTEGER);
        return lvl == null ? 1 : Math.max(1, lvl);
    }

    public void levelUp(ItemStack satchel, int remainingEnergy) {
        if (!this.isSatchel(satchel)) {
            return;
        }
        this.ensureBaseKeys(satchel);
        ItemMeta meta = satchel.getItemMeta();
        int level = this.getLevel(satchel) + 1;
        int currentMaxEnergy = this.getMaxEnergy(satchel);
        int maxEnergyIncrease = this.plugin.getConfig().getInt("satchel-upgrade.max-energy-increase", 500);
        int capacityIncrease = this.plugin.getConfig().getInt("satchel-upgrade.capacity-increase", 128);
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, level);
        meta.getPersistentDataContainer().set(this.maxEnergyKey, PersistentDataType.INTEGER, currentMaxEnergy + maxEnergyIncrease);
        Integer currentBonus = meta.getPersistentDataContainer().get(this.capacityBonusKey, PersistentDataType.INTEGER);
        if (currentBonus == null) {
            currentBonus = 0;
        }
        meta.getPersistentDataContainer().set(this.capacityBonusKey, PersistentDataType.INTEGER, currentBonus + capacityIncrease);
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, Math.max(0, remainingEnergy));
        meta.setDisplayName(Text.color(this.buildName(this.getType(satchel), level)));
        satchel.setItemMeta(meta);
        this.updateLore(satchel);
    }

    private void updateLore(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return;
        }
        this.ensureBaseKeys(satchel);
        ItemMeta meta = satchel.getItemMeta();
        int amt = this.getAmount(satchel);
        int cap = this.getCapacity(satchel);
        int energy = this.getEnergy(satchel);
        int maxEnergy = this.getMaxEnergy(satchel);
        double percent = maxEnergy <= 0 ? 0.0 : Math.min(1.0, Math.max(0.0, (double)energy / (double)maxEnergy));
        int filled = maxEnergy <= 0 ? 0 : (int)Math.round(percent * (double)this.barConfig.getLength());
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(Text.color("&7Stored: &e" + amt + " &7/ &e" + cap));
        lore.add("");
        lore.add(Text.color(this.plugin.getConfig().getString("satchel-energy.label", "&d&lSatchel Charge")));
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < this.barConfig.getLength(); ++i) {
            if (i < filled) {
                bar.append(this.barConfig.getFilledColor()).append(this.barConfig.getFilledChar());
                continue;
            }
            bar.append(this.barConfig.getEmptyColor()).append(this.barConfig.getEmptyChar());
        }
        Object barLine = this.barConfig.getFormat().replace("{bar}", ChatColor.translateAlternateColorCodes((char)'&', (String)bar.toString())).replace("{current}", String.valueOf(energy)).replace("{max}", String.valueOf(maxEnergy));
        double percentDisplay = maxEnergy <= 0 ? 0.0 : (double)Math.round(percent * 1000.0) / 10.0;
        barLine = (String)barLine + Text.color(" &f&l" + percentDisplay + "%");
        lore.add(Text.color((String)barLine));
        lore.add(Text.color("&7(" + energy + " / " + maxEnergy + ")"));
        lore.add(Text.color("&8Shift-click while holding to sell"));
        meta.setLore(lore);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        satchel.setItemMeta(meta);
    }

    private String pretty(Material mat) {
        if (mat == null) {
            return "Unknown";
        }
        return mat.name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private void ensureBaseKeys(ItemStack satchel) {
        if (!this.isSatchel(satchel)) {
            return;
        }
        ItemMeta meta = satchel.getItemMeta();
        boolean changed = false;
        boolean nameChanged = false;
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(this.maxEnergyKey, PersistentDataType.INTEGER)) {
            container.set(this.maxEnergyKey, PersistentDataType.INTEGER, this.plugin.getConfig().getInt("satchel-energy.max", 1000));
            changed = true;
        }
        if (!container.has(this.capacityBonusKey, PersistentDataType.INTEGER)) {
            container.set(this.capacityBonusKey, PersistentDataType.INTEGER, 0);
            changed = true;
        }
        if (!container.has(this.levelKey, PersistentDataType.INTEGER)) {
            container.set(this.levelKey, PersistentDataType.INTEGER, 1);
            changed = true;
            nameChanged = true;
        }
        if (changed) {
            satchel.setItemMeta(meta);
        }
        if (nameChanged) {
            meta = satchel.getItemMeta();
            meta.setDisplayName(Text.color(this.buildName(this.getType(satchel), this.getLevel(satchel))));
            satchel.setItemMeta(meta);
        }
    }

    private String buildName(Material type, int level) {
        String base = this.displayMap.getOrDefault(type, "&e" + this.pretty(type) + " Satchel");
        return base + " &a&l" + level;
    }
}
