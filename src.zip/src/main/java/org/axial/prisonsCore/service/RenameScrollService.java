/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class RenameScrollService {
    private final PrisonsCore plugin;
    private final NamespacedKey scrollKey;
    private Material material = Material.NAME_TAG;
    private String displayName = "&d&lRename Scroll";
    private List<String> lore = List.of("&7Right-click to enter rename mode.", "&7Type the new name in chat.");

    public RenameScrollService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.scrollKey = Keys.renameScroll(plugin);
        this.loadConfig();
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public ItemStack createScroll() {
        ItemStack stack = new ItemStack(this.material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(Text.color(this.displayName));
        if (this.lore != null) {
            meta.setLore(this.lore.stream().map(Text::color).collect(Collectors.toList()));
        }
        meta.getPersistentDataContainer().set(this.scrollKey, PersistentDataType.BYTE, (byte)1);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isRenameScroll(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.scrollKey, PersistentDataType.BYTE);
    }

    public void reload() {
        this.loadConfig();
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection section = cfg.getConfigurationSection("items.rename-scroll");
        if (section == null) {
            return;
        }
        Material mat = Material.matchMaterial((String)section.getString("material", this.material.name()));
        if (mat != null) {
            this.material = mat;
        }
        this.displayName = section.getString("display-name", this.displayName);
        this.lore = section.getStringList("lore");
        if (this.lore == null || this.lore.isEmpty()) {
            this.lore = List.of("&7Right-click to enter rename mode.", "&7Type the new name in chat.");
        }
    }
}
