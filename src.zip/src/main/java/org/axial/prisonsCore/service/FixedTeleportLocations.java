package org.axial.prisonsCore.service;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public final class FixedTeleportLocations {
    private static final Spec SPAWN = new Spec("prisons", -82, 246, 1, -90.0f, 0.0f);
    private static final Spec TUTORIAL_SPAWN = new Spec("tutorial", -11, 95, 157, 90.0f, 0.0f);
    private static final Map<String, Spec> WARPS = createWarps();

    private FixedTeleportLocations() {
    }

    public static Location getSpawn() {
        return SPAWN.toLocation();
    }

    public static Location getTutorialSpawn() {
        return TUTORIAL_SPAWN.toLocation();
    }

    public static Location getWarp(String name) {
        if (name == null) {
            return null;
        }
        Spec spec = WARPS.get(name.toLowerCase(Locale.ROOT));
        return spec == null ? null : spec.toLocation();
    }

    public static Set<String> getWarpNames() {
        return Set.copyOf(WARPS.keySet());
    }

    public static String getWarpCoordinateLine(String name) {
        if (name == null) {
            return "&7(Not set)";
        }
        Spec spec = WARPS.get(name.toLowerCase(Locale.ROOT));
        return spec == null ? "&7(Not set)" : spec.coordinateLine();
    }

    private static Map<String, Spec> createWarps() {
        Map<String, Spec> warps = new LinkedHashMap<>();
        warps.put("emerald", new Spec("prisons", 1481, 231, -1374, 180.0f, 0.0f));
        warps.put("diamond", new Spec("prisons", 1061, 283, 970, 90.0f, 0.0f));
        warps.put("coal", new Spec("prisons", -384, 238, 407, -90.0f, 0.0f));
        warps.put("iron", new Spec("prisons", -227, 232, -664, 0.0f, 0.0f));
        warps.put("lapis", new Spec("prisons", -1061, 226, 430, 180.0f, 0.0f));
        warps.put("redstone", new Spec("prisons", 746, 241, -2, 90.0f, 0.0f));
        warps.put("gold", new Spec("prisons", -1367, 234, -1510, 180.0f, 0.0f));
        warps.put("inmate", new Spec("Cells", -29, -62, 9, 0.0f, 0.0f));
        warps.put("trustee", new Spec("Cells", 2, -62, -225, 0.0f, 0.0f));
        warps.put("warden", new Spec("Cells", -473, -62, 180, 0.0f, 0.0f));
        return warps;
    }

    private record Spec(String worldName, double x, double y, double z, float yaw, float pitch) {
        private Location toLocation() {
            World world = Bukkit.getWorld(this.worldName);
            if (world == null) {
                return null;
            }
            return new Location(world, this.x, this.y, this.z, this.yaw, this.pitch);
        }

        private String coordinateLine() {
            return "&7(" + (int)this.x + ", " + (int)this.y + ", " + (int)this.z + ")";
        }
    }
}
