package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.KitService.GKitType;
import org.axial.prisonsCore.service.RankTokenService.RankType;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class PowerboxService {
    private static final String FROZEN_WASTELANDS_ID = "frozen_wastelands";
    private static final String FROZEN_WASTELANDS_NAME = "&r&f&lPowerbox: &b&lFrozen &3&lWastelands &f&l(&75 Items&f&l)";
    private static final String HEATWAVE_ID = "heatwave";
    private static final String HEATWAVE_NAME = "&r&f&lPowerbox: &c&lH&6&le&c&la&6&lt&c&lw&6&la&c&lv&6&le &f&l(&75 Items&f&l)";
    private final PrisonsCore plugin;
    private final Map<String, PowerboxType> powerboxes = new LinkedHashMap<String, PowerboxType>();

    public PowerboxService(PrisonsCore plugin, EnergyItemService energyItemService, ChargeOrbService chargeOrbService, BankNoteService bankNoteService, BoosterService boosterService, RankTokenService rankTokenService, MeteorService meteorService, ContrabandService contrabandService, KitService kitService) {
        this.plugin = plugin;
        this.register(new PowerboxType(
                FROZEN_WASTELANDS_ID,
                FROZEN_WASTELANDS_NAME,
                List.of("&b&lFrozen Wastelands Lootbox"),
                List.of(
                        new RewardDefinition("skin_box", "&6&lSkin Box &f&l(&71 Item&f&l)", 10.0D, () -> this.createSkinBoxItem(1)),
                        new RewardDefinition("meteor_flare", "&dMeteor Flare", 10.0D, () -> meteorService.createFlare(1)),
                        new RewardDefinition("charge_orb_25", "&a&l+25% &6&lCharge Orb", 15.0D, () -> chargeOrbService.createOrb(25)),
                        new RewardDefinition("charge_extractor_5", "&eCharge Extractor &7x5", 10.0D, () -> {
                            ItemStack item = energyItemService.createExtractorItem();
                            item.setAmount(5);
                            return item;
                        }),
                        new RewardDefinition("booster_xp_3h", "&b&l3 Hour &b&l3x &fMining XP Booster", 10.0D, () -> boosterService.createBoosterItem(BoosterService.BoosterType.XP, 10800, 3.0D, 1)),
                        new RewardDefinition("booster_xp_2h5", "&b&l2 Hour &b&l2.5x &fMining XP Booster", 11.0D, () -> boosterService.createBoosterItem(BoosterService.BoosterType.XP, 7200, 2.5D, 1)),
                        new RewardDefinition("legendary_contraband", "&f&lLegendary Contraband &7x1-3", 5.0D, () -> this.createContrabandStack(contrabandService, "legendary_cont", 1, 3)),
                        new RewardDefinition("elite_contraband", "&f&lElite Contraband &7x1-5", 4.0D, () -> this.createContrabandStack(contrabandService, "elite_cont", 1, 5))
                ),
                List.of(
                        new RewardDefinition("rank_vanguard", "&6&lRank: &e&lVanguard", 3.0D, () -> rankTokenService.createToken(RankType.VANGUARD)),
                        new RewardDefinition("gkit_stormstride", "&9&lStormstride &9Gkit Gem", 5.0D, () -> kitService.createGKitToken(GKitType.STORMSTRIDE)),
                        new RewardDefinition("gkit_ironhide", "&b&lIronhide &bGkit Gem", 5.0D, () -> kitService.createGKitToken(GKitType.IRONHIDE)),
                        new RewardDefinition("gkit_deepforge", "&3&lDeep Forge &3Gkit Gem", 5.0D, () -> kitService.createGKitToken(GKitType.DEEPFORGE)),
                        new RewardDefinition("raw_charge_500k_1m", "&d&lRaw Charge &7x500,000-1,000,000", 8.0D, () -> energyItemService.createEnergyItem(this.randomRange(500000, 1000000))),
                        new RewardDefinition("bank_note_500k", "&a&lBank Note &7($500,000)", 5.0D, () -> bankNoteService.createBankNote(500000.0D))
                )
        ));
        this.register(new PowerboxType(
                HEATWAVE_ID,
                HEATWAVE_NAME,
                List.of(),
                List.of(
                        new RewardDefinition("legendary_contraband", "&f&lLegendary Contraband &7x1-5", 7.0D, () -> this.createContrabandStack(contrabandService, "legendary_cont", 1, 5)),
                        new RewardDefinition("skin_box", "&6&lSkin Box &7x1-3", 5.0D, () -> this.createSkinBoxItem(this.randomRange(1, 3))),
                        new RewardDefinition("pickaxe_prestige_token", "&6&lPickaxe Prestige Token &7x1-4", 8.0D, () -> this.createPrestigeTokens(this.randomRange(1, 4))),
                        new RewardDefinition("xp_booster_5x_30m", "&a&l5x 30m XP Booster &7x1-3", 9.0D, () -> boosterService.createBoosterItem(BoosterService.BoosterType.XP, 1800, 5.0D, this.randomRange(1, 3))),
                        new RewardDefinition("turkey_mask", "&6&lTurkey Mask", 10.0D, () -> this.createMaskItem("turkey")),
                        new RewardDefinition("purge_mask", "&c&lPurge Mask", 10.0D, () -> this.createMaskItem("purge")),
                        new RewardDefinition("excavator_mask", "&e&lExcavator Mask", 10.0D, () -> this.createMaskItem("excavator")),
                        new RewardDefinition("mini_palm_tree", "&e&lMini Palm Tree", 4.0D, () -> this.createCustomBlockItem("mini_palm_tree")),
                        new RewardDefinition("beach_ball", "&e&lBeach Ball", 4.0D, () -> this.createCustomBlockItem("beach_ball")),
                        new RewardDefinition("deepforge_gkit_gem", "&3&lDeep Forge &3Gkit Gem", 3.0D, () -> kitService.createGKitToken(GKitType.DEEPFORGE))
                ),
                List.of(
                        new RewardDefinition("frozen_wastelands_lootbox", "&b&lFrozen Wastelands Lootbox", 3.0D, () -> this.renameItem(this.createPowerbox("frozen_wastelands", 1), "&b&lFrozen Wastelands Lootbox")),
                        new RewardDefinition("alien_supply_box", "&a&lAlien Supply Box", 1.0D, () -> this.renameItem(this.createAlienSupplyCrate(false), "&a&lAlien Supply Box")),
                        new RewardDefinition("alien_crate_key", "&a&lAlien Crate Key", 3.0D, () -> this.renameItem(this.createAlienKey(1), "&a&lAlien Crate Key")),
                        new RewardDefinition("bank_note_3m", "&a&lBank Note &7($3,000,000)", 4.0D, () -> bankNoteService.createBankNote(3000000.0D)),
                        new RewardDefinition("flamingo_floaty_item_skin", "&f&lItem Skin (&6&lFlamingo Floaty&f&l)", 6.0D, () -> this.renameItem(this.createSkinItem("floaty_flamingo"), "&f&lItem Skin (&6&lFlamingo Floaty&f&l)")),
                        new RewardDefinition("rocket_lolly_item_skin", "&f&lItem Skin (&6&lRocket Lolly&f&l)", 6.0D, () -> this.createSkinItem("rocket_lolly"))
                )
        ));
    }

    public List<String> powerboxIds() {
        return List.copyOf(this.powerboxes.keySet());
    }

    public boolean hasPowerbox(String id) {
        return this.getPowerbox(id) != null;
    }

    public String displayName(String id) {
        PowerboxType type = this.getPowerbox(id);
        return type == null ? "&fPowerbox" : type.displayName();
    }

    public String menuTitle(String id) {
        PowerboxType type = this.getPowerbox(id);
        if (type == null) {
            return "&8Powerbox";
        }
        if (FROZEN_WASTELANDS_ID.equalsIgnoreCase(type.id())) {
            return "&8Powerbox: &b&lFrozen &3&lWastelands";
        }
        if (HEATWAVE_ID.equalsIgnoreCase(type.id())) {
            return "&8Powerbox: &c&lH&6&le&c&la&6&lt&c&lw&6&la&c&lv&6&le";
        }
        return "&8Powerbox";
    }

    public ItemStack createPowerbox(String id, int amount) {
        PowerboxType type = this.getPowerbox(id);
        if (type == null) {
            return null;
        }
        ItemStack stack = new ItemStack(this.powerboxMaterial(type.id()), Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(type.displayName()));
            meta.setLore(type.buildLore());
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            Enchantment glint = Enchantment.getByName("DURABILITY");
            if (glint != null) {
                meta.addEnchant(glint, 1, true);
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public boolean isPowerbox(ItemStack item) {
        return this.getPowerboxId(item) != null;
    }

    public String getPowerboxId(ItemStack item) {
        if (item == null || !item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) {
            return null;
        }
        String stripped = Text.strip(item.getItemMeta().getDisplayName());
        for (PowerboxType type : this.powerboxes.values()) {
            if (type.matchesDisplayName(stripped)) {
                return type.id();
            }
        }
        return null;
    }

    public RewardRoll rollReward(String id) {
        return this.rollReward(id, Set.of());
    }

    public RewardRoll rollReward(String id, Set<String> excludedRewardIds) {
        PowerboxType type = this.getPowerbox(id);
        if (type == null) {
            return null;
        }
        List<RewardDefinition> rewards = type.allRewards();
        if (excludedRewardIds != null && !excludedRewardIds.isEmpty()) {
            rewards = rewards.stream()
                    .filter(reward -> !excludedRewardIds.contains(reward.id()))
                    .toList();
        }
        if (rewards.isEmpty()) {
            return null;
        }
        double totalWeight = 0.0D;
        for (RewardDefinition reward : rewards) {
            totalWeight += reward.chance();
        }
        if (totalWeight <= 0.0D) {
            return null;
        }
        double pick = this.plugin.getRandom().nextDouble() * totalWeight;
        double cursor = 0.0D;
        for (RewardDefinition reward : rewards) {
            cursor += reward.chance();
            if (pick <= cursor) {
                return new RewardRoll(type, reward, reward.createItem());
            }
        }
        RewardDefinition fallback = rewards.get(rewards.size() - 1);
        return new RewardRoll(type, fallback, fallback.createItem());
    }

    public ItemStack previewItem(RewardRoll roll) {
        if (roll == null || roll.item() == null) {
            return this.namedItem(Material.BARRIER, "&cNo reward", List.of("&7This powerbox has no configured rewards."));
        }
        return roll.item().clone();
    }

    public void award(Player player, RewardRoll roll) {
        if (player == null || roll == null || roll.item() == null) {
            return;
        }
        ItemStack item = roll.item().clone();
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, item);
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
        for (ItemStack stack : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), stack);
        }
    }

    public String rewardSummary(RewardRoll roll) {
        if (roll == null || roll.item() == null) {
            return "&cUnknown reward";
        }
        ItemStack item = roll.item();
        String name = item.hasItemMeta() && item.getItemMeta().hasDisplayName() ? item.getItemMeta().getDisplayName() : "&fReward";
        if (item.getAmount() > 1) {
            return name + Text.color(" &7x&f" + item.getAmount());
        }
        return name;
    }

    public ItemStack createSkinBoxItem(int amount) {
        if (this.plugin.getAxialSkinsModule() != null && this.plugin.getAxialSkinsModule().skinBoxService() != null) {
            return this.plugin.getAxialSkinsModule().skinBoxService().createSkinBox(amount);
        }
        ItemStack stack = new ItemStack(Material.BEACON, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&r&6&lSkin Box &f&l(&71 Item&f&l)"));
            meta.setLore(List.of(
                    Text.color("&7Right-Click to recieve 1 random Item Skin."),
                    Text.color("&7"),
                    Text.color("&7Contains:"),
                    Text.color("&6&l* &f&lItem Skin (&6&lKryo Helmet&f&l)"),
                    Text.color("&6&l* &f&lItem Skin (&6&lUtility Belt&f&l)"),
                    Text.color("&6&l* &f&lItem Skin (&6&lKryo Pickaxe&f&l)"),
                    Text.color("&6&l* &f&lItem Skin (&6&lMoon Boots&f&l)"),
                    Text.color("&6&l* &f&lItem Skin (&6&lKryo Amulet&f&l)")
            ));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            Enchantment glint = Enchantment.getByName("DURABILITY");
            if (glint != null) {
                meta.addEnchant(glint, 1, true);
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack createSkinItem(String skinId) {
        if (this.plugin.getAxialSkinsModule() == null || this.plugin.getAxialSkinsModule().skinManager() == null) {
            return new ItemStack(Material.BARRIER);
        }
        return this.plugin.getAxialSkinsModule().skinManager().get(skinId)
                .map(this.plugin.getAxialSkinsModule().skinManager()::createSkinItem)
                .orElseGet(() -> new ItemStack(Material.BARRIER));
    }

    private ItemStack createAlienSupplyCrate(boolean unlocked) {
        if (this.plugin.getAlienSupplyCrateService() == null) {
            return new ItemStack(Material.CHEST);
        }
        ItemStack stack = this.plugin.getAlienSupplyCrateService().createCrate(unlocked);
        return stack == null ? new ItemStack(Material.CHEST) : stack;
    }

    private ItemStack createAlienKey(int amount) {
        if (this.plugin.getAlienSupplyCrateService() == null) {
            return new ItemStack(Material.TRIPWIRE_HOOK, Math.max(1, amount));
        }
        ItemStack stack = this.plugin.getAlienSupplyCrateService().createKey(Math.max(1, amount));
        return stack == null ? new ItemStack(Material.TRIPWIRE_HOOK, Math.max(1, amount)) : stack;
    }

    private ItemStack createPrestigeTokens(int amount) {
        ItemStack item = new ItemStack(Material.SUNFLOWER, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&6&lPickaxe Prestige Token"));
            meta.setLore(List.of(
                    Text.color("&7Right-click a prison pickaxe"),
                    Text.color("&7to unlock the prestige menu.")
            ));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            meta.setEnchantmentGlintOverride(Boolean.TRUE);
            meta.getPersistentDataContainer().set(Keys.pickaxePrestigeToken(this.plugin), PersistentDataType.BYTE, (byte)1);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createMaskItem(String maskId) {
        if (this.plugin.getMaskModule() == null || this.plugin.getMaskModule().getMaskManager() == null) {
            return new ItemStack(Material.PLAYER_HEAD);
        }
        ItemStack stack = this.plugin.getMaskModule().getMaskManager().createMaskItem(maskId);
        return stack == null ? new ItemStack(Material.PLAYER_HEAD) : stack;
    }

    private ItemStack createCustomBlockItem(String id) {
        if (this.plugin.getCustomBlockService() == null) {
            return new ItemStack(Material.NOTE_BLOCK);
        }
        ItemStack stack = this.plugin.getCustomBlockService().createItem(id);
        return stack == null ? new ItemStack(Material.NOTE_BLOCK) : stack;
    }

    private Material powerboxMaterial(String id) {
        if (HEATWAVE_ID.equalsIgnoreCase(id)) {
            return Material.RED_GLAZED_TERRACOTTA;
        }
        return Material.BEACON;
    }

    private ItemStack renameItem(ItemStack item, String displayName) {
        if (item == null) {
            return null;
        }
        ItemStack copy = item.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(displayName));
            copy.setItemMeta(meta);
        }
        return copy;
    }

    private ItemStack createContrabandStack(ContrabandService contrabandService, String id, int min, int max) {
        if (contrabandService == null) {
            return new ItemStack(Material.CHEST);
        }
        ItemStack stack = contrabandService.createContraband(id);
        if (stack == null) {
            return new ItemStack(Material.CHEST);
        }
        int amount = this.randomRange(min, max);
        stack.setAmount(Math.max(1, amount));
        return stack;
    }

    private int randomRange(int min, int max) {
        int safeMin = Math.max(1, min);
        int safeMax = Math.max(safeMin, max);
        if (safeMin == safeMax) {
            return safeMin;
        }
        return safeMin + this.plugin.getRandom().nextInt(safeMax - safeMin + 1);
    }

    private ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(name));
            if (lore != null && !lore.isEmpty()) {
                ArrayList<String> lines = new ArrayList<String>();
                for (String line : lore) {
                    lines.add(Text.color(line));
                }
                meta.setLore(lines);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    private PowerboxType getPowerbox(String id) {
        if (id == null) {
            return null;
        }
        return this.powerboxes.get(id.toLowerCase(Locale.ROOT));
    }

    private void register(PowerboxType type) {
        if (type == null || type.id() == null) {
            return;
        }
        this.powerboxes.put(type.id().toLowerCase(Locale.ROOT), type);
    }

    public record RewardRoll(PowerboxType type, RewardDefinition reward, ItemStack item) {
    }

    public static final class RewardDefinition {
        private final String id;
        private final String loreLabel;
        private final double chance;
        private final Supplier<ItemStack> factory;

        public RewardDefinition(String id, String loreLabel, double chance, Supplier<ItemStack> factory) {
            this.id = id;
            this.loreLabel = loreLabel;
            this.chance = chance;
            this.factory = factory;
        }

        public String id() {
            return this.id;
        }

        public String loreLabel() {
            return this.loreLabel;
        }

        public double chance() {
            return this.chance;
        }

        public ItemStack createItem() {
            if (this.factory == null) {
                return null;
            }
            ItemStack item = this.factory.get();
            return item == null ? null : item.clone();
        }
    }

    private static final class PowerboxType {
        private final String id;
        private final String displayName;
        private final List<String> aliases;
        private final List<RewardDefinition> normalRewards;
        private final List<RewardDefinition> jackpotRewards;

        private PowerboxType(String id, String displayName, List<String> aliases, List<RewardDefinition> normalRewards, List<RewardDefinition> jackpotRewards) {
            this.id = id;
            this.displayName = displayName;
            this.aliases = aliases;
            this.normalRewards = normalRewards;
            this.jackpotRewards = jackpotRewards;
        }

        public String id() {
            return this.id;
        }

        public String displayName() {
            return this.displayName;
        }

        public boolean matchesDisplayName(String strippedDisplayName) {
            if (strippedDisplayName == null) {
                return false;
            }
            if (strippedDisplayName.equalsIgnoreCase(Text.strip(this.displayName))) {
                return true;
            }
            for (String alias : this.aliases) {
                if (strippedDisplayName.equalsIgnoreCase(Text.strip(alias))) {
                    return true;
                }
            }
            return false;
        }

        public List<String> buildLore() {
            ArrayList<String> lore = new ArrayList<String>();
            if (FROZEN_WASTELANDS_ID.equalsIgnoreCase(this.id)) {
                lore.add(Text.color("&7Forged in the ice spikes of a frozen wasteland."));
            } else if (HEATWAVE_ID.equalsIgnoreCase(this.id)) {
                lore.add(Text.color("&7Forged in the heat shimmer of a burning wasteland."));
            } else {
                lore.add(Text.color("&7A powerbox forged for the battlefield."));
            }
            lore.add(Text.color("&7Open this Powerbox to recieve &f&n5"));
            lore.add(Text.color("&7random rewards from the loot below."));
            lore.add(Text.color(""));
            lore.add(Text.color("&7Contains:"));
            for (RewardDefinition reward : this.normalRewards) {
                lore.add(Text.color("&6&l* " + reward.loreLabel() + " &7(" + this.formatChance(reward.chance()) + "%)"));
            }
            lore.add(Text.color(""));
            lore.add(Text.color("&f&lJackpot"));
            for (RewardDefinition reward : this.jackpotRewards) {
                lore.add(Text.color("&6&l* " + reward.loreLabel() + " &7(" + this.formatChance(reward.chance()) + "%)"));
            }
            return lore;
        }

        public List<RewardDefinition> allRewards() {
            ArrayList<RewardDefinition> rewards = new ArrayList<RewardDefinition>(this.normalRewards.size() + this.jackpotRewards.size());
            rewards.addAll(this.normalRewards);
            rewards.addAll(this.jackpotRewards);
            return rewards;
        }

        private String formatChance(double chance) {
            if (Math.abs(chance - Math.rint(chance)) < 0.0001D) {
                return String.valueOf((int)Math.round(chance));
            }
            return String.format(Locale.ENGLISH, "%.1f", chance);
        }
    }
}
