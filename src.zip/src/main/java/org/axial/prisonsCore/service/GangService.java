/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashSet;
import java.util.UUID;
import java.util.Set;
import org.axial.prisonsCore.model.Gang;
import org.axial.prisonsCore.model.GangRole;
import org.axial.prisonsCore.cell.Cell;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Lang;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
public class GangService {
    private final PrisonsCore plugin;
    private final Map<String, Gang> gangs = new HashMap<String, Gang>();
    private final Map<UUID, String> playerGang = new HashMap<UUID, String>();
    private final Map<String, Map<String, Relation>> relations = new HashMap<String, Map<String, Relation>>();
    private final Map<UUID, Set<String>> pendingInvites = new HashMap<UUID, Set<String>>();
    private final Map<UUID, Boolean> gangChatToggled = new HashMap<UUID, Boolean>();
    private File file;
    private YamlConfiguration data;

    public GangService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.load();
    }

    public void load() {
        ConfigurationSection relSec;
        this.file = new File(this.plugin.getDataFolder(), "gangs.yml");
        if (!this.file.exists()) {
            this.file.getParentFile().mkdirs();
            try {
                this.file.createNewFile();
            }
            catch (IOException iOException) {
                // empty catch block
            }
        }
        this.data = YamlConfiguration.loadConfiguration((File)this.file);
        this.gangs.clear();
        this.playerGang.clear();
        this.relations.clear();
        this.pendingInvites.clear();
        ConfigurationSection gsec = this.data.getConfigurationSection("gangs");
        if (gsec != null) {
            for (String id : gsec.getKeys(false)) {
                ConfigurationSection gangSec = gsec.getConfigurationSection(id);
                if (gangSec == null) {
                    continue;
                }
                String name = gangSec.getString("name", id);
                Gang gang = new Gang(id, name);
                gang.addPoints(gangSec.getInt("points", 0));
                ConfigurationSection membersSec = gangSec.getConfigurationSection("members");
                if (membersSec != null) {
                    for (String uuidStr : membersSec.getKeys(false)) {
                        try {
                            UUID uuid = UUID.fromString(uuidStr);
                            GangRole role = GangRole.valueOf(membersSec.getString(uuidStr, "MEMBER"));
                            gang.setRole(uuid, role);
                            this.playerGang.put(uuid, id);
                        }
                        catch (IllegalArgumentException illegalArgumentException) {}
                    }
                }
                this.gangs.put(id, gang);
            }
        }
        if ((relSec = this.data.getConfigurationSection("relations")) != null) {
            for (String a : relSec.getKeys(false)) {
                HashMap<String, Relation> map = new HashMap<String, Relation>();
                for (String b : relSec.getConfigurationSection(a).getKeys(false)) {
                    try {
                        map.put(b, Relation.valueOf(relSec.getString(a + "." + b, "NEUTRAL")));
                    }
                    catch (Exception exception) {}
                }
                this.relations.put(a, map);
            }
        }
        ConfigurationSection inviteSec = this.data.getConfigurationSection("pending-invites");
        if (inviteSec != null) {
            for (String uuidStr : inviteSec.getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(uuidStr);
                    HashSet<String> ids = new HashSet<String>();
                    ConfigurationSection playerSec = inviteSec.getConfigurationSection(uuidStr);
                    if (playerSec != null) {
                        for (String gangId : playerSec.getKeys(false)) {
                            ids.add(gangId);
                        }
                    }
                    if (!ids.isEmpty()) {
                        this.pendingInvites.put(uuid, ids);
                    }
                }
                catch (IllegalArgumentException illegalArgumentException) {}
            }
        }
        this.pruneEmptyGangs();
    }

    public void save() {
        this.data.set("gangs", null);
        for (Gang gang : this.gangs.values()) {
            String path = "gangs." + gang.getId();
            this.data.set(path + ".name", (Object)gang.getName());
            this.data.set(path + ".points", (Object)gang.getPoints());
            for (Map.Entry<UUID, GangRole> e : gang.getMembers().entrySet()) {
                this.data.set(path + ".members." + String.valueOf(e.getKey()), (Object)e.getValue().name());
            }
        }
        this.data.set("relations", null);
        for (Map.Entry<String, Map<String, Relation>> entry : this.relations.entrySet()) {
            for (Map.Entry<String, Relation> inner : entry.getValue().entrySet()) {
                this.data.set("relations." + entry.getKey() + "." + inner.getKey(), inner.getValue().name());
            }
        }
        this.data.set("pending-invites", null);
        for (Map.Entry<UUID, Set<String>> entry : this.pendingInvites.entrySet()) {
            for (String gangId : entry.getValue()) {
                this.data.set("pending-invites." + entry.getKey() + "." + gangId, (Object)true);
            }
        }
        try {
            this.data.save(this.file);
        }
        catch (IOException iOException) {
            // empty catch block
        }
    }

    public Gang createGang(Player creator, String name) {
        if (creator == null || name == null) {
            return null;
        }
        if (this.playerGang.containsKey(creator.getUniqueId())) {
            return null;
        }
        String id = name.toLowerCase(Locale.ROOT).replace(" ", "_");
        if (this.gangs.containsKey(id)) {
            return null;
        }
        Gang gang = new Gang(id, name);
        gang.setRole(creator.getUniqueId(), GangRole.LEADER);
        this.gangs.put(id, gang);
        this.playerGang.put(creator.getUniqueId(), id);
        this.save();
        return gang;
    }

    public boolean renameGang(Gang gang, String newName) {
        if (gang == null || newName == null) {
            return false;
        }
        gang.setName(newName);
        this.save();
        return true;
    }

    public Gang getGangByPlayer(UUID uuid) {
        String id = this.playerGang.get(uuid);
        return id == null ? null : this.gangs.get(id);
    }

    public Gang getGang(String idOrName) {
        if (idOrName == null) {
            return null;
        }
        Gang g = this.gangs.get(idOrName.toLowerCase(Locale.ROOT));
        if (g != null) {
            return g;
        }
        return this.gangs.values().stream().filter(x -> x.getName().equalsIgnoreCase(idOrName)).findFirst().orElse(null);
    }

    public boolean invite(Gang gang, Player inviter, OfflinePlayer target) {
        if (gang == null || inviter == null || target == null) {
            return false;
        }
        GangRole role = gang.getRole(inviter.getUniqueId());
        if (role == null || !role.isHigherOrEqual(GangRole.MOD)) {
            return false;
        }
        if (this.playerGang.containsKey(target.getUniqueId())) {
            return false;
        }
        String targetName = target.getName() != null ? target.getName() : "that player";
        if (target.isOnline() && target.getPlayer() != null) {
            target.getPlayer().sendMessage(Lang.msg("gang.invite.target", "&e&l(!) &eYou have been invited to join &f&l{gang}&e.\n&7Join with /gang join &f{gang}&7.").replace("{gang}", gang.getName()));
        } else {
            this.pendingInvites.computeIfAbsent(target.getUniqueId(), key -> new HashSet<String>()).add(gang.getId());
            this.save();
        }
        inviter.sendMessage(Lang.msg("gang.invite.sent", "&e&l(!) &eYou have invited &f&l{player} &eto the gang &f&l{gang}&e.\n&7They have 60 seconds to &a&lACCEPT &7or &c&lDENY&7.").replace("{player}", targetName).replace("{gang}", gang.getName()));
        return true;
    }

    public List<String> consumePendingInvites(UUID targetId) {
        if (targetId == null) {
            return List.of();
        }
        Set<String> invites = this.pendingInvites.remove(targetId);
        if (invites == null || invites.isEmpty()) {
            return List.of();
        }
        this.save();
        return new ArrayList<String>(invites);
    }

    public boolean joinGang(Player player, Gang gang) {
        if (player == null || gang == null) {
            return false;
        }
        if (this.playerGang.containsKey(player.getUniqueId())) {
            return false;
        }
        gang.setRole(player.getUniqueId(), GangRole.MEMBER);
        this.playerGang.put(player.getUniqueId(), gang.getId());
        this.save();
        return true;
    }

    public boolean leaveGang(Player player) {
        UUID newLeader;
        Gang gang = this.getGangByPlayer(player.getUniqueId());
        if (gang == null) {
            return false;
        }
        GangRole role = gang.getRole(player.getUniqueId());
        gang.removeMember(player.getUniqueId());
        this.playerGang.remove(player.getUniqueId());
        if (role == GangRole.LEADER && (newLeader = (UUID)gang.getMembers().entrySet().stream().sorted((a, b) -> ((GangRole)((Object)((Object)b.getValue()))).ordinal() - ((GangRole)((Object)((Object)a.getValue()))).ordinal()).map(Map.Entry::getKey).findFirst().orElse(null)) != null) {
            gang.setRole(newLeader, GangRole.LEADER);
        }
        if (gang.getMembers().isEmpty()) {
            this.removeGang(gang.getId());
            return true;
        }
        this.save();
        return true;
    }

    public boolean promote(Gang gang, Player actor, Player target) {
        if (gang == null || actor == null || target == null) {
            return false;
        }
        GangRole actorRole = gang.getRole(actor.getUniqueId());
        GangRole targetRole = gang.getRole(target.getUniqueId());
        if (actorRole == null || targetRole == null) {
            return false;
        }
        if (!actorRole.isHigherOrEqual(GangRole.CO_LEADER)) {
            return false;
        }
        GangRole next = targetRole.promote();
        if (next == targetRole) {
            return false;
        }
        if (next == GangRole.LEADER) {
            if (actorRole != GangRole.LEADER) {
                return false;
            }
            UUID current = gang.getLeader();
            if (current != null) {
                gang.setRole(current, GangRole.CO_LEADER);
            }
        }
        gang.setRole(target.getUniqueId(), next);
        this.save();
        return true;
    }

    public boolean demote(Gang gang, Player actor, Player target) {
        if (gang == null || actor == null || target == null) {
            return false;
        }
        GangRole actorRole = gang.getRole(actor.getUniqueId());
        GangRole targetRole = gang.getRole(target.getUniqueId());
        if (actorRole == null || targetRole == null) {
            return false;
        }
        if (!actorRole.isHigherOrEqual(GangRole.CO_LEADER)) {
            return false;
        }
        if (targetRole == GangRole.LEADER) {
            return false;
        }
        GangRole next = targetRole.demote();
        if (next == targetRole) {
            return false;
        }
        gang.setRole(target.getUniqueId(), next);
        this.save();
        return true;
    }

    public boolean kick(Gang gang, Player actor, OfflinePlayer target) {
        if (gang == null || actor == null || target == null) {
            return false;
        }
        GangRole actorRole = gang.getRole(actor.getUniqueId());
        GangRole targetRole = gang.getRole(target.getUniqueId());
        if (actorRole == null || targetRole == null) {
            return false;
        }
        if (!actorRole.isHigherOrEqual(GangRole.CO_LEADER)) {
            return false;
        }
        if (targetRole == GangRole.LEADER) {
            return false;
        }
        gang.removeMember(target.getUniqueId());
        this.playerGang.remove(target.getUniqueId());
        this.save();
        if (target.isOnline() && target.getPlayer() != null) {
            target.getPlayer().sendMessage(Lang.msg("gang.kick.target", "&cYou were kicked from gang &f{name}&c.").replace("{name}", gang.getName()));
        }
        return true;
    }

    public Relation getRelation(String gangA, String gangB) {
        if (gangA == null || gangB == null || gangA.equals(gangB)) {
            return Relation.NEUTRAL;
        }
        return this.relations.getOrDefault(gangA, Collections.emptyMap()).getOrDefault(gangB, Relation.NEUTRAL);
    }

    public List<String> getRelated(String gangId, Relation relation) {
        Map<String, Relation> rels = this.relations.getOrDefault(gangId, Collections.emptyMap());
        ArrayList<String> out = new ArrayList<>();
        for (Map.Entry<String, Relation> entry : rels.entrySet()) {
            if (entry.getValue() != relation) continue;
            Gang g = this.gangs.get(entry.getKey());
            out.add(g != null ? g.getName() : entry.getKey());
        }
        return out;
    }

    public void setRelation(String a, String b, Relation relation) {
        if (a == null || b == null || a.equals(b)) {
            return;
        }
        this.relations.computeIfAbsent(a, k -> new HashMap()).put(b, relation);
        this.relations.computeIfAbsent(b, k -> new HashMap()).put(a, relation);
        this.save();
    }

    public String nameColor(UUID viewer, UUID target) {
        Gang viewerGang = this.getGangByPlayer(viewer);
        Gang targetGang = this.getGangByPlayer(target);
        if (viewerGang == null || targetGang == null) {
            return "&f";
        }
        if (viewerGang.getId().equals(targetGang.getId())) {
            return "&a";
        }
        Relation rel = this.getRelation(viewerGang.getId(), targetGang.getId());
        return switch (rel.ordinal()) {
            case 2 -> "&c";
            case 1 -> "&a";
            case 0 -> "&7";
            default -> "&f";
        };
    }

    public List<Gang> topByPoints(int limit) {
        return this.gangs.values().stream().filter(g -> g != null && !g.getMembers().isEmpty()).sorted(Comparator.comparingInt(this::getEffectivePoints).reversed()).limit(limit).toList();
    }

    public void addPoints(String gangId, int amount) {
        Gang g = this.gangs.get(gangId);
        if (g == null) {
            return;
        }
        g.addPoints(amount);
        this.save();
    }

    public void setGangChat(UUID playerId, boolean enabled) {
        if (enabled) {
            this.gangChatToggled.put(playerId, true);
        } else {
            this.gangChatToggled.remove(playerId);
        }
    }

    public boolean isGangChat(UUID playerId) {
        return this.gangChatToggled.getOrDefault(playerId, false);
    }

    public int getEffectivePoints(Gang gang) {
        if (gang == null) {
            return 0;
        }
        int total = gang.getPoints();
        if (this.plugin.getCellService() == null) {
            return total;
        }
        for (Cell cell : this.plugin.getCellService().getCells()) {
            if (cell == null || cell.getOwner() == null) {
                continue;
            }
            if (!gang.getMembers().containsKey(cell.getOwner())) {
                continue;
            }
            if (this.plugin.getGeneratorService() != null) {
                total += this.plugin.getGeneratorService().getGangPoints(cell);
            }
            if (this.plugin.getCustomBlockService() != null) {
                total += this.plugin.getCustomBlockService().getGangPoints(cell);
            }
        }
        return total;
    }

    private void pruneEmptyGangs() {
        ArrayList<String> empty = new ArrayList<String>();
        for (Gang gang : this.gangs.values()) {
            if (gang == null) {
                continue;
            }
            if (gang.getMembers().isEmpty()) {
                empty.add(gang.getId());
            }
        }
        if (empty.isEmpty()) {
            return;
        }
        for (String gangId : empty) {
            this.removeGang(gangId);
        }
        this.save();
    }

    private void removeGang(String gangId) {
        if (gangId == null) {
            return;
        }
        Gang removed = this.gangs.remove(gangId);
        if (removed == null) {
            return;
        }
        for (UUID memberId : new ArrayList<UUID>(removed.getMembers().keySet())) {
            this.playerGang.remove(memberId);
        }
        this.relations.remove(gangId);
        for (Map<String, Relation> relMap : this.relations.values()) {
            relMap.remove(gangId);
        }
        for (Set<String> invites : this.pendingInvites.values()) {
            invites.remove(gangId);
        }
        this.pendingInvites.entrySet().removeIf(entry -> entry.getValue() == null || entry.getValue().isEmpty());
    }

    public static enum Relation {
        NEUTRAL,
        TRUCE,
        ENEMY;

    }
}
