/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;
import com.github.retrooper.packetevents.PacketEvents;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public class BlockProgressService {
    private final Map<Key, Float> progressMap = new ConcurrentHashMap<Key, Float>();
    private final Map<Key, Integer> renderTasks = new ConcurrentHashMap<Key, Integer>();
    private final Map<Key, Integer> expiryTasks = new ConcurrentHashMap<Key, Integer>();
    private final Map<Key, Integer> animIds = new ConcurrentHashMap<Key, Integer>();
    private final Map<Key, Integer> mineTasks = new ConcurrentHashMap<Key, Integer>();
    private final Map<UUID, Key> activeDigging = new ConcurrentHashMap<UUID, Key>();
    private final Plugin plugin;
    private final long holdTicks;
    private final boolean packetEventsEnabled;

    public BlockProgressService(Plugin plugin, long holdTicks) {
        this.plugin = plugin;
        this.holdTicks = holdTicks;
        this.packetEventsEnabled = plugin.getServer().getPluginManager().getPlugin("packetevents") != null;
    }

    public boolean isPacketEventsEnabled() {
        return this.packetEventsEnabled && PacketEvents.getAPI() != null;
    }

    public void beginDigging(Block block, Player player) {
        if (block == null || player == null) {
            return;
        }
        this.activeDigging.put(player.getUniqueId(), Key.of(block, player));
    }

    public void endDigging(Player player) {
        if (player == null) {
            return;
        }
        this.activeDigging.remove(player.getUniqueId());
    }

    public boolean isActivelyDigging(Player player, Block block) {
        if (!this.packetEventsEnabled || player == null || block == null || !player.isOnline()) {
            return false;
        }
        Key key = this.activeDigging.get(player.getUniqueId());
        return key != null && key.pos.equals(BlockPos.of(block));
    }

    public void ensureTracking(Block block, Player player) {
        Key key = Key.of(block, player);
        this.progressMap.putIfAbsent(key, Float.valueOf(0.0f));
        this.scheduleRender(block, player, key);
        this.rescheduleExpiry(block, key);
    }

    public float addProgress(Block block, Player player, float amount) {
        Key key = Key.of(block, player);
        float current = this.progressMap.getOrDefault(key, Float.valueOf(0.0f)).floatValue();
        float updated = Math.min(1.0f, current + amount);
        this.progressMap.put(key, Float.valueOf(updated));
        this.scheduleRender(block, player, key);
        this.rescheduleExpiry(block, key);
        return updated;
    }

    public void clear(Block block, Player player) {
        this.clear(Key.of(block, player), block, player);
    }

    public void clear(Block block) {
        BlockPos pos = BlockPos.of(block);
        ArrayList<Key> keys = new ArrayList<Key>();
        for (Key k : this.progressMap.keySet()) {
            if (!k.pos.equals(pos)) continue;
            keys.add(k);
        }
        ArrayList<UUID> activePlayers = new ArrayList<UUID>();
        for (Map.Entry<UUID, Key> entry : this.activeDigging.entrySet()) {
            if (!entry.getValue().pos.equals(pos)) continue;
            activePlayers.add(entry.getKey());
        }
        for (Key k : keys) {
            this.clear(k, block, Bukkit.getPlayer((UUID)k.playerId));
        }
        for (UUID id : activePlayers) {
            this.activeDigging.remove(id);
        }
    }

    private void clear(Key key, Block block, Player player) {
        Integer mine;
        Integer anim;
        Integer expId;
        this.progressMap.remove(key);
        this.activeDigging.computeIfPresent((UUID)key.playerId, (id, current) -> current != null && current.equals(key) ? null : current);
        Integer renderId = this.renderTasks.remove(key);
        if (renderId != null) {
            Bukkit.getScheduler().cancelTask(renderId.intValue());
        }
        if ((expId = this.expiryTasks.remove(key)) != null) {
            Bukkit.getScheduler().cancelTask(expId.intValue());
        }
        if ((anim = this.animIds.remove(key)) != null && player != null) {
            this.sendBreakPacket(block, player, anim, -1.0f);
        }
        if ((mine = this.mineTasks.remove(key)) != null) {
            Bukkit.getScheduler().cancelTask(mine.intValue());
        }
    }

    private void scheduleRender(Block block, Player player, Key key) {
        if (this.renderTasks.containsKey(key)) {
            return;
        }
        int id = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, () -> {
            Float prog = this.progressMap.get(key);
            if (prog == null) {
                Integer rid = this.renderTasks.remove(key);
                if (rid != null) {
                    Bukkit.getScheduler().cancelTask(rid.intValue());
                }
                return;
            }
            int anim = this.animIds.computeIfAbsent(key, k -> this.computeAnimId((Key)k));
            this.sendBreakPacket(block, player, anim, prog.floatValue());
        }, 0L, 1L);
        this.renderTasks.put(key, id);
    }

    public void startMining(Player player, Block block, float perTick, Supplier<Boolean> shouldTick) {
        this.startMining(player, block, () -> Float.valueOf(perTick), shouldTick);
    }

    public void startMining(Player player, Block block, Supplier<Float> perTickSupplier, Supplier<Boolean> shouldTick) {
        this.startMining(player, block, perTickSupplier, shouldTick, null, true);
    }

    public void startMining(Player player, Block block, Supplier<Float> perTickSupplier, Supplier<Boolean> shouldTick, Supplier<Boolean> onCompleteContinue, boolean autoBreakOnComplete) {
        Key key = Key.of(block, player);
        if (this.mineTasks.containsKey(key)) {
            return;
        }
        this.ensureTracking(block, player);
        final int[] taskIdHolder = new int[1];
        int taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, () -> {
            if (shouldTick != null && !((Boolean)shouldTick.get()).booleanValue()) {
                this.stopMining(key, player);
                return;
            }
            float perTick = 0.0f;
            if (perTickSupplier != null) {
                Float supplied = perTickSupplier.get();
                if (supplied != null) {
                    perTick = Math.max(0.0f, supplied.floatValue());
                }
            }
            if (perTick <= 0.0f) {
                this.stopMining(key, player);
                return;
            }
            Float prog = this.progressMap.get(key);
            if (prog == null) {
                prog = Float.valueOf(0.0f);
            }
            float updated = Math.min(1.0f, prog.floatValue() + perTick);
            this.progressMap.put(key, Float.valueOf(updated));
            this.rescheduleExpiry(block, key);
            if (updated >= 1.0f) {
                boolean keepGoing = onCompleteContinue != null && Boolean.TRUE.equals(onCompleteContinue.get());
                if (keepGoing) {
                    this.progressMap.put(key, Float.valueOf(0.0f));
                    this.rescheduleExpiry(block, key);
                    return;
                }
                this.mineTasks.remove(key);
                Bukkit.getScheduler().cancelTask(taskIdHolder[0]);
                if (autoBreakOnComplete) {
                    Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                        Float current = this.progressMap.get(key);
                        if (current == null || current.floatValue() < 1.0f) {
                            return;
                        }
                        this.clear(key, block, player);
                        player.breakBlock(block);
                    }, 2L);
                }
            }
        }, 1L, 1L);
        taskIdHolder[0] = taskId;
        this.mineTasks.put(key, taskId);
    }

    public void resetProgress(Block block, Player player) {
        if (block == null || player == null) {
            return;
        }
        Key key = Key.of(block, player);
        this.progressMap.put(key, Float.valueOf(0.0f));
        this.scheduleRender(block, player, key);
        this.rescheduleExpiry(block, key);
    }

    private void stopMining(Key key, Player player) {
        Integer mine = this.mineTasks.remove(key);
        if (mine != null) {
            Bukkit.getScheduler().cancelTask(mine.intValue());
        }
        if (player != null) {
            this.activeDigging.remove(player.getUniqueId(), key);
        }
    }

    private void rescheduleExpiry(Block block, Key key) {
        Integer existing = this.expiryTasks.remove(key);
        if (existing != null) {
            Bukkit.getScheduler().cancelTask(existing.intValue());
        }
        int id = Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, () -> this.clear(key, block, Bukkit.getPlayer((UUID)key.playerId)), this.holdTicks);
        this.expiryTasks.put(key, id);
    }

    private void sendBreakPacket(Block block, Player player, int animationId, float progress) {
        if (player == null || !player.isOnline()) {
            return;
        }
        if (player.getLocation().distanceSquared(block.getLocation()) > 4096.0) {
            return;
        }
        float clamped = progress < 0.0f ? 0.0f : Math.min(1.0f, Math.max(0.0f, progress));
        player.sendBlockDamage(block.getLocation(), clamped, animationId);
    }

    private int computeAnimId(Key key) {
        int hash = key.pos.world.hashCode();
        hash = 31 * hash + key.pos.x;
        hash = 31 * hash + key.pos.y;
        hash = 31 * hash + key.pos.z;
        hash = 31 * hash + key.playerId.hashCode();
        return Math.abs(hash % 2000000000);
    }

    private record Key(BlockPos pos, UUID playerId) {
        static Key of(Block block, Player player) {
            return new Key(BlockPos.of(block), player.getUniqueId());
        }
    }

    private record BlockPos(String world, int x, int y, int z) {
        static BlockPos of(Block block) {
            return new BlockPos(block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
        }
    }
}
