package org.axial.prisonsCore.service;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public final class PrivateMessageService {
    private static final String SENDER_FORMAT = "&e[&bKryo&e] &7[&bMe &7-> &e{recipient}&7] &f";
    private static final String RECEIVER_FORMAT = "&e[&bKryo&e] &7[&b{player} &7-> &eMe&7] &f";
    private final PlayerDataService playerDataService;
    private final PlayerToggleService toggleService;
    private final Map<UUID, UUID> lastReplyTargets = new ConcurrentHashMap<UUID, UUID>();

    public PrivateMessageService(PlayerDataService playerDataService, PlayerToggleService toggleService) {
        this.playerDataService = playerDataService;
        this.toggleService = toggleService;
    }

    public boolean sendMessage(Player sender, Player target, String message) {
        if (sender == null || target == null || message == null || message.isBlank()) {
            return false;
        }
        if (!target.isOnline()) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return false;
        }
        if (this.toggleService != null && !this.toggleService.isEnabled(target, PlayerToggleService.Toggle.PRIVATE_MESSAGES)) {
            sender.sendMessage(Text.color("&c" + this.displayName(target) + " is not receiving private messages right now."));
            return false;
        }
        sender.sendMessage(this.buildSenderMessage(target, message));
        target.sendMessage(this.buildReceiverMessage(sender, message));
        this.lastReplyTargets.put(target.getUniqueId(), sender.getUniqueId());
        return true;
    }

    public boolean reply(Player sender, String message) {
        if (sender == null || message == null || message.isBlank()) {
            return false;
        }
        UUID targetId = this.lastReplyTargets.get(sender.getUniqueId());
        if (targetId == null) {
            sender.sendMessage(Text.color("&cYou have no one to reply to."));
            return false;
        }
        Player target = Bukkit.getPlayer((UUID)targetId);
        if (target == null || !target.isOnline()) {
            sender.sendMessage(Text.color("&cThat player is no longer online."));
            return false;
        }
        return this.sendMessage(sender, target, message);
    }

    public void handleQuit(UUID playerId) {
        if (playerId == null) {
            return;
        }
        this.lastReplyTargets.entrySet().removeIf(entry -> playerId.equals(entry.getKey()) || playerId.equals(entry.getValue()));
    }

    private String displayName(Player player) {
        if (player == null) {
            return "Player";
        }
        if (this.playerDataService == null) {
            return player.getName();
        }
        String chatName = this.playerDataService.getChatName(player);
        return chatName == null || chatName.isBlank() ? player.getName() : chatName;
    }

    private Component buildSenderMessage(Player target, String message) {
        String prefix = SENDER_FORMAT.replace("{recipient}", this.displayName(target));
        return Text.componentNoItalics(prefix).append(Component.text(message).decoration(TextDecoration.ITALIC, false));
    }

    private Component buildReceiverMessage(Player sender, String message) {
        String prefix = RECEIVER_FORMAT.replace("{player}", this.displayName(sender));
        return Text.componentNoItalics(prefix).append(Component.text(message).decoration(TextDecoration.ITALIC, false));
    }
}
