/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.EntityEquipment
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.scheduler.BukkitTask
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class GuardService {
    private static final String DEFAULT_GUARD_TEXTURE = "ewogICJ0aW1lc3RhbXAiIDogMTczODE5Njg1NDM0NSwKICAicHJvZmlsZUlkIiA6ICJmMzNlZGMyNTRmNDk0NWY2YTg5ZjFjM2JhZmNkZjIwNiIsCiAgInByb2ZpbGVOYW1lIiA6ICJGVV9CYWJ5IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2Q4ZDc1YWJmYzAyYTZmNjU2YjUyNDI2ODA0YWFlNDk4ZTljM2NhOTRhOTdkN2RiYzM2OTczYTM2MGJkZjNlNzAiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==";
    private static final String DEFAULT_GUARD_SIGNATURE = "Jr7s1UxNgwnnJqajNNJVq/r+Q4TaI0PY4k7ZCZbMtxFPfRV85wop6XoIvEftUxL7IdX+lLZrt5zNgn6BZ77EL1WYrUsAgEjt4ce/h8yvqxE50bsTLSmVZmPqM1u7r1rq7LAsYtKl+pQn3U+dHAfTAoHhJf1daEL9kfw/ctK4MOxSGSrkObqXWXC6XEvpBA8maOTE93lw6l1OYWFmqnX8T1quaI9v3f6iAiEQqV420wiXFrbDI2ctb3r2WF7yd6EkJEmpf7b7bpIYtYeybdZCRffWfAyYiQJ7F/DLvEg2qhZldYolNv7yKM+KbHN+zoJmV23SzI5jzn4bn/R4jQzPUW6S+JOib2oZR5pkGnW0zxgiUmUQWWaI4M06U9+dpVRbuphO2dd1AaoRQJgElHEbJuAznI5KzezS4yKrYPNufw4m8uPI80RlHCxOVsvHFriUGxWyof66U6+cP/POkNgBiWF7pI1cQhSZH6mv50rmd22yuovttLHVJgPOanMSM7YZhnbfiG5uUDCoxOcO+aZ2FeyqtZwd9kuux1NN/3YBk8Bb3sD9dYS24S53PtqhvQUJJj/sR3U8zq+fprqXM1aPyru7z4MfeGx4pGOm+V+3sjyuYWtvr1GcL4shTUbK4YzdNNY4X+McdPGzilHPHPk8z3Ym5h5+T90rhK0bPvKNHvo=";
    public static final double GUARD_PROTECTION_RANGE = 20.0;
    private final PrisonsCore plugin;
    private final Map<String, GuardTemplate> templates = new HashMap<String, GuardTemplate>();
    private final Set<UUID> guardIds = new HashSet<UUID>();
    private final Map<UUID, Location> guardSpawns = new HashMap<UUID, Location>();
    private final Map<UUID, GuardTemplate> guardTemplatesById = new HashMap<UUID, GuardTemplate>();
    private final Map<UUID, String> guardCustomNames = new HashMap<UUID, String>();
    private final Map<UUID, UUID> guardTargets = new HashMap<UUID, UUID>();
    private double retaliationDamage = 4.0;
    private BukkitTask monitorTask;
    private BukkitTask reconcileTask;
    private File guardFile;
    private YamlConfiguration guardCfg;
    private boolean loadingSpawns = false;
    private final Map<String, GuardTemplate> builtinTemplates = new HashMap<String, GuardTemplate>();
    private final Map<UUID, Long> guardEquipReadyAt = new HashMap<UUID, Long>();
    private final Map<UUID, Double> guardPendingHealth = new HashMap<UUID, Double>();
    private final Map<UUID, Long> guardHealthReadyAt = new HashMap<UUID, Long>();
    private final Map<UUID, Double> guardDesiredHealth = new HashMap<UUID, Double>();
    private final Map<UUID, Double> guardCurrentHealth = new HashMap<UUID, Double>();
    private final Map<UUID, Long> guardLastHit = new HashMap<UUID, Long>();
    private final Map<UUID, Long> guardAttackReadyAt = new HashMap<UUID, Long>();
    private static final long IDLE_HEAL_MS = 600000L;
    private static final double GUARD_SPEED_MULTIPLIER = 1.5;
    private static final String GUARD_TAG = "prisonscore_guard";
    private static final int RECONCILE_PASSES = 5;
    private boolean skinWarningLogged = false;

    public GuardService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.initBuiltinTemplates();
        this.reload(true);
        this.startMonitorTask();
    }

    public Entity spawnDefaultGuard(Location loc, String name) {
        GuardTemplate template = this.templates.get("default");
        if (template == null) {
            template = this.builtinTemplates.get("default");
        }
        if (template == null) {
            template = this.builtinTemplates.values().stream().findFirst().orElse(null);
        }
        if (template == null) {
            return null;
        }
        return this.spawnGuard(template, loc, name, null);
    }

    public ItemStack createGuardSpawnerItem(String templateId) {
        GuardTemplate template = this.getTemplate(templateId);
        if (template == null) {
            template = this.builtinTemplates.get("default");
        }
        if (template == null) {
            return null;
        }
        ItemStack item = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String id = this.storageTemplateId(template);
            String displayName = switch (id) {
                case "enforcer" -> "&5&lEnforcer Guard Spawner";
                case "warden" -> "&b&lWarden Guard Spawner";
                default -> "&c&lDefault Guard Spawner";
            };
            String spawnName = switch (id) {
                case "enforcer" -> "Enforcer Guard";
                case "warden" -> "Warden Guard";
                default -> "Default Guard";
            };
            meta.setDisplayName(Text.color(displayName));
            meta.setLore(List.of(
                    Text.color("&7Right-click to spawn a guard."),
                    Text.color("&7Spawns: &f" + spawnName)
            ));
            meta.getPersistentDataContainer().set(Keys.guardSpawner(this.plugin), PersistentDataType.BYTE, (byte)1);
            meta.getPersistentDataContainer().set(Keys.guardSpawnerType(this.plugin), PersistentDataType.STRING, id);
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isGuardSpawnerItem(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(Keys.guardSpawner(this.plugin), PersistentDataType.BYTE);
    }

    public String getGuardSpawnerType(ItemStack item) {
        if (!this.isGuardSpawnerItem(item)) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer().get(Keys.guardSpawnerType(this.plugin), PersistentDataType.STRING);
    }

    public Set<UUID> getGuardIds() {
        return Set.copyOf(this.guardIds);
    }

    public double nearestGuardDistance(Location loc, double maxDistance) {
        if (loc == null) {
            return -1.0;
        }
        double closest = Double.MAX_VALUE;
        for (UUID id : this.guardIds) {
            double d;
            Entity entity = this.plugin.getServer().getEntity(id);
            Location checkLoc = null;
            if (entity != null && !entity.isDead() && entity.getWorld().equals((Object)loc.getWorld())) {
                checkLoc = entity.getLocation();
            } else {
                Location home = this.guardSpawns.get(id);
                if (home != null && home.getWorld().equals((Object)loc.getWorld())) {
                    checkLoc = home;
                }
            }
            if (checkLoc == null || !((d = checkLoc.distance(loc)) < closest)) continue;
            closest = d;
        }
        if (closest == Double.MAX_VALUE || closest > maxDistance) {
            return -1.0;
        }
        return closest;
    }

    public boolean hasGuardTypeNearby(Location loc, double maxDistance, String... guardTypeIds) {
        if (loc == null || loc.getWorld() == null || guardTypeIds == null || guardTypeIds.length == 0) {
            return false;
        }
        for (UUID id : this.guardIds) {
            Entity entity = this.plugin.getServer().getEntity(id);
            if (!(entity instanceof LivingEntity living) || living.isDead() || entity.getWorld() == null || !entity.getWorld().equals(loc.getWorld())) {
                continue;
            }
            double distance = entity.getLocation().distance(loc);
            if (distance > maxDistance) {
                continue;
            }
            GuardTemplate template = this.guardTemplatesById.get(id);
            String templateId = template != null && template.id() != null ? template.id().toLowerCase() : "";
            for (String guardTypeId : guardTypeIds) {
                if (guardTypeId != null && templateId.equals(guardTypeId.toLowerCase())) {
                    return true;
                }
            }
        }
        return false;
    }

    public void reload() {
        this.reload(false);
    }

    private void reload(boolean startupLoadOnly) {
        this.despawnTrackedGuards();
        this.templates.clear();
        this.guardIds.clear();
        this.guardSpawns.clear();
        this.guardTemplatesById.clear();
        this.guardCustomNames.clear();
        this.guardTargets.clear();
        this.guardFile = new File(this.plugin.getDataFolder(), "guards.yml");
        if (!this.guardFile.exists()) {
            this.plugin.saveResource("guards.yml", false);
        }
        this.guardCfg = YamlConfiguration.loadConfiguration((File)this.guardFile);
        this.purgeRuntimeGuards();
        if (this.plugin.getGuardDisplayService() != null) {
            this.plugin.getGuardDisplayService().purgeOrphanStands();
        }
        ConfigurationSection sec = this.guardCfg.getConfigurationSection("guards");
        if (sec == null) {
            this.addBuiltinTemplatesIfMissing();
            return;
        }
        this.retaliationDamage = sec.getDouble("attack-damage", this.retaliationDamage);
        ConfigurationSection tmpl = sec.getConfigurationSection("templates");
        if (tmpl != null) {
            for (String key : tmpl.getKeys(false)) {
                ConfigurationSection node = tmpl.getConfigurationSection(key);
                if (node == null) continue;
                String name = node.getString("display-name", "&cGuard");
                ConfigurationSection skinNode = node.getConfigurationSection("skin");
                Skin skin = null;
                if (skinNode != null) {
                    skin = new Skin(skinNode.getString("owner", ""), skinNode.getString("texture", ""), skinNode.getString("signature", ""));
                }
                ItemStack helmet = this.parseItem(node.getString("helmet"));
                ItemStack chest = this.parseItem(node.getString("chestplate"));
                ItemStack legs = this.parseItem(node.getString("leggings"));
                ItemStack boots = this.parseItem(node.getString("boots"));
                ItemStack weapon = this.parseItem(node.getString("weapon"));
                double health = node.getDouble("health", 1000.0);
                this.templates.put(key.toLowerCase(), this.enforceDefaultProtection(key, new GuardTemplate(key.toLowerCase(), name, skin, helmet, chest, legs, boots, weapon, health)));
            }
        }
        this.addBuiltinTemplatesIfMissing();
        if (startupLoadOnly) {
            return;
        }
        this.loadSpawns();
        this.guardIds.clear();
        this.guardSpawns.clear();
        this.guardTemplatesById.clear();
        this.guardCustomNames.clear();
        this.scheduleReconcileSpawns();
    }

    private ItemStack parseItem(String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        Material m = Material.matchMaterial((String)name);
        return m == null ? null : new ItemStack(m);
    }

    public Set<String> ids() {
        return this.templates.keySet();
    }

    public GuardTemplate getTemplate(String id) {
        if (id == null || id.isBlank()) {
            return null;
        }
        String normalized = id.toLowerCase();
        if ("guard".equals(normalized)) {
            normalized = "default";
        }
        GuardTemplate template = this.templates.get(normalized);
        if (template == null && "default".equals(normalized)) {
            return this.builtinTemplates.get("default");
        }
        return template;
    }

    private void loadSpawns() {
        if (this.guardCfg == null) {
            return;
        }
        this.removeDuplicateTaggedGuards();
        this.recoverExistingGuards();
        ConfigurationSection spawns = this.guardCfg.getConfigurationSection("spawns");
        if (spawns == null) {
            return;
        }
        this.loadingSpawns = true;
        for (String key : spawns.getKeys(false)) {
            World world;
            String templateId;
            GuardTemplate template;
            ConfigurationSection node = spawns.getConfigurationSection(key);
            if (node == null || (template = (templateId = node.getString("template")) != null ? this.getTemplate(templateId) : null) == null) continue;
            String worldName = node.getString("world");
            World world2 = world = worldName != null ? Bukkit.getWorld((String)worldName) : null;
            if (world == null) continue;
            double x = node.getDouble("x");
            double y = node.getDouble("y");
            double z = node.getDouble("z");
            float yaw = (float)node.getDouble("yaw");
            float pitch = (float)node.getDouble("pitch");
            String name = node.getString("name", null);
            UUID entityId = this.parseEntityId(node.getString("entity-uuid"));
            Location loc = new Location(world, x, y, z, yaw, pitch);
            try {
                if (this.hasTrackedGuard(template, loc, name)) continue;
                if (this.bindExistingGuard(template, loc, name, entityId) != null) continue;
            }
            catch (Exception e) {
                this.plugin.getLogger().warning("Failed to respawn guard '" + key + "': " + e.getMessage());
            }
        }
        this.loadingSpawns = false;
    }

    public void scheduleReconcileSpawns() {
        if (this.reconcileTask != null) {
            this.reconcileTask.cancel();
            this.reconcileTask = null;
        }
        final int[] pass = new int[]{0};
        this.reconcileTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            pass[0]++;
            this.reconcileSpawns(pass[0] >= RECONCILE_PASSES);
            if (pass[0] >= RECONCILE_PASSES && this.reconcileTask != null) {
                this.reconcileTask.cancel();
                this.reconcileTask = null;
            }
        }, 20L, 40L);
    }

    private void reconcileSpawns(boolean allowSpawn) {
        if (this.guardCfg == null) {
            return;
        }
        this.removeDuplicateTaggedGuards();
        this.recoverExistingGuards();
        ConfigurationSection spawns = this.guardCfg.getConfigurationSection("spawns");
        if (spawns == null) {
            return;
        }
        this.loadingSpawns = true;
        for (String key : spawns.getKeys(false)) {
            ConfigurationSection node = spawns.getConfigurationSection(key);
            if (node == null) {
                continue;
            }
            GuardTemplate template = this.getTemplate(node.getString("template"));
            if (template == null) {
                continue;
            }
            World world = Bukkit.getWorld(node.getString("world"));
            if (world == null) {
                continue;
            }
            Location loc = new Location(world, node.getDouble("x"), node.getDouble("y"), node.getDouble("z"), (float)node.getDouble("yaw"), (float)node.getDouble("pitch"));
            String name = node.getString("name", null);
            UUID entityId = this.parseEntityId(node.getString("entity-uuid"));
            if (this.hasTrackedGuard(template, loc, name)) {
                continue;
            }
            LivingEntity existing = this.bindExistingGuard(template, loc, name, entityId);

            if (existing == null && allowSpawn) {

                // 🔥 DOUBLE CHECK: prevent duplicates
                if (!this.hasTrackedGuard(template, loc, name)) {
                    this.spawnGuard(template, loc, name, null);
                }
            }
        }
        this.loadingSpawns = false;
    }

    private boolean hasTrackedGuard(GuardTemplate template, Location home, String customName) {
        if (template == null || home == null || home.getWorld() == null) {
            return false;
        }
        for (UUID id : this.guardIds) {
            GuardTemplate trackedTemplate = this.guardTemplatesById.get(id);
            Location trackedHome = this.guardSpawns.get(id);
            String trackedName = this.guardCustomNames.get(id);
            if (trackedTemplate == null || trackedHome == null || trackedHome.getWorld() == null) {
                continue;
            }
            if (!template.id().equalsIgnoreCase(trackedTemplate.id())) {
                continue;
            }
            if (!trackedHome.getWorld().equals(home.getWorld()) || trackedHome.distanceSquared(home) > 0.25) {
                continue;
            }
            if (!this.sameCustomName(trackedName, customName)) {
                continue;
            }
            return true;
        }
        return false;
    }

    private void saveSpawns() {
        if (this.guardCfg == null || this.guardFile == null) {
            return;
        }
        this.guardCfg.set("spawns", null);
        int idx = 0;
        for (UUID id : this.guardIds) {
            Location home = this.guardSpawns.get(id);
            GuardTemplate template = this.guardTemplatesById.get(id);
            if (home == null || template == null) continue;
            String base = "spawns." + idx++;
            this.guardCfg.set(base + ".template", (Object)this.storageTemplateId(template));
            this.guardCfg.set(base + ".world", home.getWorld() != null ? home.getWorld().getName() : null);
            this.guardCfg.set(base + ".x", (Object)home.getX());
            this.guardCfg.set(base + ".y", (Object)home.getY());
            this.guardCfg.set(base + ".z", (Object)home.getZ());
            this.guardCfg.set(base + ".yaw", (Object)Float.valueOf(home.getYaw()));
            this.guardCfg.set(base + ".pitch", (Object)Float.valueOf(home.getPitch()));
            this.guardCfg.set(base + ".entity-uuid", (Object)id.toString());
            String name = this.guardCustomNames.get(id);
            if (name == null) continue;
            this.guardCfg.set(base + ".name", (Object)name);
        }
        try {
            this.guardCfg.save(this.guardFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save guard spawns: " + e.getMessage());
        }
    }

    private void despawnTrackedGuards() {
        for (UUID gid : new HashSet<UUID>(this.guardIds)) {
            Entity ent = Bukkit.getEntity((UUID)gid);
            if (ent != null) {
                this.destroyCitizensNpc(ent);
                continue;
            }
            this.destroyCitizensNpc(gid);
        }
        this.guardIds.clear();
        this.guardTargets.clear();
        this.guardPendingHealth.clear();
        this.guardHealthReadyAt.clear();
        this.guardEquipReadyAt.clear();
        this.guardDesiredHealth.clear();
        this.guardCurrentHealth.clear();
        this.guardLastHit.clear();
        this.guardAttackReadyAt.clear();
        this.guardSpawns.clear();
        this.guardTemplatesById.clear();
        this.guardCustomNames.clear();
    }

    private String storageTemplateId(GuardTemplate template) {
        if (template == null || template.id() == null || template.id().isBlank()) {
            return "default";
        }
        return "guard".equalsIgnoreCase(template.id()) ? "default" : template.id();
    }

    private void recoverExistingGuards() {
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (!(entity instanceof LivingEntity living) || entity.isDead() || !this.isTaggedGuard(living)) {
                    continue;
                }
                if (this.restoreTrackedGuard(living)) {
                    this.sendGuardHome(living.getUniqueId(), living);
                }
            }
        }
    }

    private void removeDuplicateTaggedGuards() {
        Map<String, LivingEntity> seen = new HashMap<String, LivingEntity>();
        List<LivingEntity> duplicates = new ArrayList<LivingEntity>();
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (!(entity instanceof LivingEntity living) || entity.isDead() || !this.isTaggedGuard(living)) {
                    continue;
                }
                GuardTemplate template = this.resolveTaggedTemplate(living);
                Location home = this.readTaggedHome(living);
                if (template == null || home == null || home.getWorld() == null) {
                    continue;
                }
                String key = this.storageTemplateId(template)
                        + "|" + home.getWorld().getName()
                        + "|" + home.getBlockX()
                        + "|" + home.getBlockY()
                        + "|" + home.getBlockZ()
                        + "|" + (this.readTaggedCustomName(living) == null ? "" : this.readTaggedCustomName(living));
                LivingEntity existing = seen.putIfAbsent(key, living);
                if (existing != null && !existing.getUniqueId().equals(living.getUniqueId())) {
                    duplicates.add(living);
                }
            }
        }
        for (LivingEntity duplicate : duplicates) {
            this.destroyCitizensNpc((Entity)duplicate);
        }
    }

    private void purgeRuntimeGuards() {
        int removed = 0;
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : new ArrayList<>(world.getEntities())) {
                if (!(entity instanceof LivingEntity living) || entity.isDead()) {
                    continue;
                }
                if (!this.isTaggedGuard(living) && !this.isCitizensNpc(living) && !this.isChasingGuard(living)) {
                    continue;
                }
                this.destroyCitizensNpc(entity);
                entity.remove();
                removed++;
            }
        }
        if (removed > 0) {
            this.plugin.getLogger().info("[Guards] Purged " + removed + " runtime guard NPCs before respawn.");
        }
    }

    public void shutdown() {
        if (this.monitorTask != null) {
            this.monitorTask.cancel();
            this.monitorTask = null;
        }
        if (this.reconcileTask != null) {
            this.reconcileTask.cancel();
            this.reconcileTask = null;
        }
        this.saveSpawns();
        this.despawnTrackedGuards();
        this.guardTargets.clear();
        this.guardPendingHealth.clear();
        this.guardHealthReadyAt.clear();
        this.guardEquipReadyAt.clear();
        this.guardDesiredHealth.clear();
        this.guardCurrentHealth.clear();
        this.guardLastHit.clear();
        this.guardAttackReadyAt.clear();
    }

    private void destroyCitizensNpc(Entity ent) {
        if (ent == null) {
            return;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, ent);
            if (npc != null) {
                this.destroyNpcHandle(npc);
                return;
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        ent.remove();
    }

    private void destroyCitizensNpc(UUID entityId) {
        if (entityId == null) {
            return;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getByUniqueIdGlobal", UUID.class).invoke(registry, entityId);
            if (npc != null) {
                this.destroyNpcHandle(npc);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void destroyNpcHandle(Object npc) {
        if (npc == null) {
            return;
        }
        try {
            npc.getClass().getMethod("destroy", new Class[0]).invoke(npc, new Object[0]);
            return;
        }
        catch (NoSuchMethodException ignored) {
            // fall through
        }
        catch (Exception exception) {
            // fall through
        }
        try {
            npc.getClass().getMethod("despawn", new Class[0]).invoke(npc, new Object[0]);
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            npc.getClass().getMethod("deregister", new Class[0]).invoke(npc, new Object[0]);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void initBuiltinTemplates() {
        ItemStack ironHelm = this.addEnchant(new ItemStack(Material.IRON_HELMET), Enchantment.PROTECTION, 5);
        ItemStack ironChest = this.addEnchant(new ItemStack(Material.IRON_CHESTPLATE), Enchantment.PROTECTION, 5);
        ItemStack ironLegs = this.addEnchant(new ItemStack(Material.IRON_LEGGINGS), Enchantment.PROTECTION, 5);
        ItemStack ironBoots = this.addEnchant(new ItemStack(Material.IRON_BOOTS), Enchantment.PROTECTION, 5);
        ItemStack goldSwordDefault = new ItemStack(Material.GOLDEN_SWORD);
        this.builtinTemplates.put("default", this.enforceDefaultProtection("default", new GuardTemplate("guard", "&c&lGuard", new Skin("", DEFAULT_GUARD_TEXTURE, DEFAULT_GUARD_SIGNATURE), ironHelm, ironChest, ironLegs, ironBoots, goldSwordDefault, 1000.0)));
        ItemStack diaHelm = new ItemStack(Material.DIAMOND_HELMET);
        ItemStack diaChest = new ItemStack(Material.DIAMOND_CHESTPLATE);
        ItemStack diaLegs = new ItemStack(Material.DIAMOND_LEGGINGS);
        ItemStack diaBoots = new ItemStack(Material.DIAMOND_BOOTS);
        ItemStack goldAxe = new ItemStack(Material.GOLDEN_AXE);
        this.builtinTemplates.put("warden", new GuardTemplate("warden", "&b&lWarden", null, diaHelm, diaChest, diaLegs, diaBoots, goldAxe, 250.0));
        ItemStack goldChest = new ItemStack(Material.GOLDEN_CHESTPLATE);
        ItemStack goldLegs = new ItemStack(Material.GOLDEN_LEGGINGS);
        ItemStack goldBoots = new ItemStack(Material.GOLDEN_BOOTS);
        ItemStack goldSword = new ItemStack(Material.GOLDEN_SWORD);
        this.builtinTemplates.put("enforcer", new GuardTemplate("enforcer", "&5&lEnforcer", null, null, goldChest, goldLegs, goldBoots, goldSword, 300.0));
    }

    private void addBuiltinTemplatesIfMissing() {
        for (Map.Entry<String, GuardTemplate> entry : this.builtinTemplates.entrySet()) {
            this.templates.putIfAbsent(entry.getKey(), this.enforceDefaultProtection(entry.getKey(), entry.getValue()));
        }
    }

    private ItemStack addEnchant(ItemStack item, Enchantment ench, int level) {
        item.addUnsafeEnchantment(ench, level);
        return item;
    }

    private GuardTemplate enforceDefaultProtection(String key, GuardTemplate template) {
        boolean isDefault;
        if (template == null) {
            return null;
        }
        String id = key != null ? key.toLowerCase() : "";
        String templateId = template.id() != null ? template.id().toLowerCase() : "";
        boolean bl = isDefault = id.equals("default") || templateId.equals("guard");
        if (!isDefault) {
            return template;
        }
        return new GuardTemplate(template.id(), template.displayName(), template.skin(), this.addEnchantSafe(template.helmet(), Enchantment.PROTECTION, 5), this.addEnchantSafe(template.chest(), Enchantment.PROTECTION, 5), this.addEnchantSafe(template.legs(), Enchantment.PROTECTION, 5), this.addEnchantSafe(template.boots(), Enchantment.PROTECTION, 5), template.weapon(), template.health());
    }

    private ItemStack addEnchantSafe(ItemStack item, Enchantment ench, int level) {
        if (item == null) {
            return null;
        }
        ItemStack copy = item.clone();
        try {
            copy.addUnsafeEnchantment(ench, level);
        }
        catch (Exception exception) {
            // empty catch block
        }
        return copy;
    }

    private ItemStack cloneItem(ItemStack item) {
        return item == null ? null : item.clone();
    }

    public Entity spawnGuard(GuardTemplate template, Location loc, String customName, Player requester) {

        if (loc == null) {
            if (requester != null) {
                requester.sendMessage(Lang.msg("guard.invalid-location", "&cInvalid location for guard spawn."));
            }
            return null;
        }

        Location home = loc.getBlock().getLocation().add(0.5, 0.0, 0.5);
        home.setYaw(loc.getYaw());
        home.setPitch(loc.getPitch());

        // =========================
        // 🚫 BLOCK DUPLICATES (TRACKED)
        // =========================
        for (UUID id : this.guardIds) {
            Location existing = this.guardSpawns.get(id);
            GuardTemplate existingTemplate = this.guardTemplatesById.get(id);
            String existingName = this.guardCustomNames.get(id);

            if (existing == null || existingTemplate == null) continue;
            if (!existing.getWorld().equals(home.getWorld())) continue;
            if (existing.distanceSquared(home) > 0.25) continue;
            if (!existingTemplate.id().equalsIgnoreCase(template.id())) continue;
            if (!this.sameCustomName(existingName, customName)) continue;

            return null; // already exists
        }

        // =========================
        // 🚫 BLOCK DUPLICATES (WORLD SCAN)
        // =========================
        for (Entity entity : home.getWorld().getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity.isDead()) continue;
            if (!this.isTaggedGuard(living)) continue;

            Location existingHome = this.readTaggedHome(living);
            GuardTemplate existingTemplate = this.resolveTaggedTemplate(living);

            if (existingHome == null || existingTemplate == null) continue;
            if (!existingHome.getWorld().equals(home.getWorld())) continue;
            if (existingHome.distanceSquared(home) > 0.25) continue;
            if (!existingTemplate.id().equalsIgnoreCase(template.id())) continue;

            String existingName = this.readTaggedCustomName(living);
            if (!this.sameCustomName(existingName, customName)) continue;

            this.trackGuard(living, template, existingHome, existingName);
            return living;
        }

        // =========================
        // ✅ SAFE SPAWN
        // =========================
        Entity npc = this.createCitizensNPC(template, home, customName);

        if (npc == null) {
            if (requester != null) {
                requester.sendMessage(Lang.msg("guard.citizens-required", "&cCitizens plugin is required to spawn guards."));
            }
            return null;
        }

        this.applyLoadout(template, npc, customName);

        this.guardIds.add(npc.getUniqueId());
        this.guardSpawns.put(npc.getUniqueId(), home.clone());
        this.guardTemplatesById.put(npc.getUniqueId(), template);
        this.guardCustomNames.put(npc.getUniqueId(), customName);

        if (npc instanceof LivingEntity living) {
            this.tagGuardEntity(living, template, home, customName);
        }

        this.ensureUnprotected(npc);

        if (!this.loadingSpawns) {
            this.saveSpawns();
        }

        return npc;
    }

    private Entity createCitizensNPC(GuardTemplate template, Location loc, String customName) {
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Class<?> npcRegistryClass = Class.forName("net.citizensnpcs.api.npc.NPCRegistry");
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            Class<?> entityTypeClass = Class.forName("org.bukkit.entity.EntityType");
            Object playerType = entityTypeClass.getField("PLAYER").get(null);
            Method create = npcRegistryClass.getMethod("createNPC", entityTypeClass, String.class);
            Object npc = create.invoke(registry, playerType, Text.color(customName != null ? customName : template.displayName()));
            try {
                this.applyPersistentSkin(npc, npcClass, this.resolveSkin(template));
            }
            catch (Exception exception) {
                // empty catch block
            }
            Method spawn = npcClass.getMethod("spawn", Location.class);
            spawn.invoke(npc, loc);
            try {
                npcClass.getMethod("setProtected", Boolean.TYPE).invoke(npc, false);
            }
            catch (NoSuchMethodException ignored) {
                try {
                Class<?> metadataEnum = Class.forName("net.citizensnpcs.api.npc.NPC$Metadata");
                Object protectedMeta = Enum.valueOf((Class)metadataEnum, "DEFAULT_PROTECTED");
                Object dataStore = npcClass.getMethod("data", new Class[0]).invoke(npc, new Object[0]);
                dataStore.getClass().getMethod("set", metadataEnum, Object.class).invoke(dataStore, protectedMeta, false);
            }
            catch (Exception metadataEnum) {}
            }
            catch (Exception ignored) {
                // empty catch block
            }
            Method getEntity = npcClass.getMethod("getEntity", new Class[0]);
            Entity bukkitEntity = (Entity)getEntity.invoke(npc, new Object[0]);
            this.applyFacing(bukkitEntity, loc);
            this.scheduleSkinApplications(npc, npcClass, this.resolveSkin(template));
            return bukkitEntity;
        }
        catch (Exception e) {
            this.plugin.getLogger().warning("Citizens not found or failed to create guard NPC: " + e.getMessage());
            return null;
        }
    }

    private void applyFacing(Entity entity, Location facing) {
        if (entity == null || facing == null) {
            return;
        }
        Location updated = entity.getLocation();
        updated.setYaw(facing.getYaw());
        updated.setPitch(facing.getPitch());
        entity.teleport(updated);
    }

    private void scheduleSkinApplications(final Object npc, final Class<?> npcClass, final Skin skin) {
        long[] delays;
        if (npc == null || npcClass == null) {
            return;
        }
        for (long delay : delays = new long[]{0L, 20L}) {
            new BukkitRunnable(){
                public void run() {
                    GuardService.this.applyPersistentSkin(npc, npcClass, skin);
                }
            }.runTaskLater((Plugin)this.plugin, delay);
        }
    }

    private Skin resolveSkin(GuardTemplate template) {
        return new Skin("", DEFAULT_GUARD_TEXTURE, DEFAULT_GUARD_SIGNATURE);
    }

    private void applyPersistentSkin(Object npc, Class<?> npcClass, Skin skin) {
        if (skin == null) {
            return;
        }
        try {
            Class<?> skinTraitClass = this.resolveSkinTraitClass();
            Method getOrAddTrait = npcClass.getMethod("getOrAddTrait", Class.class);
            Object trait = getOrAddTrait.invoke(npc, skinTraitClass);
            if (trait == null) {
                return;
            }
            try {
                skinTraitClass.getMethod("setFetchDefaultSkin", Boolean.TYPE).invoke(trait, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                skinTraitClass.getMethod("setShouldUpdateSkins", Boolean.TYPE).invoke(trait, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                skinTraitClass.getMethod("setUpdateSkins", Boolean.TYPE).invoke(trait, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                skinTraitClass.getMethod("setUseCache", Boolean.TYPE).invoke(trait, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                Class<?> metadataEnum = Class.forName("net.citizensnpcs.api.npc.NPC$Metadata");
                Object dataStore = npcClass.getMethod("data", new Class[0]).invoke(npc, new Object[0]);
                Method setPersistent = dataStore.getClass().getMethod("setPersistent", metadataEnum, Object.class);
                try {
                    Object useLatest = Enum.valueOf((Class)metadataEnum, "PLAYER_SKIN_USE_LATEST");
                    setPersistent.invoke(dataStore, useLatest, false);
                }
                catch (Exception useLatest) {
                    // empty catch block
                }
                try {
                    Object skinUuid = Enum.valueOf((Class)metadataEnum, "PLAYER_SKIN_UUID_METADATA");
                    setPersistent.invoke(dataStore, skinUuid, "guardskin");
                }
                catch (Exception exception) {}
            }
            catch (Exception metadataEnum) {
                // empty catch block
            }
            try {
                skinTraitClass.getMethod("clearTexture", new Class[0]).invoke(trait, new Object[0]);
            }
            catch (Exception metadataEnum) {
                // empty catch block
            }
            boolean applied = false;
            try {
                skinTraitClass.getMethod("setSkinPersistent", String.class, String.class, String.class, Boolean.TYPE).invoke(trait, UUID.randomUUID().toString(), skin.signature(), skin.texture(), true);
                applied = true;
            }
            catch (NoSuchMethodException dataStore) {
            }
            catch (Exception e) {
                this.logSkinError("4-arg setSkinPersistent", e);
            }
            try {
                skinTraitClass.getMethod("setSkinPersistent", String.class, String.class, String.class).invoke(trait, UUID.randomUUID().toString(), skin.signature(), skin.texture());
                applied = true;
            }
            catch (NoSuchMethodException e) {
            }
            catch (Exception e) {
                this.logSkinError("3-arg setSkinPersistent", e);
            }
            if (!applied) {
                try {
                    skinTraitClass.getMethod("setSkinPersistent", String.class, String.class).invoke(trait, skin.signature(), skin.texture());
                    applied = true;
                }
                catch (Exception e) {
                    this.logSkinError("2-arg setSkinPersistent", e);
                }
            }
            if (!applied) {
                if (!this.skinWarningLogged) {
                    this.plugin.getLogger().warning("Failed to apply guard skin: setSkinPersistent method not found.");
                    this.skinWarningLogged = true;
                }
                return;
            }
            this.invokeIfPresent(skinTraitClass, trait, "updateSkin");
            this.invokeIfPresent(skinTraitClass, trait, "applySkin");
            this.invokeIfPresent(skinTraitClass, trait, "updateAndApply");
        }
        catch (Exception e) {
            this.logSkinError("outer", e);
        }
    }

    private void logSkinError(String step, Exception e) {
        if (!this.skinWarningLogged) {
            String msg = e == null ? "unknown" : e.getClass().getName() + (String)(e.getMessage() == null ? "" : ": " + e.getMessage());
            this.plugin.getLogger().warning("Guard skin step failed (" + step + "): " + msg);
            if (e != null) {
                e.printStackTrace();
            }
            this.skinWarningLogged = true;
        }
    }

    private void ensureUnprotected(Entity ent) {
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, ent);
            if (npc == null) {
                return;
            }
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            try {
                npcClass.getMethod("setProtected", Boolean.TYPE).invoke(npc, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                Class<?> metadataEnum = Class.forName("net.citizensnpcs.api.npc.NPC$Metadata");
                Object dataStore = npcClass.getMethod("data", new Class[0]).invoke(npc, new Object[0]);
                Object protectedMeta = Enum.valueOf((Class)metadataEnum, "DEFAULT_PROTECTED");
                dataStore.getClass().getMethod("setPersistent", metadataEnum, Object.class).invoke(dataStore, protectedMeta, false);
            }
            catch (Exception exception) {}
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void invokeIfPresent(Class<?> clazz, Object target, String method) {
        try {
            clazz.getMethod(method, new Class[0]).invoke(target, new Object[0]);
        }
        catch (NoSuchMethodException noSuchMethodException) {
        }
        catch (Exception e) {
            this.logSkinError(method, e);
        }
    }

    private Class<?> resolveSkinTraitClass() throws ClassNotFoundException {
        String[] candidates = new String[]{"net.citizensnpcs.api.trait.SkinTrait", "net.citizensnpcs.api.trait.trait.SkinTrait", "net.citizensnpcs.trait.SkinTrait", "net.citizensnpcs.trait.trait.SkinTrait"};
        ClassNotFoundException last = null;
        for (String name : candidates) {
            try {
                return Class.forName(name);
            }
            catch (ClassNotFoundException e) {
                last = e;
            }
        }
        throw last != null ? last : new ClassNotFoundException("SkinTrait not found");
    }

    private void applyLoadout(final GuardTemplate template, Entity npc, String customName) {
        if (!(npc instanceof LivingEntity)) {
            return;
        }
        final LivingEntity living = (LivingEntity)npc;
        living.setRemoveWhenFarAway(false);
        this.ensureUnprotected((Entity)living);
        this.applyMovementSpeed(living);
        String fallbackName = template.displayName() != null ? template.displayName() : "&c&lGuard";
        String nameToUse = customName != null ? customName : fallbackName;
        this.scheduleHealthApply(living, template);
        if (this.shouldAutoEquip(template)) {
            long delayTicks = this.getEquipDelayTicks(template);
            if (delayTicks > 0L) {
                this.guardEquipReadyAt.put(living.getUniqueId(), System.currentTimeMillis() + delayTicks * 50L);
            }
            this.applyEquipment(living, template, delayTicks);
            new BukkitRunnable(){
                public void run() {
                    GuardService.this.applyEquipment(living, template, 0L);
                }
            }.runTaskLater((Plugin)this.plugin, 5L);
        }
        this.updateGuardName(living, nameToUse);
    }

    public boolean isGuard(Entity entity) {
        if (entity == null) {
            return false;
        }
        if (this.guardIds.contains(entity.getUniqueId())) {
            return true;
        }
        if (!(entity instanceof LivingEntity living) || !this.isTaggedGuard(living)) {
            return false;
        }
        return this.restoreTrackedGuard(living);
    }

    public double getRetaliationDamage() {
        return this.retaliationDamage;
    }

    public double getRetaliationDamage(Entity guard) {
        String id;
        if (guard == null) {
            return this.retaliationDamage;
        }
        GuardTemplate template = this.guardTemplatesById.get(guard.getUniqueId());
        if (template == null) {
            return this.retaliationDamage;
        }
        return switch (id = template.id() != null ? template.id().toLowerCase() : "") {
            case "guard" -> 30.0;
            case "enforcer" -> 45.0;
            case "warden" -> 60.0;
            default -> this.retaliationDamage;
        };
    }

    public double damageReductionMultiplier(Entity guard) {
        String id;
        if (guard == null) {
            return 1.0;
        }
        GuardTemplate template = this.guardTemplatesById.get(guard.getUniqueId());
        if (template == null) {
            return 1.0;
        }
        return switch (id = template.id() != null ? template.id().toLowerCase() : "") {
            case "guard" -> 1.25;
            case "enforcer" -> 1.7;
            case "warden" -> 2.2;
            default -> 1.0;
        };
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    private boolean shouldAutoEquip(GuardTemplate template) {
        return template != null;
    }

    private long getEquipDelayTicks(GuardTemplate template) {
        return 40L;
    }

    private void scheduleHealthApply(final LivingEntity living, GuardTemplate template) {
        if (living == null || template == null) {
            return;
        }
        double health = template.health() > 0.0 ? template.health() : 1000.0;
        long delayTicks = 40L;
        this.guardDesiredHealth.put(living.getUniqueId(), health);
        this.guardCurrentHealth.put(living.getUniqueId(), health);
        this.guardPendingHealth.put(living.getUniqueId(), health);
        this.guardHealthReadyAt.put(living.getUniqueId(), System.currentTimeMillis() + delayTicks * 50L);
        new BukkitRunnable(){
            public void run() {
                GuardService.this.applyHealthIfReady(living.getUniqueId());
            }
        }.runTaskLater((Plugin)this.plugin, delayTicks);
    }

    private void applyHealthIfReady(UUID guardId) {
        Entity ent = Bukkit.getEntity((UUID)guardId);
        if (!(ent instanceof LivingEntity)) {
            return;
        }
        LivingEntity living = (LivingEntity)ent;
        Long readyAt = this.guardHealthReadyAt.get(guardId);
        Double target = this.guardPendingHealth.get(guardId);
        if (readyAt == null || target == null) {
            return;
        }
        if (System.currentTimeMillis() < readyAt) {
            return;
        }
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance maxHealthAttr = maxHealthAttribute != null ? living.getAttribute(maxHealthAttribute) : null;
            if (maxHealthAttr != null) {
                maxHealthAttr.setBaseValue(target.doubleValue());
            }
            living.setHealth(Math.min(target, this.resolvedMaxHealth(living)));
            this.guardCurrentHealth.put(guardId, living.getHealth());
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.guardPendingHealth.remove(guardId);
        this.guardHealthReadyAt.remove(guardId);
    }

    public void recordGuardHealth(LivingEntity guard) {
        if (guard == null) {
            return;
        }
        this.recordGuardHealth(guard, guard.getHealth());
    }

    public void recordGuardHealth(LivingEntity guard, double currentHealth) {
        if (guard == null) {
            return;
        }
        this.guardCurrentHealth.put(guard.getUniqueId(), currentHealth);
    }

    private void applyEquipment(LivingEntity living, GuardTemplate template, long delayTicks) {
        if (!this.shouldAutoEquip(template)) {
            return;
        }
        EntityEquipment equip = living.getEquipment();
        if (equip == null) {
            return;
        }
        if (template == null) {
            return;
        }
        ItemStack helmet = this.cloneItem(template.helmet());
        ItemStack chest = this.cloneItem(template.chest());
        ItemStack legs = this.cloneItem(template.legs());
        ItemStack boots = this.cloneItem(template.boots());
        ItemStack weapon = this.cloneItem(template.weapon());
        final Runnable equipNow = () -> {
            EntityEquipment eq = living.getEquipment();
            if (eq == null) {
                return;
            }
            eq.setHelmet(this.cloneItem(helmet));
            eq.setChestplate(this.cloneItem(chest));
            eq.setLeggings(this.cloneItem(legs));
            eq.setBoots(this.cloneItem(boots));
            eq.setItemInMainHand(this.cloneItem(weapon));
            this.setDropChancesSafe(eq);
            this.guardEquipReadyAt.remove(living.getUniqueId());
        };
        if (delayTicks > 0L) {
            new BukkitRunnable(){

                public void run() {
                    equipNow.run();
                }
            }.runTaskLater((Plugin)this.plugin, delayTicks);
            new BukkitRunnable(){

                public void run() {
                    equipNow.run();
                }
            }.runTaskLater((Plugin)this.plugin, delayTicks + 10L);
            new BukkitRunnable(){

                public void run() {
                    equipNow.run();
                }
            }.runTaskLater((Plugin)this.plugin, delayTicks + 20L);
            return;
        }
        equipNow.run();
        new BukkitRunnable(){

            public void run() {
                equipNow.run();
            }
        }.runTaskLater((Plugin)this.plugin, 1L);
        new BukkitRunnable(){

            public void run() {
                equipNow.run();
            }
        }.runTaskLater((Plugin)this.plugin, 20L);
    }

    public void updateGuardName(LivingEntity guard, String baseName) {
        if (guard == null) {
            return;
        }
        Object name = baseName != null ? baseName : "&c&lGuard";
        double current = 0.0;
        try {
            current = guard.getHealth();
        }
        catch (Exception exception) {
            // empty catch block
        }
        name = (String)name + " &7[&f" + (int)Math.ceil(current) + " &c\u2764&7]";
        guard.setCustomName(Text.color((String)name));
        guard.setCustomNameVisible(true);
    }

    public void recordGuardHit(LivingEntity guard) {
        if (guard == null) {
            return;
        }
        this.guardLastHit.put(guard.getUniqueId(), System.currentTimeMillis());
    }

    public void commandAttack(Entity guard, Player target) {
        if (guard == null || target == null || !this.isGuard(guard)) {
            return;
        }
        this.guardTargets.put(guard.getUniqueId(), target.getUniqueId());
        if (guard instanceof LivingEntity living) {
            this.markGuardChasing(living);
            this.applyMovementSpeed(living);
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, guard);
            if (npc != null) {
                Object navigator = npc.getClass().getMethod("getNavigator", new Class[0]).invoke(npc, new Object[0]);
                this.applyNavigatorSpeed(navigator);
                Class<?> navigatorClass = Class.forName("net.citizensnpcs.api.ai.Navigator");
                navigatorClass.getMethod("setTarget", Entity.class, Boolean.TYPE).invoke(navigator, target, true);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void sendGuardHome(UUID guardId, Entity guard) {

        this.guardTargets.remove(guardId);
        this.guardAttackReadyAt.remove(guardId);
        this.clearGuardChasing(guard);

        Location home = this.guardSpawns.get(guardId);

        if (home == null || guard == null) return;

        // ✅ HARD TELEPORT if too far (fixes "wrong home" issue)
        if (guard.getWorld() != home.getWorld() || guard.getLocation().distanceSquared(home) > 400) {
            guard.teleport(home);
            this.healToMax(guard);
            return;
        }

        // ✅ Otherwise use navigator
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry").invoke(null);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, guard);

            if (npc != null) {
                Object navigator = npc.getClass().getMethod("getNavigator").invoke(npc);
                Class<?> navClass = Class.forName("net.citizensnpcs.api.ai.Navigator");

                navClass.getMethod("cancelNavigation").invoke(navigator);
                this.applyNavigatorSpeed(navigator);

                navClass.getMethod("setTarget", Location.class, Boolean.TYPE).invoke(navigator, home, true);
                return;
            }

        } catch (Exception ignored) {}

        // fallback
        guard.teleport(home);
        this.healToMax(guard);
    }

    private void healToMax(Entity guard) {
        if (!(guard instanceof LivingEntity)) {
            return;
        }
        LivingEntity living = (LivingEntity)guard;
        try {
            double target = this.desiredGuardHealth(living);
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            if (maxHealthAttribute != null) {
                AttributeInstance maxHealthAttr = living.getAttribute(maxHealthAttribute);
                if (maxHealthAttr != null) {
                    maxHealthAttr.setBaseValue(target);
                }
            }
            living.setHealth(Math.min(target, this.resolvedMaxHealth(living)));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void maybeHealIdle(LivingEntity guard, long nowMillis) {
        if (guard == null) {
            return;
        }
        UUID id = guard.getUniqueId();
        Long last = this.guardLastHit.get(id);
        if (last != null && nowMillis - last < 600000L) {
            return;
        }
        this.healToMax((Entity)guard);
        this.guardLastHit.put(id, nowMillis);
    }

    private void startMonitorTask() {
        if (this.monitorTask != null) {
            this.monitorTask.cancel();
        }
        this.monitorTask = this.plugin.getServer().getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            long now = System.currentTimeMillis();
            for (UUID uUID : new HashSet<UUID>(this.guardIds)) {
                Entity ent = Bukkit.getEntity((UUID)uUID);
                GuardTemplate tmpl = this.guardTemplatesById.get(uUID);
                if (!(ent instanceof LivingEntity)) continue;
                LivingEntity living = (LivingEntity)ent;
                this.ensureUnprotected((Entity)living);
                this.applyMovementSpeed(living);
                this.applyHealthIfReady(uUID);
                this.restoreGuardHealthIfNeeded(living);
                this.guardCurrentHealth.put(uUID, living.getHealth());
                this.ensureEquipment(living, tmpl);
                this.maybeHealIdle(living, now);
                if (this.guardTargets.containsKey(uUID)) continue;
                this.stopNavigation(ent);
            }
            for (Map.Entry<UUID, UUID> entry : new HashMap<UUID, UUID>(this.guardTargets).entrySet()) {
                LivingEntity living;
                Entity guard;
                UUID targetId;
                UUID guardId;
                block7: {
                    block6: {
                        guardId = entry.getKey();
                        targetId = entry.getValue();
                        guard = Bukkit.getEntity((UUID)guardId);
                        if (!(guard instanceof LivingEntity)) break block6;
                        living = (LivingEntity)guard;
                        if (!guard.isDead()) break block7;
                    }
                    this.guardTargets.remove(guardId);
                    continue;
                }
                GuardTemplate tmpl = this.guardTemplatesById.get(guardId);
                this.ensureEquipment(living, tmpl);
                this.ensureUnprotected((Entity)living);
                this.applyMovementSpeed(living);
                this.maybeHealIdle(living, now);
                this.restoreGuardHealthIfNeeded(living);
                this.guardCurrentHealth.put(guardId, living.getHealth());
                Player target = Bukkit.getPlayer((UUID)targetId);
                if (target == null || target.isDead() || !target.isOnline()) {
                    this.sendGuardHome(guardId, guard);
                    continue;
                }
                if (!(guard.getLocation().distanceSquared(target.getLocation()) > 900.0)) continue;
                this.sendGuardHome(guardId, guard);
                continue;
            }
            for (Map.Entry<UUID, UUID> entry : new HashMap<UUID, UUID>(this.guardTargets).entrySet()) {
                UUID guardId = entry.getKey();
                UUID targetId = entry.getValue();
                Entity guard = Bukkit.getEntity(guardId);
                if (!(guard instanceof LivingEntity living) || guard.isDead()) {
                    continue;
                }
                Player target = Bukkit.getPlayer(targetId);
                if (target == null || target.isDead() || !target.isOnline()) {
                    continue;
                }
                if (!guard.getWorld().equals(target.getWorld())) {
                    continue;
                }
                double distanceSquared = guard.getLocation().distanceSquared(target.getLocation());
                if (distanceSquared > 9.0) {
                    continue;
                }
                long readyAt = this.guardAttackReadyAt.getOrDefault(guardId, 0L);
                if (now < readyAt) {
                    continue;
                }
                this.guardAttackReadyAt.put(guardId, now + 1000L);
                double damage = Math.max(1.0D, this.getRetaliationDamage(guard));
                target.damage(damage);
                target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
                target.sendActionBar(Text.color("&cA guard attacked you!"));
            }
        }, 20L, 20L);
    }

    private void stopNavigation(Entity ent) {
        if (ent == null) {
            return;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, ent);
            if (npc == null) {
                return;
            }
            Object navigator = npc.getClass().getMethod("getNavigator", new Class[0]).invoke(npc, new Object[0]);
            Class<?> navigatorClass = Class.forName("net.citizensnpcs.api.ai.Navigator");
            try {
                navigatorClass.getMethod("cancelNavigation", new Class[0]).invoke(navigator, new Object[0]);
            }
            catch (Exception exception) {}
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public void handleGuardDeath(LivingEntity guard) {
        if (guard == null) {
            return;
        }
        UUID id = guard.getUniqueId();
        this.guardIds.remove(id);
        this.guardTargets.remove(id);
        this.guardAttackReadyAt.remove(id);
        this.guardPendingHealth.remove(id);
        this.guardHealthReadyAt.remove(id);
        this.guardEquipReadyAt.remove(id);
        this.guardDesiredHealth.remove(id);
        this.guardLastHit.remove(id);
        this.clearGuardChasing(guard);
        Location home = this.guardSpawns.remove(id);
        GuardTemplate template = this.guardTemplatesById.remove(id);
        String customName = this.guardCustomNames.remove(id);
        if (home == null || template == null) {
            return;
        }
        this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> this.spawnGuard(template, home, customName, null), 1200L);
    }

    public void despawnGuard(UUID guardId) {
        if (guardId == null) {
            return;
        }
        Entity guard = Bukkit.getEntity((UUID)guardId);
        this.guardIds.remove(guardId);
        this.guardTargets.remove(guardId);
        this.guardAttackReadyAt.remove(guardId);
        this.guardPendingHealth.remove(guardId);
        this.guardHealthReadyAt.remove(guardId);
        this.guardEquipReadyAt.remove(guardId);
        this.guardDesiredHealth.remove(guardId);
        this.guardLastHit.remove(guardId);
        this.clearGuardChasing(guard);
        this.guardSpawns.remove(guardId);
        this.guardTemplatesById.remove(guardId);
        this.guardCustomNames.remove(guardId);
        if (guard != null) {
            this.destroyCitizensNpc(guard);
        } else {
            this.destroyCitizensNpc(guardId);
        }
        if (!this.loadingSpawns) {
            this.saveSpawns();
        }
    }

    public void clearTargetForPlayer(UUID playerId) {
        if (playerId == null) {
            return;
        }
        Map<UUID, UUID> snapshot = new HashMap<UUID, UUID>(this.guardTargets);
        for (Map.Entry<UUID, UUID> entry : snapshot.entrySet()) {
            if (!playerId.equals(entry.getValue())) continue;
            UUID guardId = entry.getKey();
            Entity guard = Bukkit.getEntity(guardId);
            this.sendGuardHome(guardId, guard);
        }
    }

    public void sendHomeAfterKill(Player deadPlayer) {
        if (deadPlayer == null) {
            return;
        }
        this.clearTargetForPlayer(deadPlayer.getUniqueId());
        Location deathLoc = deadPlayer.getLocation();
        for (UUID guardId : new HashSet<UUID>(this.guardIds)) {
            Location home;
            Entity guard = Bukkit.getEntity((UUID)guardId);
            if (guard == null || guard.isDead() || (home = this.guardSpawns.get(guardId)) == null || !guard.getWorld().equals((Object)deathLoc.getWorld()) || !(guard.getLocation().distanceSquared(deathLoc) <= 1600.0)) continue;
            this.sendGuardHome(guardId, guard);
        }
    }

    private boolean isEmpty(ItemStack item) {
        return item == null || item.getType() == Material.AIR;
    }

    private void setDropChancesSafe(EntityEquipment equip) {
        try {
            equip.setHelmetDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setChestplateDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setLeggingsDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setBootsDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setItemInMainHandDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
    }

    private void ensureSkin(LivingEntity living, GuardTemplate template) {
        if (living == null) {
            return;
        }
        Skin skin = this.resolveSkin(template);
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, living);
            if (npc == null) {
                return;
            }
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            this.applyPersistentSkin(npc, npcClass, skin);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void ensureEquipment(final LivingEntity living, GuardTemplate template) {
        EntityEquipment equip;
        if (!this.shouldAutoEquip(template)) {
            return;
        }
        if (living == null || template == null) {
            return;
        }
        this.applyMovementSpeed(living);
        Long readyAt = this.guardEquipReadyAt.get(living.getUniqueId());
        if (readyAt != null && System.currentTimeMillis() < readyAt) {
            return;
        }
        if (readyAt != null && System.currentTimeMillis() >= readyAt) {
            this.guardEquipReadyAt.remove(living.getUniqueId());
        }
        if ((equip = living.getEquipment()) == null) {
            return;
        }
        boolean missing = false;
        if (!this.isEmpty(template.helmet()) && this.isEmpty(equip.getHelmet())) {
            equip.setHelmet(this.cloneItem(template.helmet()));
            missing = true;
        }
        if (!this.isEmpty(template.chest()) && this.isEmpty(equip.getChestplate())) {
            equip.setChestplate(this.cloneItem(template.chest()));
            missing = true;
        }
        if (!this.isEmpty(template.legs()) && this.isEmpty(equip.getLeggings())) {
            equip.setLeggings(this.cloneItem(template.legs()));
            missing = true;
        }
        if (!this.isEmpty(template.boots()) && this.isEmpty(equip.getBoots())) {
            equip.setBoots(this.cloneItem(template.boots()));
            missing = true;
        }
        if (!this.isEmpty(template.weapon()) && this.isEmpty(equip.getItemInMainHand())) {
            equip.setItemInMainHand(this.cloneItem(template.weapon()));
            missing = true;
        }
        if (!missing) {
            return;
        }
        this.setDropChancesSafe(equip);
        final ItemStack helmet = this.cloneItem(template.helmet());
        final ItemStack chest = this.cloneItem(template.chest());
        final ItemStack legs = this.cloneItem(template.legs());
        final ItemStack boots = this.cloneItem(template.boots());
        final ItemStack weapon = this.cloneItem(template.weapon());
        new BukkitRunnable(){
            public void run() {
                EntityEquipment eq = living.getEquipment();
                if (eq == null) {
                    return;
                }
                if (!GuardService.this.isEmpty(helmet)) {
                    eq.setHelmet(GuardService.this.cloneItem(helmet));
                }
                if (!GuardService.this.isEmpty(chest)) {
                    eq.setChestplate(GuardService.this.cloneItem(chest));
                }
                if (!GuardService.this.isEmpty(legs)) {
                    eq.setLeggings(GuardService.this.cloneItem(legs));
                }
                if (!GuardService.this.isEmpty(boots)) {
                    eq.setBoots(GuardService.this.cloneItem(boots));
                }
                if (!GuardService.this.isEmpty(weapon)) {
                    eq.setItemInMainHand(GuardService.this.cloneItem(weapon));
                }
                GuardService.this.setDropChancesSafe(eq);
            }
        }.runTaskLater((Plugin)this.plugin, 1L);
    }

    public double[] displayHealth(LivingEntity living) {
        return this.displayHealthInternal(living);
    }

    public double healthScale(LivingEntity living) {
        return this.healthScaleInternal(living);
    }

    private double[] displayHealthInternal(LivingEntity living) {
        if (living == null) {
            return new double[]{0.0, 0.0};
        }
        double desired = this.guardDesiredHealth.getOrDefault(living.getUniqueId(), 0.0);
        double actualMax = 0.0;
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance attr = maxHealthAttribute != null ? living.getAttribute(maxHealthAttribute) : null;
            actualMax = attr != null ? attr.getBaseValue() : living.getMaxHealth();
        }
        catch (Exception attr) {
            // empty catch block
        }
        if (actualMax <= 0.0) {
            actualMax = living.getMaxHealth();
        }
        if (desired <= 0.0) {
            desired = actualMax;
        }
        if (desired <= 0.0) {
            return new double[]{0.0, 0.0};
        }
        double scale = actualMax > 0.0 ? desired / actualMax : 1.0;
        double current = living.getHealth() * scale;
        if (current > desired) {
            current = desired;
        }
        return new double[]{current, desired};
    }

    private double healthScaleInternal(LivingEntity living) {
        if (living == null) {
            return 1.0;
        }
        double desired = this.guardDesiredHealth.getOrDefault(living.getUniqueId(), 0.0);
        double actualMax = 0.0;
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance attr = maxHealthAttribute != null ? living.getAttribute(maxHealthAttribute) : null;
            actualMax = attr != null ? attr.getBaseValue() : living.getMaxHealth();
        }
        catch (Exception exception) {
            // empty catch block
        }
        if (desired <= 0.0 || actualMax <= 0.0) {
            return 1.0;
        }
        return Math.max(1.0, desired / actualMax);
    }

    private Attribute resolveMaxHealthAttribute() {
        try {
            return Attribute.valueOf("GENERIC_MAX_HEALTH");
        }
        catch (IllegalArgumentException ignored) {
            try {
                return Attribute.valueOf("MAX_HEALTH");
            }
            catch (IllegalArgumentException ex) {
                return null;
            }
        }
    }

    private double resolvedMaxHealth(LivingEntity living) {
        if (living == null) {
            return 0.0D;
        }
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            if (maxHealthAttribute != null) {
                AttributeInstance attr = living.getAttribute(maxHealthAttribute);
                if (attr != null) {
                    return attr.getBaseValue();
                }
            }
        }
        catch (Exception ignored) {
            // fall back to the entity API value below
        }
        return living.getMaxHealth();
    }

    private double desiredGuardHealth(LivingEntity living) {
        if (living == null) {
            return 0.0D;
        }
        Double desired = this.guardDesiredHealth.get(living.getUniqueId());
        if (desired != null && desired.doubleValue() > 0.0D) {
            return desired.doubleValue();
        }
        return this.resolvedMaxHealth(living);
    }

    private void restoreGuardHealthIfNeeded(LivingEntity living) {
        if (living == null) {
            return;
        }
        double desired = this.desiredGuardHealth(living);
        if (desired <= 0.0D) {
            return;
        }
        double actualMax = this.resolvedMaxHealth(living);
        if (actualMax + 0.1D >= desired) {
            return;
        }
        double current = this.guardCurrentHealth.getOrDefault(living.getUniqueId(), desired);
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance maxAttr = maxHealthAttribute != null ? living.getAttribute(maxHealthAttribute) : null;
            if (maxAttr != null) {
                maxAttr.setBaseValue(desired);
            }
            living.setHealth(Math.min(current > 0.0D ? current : desired, desired));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void applyMovementSpeed(LivingEntity living) {
        if (living == null) {
            return;
        }
        try {
            AttributeInstance movement = living.getAttribute(Attribute.MOVEMENT_SPEED);
            if (movement == null) {
                return;
            }
            double currentBase = movement.getBaseValue();
            double targetBase = 0.1 * GUARD_SPEED_MULTIPLIER;
            if (currentBase < targetBase) {
                movement.setBaseValue(targetBase);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void applyNavigatorSpeed(Object navigator) {
        if (navigator == null) {
            return;
        }
        try {
            Object params;
            try {
                params = navigator.getClass().getMethod("getDefaultParameters", new Class[0]).invoke(navigator, new Object[0]);
            }
            catch (NoSuchMethodException ignored) {
                params = navigator.getClass().getMethod("getLocalParameters", new Class[0]).invoke(navigator, new Object[0]);
            }
            if (params != null) {
                params.getClass().getMethod("speedModifier", Float.TYPE).invoke(params, (float)GUARD_SPEED_MULTIPLIER);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private LivingEntity bindExistingGuard(GuardTemplate template, Location home, String customName, UUID expectedEntityId) {
        if (template == null || home == null || home.getWorld() == null) {
            return null;
        }
        if (expectedEntityId != null) {
            Entity entity = Bukkit.getEntity(expectedEntityId);
            if (entity instanceof LivingEntity living && !entity.isDead()) {
                this.trackGuard(living, template, home, customName);
                this.sendGuardHome(living.getUniqueId(), living);
                return living;
            }
        }
        for (Entity entity : home.getWorld().getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity.isDead()) continue;
            if (!this.isTaggedGuard(living)) continue;
            GuardTemplate existingTemplate = this.resolveTaggedTemplate(living);
            if (existingTemplate == null) continue;
            if (!template.id().equalsIgnoreCase(existingTemplate.id())) continue;
            Location existingHome = this.readTaggedHome(living);
            if (existingHome == null) continue;
            if (existingHome.distanceSquared(home) > 1.0) continue;
            String existingName = this.readTaggedCustomName(living);
            if (!this.sameCustomName(existingName, customName)) continue;
            this.trackGuard(living, template, home, customName);
            this.sendGuardHome(living.getUniqueId(), living);
            return living;
        }
        // Priority 3: nearby fallback for already-spawned guards that lost their direct handle.
        List<LivingEntity> matches = new ArrayList<>();
        for (Entity entity : home.getWorld().getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity.isDead()) continue;
            if (!this.isTaggedGuard(living) && !this.isCitizensNpc(living)) continue;
            GuardTemplate existingTemplate = this.resolveTaggedTemplate(living);
            String existingName = this.readTaggedCustomName(living);
            Location matchLocation = this.readTaggedHome(living);
            if (matchLocation == null) {
                matchLocation = living.getLocation();
            }
            if (matchLocation.getWorld() == null) continue;
            if (!matchLocation.getWorld().equals(home.getWorld())) continue;
            if (matchLocation.distanceSquared(home) > 9.0) continue;
            if (existingTemplate != null && !template.id().equalsIgnoreCase(existingTemplate.id())) continue;
            if (customName != null && !customName.isBlank() && !this.sameCustomName(existingName != null ? existingName : living.getCustomName(), customName)) continue;
            matches.add(living);
        }
        if (matches.isEmpty()) {
            return null;
        }
        LivingEntity primary = matches.get(0);
        this.trackGuard(primary, template, home, customName);
        this.sendGuardHome(primary.getUniqueId(), primary);
        for (int i = 1; i < matches.size(); i++) {
            this.destroyCitizensNpc(matches.get(i));
        }
        return primary;
    }

    private LivingEntity findGuardByEntityId(UUID entityId, GuardTemplate template, Location home, String customName) {
        if (entityId == null) {
            return null;
        }
        Entity entity = Bukkit.getEntity(entityId);
        if (!(entity instanceof LivingEntity living) || entity.isDead() || !this.isCitizensNpc(living)) {
            return null;
        }
        if (living.getWorld() == null || !living.getWorld().equals(home.getWorld()) || living.getLocation().distanceSquared(home) > 9.0) {
            return null;
        }
        String currentName = this.readTaggedCustomName(living);
        if (customName != null && !customName.isBlank() && !this.sameCustomName(currentName != null ? currentName : living.getCustomName(), customName)) {
            return null;
        }
        GuardTemplate existingTemplate = this.resolveTaggedTemplate(living);
        if (existingTemplate != null && !template.id().equalsIgnoreCase(existingTemplate.id())) {
            return null;
        }
        return living;
    }

    private void destroyDuplicateSlotMatches(GuardTemplate template, Location home, String customName, UUID keepId) {
        for (Entity entity : home.getWorld().getEntities()) {
            if (!(entity instanceof LivingEntity living) || entity.isDead() || keepId.equals(living.getUniqueId())) {
                continue;
            }
            boolean taggedGuard = this.isTaggedGuard(living);
            boolean citizensNpc = this.isCitizensNpc(living);
            if (!taggedGuard && !citizensNpc) {
                continue;
            }
            GuardTemplate existingTemplate = taggedGuard ? this.resolveTaggedTemplate(living) : template;
            String existingName = taggedGuard ? this.readTaggedCustomName(living) : living.getCustomName();
            Location existingHome = taggedGuard ? this.readTaggedHome(living) : null;
            Location matchLocation = existingHome != null ? existingHome : living.getLocation();
            if (matchLocation.getWorld() == null || !matchLocation.getWorld().equals(home.getWorld()) || matchLocation.distanceSquared(home) > 2.25) {
                continue;
            }
            if (existingTemplate != null && !template.id().equalsIgnoreCase(existingTemplate.id())) {
                continue;
            }
            if (customName != null && !customName.isBlank() && !this.sameCustomName(existingName != null ? existingName : living.getCustomName(), customName)) {
                continue;
            }
            this.destroyCitizensNpc((Entity)living);
        }
    }

    private boolean restoreTrackedGuard(LivingEntity living) {
        GuardTemplate template;
        Location home;
        if (living == null || (template = this.resolveTaggedTemplate(living)) == null || (home = this.readTaggedHome(living)) == null) {
            return false;
        }
        this.trackGuard(living, template, home, this.readTaggedCustomName(living));
        return true;
    }

    private void trackGuard(LivingEntity living, GuardTemplate template, Location home, String customName) {
        if (living == null || template == null || home == null) {
            return;
        }
        UUID id = living.getUniqueId();
        this.guardIds.add(id);
        this.guardSpawns.put(id, home.clone());
        this.guardTemplatesById.put(id, template);
        this.guardCustomNames.put(id, customName);
        this.tagGuardEntity(living, template, home, customName);
        this.applyLoadout(template, living, customName);
    }

    private void tagGuardEntity(LivingEntity living, GuardTemplate template, Location home, String customName) {
        if (living == null || template == null || home == null || home.getWorld() == null) {
            return;
        }
        PersistentDataContainer pdc = living.getPersistentDataContainer();
        pdc.set(Keys.guardMarker(this.plugin), PersistentDataType.BYTE, (byte)1);
        pdc.set(Keys.guardTemplate(this.plugin), PersistentDataType.STRING, template.id());
        pdc.set(Keys.guardHome(this.plugin), PersistentDataType.STRING, this.serializeLocation(home));
        if (customName == null || customName.isBlank()) {
            pdc.remove(Keys.guardCustomName(this.plugin));
        } else {
            pdc.set(Keys.guardCustomName(this.plugin), PersistentDataType.STRING, customName);
        }
        living.addScoreboardTag(GUARD_TAG);
    }

    private void markGuardChasing(LivingEntity living) {
        if (living == null) {
            return;
        }
        living.getPersistentDataContainer().set(Keys.guardChasing(this.plugin), PersistentDataType.BYTE, (byte)1);
        living.addScoreboardTag("prisonscore_guard_chasing");
    }

    private void clearGuardChasing(Entity guard) {
        if (!(guard instanceof LivingEntity living)) {
            return;
        }
        try {
            living.getPersistentDataContainer().remove(Keys.guardChasing(this.plugin));
        }
        catch (Exception exception) {
            // empty catch block
        }
        try {
            living.removeScoreboardTag("prisonscore_guard_chasing");
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private boolean isChasingGuard(Entity entity) {
        if (!(entity instanceof LivingEntity living)) {
            return false;
        }
        PersistentDataContainer pdc = living.getPersistentDataContainer();
        return pdc.has(Keys.guardChasing(this.plugin), PersistentDataType.BYTE) || living.getScoreboardTags().contains("prisonscore_guard_chasing");
    }

    private boolean isTaggedGuard(LivingEntity living) {
        if (living == null) {
            return false;
        }
        PersistentDataContainer pdc = living.getPersistentDataContainer();
        return pdc.has(Keys.guardMarker(this.plugin), PersistentDataType.BYTE) || living.getScoreboardTags().contains(GUARD_TAG);
    }

    private boolean isCitizensNpc(Entity entity) {
        if (entity == null) {
            return false;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, entity);
            return npc != null;
        }
        catch (Exception exception) {
            return false;
        }
    }

    private GuardTemplate resolveTaggedTemplate(LivingEntity living) {
        if (living == null) {
            return null;
        }
        String templateId = (String)living.getPersistentDataContainer().get(Keys.guardTemplate(this.plugin), PersistentDataType.STRING);
        if (templateId == null || templateId.isBlank()) {
            return this.getTemplate("default");
        }
        return this.getTemplate(templateId);
    }

    private Location readTaggedHome(LivingEntity living) {
        if (living == null) {
            return null;
        }
        String encoded = (String)living.getPersistentDataContainer().get(Keys.guardHome(this.plugin), PersistentDataType.STRING);
        return this.deserializeLocation(encoded);
    }

    private String readTaggedCustomName(LivingEntity living) {
        if (living == null) {
            return null;
        }
        return (String)living.getPersistentDataContainer().get(Keys.guardCustomName(this.plugin), PersistentDataType.STRING);
    }

    private String serializeLocation(Location loc) {
        if (loc == null || loc.getWorld() == null) {
            return null;
        }
        return loc.getWorld().getName() + ";" + loc.getX() + ";" + loc.getY() + ";" + loc.getZ() + ";" + loc.getYaw() + ";" + loc.getPitch();
    }

    private Location deserializeLocation(String encoded) {
        if (encoded == null || encoded.isBlank()) {
            return null;
        }
        String[] parts = encoded.split(";", 6);
        if (parts.length != 6) {
            return null;
        }
        World world = Bukkit.getWorld(parts[0]);
        if (world == null) {
            return null;
        }
        try {
            return new Location(world, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]), Double.parseDouble(parts[3]), Float.parseFloat(parts[4]), Float.parseFloat(parts[5]));
        }
        catch (NumberFormatException e) {
            return null;
        }
    }

    private boolean sameCustomName(String a, String b) {
        String left = this.normalizeGuardName(a);
        String right = this.normalizeGuardName(b);
        return left == null ? right == null : left.equals(right);
    }

    private String normalizeGuardName(String value) {
        if (value == null) {
            return null;
        }
        String stripped = ChatColor.stripColor(Text.color(value));
        if (stripped == null) {
            return null;
        }
        String trimmed = stripped.replaceFirst("\\s*\\[[^\\]]*]$", "").trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private UUID parseEntityId(String raw) {
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(raw);
        }
        catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    public record GuardTemplate(String id, String displayName, Skin skin, ItemStack helmet, ItemStack chest, ItemStack legs, ItemStack boots, ItemStack weapon, double health) {
    }

    public record Skin(String owner, String texture, String signature) {
    }
}
