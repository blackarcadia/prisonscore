package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;

public final class PlayerToggleService {
    private final PlayerDataService playerDataService;

    public PlayerToggleService(PlayerDataService playerDataService) {
        this.playerDataService = playerDataService;
    }

    public boolean isEnabled(Player player, Toggle toggle) {
        if (player == null || toggle == null) {
            return true;
        }
        PlayerDataService.PlayerData data = this.playerDataService.get(player.getUniqueId());
        return switch (toggle) {
            case INVENTORY_FULL_NOTIFICATIONS -> data.hasInventoryFullNotifications();
            case PICKAXE_CHARGE_FULL_NOTIFICATIONS -> data.hasPickaxeChargeFullNotifications();
            case STASH_NOTIFICATIONS -> data.hasStashNotifications();
            case MINING_XP_ACTION_BAR -> data.hasMiningXpActionBar();
            case CHARGE_ACTION_BAR -> data.hasChargeActionBar();
            case ENCHANT_PROC_ACTION_BAR -> data.hasEnchantProcActionBar();
            case TUTORIAL_SKIP_CONFIRM -> data.hasTutorialSkipConfirm();
            case TPA_REQUESTS -> data.hasTpaRequests();
            case PAY_REQUESTS -> data.hasPayRequests();
            case PRIVATE_MESSAGES -> data.hasPrivateMessages();
            case FRAGMENT_NOTIFICATIONS -> data.hasFragmentNotifications();
            case CHAT_ENABLED -> data.hasChatEnabled();
        };
    }

    public void setEnabled(Player player, Toggle toggle, boolean enabled) {
        if (player == null || toggle == null) {
            return;
        }
        this.playerDataService.update(player.getUniqueId(), data -> {
            switch (toggle) {
                case INVENTORY_FULL_NOTIFICATIONS -> data.setInventoryFullNotifications(enabled);
                case PICKAXE_CHARGE_FULL_NOTIFICATIONS -> data.setPickaxeChargeFullNotifications(enabled);
                case STASH_NOTIFICATIONS -> data.setStashNotifications(enabled);
                case MINING_XP_ACTION_BAR -> data.setMiningXpActionBar(enabled);
                case CHARGE_ACTION_BAR -> data.setChargeActionBar(enabled);
                case ENCHANT_PROC_ACTION_BAR -> data.setEnchantProcActionBar(enabled);
                case TUTORIAL_SKIP_CONFIRM -> data.setTutorialSkipConfirm(enabled);
                case TPA_REQUESTS -> data.setTpaRequests(enabled);
                case PAY_REQUESTS -> data.setPayRequests(enabled);
                case PRIVATE_MESSAGES -> data.setPrivateMessages(enabled);
                case FRAGMENT_NOTIFICATIONS -> data.setFragmentNotifications(enabled);
                case CHAT_ENABLED -> data.setChatEnabled(enabled);
            }
        });
    }

    public boolean toggle(Player player, Toggle toggle) {
        boolean enabled = !this.isEnabled(player, toggle);
        this.setEnabled(player, toggle, enabled);
        return enabled;
    }

    public boolean canReceiveChat(Player player) {
        return player != null && this.isEnabled(player, Toggle.CHAT_ENABLED);
    }

    public List<Toggle> togglesFor(Category category) {
        ArrayList<Toggle> list = new ArrayList<Toggle>();
        for (Toggle toggle : Toggle.values()) {
            if (toggle.category != category) {
                continue;
            }
            list.add(toggle);
        }
        return list;
    }

    public enum Category {
        NOTIFICATIONS("&b&lCyan"),
        CONFIRMATIONS("&e&lYellow"),
        REQUESTS("&9&lBlue"),
        OTHER("&7&lLight Gray");

        private final String displayName;

        Category(String displayName) {
            this.displayName = displayName;
        }

        public String displayName() {
            return this.displayName;
        }
    }

    public enum Toggle {
        INVENTORY_FULL_NOTIFICATIONS(Category.NOTIFICATIONS, "Inventory Full Title and Message", "Show the full inventory warning."),
        PICKAXE_CHARGE_FULL_NOTIFICATIONS(Category.NOTIFICATIONS, "Pickaxe Charge Full Title and Message", "Show the pickaxe full warning."),
        STASH_NOTIFICATIONS(Category.NOTIFICATIONS, "/stash Notifications", "Receive stash reminder messages."),
        MINING_XP_ACTION_BAR(Category.NOTIFICATIONS, "Mining XP Action Bar", "Show mining XP in the action bar."),
        CHARGE_ACTION_BAR(Category.NOTIFICATIONS, "Charge Action Bar", "Show charge gain in the action bar."),
        ENCHANT_PROC_ACTION_BAR(Category.NOTIFICATIONS, "Enchant Proc Action Bar", "Show enchant procs in the action bar."),
        TUTORIAL_SKIP_CONFIRM(Category.CONFIRMATIONS, "Tutorial Skip Confirm", "Require a confirmation before skipping the tutorial."),
        TPA_REQUESTS(Category.REQUESTS, "/tpa Requests", "Receive teleport requests from other players."),
        PAY_REQUESTS(Category.REQUESTS, "/pay Requests", "Allow other players to pay you."),
        PRIVATE_MESSAGES(Category.REQUESTS, "/msg Messages", "Receive private messages from other players."),
        FRAGMENT_NOTIFICATIONS(Category.OTHER, "Fragment Notifications", "Show fragment discovery messages."),
        CHAT_ENABLED(Category.OTHER, "Chat", "See player messages in chat.");

        private final Category category;
        private final String displayName;
        private final List<String> lore;

        Toggle(Category category, String displayName, String... lore) {
            this.category = category;
            this.displayName = displayName;
            this.lore = List.of(lore);
        }

        public Category category() {
            return this.category;
        }

        public String displayName() {
            return this.displayName;
        }

        public List<String> lore() {
            return this.lore;
        }
    }
}
