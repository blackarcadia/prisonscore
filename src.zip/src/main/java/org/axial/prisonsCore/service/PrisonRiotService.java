package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.gui.PrisonRiotMenu;
import org.axial.prisonsCore.model.PickaxeType;
import org.axial.prisonsCore.util.EnchantDisplayUtil;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Color;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.block.Block;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;
import org.bukkit.util.Transformation;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class PrisonRiotService implements Listener {

    private static final String CONFIG_FILE = "prison-riot.yml";
    private static final String ADMIN_PERMISSION = "prisons.prisonriot.admin";
    private static final int TITLE_FADE_IN = 0;
    private static final int TITLE_STAY = 20;
    private static final int TITLE_FADE_OUT = 0;
    private static final int ARENA_FILL_BATCH_SIZE = 1000;
    private static final double RIOT_SHATTER_CHANCE_PER_LEVEL = 10.0D;
    private static final double RIOT_SHATTER_CHANCE_CAP = 60.0D;
    private static final double ABILITY_BLOCK_CHANCE = 0.00025D;
    private final PrisonsCore plugin;
    private final PlayerDataService playerDataService;
    private final PlayerLevelService playerLevelService;
    private final PickaxeManager pickaxeManager;
    private final GearManager gearManager;
    private final CustomEnchantService customEnchantService;
    private final Random random = new Random();
    private final Map<UUID, Integer> currentPoints = new HashMap<>();
    private final Map<UUID, InventorySnapshot> normalInventories = new HashMap<>();
    private final Map<UUID, InventorySnapshot> riotInventories = new HashMap<>();
    private final LinkedHashSet<UUID> queuedPlayers = new LinkedHashSet<>();
    private final LinkedHashSet<UUID> activePlayers = new LinkedHashSet<>();
    private final Map<BlockPos, AbilityBlockState> abilityBlocks = new HashMap<>();
    private final Map<UUID, RiotBoostState> riotBoosts = new HashMap<>();
    private final Map<Material, Integer> orePoints = new EnumMap<>(Material.class);
    private final List<Material> orePalette = new ArrayList<>();
    private final Set<UUID> internalTeleports = new HashSet<>();
    private final Map<UUID, Long> lastMineSoundAt = new ConcurrentHashMap<>();
    private final File file;
    private YamlConfiguration cfg;
    private PrisonRiotMenu riotMenu;
    private BukkitTask tickTask;
    private BukkitTask arenaFillTask;
    private BukkitTask legacyRiotDisplayCleanupTask;
    private List<ArenaPos> arenaFillPositions = Collections.emptyList();
    private int arenaFillIndex = 0;
    private Runnable arenaFillCompleteAction;
    private Phase phase = Phase.IDLE;
    private int phaseSecondsRemaining = 0;
    private int roundNumber = 0;
    private int queueDurationSeconds = 60;
    private int roundCountdownSeconds = 10;
    private int roundLengthSeconds = 180;
    private int totalRounds = 5;
    private int maxPlayers = 25;
    private String modeName = "Standard";
    private String arenaWorldName = "riotworld";
    private String prisonWorldName = "prisons";
    private Location arenaCorner1;
    private Location arenaCorner2;
    private Location arenaSpawn;

    public PrisonRiotService(PrisonsCore plugin, PlayerDataService playerDataService, PlayerLevelService playerLevelService, PickaxeManager pickaxeManager, GearManager gearManager, CustomEnchantService customEnchantService) {
        this.plugin = plugin;
        this.playerDataService = playerDataService;
        this.playerLevelService = playerLevelService;
        this.pickaxeManager = pickaxeManager;
        this.gearManager = gearManager;
        this.customEnchantService = customEnchantService;
        this.file = new File(plugin.getDataFolder(), CONFIG_FILE);
        this.load();
    }

    public void start() {
        if (this.tickTask != null) {
            this.tickTask.cancel();
            this.tickTask = null;
        }
        this.tickTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::tick, 20L, 20L);
        this.scheduleLegacyRiotDisplayCleanup();
        this.cleanupLegacyAstronautEntities();
        this.refreshAllScoreboards();
    }

    public void stop() {
        if (this.tickTask != null) {
            this.tickTask.cancel();
            this.tickTask = null;
        }
        this.stopArenaFill();
        this.stopLegacyRiotDisplayCleanup();
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.restorePrisonScoreboard(player);
        }
    }

    public void setRiotMenu(PrisonRiotMenu riotMenu) {
        this.riotMenu = riotMenu;
    }

    public void load() {
        if (!this.file.exists()) {
            try {
                this.file.getParentFile().mkdirs();
                this.file.createNewFile();
            } catch (IOException e) {
                this.plugin.getLogger().warning("Failed to create prison-riot.yml: " + e.getMessage());
            }
        }
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.queueDurationSeconds = Math.max(10, this.cfg.getInt("queue-duration-seconds", 60));
        this.roundCountdownSeconds = Math.max(3, this.cfg.getInt("round-countdown-seconds", 10));
        this.roundLengthSeconds = Math.max(30, this.cfg.getInt("round-length-seconds", 180));
        this.totalRounds = Math.max(1, this.cfg.getInt("rounds", 5));
        this.maxPlayers = Math.max(1, this.cfg.getInt("max-players", 25));
        this.modeName = this.cfg.getString("mode", "Standard");
        this.arenaWorldName = this.cfg.getString("arena.world", "riotworld");
        if ("prisonriot".equalsIgnoreCase(this.arenaWorldName)) {
            this.arenaWorldName = "riotworld";
            this.cfg.set("arena.world", this.arenaWorldName);
            this.save();
        }
        this.prisonWorldName = this.cfg.getString("prison-world", "prisons");
        this.arenaCorner1 = this.normalizeArenaLocation(this.readLocation("arena.corner1"));
        this.arenaCorner2 = this.normalizeArenaLocation(this.readLocation("arena.corner2"));
        this.arenaSpawn = this.normalizeArenaLocation(this.readLocation("arena.spawn"));
        this.loadPoints();
    }

    public void save() {
        this.cfg.set("queue-duration-seconds", this.queueDurationSeconds);
        this.cfg.set("round-countdown-seconds", this.roundCountdownSeconds);
        this.cfg.set("round-length-seconds", this.roundLengthSeconds);
        this.cfg.set("rounds", this.totalRounds);
        this.cfg.set("max-players", this.maxPlayers);
        this.cfg.set("mode", this.modeName);
        this.cfg.set("arena.world", this.arenaWorldName);
        this.cfg.set("prison-world", this.prisonWorldName);
        this.writeLocation("arena.corner1", this.arenaCorner1);
        this.writeLocation("arena.corner2", this.arenaCorner2);
        this.writeLocation("arena.spawn", this.arenaSpawn);
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save prison-riot.yml: " + e.getMessage());
        }
    }

    public boolean isAdmin(Player player) {
        return player != null && (player.hasPermission(ADMIN_PERMISSION) || player.isOp());
    }

    public boolean isRiotWorld(World world) {
        return world != null && world.getName().equalsIgnoreCase(this.arenaWorldName);
    }

    public boolean isEventActive() {
        return this.phase != Phase.IDLE;
    }

    public boolean isQueueOpen() {
        return this.phase == Phase.QUEUE;
    }

    public boolean isRoundActive() {
        return this.phase == Phase.ROUND_ACTIVE;
    }

    public String getModeName() {
        return this.modeName;
    }

    public int getQueueDurationSeconds() {
        return this.queueDurationSeconds;
    }

    public int getRoundCountdownSeconds() {
        return this.roundCountdownSeconds;
    }

    public int getRoundLengthSeconds() {
        return this.roundLengthSeconds;
    }

    public int getTotalRounds() {
        return this.totalRounds;
    }

    public int getMaxPlayers() {
        return this.maxPlayers;
    }

    public String getArenaWorldName() {
        return this.arenaWorldName;
    }

    public String getPrisonWorldName() {
        return this.prisonWorldName;
    }

    public int getCurrentPoints(UUID playerId) {
        return this.currentPoints.getOrDefault(playerId, 0);
    }

    public int getCurrentPoints(Player player) {
        return player == null ? 0 : this.getCurrentPoints(player.getUniqueId());
    }

    public Map<UUID, Integer> getCurrentPointsSnapshot() {
        return new HashMap<>(this.currentPoints);
    }

    public List<UUID> getQueuedPlayers() {
        return new ArrayList<>(this.queuedPlayers);
    }

    public List<UUID> getActivePlayers() {
        return new ArrayList<>(this.activePlayers);
    }

    public boolean isQueued(UUID uuid) {
        return this.queuedPlayers.contains(uuid);
    }

    public boolean isActiveParticipant(UUID uuid) {
        return this.activePlayers.contains(uuid);
    }

    public String getStartCountdownText() {
        if (this.phase == Phase.QUEUE || this.phase == Phase.ROUND_COUNTDOWN) {
            return this.formatSeconds(this.phaseSecondsRemaining);
        }
        return "&cClosed";
    }

    public String getQueueWindowText() {
        return this.formatSeconds(this.queueDurationSeconds);
    }

    public String getStatusText() {
        return switch (this.phase) {
            case QUEUE -> "&aQueue Open";
            case PREPARING -> "&ePreparing Arena";
            case ROUND_COUNTDOWN -> "&eRound Countdown";
            case ROUND_ACTIVE -> "&cRound Active";
            case IDLE -> "&7Closed";
            case FINISHING -> "&7Closing";
        };
    }

    public String getRoundStatusText() {
        return this.phase == Phase.ROUND_ACTIVE ? this.formatSeconds(this.phaseSecondsRemaining) : "&7--";
    }

    public void setArenaCorner1(Location location) {
        this.arenaCorner1 = this.normalizeArenaLocation(location);
        this.save();
    }

    public void setArenaCorner2(Location location) {
        this.arenaCorner2 = this.normalizeArenaLocation(location);
        this.save();
    }

    public void setArenaSpawn(Location location) {
        this.arenaSpawn = this.normalizeArenaLocation(location);
        this.save();
    }

    public boolean hasArenaSetup() {
        return this.arenaCorner1 != null && this.arenaCorner2 != null;
    }

    public String describeArenaSetup() {
        if (!this.hasArenaSetup()) {
            return "&cArena corners are not set.";
        }
        return "&7Arena: &f" + this.formatLocation(this.arenaCorner1) + " &7-> &f" + this.formatLocation(this.arenaCorner2)
                + "&7, spawn: &f" + (this.arenaSpawn == null ? "auto" : this.formatLocation(this.arenaSpawn));
    }

    public boolean joinQueue(Player player) {
        if (player == null) {
            return false;
        }
        if (this.phase != Phase.QUEUE) {
            player.sendMessage(Text.color("&cThe Prison Riot queue is not open."));
            return false;
        }
        if (this.queuedPlayers.contains(player.getUniqueId())) {
            this.queuedPlayers.remove(player.getUniqueId());
            player.sendMessage(Text.color("&eYou left the /riot queue."));
            this.refreshAllScoreboards();
            return true;
        }
        if (this.queuedPlayers.size() >= this.maxPlayers) {
            player.sendMessage(Text.color("&cThe queue is full."));
            return false;
        }
        this.queuedPlayers.add(player.getUniqueId());
        player.sendMessage(Text.color("&b&l(!) &bYou have joined the /riot queue\n&7To leave the queue run &f/spawn&7."));
        this.refreshAllScoreboards();
        return true;
    }

    public boolean startEventCycle() {
        if (this.phase != Phase.IDLE) {
            return false;
        }
        if (!this.hasArenaSetup()) {
            this.plugin.getLogger().warning("Prison Riot cannot start without arena corners set.");
            return false;
        }
        this.resetEventPoints();
        this.activePlayers.clear();
        this.queuedPlayers.clear();
        this.phase = Phase.QUEUE;
        this.phaseSecondsRemaining = this.queueDurationSeconds;
        this.ensureRiotWorld();
        this.startArenaFill(() -> {
            if (this.phase == Phase.PREPARING || (this.phase == Phase.QUEUE && this.phaseSecondsRemaining <= 0)) {
                this.beginEvent();
            }
        });
        Bukkit.broadcastMessage(Text.color("&b&lPrison Riot &7queue is now open for &f" + this.formatSeconds(this.queueDurationSeconds) + "&7."));
        this.refreshAllScoreboards();
        return true;
    }

    public void endEventCycle() {
        if (this.phase == Phase.IDLE) {
            return;
        }
        this.abortEvent("&cThe Prison Riot has been ended by staff.");
    }

    public void addEventPoints(UUID playerId, int amount) {
        if (playerId == null || amount <= 0) {
            return;
        }
        this.currentPoints.put(playerId, this.getCurrentPoints(playerId) + amount);
        this.refreshAllScoreboards();
    }

    public void removeEventPoints(UUID playerId, int amount) {
        if (playerId == null || amount <= 0) {
            return;
        }
        this.currentPoints.put(playerId, Math.max(0, this.getCurrentPoints(playerId) - amount));
        this.refreshAllScoreboards();
    }

    public void setEventPoints(UUID playerId, int amount) {
        if (playerId == null) {
            return;
        }
        this.currentPoints.put(playerId, Math.max(0, amount));
        this.refreshAllScoreboards();
    }

    public void resetEventPoints(UUID playerId) {
        if (playerId == null) {
            return;
        }
        this.currentPoints.remove(playerId);
        this.refreshAllScoreboards();
    }

    public void resetEventPoints() {
        this.currentPoints.clear();
        this.refreshAllScoreboards();
    }

    public Material randomOre() {
        if (this.orePalette.isEmpty()) {
            return Material.COAL_ORE;
        }
        return this.orePalette.get(this.random.nextInt(this.orePalette.size()));
    }

    public int getOrePoints(Material material) {
        Material normalized = this.normalizeOre(material);
        return this.orePoints.getOrDefault(normalized, 0);
    }

    public int getOreExp(Material material) {
        Material normalized = this.normalizeOre(material);
        if (this.playerLevelService == null) {
            return 0;
        }
        int exp = this.playerLevelService.getOreExp(normalized);
        if (exp > 0) {
            return exp;
        }
        return switch (normalized) {
            case STONE -> 15;
            case COAL_ORE -> 25;
            case IRON_ORE -> 50;
            case LAPIS_ORE -> 75;
            case REDSTONE_ORE -> 75;
            case GOLD_ORE -> 125;
            case DIAMOND_ORE -> 250;
            case EMERALD_ORE -> 500;
            default -> 0;
        };
    }

    public boolean isArenaBlock(Block block) {
        if (block == null || !this.isRiotWorld(block.getWorld()) || !this.hasArenaSetup()) {
            return false;
        }
        Location loc = block.getLocation();
        return this.insideArena(loc);
    }

    public boolean isParticipant(Player player) {
        if (player == null) {
            return false;
        }
        return this.activePlayers.contains(player.getUniqueId()) || this.queuedPlayers.contains(player.getUniqueId());
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!this.isRiotWorld(block.getWorld())) {
            return;
        }

        if (!this.isRoundActive()) {
            event.setCancelled(true);
            return;
        }

        if (!this.isArenaBlock(block) && !this.isOre(block.getType())) {
            event.setCancelled(true);
            return;
        }

        if (!this.activePlayers.contains(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }

        Material type = block.getType();
        if (!this.isOre(type)) {
            event.setCancelled(true);
            return;
        }

        event.setCancelled(true);
        event.setDropItems(false);
        event.setExpToDrop(0);
        AbilityBlockState ability = this.consumeAbilityBlock(block);
        block.setType(Material.AIR, false);

        int points = this.getOrePoints(type);
        int exp = this.getOreExp(type);
        points = this.applyPointMultiplier(player.getUniqueId(), points);
        exp = this.applyExpMultiplier(player.getUniqueId(), exp);
        if (points > 0) {
            this.addEventPoints(player.getUniqueId(), points);
        }
        List<String> procList = new ArrayList<String>();
        if (exp > 0) {
            this.playerLevelService.addExp(player, exp);
        }
        if (ability != null) {
            this.applyAbilityEffect(player, player.getUniqueId(), ability.type(), procList);
        }
        if (this.tryRiotShatter(player, block, tool)) {
            int level = this.gearManager != null && tool != null ? this.gearManager.getEnchants(tool).getOrDefault("shatter", 0) : 0;
            procList.add(this.formatProc("shatter", level));
        }
        this.sendRiotActionBar(player, exp, procList);
        this.playMineSound(player);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        this.refreshPlayerScoreboard(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (this.isRiotWorld(player.getWorld())) {
            this.riotInventories.put(player.getUniqueId(), this.snapshot(player.getInventory()));
        }
        this.refreshAllScoreboards();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        if (this.internalTeleports.remove(player.getUniqueId())) {
            this.refreshPlayerScoreboard(player);
            return;
        }
        World to = player.getWorld();
        World from = event.getFrom();
        if (this.isRiotWorld(from) && !this.isRiotWorld(to)) {
            this.riotInventories.put(player.getUniqueId(), this.snapshot(player.getInventory()));
            this.restoreNormalInventory(player);
            this.teleportToPrisonSpawn(player);
            this.restorePrisonScoreboard(player);
        } else if (!this.isRiotWorld(from) && this.isRiotWorld(to)) {
            if (this.plugin.getMiningLevelScoreboardService() != null) {
                this.plugin.getMiningLevelScoreboardService().remove(player);
            }
            this.normalInventories.put(player.getUniqueId(), this.snapshot(player.getInventory()));
            if (this.isEventActive() && this.activePlayers.contains(player.getUniqueId())) {
                this.restoreRiotInventoryOrKit(player);
            }
        }
        this.refreshPlayerScoreboard(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        this.refreshPlayerScoreboard(player);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (player == null || !this.isQueued(player.getUniqueId())) {
            return;
        }
        String message = event.getMessage();
        if (message == null || message.isBlank()) {
            return;
        }
        String lower = message.toLowerCase();
        if (lower.startsWith("/spawn")) {
            this.queuedPlayers.remove(player.getUniqueId());
            this.refreshAllScoreboards();
            return;
        }
        if (lower.equals("/pr") || lower.startsWith("/pr ") || lower.equals("/riot") || lower.startsWith("/riot ")) {
            return;
        }
        event.setCancelled(true);
        player.sendMessage(Text.color("&cYou can not run this command while queuing for a Prison Riot. To leave queue run &f/spawn."));
        player.playSound(player.getLocation(), this.resolveBassSound(), 1.0f, 1.0f);
    }

    public void tick() {
        if (this.riotMenu != null) {
            this.riotMenu.refreshOpenMenus();
        }
        if (this.phase == Phase.IDLE) {
            this.tickRiotBoosts();
            this.refreshAllScoreboards();
            return;
        }

        this.tickRiotBoosts();
        this.refreshAllScoreboards();

        if (this.phase == Phase.ROUND_ACTIVE && this.phaseSecondsRemaining > 0 && this.phaseSecondsRemaining <= 10) {
            this.playRoundEndingCountdownSound();
        }

        if (this.phaseSecondsRemaining > 0) {
            this.phaseSecondsRemaining--;
        }

        if (this.phase == Phase.QUEUE) {
            this.handleQueueTick();
        } else if (this.phase == Phase.ROUND_COUNTDOWN) {
            this.handleRoundCountdownTick();
        } else if (this.phase == Phase.ROUND_ACTIVE) {
            this.handleRoundActiveTick();
        }
    }

    private void handleQueueTick() {
        if (this.phaseSecondsRemaining > 0) {
            if (this.phaseSecondsRemaining == 30 || this.phaseSecondsRemaining == 10 || this.phaseSecondsRemaining <= 5) {
                this.broadcastQueueCountdown();
            }
            return;
        }
        if (this.arenaFillTask != null) {
            this.phase = Phase.PREPARING;
            return;
        }
        this.beginEvent();
    }

    private void beginEvent() {
        List<UUID> queued = new ArrayList<>(this.queuedPlayers);
        this.queuedPlayers.clear();
        if (queued.isEmpty()) {
            Bukkit.broadcastMessage(Text.color("&cPrison Riot was cancelled because nobody queued."));
            this.phase = Phase.IDLE;
            this.phaseSecondsRemaining = 0;
            return;
        }

        this.activePlayers.clear();
        this.currentPoints.clear();
        this.clearAbilityBlocks();
        this.riotBoosts.clear();
        this.roundNumber = 1;
        this.phase = Phase.ROUND_COUNTDOWN;
        this.phaseSecondsRemaining = this.roundCountdownSeconds;
        this.ensureRiotWorld();
        for (UUID id : queued) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            this.enterRiotWorld(player);
            this.activePlayers.add(id);
        }
        if (this.activePlayers.isEmpty()) {
            Bukkit.broadcastMessage(Text.color("&cPrison Riot was cancelled because no queued players were online."));
            this.phase = Phase.IDLE;
            this.phaseSecondsRemaining = 0;
            return;
        }
        this.broadcastRoundCountdown();
        this.refreshAllScoreboards();
    }

    private void handleRoundCountdownTick() {
        if (this.phaseSecondsRemaining > 0) {
            this.broadcastRoundCountdown();
            return;
        }
        this.startRound();
    }

    private void startRound() {
        this.phase = Phase.ROUND_ACTIVE;
        this.phaseSecondsRemaining = this.roundLengthSeconds;
        Bukkit.broadcastMessage(Text.color("&b&lPrison Riot &7Round &f" + this.roundNumber + " &7has started."));
        this.refreshAllScoreboards();
    }

    private void handleRoundActiveTick() {
        if (this.phaseSecondsRemaining > 0) {
            return;
        }
        if (this.roundNumber >= this.totalRounds) {
            this.finishEvent();
            return;
        }
        this.roundNumber++;
        this.prepareNextRound();
    }

    private void playRoundEndingCountdownSound() {
        for (UUID id : new ArrayList<>(this.activePlayers)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline() || !this.isRiotWorld(player.getWorld())) {
                continue;
            }
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.0f);
        }
    }

    private void prepareNextRound() {
        this.phase = Phase.PREPARING;
        this.phaseSecondsRemaining = 0;
        this.ensureRiotWorld();
        this.startArenaFill(() -> {
            if (this.phase != Phase.PREPARING) {
                return;
            }
            this.repositionActivePlayersToArenaTop();
            this.phase = Phase.ROUND_COUNTDOWN;
            this.phaseSecondsRemaining = this.roundCountdownSeconds;
            this.broadcastRoundCountdown();
            this.refreshAllScoreboards();
        });
    }

    private void finishEvent() {
        this.phase = Phase.FINISHING;
        this.phaseSecondsRemaining = 0;
        this.stopArenaFill();
        this.awardShopPoints();
        this.clearAbilityBlocks();
        this.riotBoosts.clear();
        Bukkit.broadcastMessage(Text.color("&b&lPrison Riot &7has ended."));
        for (UUID id : new ArrayList<>(this.activePlayers)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            this.clearRiotInventory(player);
            this.restoreNormalInventory(player);
            this.teleportToPrisonSpawn(player);
            this.riotInventories.remove(id);
            this.restorePrisonScoreboard(player);
        }
        this.activePlayers.clear();
        this.currentPoints.clear();
        this.phase = Phase.QUEUE;
        this.phaseSecondsRemaining = this.queueDurationSeconds;
        this.roundNumber = 0;
        Bukkit.broadcastMessage(Text.color("&b&lPrison Riot &7queue is now open for &f" + this.formatSeconds(this.queueDurationSeconds) + "&7."));
        this.refreshAllScoreboards();
    }

    private void abortEvent(String message) {
        if (message != null && !message.isBlank()) {
            Bukkit.broadcastMessage(Text.color(message));
        }
        this.stopArenaFill();
        this.stopLegacyRiotDisplayCleanup();
        this.clearAbilityBlocks();
        this.riotBoosts.clear();
        for (UUID id : new ArrayList<>(this.activePlayers)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            this.clearRiotInventory(player);
            this.restoreNormalInventory(player);
            this.teleportToPrisonSpawn(player);
            this.riotInventories.remove(id);
            this.restorePrisonScoreboard(player);
        }
        this.activePlayers.clear();
        this.queuedPlayers.clear();
        this.currentPoints.clear();
        this.clearAbilityBlocks();
        this.riotBoosts.clear();
        this.phase = Phase.IDLE;
        this.phaseSecondsRemaining = 0;
        this.roundNumber = 0;
        this.refreshAllScoreboards();
    }

    private void awardShopPoints() {
        List<UUID> ranking = new ArrayList<>(this.activePlayers);
        ranking.sort(Comparator.<UUID>comparingInt(this::getCurrentPoints).reversed()
                .thenComparing(this::playerName, String.CASE_INSENSITIVE_ORDER));

        int participantCount = ranking.size();
        if (participantCount == 0) {
            return;
        }

        int maxReward = 250;
        int minReward = 25;
        for (int i = 0; i < ranking.size(); ++i) {
            UUID id = ranking.get(i);
            int rank = i + 1;
            int reward;
            if (participantCount == 1) {
                reward = maxReward;
            } else {
                double progress = (double)(participantCount - rank) / (double)(participantCount - 1);
                reward = (int)Math.round((double)minReward + ((double)(maxReward - minReward) * progress));
            }
            this.playerDataService.update(id, data -> data.addPrisonRiotShopPoints(reward));
            Player player = Bukkit.getPlayer(id);
            if (player != null && player.isOnline()) {
                player.sendMessage(Text.color("&aYou earned &f" + reward + " &aPrison Riot shop points."));
            }
        }
    }

    private void enterRiotWorld(Player player) {
        if (player == null) {
            return;
        }
        if (this.plugin.getMiningLevelScoreboardService() != null) {
            this.plugin.getMiningLevelScoreboardService().remove(player);
        }
        this.normalInventories.put(player.getUniqueId(), this.snapshot(player.getInventory()));
        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[4]);
        player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
        this.applyKit(player);
        this.riotInventories.put(player.getUniqueId(), this.snapshot(player.getInventory()));
        this.teleportInternal(player, this.resolveArenaSpawn());
    }

    private void restoreRiotInventoryOrKit(Player player) {
        InventorySnapshot snapshot = this.riotInventories.get(player.getUniqueId());
        if (snapshot != null) {
            this.restore(player.getInventory(), snapshot);
            return;
        }
        this.applyKit(player);
        this.riotInventories.put(player.getUniqueId(), this.snapshot(player.getInventory()));
    }

    private void restoreNormalInventory(Player player) {
        InventorySnapshot snapshot = this.normalInventories.get(player.getUniqueId());
        if (snapshot == null) {
            player.getInventory().clear();
            player.getInventory().setArmorContents(new ItemStack[4]);
            player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
            return;
        }
        this.restore(player.getInventory(), snapshot);
    }

    private void clearRiotInventory(Player player) {
        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[4]);
        player.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
    }

    private void applyKit(Player player) {
        ItemStack pickaxe = this.createRiotPickaxe();
        ItemStack boots = this.createRiotBoots();
        player.getInventory().setItem(0, pickaxe);
        player.getInventory().setBoots(boots);
        player.getInventory().setItem(8, new ItemStack(Material.COOKED_BEEF, 16));
    }

    private ItemStack createRiotPickaxe() {
        PickaxeType type = this.pickaxeManager.getType("diamond");
        if (type == null && !this.pickaxeManager.getTypes().isEmpty()) {
            type = this.pickaxeManager.getTypes().iterator().next();
        }
        ItemStack pickaxe = type == null ? new ItemStack(Material.DIAMOND_PICKAXE) : this.pickaxeManager.createPickaxe(type, 0);
        this.pickaxeManager.applyEnchant(pickaxe, "efficiency", 6, 6);
        this.pickaxeManager.applyEnchant(pickaxe, "shatter", 4, 4);
        this.pickaxeManager.applyEnchant(pickaxe, "fireball", 3, 3);
        this.pickaxeManager.applyEnchant(pickaxe, "fissure", 6, 6);
        return pickaxe;
    }

    private ItemStack createRiotBoots() {
        ItemStack boots = this.gearManager.wrap(new ItemStack(Material.CHAINMAIL_BOOTS), "riot_boots");
        this.gearManager.applyEnchant(boots, "quick_feet", 3, 3);
        this.gearManager.applyEnchant(boots, "springs", 2, 2);
        return boots;
    }

    private void teleportToArenaSpawn(Player player) {
        Location target = this.resolveArenaSpawn();
        if (target != null) {
            player.teleport(target);
        }
    }

    private void moveToArenaTop(Player player) {
        Location target = this.resolveArenaSpawn();
        if (target == null) {
            return;
        }
        this.teleportInternal(player, target);
        this.restoreRiotInventoryOrKit(player);
    }

    private void teleportToPrisonSpawn(Player player) {
        Location target = this.plugin.getTeleportService() == null ? null : this.plugin.getTeleportService().getSpawn();
        if (target == null) {
            World world = Bukkit.getWorld(this.prisonWorldName);
            if (world != null) {
                target = world.getSpawnLocation();
            }
        }
        if (target != null) {
            this.teleportInternal(player, target);
        }
    }

    private void teleportInternal(Player player, Location target) {
        if (player == null || target == null) {
            return;
        }
        this.internalTeleports.add(player.getUniqueId());
        player.teleport(target);
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.internalTeleports.remove(player.getUniqueId()), 1L);
    }

    private void fillArena() {
        this.startArenaFill(null);
    }

    private void startArenaFill(Runnable completionAction) {
        if (!this.hasArenaSetup()) {
            return;
        }
        World world = this.ensureRiotWorld();
        if (world == null) {
            return;
        }
        this.stopArenaFill();
        this.clearAbilityBlocks();
        int minX = Math.min(this.arenaCorner1.getBlockX(), this.arenaCorner2.getBlockX());
        int maxX = Math.max(this.arenaCorner1.getBlockX(), this.arenaCorner2.getBlockX());
        int minY = Math.min(this.arenaCorner1.getBlockY(), this.arenaCorner2.getBlockY());
        int maxY = Math.max(this.arenaCorner1.getBlockY(), this.arenaCorner2.getBlockY());
        int minZ = Math.min(this.arenaCorner1.getBlockZ(), this.arenaCorner2.getBlockZ());
        int maxZ = Math.max(this.arenaCorner1.getBlockZ(), this.arenaCorner2.getBlockZ());
        ArrayList<ArenaPos> positions = new ArrayList<>();
        for (int chunkX = minX >> 4; chunkX <= maxX >> 4; ++chunkX) {
            for (int chunkZ = minZ >> 4; chunkZ <= maxZ >> 4; ++chunkZ) {
                world.getChunkAt(chunkX, chunkZ).load(true);
            }
        }
        for (int x = minX; x <= maxX; ++x) {
            for (int y = minY; y <= maxY; ++y) {
                for (int z = minZ; z <= maxZ; ++z) {
                    positions.add(new ArenaPos(x, y, z));
                }
            }
        }
        this.arenaFillPositions = positions;
        this.arenaFillIndex = 0;
        this.arenaFillCompleteAction = completionAction;
        this.arenaFillTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::tickArenaFill, 1L, 1L);
        this.tickArenaFill();
    }

    private World ensureRiotWorld() {
        World world = Bukkit.getWorld(this.arenaWorldName);
        if (world == null) {
            world = Bukkit.createWorld(new WorldCreator(this.arenaWorldName));
        }
        if (world != null) {
            world.setPVP(false);
            world.setGameRuleValue("doMobSpawning", "false");
            world.setGameRuleValue("doDaylightCycle", "false");
            world.setGameRuleValue("doWeatherCycle", "false");
            this.cleanupLegacyAstronautEntities(world);
        }
        return world;
    }

    private void cleanupLegacyAstronautEntities() {
        this.cleanupLegacyAstronautEntities(Bukkit.getWorld(this.arenaWorldName));
    }

    private void cleanupLegacyAstronautEntities(World world) {
        if (world == null) {
            return;
        }
        for (Zombie zombie : world.getEntitiesByClass(Zombie.class)) {
            String name = zombie.getCustomName();
            if (name == null) {
                continue;
            }
            String stripped = ChatColor.stripColor(name);
            if (stripped != null && stripped.startsWith("Astronaut")) {
                zombie.remove();
            }
        }
    }

    private Location resolveArenaSpawn() {
        if (this.arenaSpawn != null) {
            return this.toArenaWorld(this.arenaSpawn);
        }
        if (!this.hasArenaSetup()) {
            return null;
        }
        World world = this.ensureRiotWorld();
        if (world == null) {
            return null;
        }
        int minX = Math.min(this.arenaCorner1.getBlockX(), this.arenaCorner2.getBlockX());
        int maxX = Math.max(this.arenaCorner1.getBlockX(), this.arenaCorner2.getBlockX());
        int maxY = Math.max(this.arenaCorner1.getBlockY(), this.arenaCorner2.getBlockY());
        int minZ = Math.min(this.arenaCorner1.getBlockZ(), this.arenaCorner2.getBlockZ());
        int maxZ = Math.max(this.arenaCorner1.getBlockZ(), this.arenaCorner2.getBlockZ());
        double x = (double)minX + (double)(maxX - minX) / 2.0D + 0.5D;
        double z = (double)minZ + (double)(maxZ - minZ) / 2.0D + 0.5D;
        return new Location(world, x, (double)maxY + 2.0D, z, 0.0f, 0.0f);
    }

    private boolean insideArena(Location location) {
        if (location == null || location.getWorld() == null || !this.isRiotWorld(location.getWorld()) || this.arenaCorner1 == null || this.arenaCorner2 == null) {
            return false;
        }
        int minX = Math.min(this.arenaCorner1.getBlockX(), this.arenaCorner2.getBlockX());
        int maxX = Math.max(this.arenaCorner1.getBlockX(), this.arenaCorner2.getBlockX());
        int minY = Math.min(this.arenaCorner1.getBlockY(), this.arenaCorner2.getBlockY());
        int maxY = Math.max(this.arenaCorner1.getBlockY(), this.arenaCorner2.getBlockY());
        int minZ = Math.min(this.arenaCorner1.getBlockZ(), this.arenaCorner2.getBlockZ());
        int maxZ = Math.max(this.arenaCorner1.getBlockZ(), this.arenaCorner2.getBlockZ());
        return location.getBlockX() >= minX && location.getBlockX() <= maxX
                && location.getBlockY() >= minY && location.getBlockY() <= maxY
                && location.getBlockZ() >= minZ && location.getBlockZ() <= maxZ;
    }

    private boolean isOre(Material type) {
        return type == Material.COAL_ORE
                || type == Material.STONE
                || type == Material.IRON_ORE
                || type == Material.LAPIS_ORE
                || type == Material.GOLD_ORE
                || type == Material.REDSTONE_ORE
                || type == Material.DIAMOND_ORE
                || type == Material.EMERALD_ORE;
    }

    private Material randomOre(int y) {
        if (this.arenaCorner1 == null || this.arenaCorner2 == null) {
            return this.randomOre();
        }
        int minY = Math.min(this.arenaCorner1.getBlockY(), this.arenaCorner2.getBlockY());
        int maxY = Math.max(this.arenaCorner1.getBlockY(), this.arenaCorner2.getBlockY());
        if (maxY <= minY) {
            return this.randomOre();
        }
        double surface = Math.max(0.0D, Math.min(1.0D, (double)(y - minY) / (double)(maxY - minY)));
        return this.pickWeightedOre(surface);
    }

    private Material pickWeightedOre(double surface) {
        double roundFactor = Math.max(0.15D, 1.0D - 0.12D * (double)Math.max(0, this.roundNumber - 1));
        double[] weights = new double[]{
                this.lerp(5.0D, 42.0D, surface) * roundFactor,
                this.lerp(12.0D, 34.0D, surface),
                this.lerp(16.0D, 24.0D, surface),
                this.lerp(14.0D, 12.0D, surface),
                this.lerp(12.0D, 7.0D, surface),
                this.lerp(28.0D, 4.0D, surface),
                this.lerp(22.0D, 2.0D, surface),
                this.lerp(16.0D, 1.0D, surface)
        };
        Material[] materials = new Material[]{
                Material.STONE,
                Material.COAL_ORE,
                Material.IRON_ORE,
                Material.LAPIS_ORE,
                Material.GOLD_ORE,
                Material.REDSTONE_ORE,
                Material.DIAMOND_ORE,
                Material.EMERALD_ORE
        };
        double total = 0.0D;
        for (double weight : weights) {
            total += Math.max(0.0D, weight);
        }
        if (total <= 0.0D) {
            return Material.COAL_ORE;
        }
        double roll = this.random.nextDouble() * total;
        for (int i = 0; i < weights.length; ++i) {
            roll -= Math.max(0.0D, weights[i]);
            if (roll <= 0.0D) {
                return materials[i];
            }
        }
        return Material.EMERALD_ORE;
    }

    private double lerp(double low, double high, double t) {
        return low + (high - low) * t;
    }

    private boolean tryRiotShatter(Player player, Block origin, ItemStack tool) {
        if (player == null || origin == null || tool == null) {
            return false;
        }
        Map<String, Integer> enchants = this.pickaxeManager.getEnchants(tool);
        int level = enchants.getOrDefault("shatter", 0);
        if (level <= 0) {
            return false;
        }
        int radius = Math.max(1, (level + 1) / 2);
        int luck = enchants.getOrDefault("luck", 0);
        double chance = this.getRiotShatterChance(level, luck);
        if (this.random.nextDouble() >= chance / 100.0) {
            return false;
        }
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dy = -radius; dy <= radius; ++dy) {
                for (int dz = -radius; dz <= radius; ++dz) {
                    if (dx == 0 && dy == 0 && dz == 0) {
                        continue;
                    }
                    Block adj = origin.getRelative(dx, dy, dz);
                    if (!this.isRiotShatterTarget(adj)) {
                        continue;
                    }
                    this.breakRiotOreBlock(player, adj);
                }
            }
        }
        return true;
    }

    private double getRiotShatterChance(int level, int luck) {
        double baseChance = Math.min(RIOT_SHATTER_CHANCE_CAP, RIOT_SHATTER_CHANCE_PER_LEVEL * (double)Math.max(0, level));
        if (luck > 0) {
            baseChance = Math.min(100.0, baseChance * (1.0 + 0.1 * (double)luck));
        }
        return Math.min(100.0, baseChance);
    }

    private boolean isRiotShatterTarget(Block block) {
        return block != null
                && block.getType() != Material.AIR
                && this.isRiotWorld(block.getWorld())
                && this.isRoundActive()
                && this.isArenaBlock(block)
                && this.isOre(block.getType());
    }

    private boolean breakRiotOreBlock(Player player, Block block) {
        if (!this.isRiotShatterTarget(block)) {
            return false;
        }
        AbilityBlockState ability = this.consumeAbilityBlock(block);
        Material type = block.getType();
        int points = this.getOrePoints(type);
        int exp = this.getOreExp(type);
        points = this.applyPointMultiplier(player.getUniqueId(), points);
        exp = this.applyExpMultiplier(player.getUniqueId(), exp);
        if (points > 0) {
            this.addEventPoints(player.getUniqueId(), points);
        }
        if (exp > 0) {
            this.playerLevelService.addExp(player, exp);
        }
        if (ability != null) {
            this.applyAbilityEffect(player, player.getUniqueId(), ability.type(), null);
        }
        block.setType(Material.AIR, false);
        return true;
    }

    private void playMineSound(Player player) {
        if (player == null) {
            return;
        }
        UUID id = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = this.lastMineSoundAt.get(id);
        if (last != null && now - last.longValue() < 50L) {
            return;
        }
        this.lastMineSoundAt.put(id, now);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
    }

    private void sendRiotActionBar(Player player, int exp, List<String> procList) {
        if (player == null) {
            return;
        }
        StringBuilder action = new StringBuilder();
        if (exp > 0) {
            action.append("+ ").append(Text.formatNumber(exp)).append(" XP");
        }
        if (procList != null && !procList.isEmpty()) {
            if (action.length() > 0) {
                action.append(" &7| &7");
            }
            action.append(String.join(", ", procList)).append(" &aPROC");
        }
        if (action.length() > 0) {
            player.sendActionBar(Text.color("&d" + action));
        }
    }

    private String formatProc(String enchantId, int level) {
        return EnchantDisplayUtil.format(this.customEnchantService, enchantId, level);
    }

    private void stopArenaFill() {
        if (this.arenaFillTask != null) {
            this.arenaFillTask.cancel();
            this.arenaFillTask = null;
        }
        this.arenaFillPositions = Collections.emptyList();
        this.arenaFillIndex = 0;
        this.arenaFillCompleteAction = null;
    }

    private void scheduleLegacyRiotDisplayCleanup() {
        if (this.legacyRiotDisplayCleanupTask != null) {
            return;
        }
        World world = Bukkit.getWorld(this.arenaWorldName);
        if (world == null) {
            world = Bukkit.createWorld(new WorldCreator(this.arenaWorldName));
        }
        if (world == null) {
            return;
        }
        List<org.bukkit.entity.ItemDisplay> displays = new ArrayList<>(world.getEntitiesByClass(org.bukkit.entity.ItemDisplay.class));
        if (displays.isEmpty()) {
            return;
        }
        this.legacyRiotDisplayCleanupTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, new Runnable() {
            private int index;

            @Override
            public void run() {
                int processed = 0;
                while (this.index < displays.size() && processed < 2000) {
                    org.bukkit.entity.ItemDisplay display = displays.get(this.index++);
                    if (display != null && display.isValid()) {
                        display.remove();
                    }
                    processed++;
                }
                if (this.index >= displays.size()) {
                    stopLegacyRiotDisplayCleanup();
                }
            }
        }, 1L, 1L);
    }

    private void stopLegacyRiotDisplayCleanup() {
        if (this.legacyRiotDisplayCleanupTask != null) {
            this.legacyRiotDisplayCleanupTask.cancel();
            this.legacyRiotDisplayCleanupTask = null;
        }
    }

    private void tickArenaFill() {
        if (this.arenaFillPositions.isEmpty()) {
            this.finishArenaFill();
            return;
        }
        World world = Bukkit.getWorld(this.arenaWorldName);
        if (world == null) {
            this.finishArenaFill();
            return;
        }
        int processed = 0;
        while (this.arenaFillIndex < this.arenaFillPositions.size() && processed < ARENA_FILL_BATCH_SIZE) {
            ArenaPos pos = this.arenaFillPositions.get(this.arenaFillIndex++);
            Block block = world.getBlockAt(pos.x(), pos.y(), pos.z());
            Material ore = this.randomOre(pos.y());
            block.setType(ore, false);
            AbilityBlockType abilityType = this.rollAbilityBlock();
            if (abilityType != null) {
                this.spawnAbilityBlockDisplay(block, abilityType);
            }
            processed++;
        }
        if (this.arenaFillIndex >= this.arenaFillPositions.size()) {
            this.finishArenaFill();
        }
    }

    private void finishArenaFill() {
        if (this.arenaFillTask != null) {
            this.arenaFillTask.cancel();
            this.arenaFillTask = null;
        }
        Runnable completion = this.arenaFillCompleteAction;
        this.arenaFillCompleteAction = null;
        this.arenaFillPositions = Collections.emptyList();
        this.arenaFillIndex = 0;
        if (completion != null && (this.phase == Phase.PREPARING || (this.phase == Phase.QUEUE && this.phaseSecondsRemaining <= 0))) {
            completion.run();
        }
    }

    private void repositionActivePlayersToArenaTop() {
        for (UUID id : new ArrayList<>(this.activePlayers)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            this.moveToArenaTop(player);
        }
    }

    private void refreshAllScoreboards() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.refreshPlayerScoreboard(player);
        }
    }

    private void refreshPlayerScoreboard(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        if (!this.isRiotWorld(player.getWorld()) || !this.isEventActive()) {
            return;
        }
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) {
            return;
        }
        Scoreboard board = manager.getNewScoreboard();
        Objective objective = board.registerNewObjective("prriot", "dummy", Text.color("&c&lPrison Riot"));
        objective.setDisplaySlot(DisplaySlot.SIDEBAR);

        List<UUID> rankingIds = new ArrayList<>(this.activePlayers);
        rankingIds.sort(Comparator.<UUID>comparingInt(this::getCurrentPoints).reversed()
                .thenComparing(this::playerName, String.CASE_INSENSITIVE_ORDER));

        this.setScore(board, "&7Status: " + Text.color(this.getStatusText()), 15);
        this.setScore(board, "&7Round: &f" + Math.max(0, this.roundNumber) + "&7/&f" + this.totalRounds, 14);
        this.setScore(board, "&7Time: &f" + this.formatSeconds(this.phaseSecondsRemaining), 13);
        this.setScore(board, "&7Players: &f" + this.activePlayers.size(), 12);
        this.setScore(board, "&r ", 11);

        int line = 10;
        int visible = Math.min(8, rankingIds.size());
        for (int i = 0; i < visible; ++i) {
            UUID id = rankingIds.get(i);
            String name = this.playerName(id);
            this.setScore(board, Text.color("&f" + (i + 1) + ". &7" + name + " &b" + this.getCurrentPoints(id)), line--);
        }
        if (rankingIds.size() > visible) {
            this.setScore(board, Text.color("&7+" + (rankingIds.size() - visible) + " more"), line--);
        }

        player.setScoreboard(board);
    }

    private void restorePrisonScoreboard(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        if (this.plugin.getMiningLevelScoreboardService() != null) {
            this.plugin.getMiningLevelScoreboardService().updateLater(player);
        }
    }

    private void setScore(Scoreboard board, String text, int score) {
        if (board == null || text == null) {
            return;
        }
        String entry = Text.color(text) + ChatColor.values()[Math.abs(score) % ChatColor.values().length];
        Objective objective = board.getObjective(DisplaySlot.SIDEBAR);
        if (objective != null) {
            objective.getScore(entry).setScore(score);
        }
    }

    private void broadcastQueueCountdown() {
        String message = "&b&lPrison Riot &7queue starts in &f" + this.formatSeconds(this.phaseSecondsRemaining) + "&7.";
        Bukkit.broadcastMessage(Text.color(message));
    }

    private void broadcastRoundCountdown() {
        for (UUID id : this.activePlayers) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !player.isOnline()) {
                continue;
            }
            player.sendTitle(Text.color("&f&lRound " + this.roundNumber + " / " + this.totalRounds), Text.color("&7" + this.formatSeconds(this.phaseSecondsRemaining)), TITLE_FADE_IN, TITLE_STAY, TITLE_FADE_OUT);
            player.sendMessage(Text.color("&7Round &f" + this.roundNumber + " &7starts in &f" + this.formatSeconds(this.phaseSecondsRemaining) + "&7."));
        }
    }

    private Material normalizeOre(Material type) {
        if (type == null) {
            return null;
        }
        return switch (type) {
            case DEEPSLATE_COAL_ORE -> Material.COAL_ORE;
            case DEEPSLATE_IRON_ORE -> Material.IRON_ORE;
            case DEEPSLATE_LAPIS_ORE -> Material.LAPIS_ORE;
            case DEEPSLATE_GOLD_ORE, NETHER_GOLD_ORE -> Material.GOLD_ORE;
            case DEEPSLATE_REDSTONE_ORE -> Material.REDSTONE_ORE;
            case DEEPSLATE_DIAMOND_ORE -> Material.DIAMOND_ORE;
            case DEEPSLATE_EMERALD_ORE -> Material.EMERALD_ORE;
            default -> type;
        };
    }

    private Location readLocation(String path) {
        if (this.cfg == null || !this.cfg.isConfigurationSection(path)) {
            return null;
        }
        String worldName = this.cfg.getString(path + ".world");
        World world = worldName == null ? null : Bukkit.getWorld(worldName);
        if (world == null && worldName != null) {
            world = Bukkit.createWorld(new WorldCreator(worldName));
        }
        if (world == null) {
            return null;
        }
        double x = this.cfg.getDouble(path + ".x");
        double y = this.cfg.getDouble(path + ".y");
        double z = this.cfg.getDouble(path + ".z");
        float yaw = (float)this.cfg.getDouble(path + ".yaw", 0.0D);
        float pitch = (float)this.cfg.getDouble(path + ".pitch", 0.0D);
        return new Location(world, x, y, z, yaw, pitch);
    }

    private void writeLocation(String path, Location location) {
        if (location == null) {
            this.cfg.set(path, null);
            return;
        }
        this.cfg.set(path + ".world", location.getWorld() == null ? null : location.getWorld().getName());
        this.cfg.set(path + ".x", location.getX());
        this.cfg.set(path + ".y", location.getY());
        this.cfg.set(path + ".z", location.getZ());
        this.cfg.set(path + ".yaw", location.getYaw());
        this.cfg.set(path + ".pitch", location.getPitch());
    }

    private Location normalize(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        return new Location(location.getWorld(), location.getBlockX(), location.getBlockY(), location.getBlockZ(), location.getYaw(), location.getPitch());
    }

    private Location normalizeArenaLocation(Location location) {
        Location normalized = this.normalize(location);
        if (normalized == null) {
            return null;
        }
        World arenaWorld = this.ensureRiotWorld();
        if (arenaWorld == null) {
            return normalized;
        }
        return new Location(arenaWorld, normalized.getBlockX(), normalized.getBlockY(), normalized.getBlockZ(), normalized.getYaw(), normalized.getPitch());
    }

    private Location toArenaWorld(Location location) {
        Location normalized = this.normalize(location);
        if (normalized == null) {
            return null;
        }
        World arenaWorld = this.ensureRiotWorld();
        if (arenaWorld == null) {
            return normalized;
        }
        return new Location(arenaWorld, normalized.getBlockX(), normalized.getBlockY(), normalized.getBlockZ(), normalized.getYaw(), normalized.getPitch());
    }

    private InventorySnapshot snapshot(PlayerInventory inventory) {
        if (inventory == null) {
            return new InventorySnapshot(new ItemStack[0], new ItemStack[0], null);
        }
        ItemStack[] contents = cloneArray(inventory.getContents());
        ItemStack[] armor = cloneArray(inventory.getArmorContents());
        ItemStack offHand = cloneItem(inventory.getItemInOffHand());
        return new InventorySnapshot(contents, armor, offHand);
    }

    private void restore(PlayerInventory inventory, InventorySnapshot snapshot) {
        if (inventory == null || snapshot == null) {
            return;
        }
        inventory.setContents(cloneArray(snapshot.contents()));
        inventory.setArmorContents(cloneArray(snapshot.armor()));
        inventory.setItemInOffHand(cloneItem(snapshot.offHand()));
    }

    private ItemStack[] cloneArray(ItemStack[] items) {
        if (items == null) {
            return new ItemStack[0];
        }
        ItemStack[] copy = new ItemStack[items.length];
        for (int i = 0; i < items.length; ++i) {
            copy[i] = cloneItem(items[i]);
        }
        return copy;
    }

    private ItemStack cloneItem(ItemStack item) {
        return item == null ? null : item.clone();
    }

    private String formatSeconds(int seconds) {
        int safe = Math.max(0, seconds);
        int minutes = safe / 60;
        int remain = safe % 60;
        return String.format("%d:%02d", minutes, remain);
    }

    private String formatLocation(Location location) {
        if (location == null || location.getWorld() == null) {
            return "unset";
        }
        return location.getWorld().getName() + " " + location.getBlockX() + " " + location.getBlockY() + " " + location.getBlockZ();
    }

    private String playerName(UUID id) {
        Player player = Bukkit.getPlayer(id);
        if (player != null) {
            return player.getName();
        }
        String offlineName = Bukkit.getOfflinePlayer(id).getName();
        return offlineName != null ? offlineName : id.toString().substring(0, 8);
    }

    private int applyPointMultiplier(UUID playerId, int points) {
        if (playerId == null || points <= 0) {
            return points;
        }
        double multiplier = this.getPointMultiplier(playerId);
        return Math.max(0, (int)Math.round((double)points * multiplier));
    }

    private int applyExpMultiplier(UUID playerId, int exp) {
        if (playerId == null || exp <= 0) {
            return exp;
        }
        double multiplier = this.getExpMultiplier(playerId);
        return Math.max(0, (int)Math.round((double)exp * multiplier));
    }

    private double getPointMultiplier(UUID playerId) {
        RiotBoostState boost = this.riotBoosts.get(playerId);
        if (boost == null || boost.pointExpiresAt() <= System.currentTimeMillis()) {
            return 1.0D;
        }
        return Math.max(1.0D, boost.pointMultiplier());
    }

    private double getExpMultiplier(UUID playerId) {
        RiotBoostState boost = this.riotBoosts.get(playerId);
        if (boost == null || boost.expExpiresAt() <= System.currentTimeMillis()) {
            return 1.0D;
        }
        return Math.max(1.0D, boost.expMultiplier());
    }

    private void applyAbilityEffect(Player player, UUID minerId, AbilityBlockType type, List<String> procList) {
        if (type == null) {
            return;
        }
        UUID targetId = player != null ? player.getUniqueId() : minerId;
        if (targetId == null) {
            return;
        }
        long expiresAt = System.currentTimeMillis() + (long)type.durationSeconds() * 1000L;
        RiotBoostState current = this.riotBoosts.get(targetId);
        double pointMultiplier = current == null ? 1.0D : current.pointMultiplier();
        double expMultiplier = current == null ? 1.0D : current.expMultiplier();
        long pointExpiresAt = current == null ? 0L : current.pointExpiresAt();
        long expExpiresAt = current == null ? 0L : current.expExpiresAt();
        switch (type) {
            case LIME_POINTS -> {
                pointMultiplier = Math.max(pointMultiplier, 2.0D);
                pointExpiresAt = Math.max(pointExpiresAt, expiresAt);
            }
            case BLUE_POINTS -> {
                pointMultiplier = Math.max(pointMultiplier, 5.0D);
                pointExpiresAt = Math.max(pointExpiresAt, expiresAt);
            }
            case RED_EXP -> {
                expMultiplier = Math.max(expMultiplier, 3.0D);
                expExpiresAt = Math.max(expExpiresAt, expiresAt);
            }
            case YELLOW_MONEY -> {
                if (player != null && this.plugin.getBankNoteService() != null) {
                    ItemStack note = this.plugin.getBankNoteService().createBankNote(10000.0D);
                    if (this.plugin.getStashService() != null) {
                        this.plugin.getStashService().giveOrStash(player, note);
                    } else {
                        Map<Integer, ItemStack> leftover = player.getInventory().addItem(note);
                        leftover.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
                    }
                    player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
                }
            }
        }
        if (type != AbilityBlockType.YELLOW_MONEY) {
            this.riotBoosts.put(targetId, new RiotBoostState(pointMultiplier, pointExpiresAt, expMultiplier, expExpiresAt));
        }
        if (procList != null) {
            procList.add(type.displayName());
        }
        if (player != null) {
            player.sendMessage(Text.color(type.message()));
        }
    }

    private void tickRiotBoosts() {
        long now = System.currentTimeMillis();
        this.riotBoosts.entrySet().removeIf(entry -> {
            RiotBoostState state = entry.getValue();
            return state == null || (state.pointExpiresAt() <= now && state.expExpiresAt() <= now);
        });
    }

    private AbilityBlockType rollAbilityBlock() {
        if (this.random.nextDouble() > ABILITY_BLOCK_CHANCE) {
            return null;
        }
        AbilityBlockType[] values = AbilityBlockType.values();
        return values[this.random.nextInt(values.length)];
    }

    private void spawnAbilityBlockDisplay(Block block, AbilityBlockType type) {
        if (block == null || type == null || block.getWorld() == null) {
            return;
        }
        BlockPos pos = BlockPos.of(block);
        this.removeAbilityBlockDisplay(this.abilityBlocks.remove(pos));
        Location loc = block.getLocation().add(0.5D, 0.5D, 0.5D);
        BlockDisplay display = block.getWorld().spawn(loc, BlockDisplay.class, d -> {
            d.setBlock(block.getBlockData());
            d.setGlowing(true);
            d.setGlowColorOverride(type.glowColor());
            d.setBrightness(new Display.Brightness(15, 15));
            d.setPersistent(true);
            d.setInvulnerable(true);
            d.setGravity(false);
            d.setBillboard(Display.Billboard.FIXED);
            d.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(1.02f, 1.02f, 1.02f), new Quaternionf()));
        });
        this.abilityBlocks.put(pos, new AbilityBlockState(type, display.getUniqueId()));
    }

    private void removeAbilityBlockDisplay(AbilityBlockState state) {
        if (state == null || state.displayId() == null) {
            return;
        }
        org.bukkit.entity.Entity entity = Bukkit.getEntity(state.displayId());
        if (entity != null) {
            entity.remove();
        }
    }

    private void clearAbilityBlocks() {
        if (this.abilityBlocks.isEmpty()) {
            return;
        }
        for (AbilityBlockState state : new ArrayList<>(this.abilityBlocks.values())) {
            this.removeAbilityBlockDisplay(state);
        }
        this.abilityBlocks.clear();
    }

    private AbilityBlockState consumeAbilityBlock(Block block) {
        if (block == null) {
            return null;
        }
        BlockPos pos = BlockPos.of(block);
        AbilityBlockState state = this.abilityBlocks.remove(pos);
        if (state != null) {
            this.removeAbilityBlockDisplay(state);
        }
        return state;
    }

    private Sound resolveBassSound() {
        try {
            return Sound.valueOf("BLOCK_NOTE_BLOCK_BASS");
        } catch (IllegalArgumentException ex) {
            return Sound.valueOf("NOTE_BASS");
        }
    }

    private void loadPoints() {
        this.orePoints.clear();
        int stonePoints = this.cfg.getInt("points.STONE", 1);
        int coalPoints = this.cfg.getInt("points.COAL_ORE", 2);
        if (coalPoints <= stonePoints) {
            coalPoints = stonePoints + 1;
        }
        this.orePoints.put(Material.STONE, stonePoints);
        this.orePoints.put(Material.COAL_ORE, coalPoints);
        this.orePoints.put(Material.IRON_ORE, this.cfg.getInt("points.IRON_ORE", 3));
        this.orePoints.put(Material.LAPIS_ORE, this.cfg.getInt("points.LAPIS_ORE", 4));
        this.orePoints.put(Material.GOLD_ORE, this.cfg.getInt("points.GOLD_ORE", 5));
        this.orePoints.put(Material.REDSTONE_ORE, this.cfg.getInt("points.REDSTONE_ORE", 6));
        this.orePoints.put(Material.DIAMOND_ORE, this.cfg.getInt("points.DIAMOND_ORE", 8));
        this.orePoints.put(Material.EMERALD_ORE, this.cfg.getInt("points.EMERALD_ORE", 11));
        this.orePalette.clear();
        this.orePalette.addAll(Collections.nCopies(18, Material.STONE));
        this.orePalette.addAll(Collections.nCopies(30, Material.COAL_ORE));
        this.orePalette.addAll(Collections.nCopies(24, Material.IRON_ORE));
        this.orePalette.addAll(Collections.nCopies(14, Material.LAPIS_ORE));
        this.orePalette.addAll(Collections.nCopies(8, Material.GOLD_ORE));
        this.orePalette.addAll(Collections.nCopies(6, Material.REDSTONE_ORE));
        this.orePalette.addAll(Collections.nCopies(3, Material.DIAMOND_ORE));
        this.orePalette.addAll(Collections.nCopies(1, Material.EMERALD_ORE));
    }

    private enum Phase {
        IDLE,
        QUEUE,
        PREPARING,
        ROUND_COUNTDOWN,
        ROUND_ACTIVE,
        FINISHING
    }

    private record ArenaPos(int x, int y, int z) {
    }

    private enum AbilityBlockType {
        LIME_POINTS(Color.fromRGB(0, 255, 0), 5, "&a&lLime Boost", "&aRiot ability: &f2x points for 5 seconds."),
        RED_EXP(Color.fromRGB(255, 0, 0), 3, "&c&lRed Boost", "&cRiot ability: &f3x mining exp for 3 seconds."),
        BLUE_POINTS(Color.fromRGB(0, 0, 255), 4, "&9&lBlue Boost", "&9Riot ability: &f5x points for 4 seconds."),
        YELLOW_MONEY(Color.fromRGB(255, 255, 0), 0, "&e&lYellow Note", "&eRiot ability: &f10k bank note sent to your stash.");

        private final Color glowColor;
        private final int durationSeconds;
        private final String displayName;
        private final String message;

        AbilityBlockType(Color glowColor, int durationSeconds, String displayName, String message) {
            this.glowColor = glowColor;
            this.durationSeconds = durationSeconds;
            this.displayName = displayName;
            this.message = message;
        }

        private Color glowColor() {
            return this.glowColor;
        }

        private int durationSeconds() {
            return this.durationSeconds;
        }

        private String displayName() {
            return this.displayName;
        }

        private String message() {
            return this.message;
        }
    }

    private record AbilityBlockState(AbilityBlockType type, UUID displayId) {
    }

    private record RiotBoostState(double pointMultiplier, long pointExpiresAt, double expMultiplier, long expExpiresAt) {
    }

    private record BlockPos(String world, int x, int y, int z) {
        static BlockPos of(Block block) {
            return new BlockPos(block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
        }
    }

    private record InventorySnapshot(ItemStack[] contents, ItemStack[] armor, ItemStack offHand) {
    }
}
