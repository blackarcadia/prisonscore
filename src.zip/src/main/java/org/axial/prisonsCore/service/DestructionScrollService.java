package org.axial.prisonsCore.service;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class DestructionScrollService {
    private final PrisonsCore plugin;
    private final org.bukkit.NamespacedKey scrollKey;
    private Material material = Material.INK_SAC;
    private String displayName = "&8&lDestruction Scroll &7({percent}%)";
    private List<String> lore = List.of("&7Drag and Drop onto an item", "&7to remove a random enchant.");

    public DestructionScrollService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.scrollKey = Keys.destructionScroll(plugin);
        this.loadConfig();
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public ItemStack createScroll(int percent) {
        ItemStack stack = new ItemStack(this.material);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        int clamped = Math.max(0, Math.min(100, percent));
        meta.setDisplayName(Text.color(this.displayName.replace("{percent}", String.valueOf(clamped))));
        if (this.lore != null) {
            meta.setLore(this.lore.stream().map(line -> Text.color(line.replace("{percent}", String.valueOf(clamped)))).collect(Collectors.toList()));
        }
        meta.getPersistentDataContainer().set(this.scrollKey, PersistentDataType.INTEGER, clamped);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isDestructionScroll(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.scrollKey, PersistentDataType.INTEGER);
    }

    public int getPercent(ItemStack stack) {
        if (!this.isDestructionScroll(stack)) {
            return 0;
        }
        Integer percent = stack.getItemMeta().getPersistentDataContainer().get(this.scrollKey, PersistentDataType.INTEGER);
        return percent == null ? 0 : Math.max(0, Math.min(100, percent));
    }

    public void reload() {
        this.loadConfig();
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection section = cfg.getConfigurationSection("items.destruction-scroll");
        if (section == null) {
            return;
        }
        Material mat = Material.matchMaterial(section.getString("material", this.material.name()));
        if (mat != null) {
            this.material = mat;
        }
        this.displayName = section.getString("display-name", this.displayName);
        this.lore = section.getStringList("lore");
        if (this.lore == null || this.lore.isEmpty()) {
            this.lore = List.of("&7Drag and Drop onto an item", "&7to remove a random enchant.");
        }
    }
}
