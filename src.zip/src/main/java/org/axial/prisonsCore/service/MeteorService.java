/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.BlockDisplay
 *  org.bukkit.entity.Display
 *  org.bukkit.entity.Display$Billboard
 *  org.bukkit.entity.Display$Brightness
 *  org.bukkit.entity.ItemDisplay
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.TextDisplay
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.util.Transformation
 *  org.bukkit.util.Vector
 *  org.joml.Quaternionf
 *  org.joml.Vector3f
 */
package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.KitService.GKitType;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.service.OreRegenService;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class MeteorService {
    private static final String DEFAULT_METEOR_WORLD = "prisons";
    private static final double GKIT_STAND_HEIGHT_OFFSET = 0.55D;
    private static final int GKIT_BURST_STAND_COUNT = 32;
    private static final int GKIT_BURST_LIFETIME_TICKS = 40;
    private static final long METEOR_LIFETIME_TICKS = 12000L;
    private final PrisonsCore plugin;
    private final PlayerLevelService levelService;
    private final Random random = new Random();
    private final Map<String, Integer> hitsRemaining = new ConcurrentHashMap<String, Integer>();
    private final Map<String, BukkitTask> meteorEffectTasks = new ConcurrentHashMap<String, BukkitTask>();
    private final Map<String, BukkitTask> meteorExpiryTasks = new ConcurrentHashMap<String, BukkitTask>();
    private BukkitTask meteorTask;

    public PrisonsCore getPlugin() {
        return this.plugin;
    }
    private final Set<String> meteorOres = ConcurrentHashMap.newKeySet();
    private final Set<PendingFlare> pendingFlares = ConcurrentHashMap.newKeySet();
    private final Map<String, GKitType> gkitBlocks = new ConcurrentHashMap<String, GKitType>();
    private final Map<String, UUID> gkitBlockOwners = new ConcurrentHashMap<String, UUID>();
    private final Map<String, UUID> gkitBlockStands = new ConcurrentHashMap<String, UUID>();
    private final Map<String, BukkitTask> gkitStandTasks = new ConcurrentHashMap<String, BukkitTask>();
    private OreRegenService oreRegenService;
    private long intervalTicks;
    private long nextMeteorAtMillis = -1L;
    private int fallHeight;
    private double fallTimeSeconds;
    private int minDistance;
    private int maxDistance;
    private int maxHits;
    private String meteorWorldName;
    private static final List<Material> METEOR_ORES = List.of(Material.IRON_ORE, Material.LAPIS_ORE, Material.REDSTONE_ORE, Material.GOLD_ORE, Material.DIAMOND_ORE, Material.EMERALD_ORE);
    private static final Map<GKitType, Material> GKIT_BLOCKS = Map.of(
            GKitType.DEEPFORGE, Material.BROWN_CONCRETE,
            GKitType.IRONHIDE, Material.WHITE_CONCRETE,
            GKitType.STORMSTRIDE, Material.PURPLE_CONCRETE
    );
    private static final Particle.DustOptions METEOR_PURPLE_DUST = new Particle.DustOptions(Color.fromRGB(165, 70, 255), 1.35f);

    public MeteorService(PrisonsCore plugin, PlayerLevelService levelService) {
        this.plugin = plugin;
        this.levelService = levelService;
        this.loadConfig();
    }

    public void setOreRegenService(OreRegenService oreRegenService) {
        this.oreRegenService = oreRegenService;
    }

    private void loadConfig() {
        this.intervalTicks = 1200L;
        this.fallHeight = 70;
        this.fallTimeSeconds = 30.0;
        this.minDistance = 20;
        this.maxDistance = 50;
        this.maxHits = 100;
        this.meteorWorldName = DEFAULT_METEOR_WORLD;
        ConfigurationSection sec = this.plugin.getConfig().getConfigurationSection("meteor");
        if (sec == null) {
            return;
        }
        String configuredWorld = sec.getString("world", this.meteorWorldName);
        this.meteorWorldName = configuredWorld == null || configuredWorld.isBlank() ? DEFAULT_METEOR_WORLD : configuredWorld;
        this.intervalTicks = sec.getLong("interval-ticks", this.intervalTicks);
        this.fallHeight = sec.getInt("fall-height", this.fallHeight);
        this.minDistance = sec.getInt("min-distance", this.minDistance);
        this.maxDistance = sec.getInt("max-distance", this.maxDistance);
        if (sec.contains("fall-time-seconds")) {
            this.fallTimeSeconds = sec.getDouble("fall-time-seconds", this.fallTimeSeconds);
        } else {
            double legacySpeed = sec.getDouble("speed", -1.0);
            if (legacySpeed > 0.0) {
                this.fallTimeSeconds = Math.max(0.05, (double)this.fallHeight / legacySpeed / 20.0);
            }
        }
        this.maxHits = sec.getInt("hits", this.maxHits);
    }

    public void reload() {
        this.loadConfig();
        this.start();
    }

    public void start() {
        this.stopScheduler();
        if (this.intervalTicks <= 0L) {
            this.nextMeteorAtMillis = -1L;
            return;
        }
        final long intervalMillis = this.intervalTicks * 50L;
        this.nextMeteorAtMillis = System.currentTimeMillis() + intervalMillis;
        this.meteorTask = new BukkitRunnable(){

            public void run() {
                MeteorService.this.nextMeteorAtMillis = System.currentTimeMillis() + intervalMillis;
                if (Bukkit.getOnlinePlayers().isEmpty()) {
                    return;
                }
                if (!MeteorService.this.plugin.getFeatureToggleService().isEnabled(FeatureToggleService.Feature.METEORS)) {
                    return;
                }
                Player target = MeteorService.this.getRandomPlayer();
                if (target != null) {
                    MeteorService.this.spawnMeteor(target);
                }
            }
        }.runTaskTimer((Plugin)this.plugin, this.intervalTicks, this.intervalTicks);
    }

    private void stopScheduler() {
        if (this.meteorTask == null) {
            return;
        }
        this.meteorTask.cancel();
        this.meteorTask = null;
    }

    public long getNextMeteorAtMillis() {
        return this.nextMeteorAtMillis;
    }

    public long getTimeUntilNextMeteorMillis() {
        if (this.nextMeteorAtMillis <= 0L) {
            return -1L;
        }
        return Math.max(0L, this.nextMeteorAtMillis - System.currentTimeMillis());
    }

    public String formatDuration(long millis) {
        long safeMillis = Math.max(0L, millis);
        long totalSeconds = safeMillis / 1000L;
        long hours = totalSeconds / 3600L;
        long minutes = totalSeconds % 3600L / 60L;
        long seconds = totalSeconds % 60L;
        if (hours > 0L) {
            return hours + "h " + minutes + "m " + seconds + "s";
        }
        if (minutes > 0L) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }

    public String getNextMeteorTimeText() {
        long remaining = this.getTimeUntilNextMeteorMillis();
        if (this.nextMeteorAtMillis <= 0L || remaining < 0L) {
            return "&cUnknown";
        }
        return "&f" + this.formatDuration(remaining);
    }

    private Player getRandomPlayer() {
        ArrayList<Player> players = new ArrayList<Player>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (!this.isMeteorWorld(player.getWorld())) continue;
            players.add(player);
        }
        if (players.isEmpty()) {
            return null;
        }
        return (Player)players.get(this.random.nextInt(players.size()));
    }

    private void spawnMeteor(Player target) {
        this.spawnMeteorAt(target.getLocation(), false, target);
    }

    public boolean spawnMeteorAt(Location targetLoc) {
        return this.spawnMeteorAt(targetLoc, false, null);
    }

    public boolean spawnMeteorAt(Location targetLoc, boolean fromFlare) {
        return this.spawnMeteorAt(targetLoc, fromFlare, null);
    }

    public boolean spawnMeteorAt(Location targetLoc, final boolean fromFlare, Player flareOwner) {
        if (!this.plugin.getFeatureToggleService().isEnabled(FeatureToggleService.Feature.METEORS)) {
            if (flareOwner != null) {
                this.plugin.getFeatureToggleService().checkEnabled(flareOwner, FeatureToggleService.Feature.METEORS);
            }
            return false;
        }
        if (targetLoc == null) {
            return false;
        }
        World world = targetLoc.getWorld();
        if (world == null) {
            return false;
        }
        if (!this.isMeteorWorld(world)) {
            if (fromFlare && flareOwner != null) {
                flareOwner.sendMessage(Text.color("&cMeteor flares can only be used in the meteor world: &f" + this.meteorWorldName + "&c."));
            }
            return false;
        }
        Location groundTarget = fromFlare ? targetLoc.clone() : this.findSpawnOffset(targetLoc);
        double offsetX = this.random.nextDouble() * 6.0 - 3.0;
        double offsetZ = this.random.nextDouble() * 6.0 - 3.0;
        Location start = groundTarget.clone().add(offsetX, (double)this.fallHeight, offsetZ);
        Vector direction = groundTarget.clone().add(0.0, (double)(-this.fallHeight), 0.0).subtract(start).toVector();
        Block surface = this.findSurfaceBlock(world, groundTarget.getBlockX(), groundTarget.getBlockZ());
        final Location landingSpot = (surface == null ? groundTarget : surface.getLocation().add(0.0, 1.0, 0.0)).add(0.5, 0.0, 0.5);
        Vector travel = landingSpot.clone().subtract(start).toVector();
        double distance = travel.length();
        final int travelTicks = Math.max(1, (int)Math.round(this.fallTimeSeconds * 20.0));
        final Vector step = travel.normalize().multiply(distance / (double)travelTicks);
        Map<String, String> placeholders = Map.of("x", String.valueOf(groundTarget.getBlockX()), "y", String.valueOf(groundTarget.getBlockY()), "z", String.valueOf(groundTarget.getBlockZ()));
        String msg = Lang.msg("meteor.incoming", "&c&lMeteor &7is landing at &f{x} {y} {z}&7!", placeholders);
        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(msg));
        final BlockDisplay display = (BlockDisplay)world.spawn(start, BlockDisplay.class, d -> {
            d.setBlock(Material.GILDED_BLACKSTONE.createBlockData());
            d.setGlowing(true);
            d.setBrightness(new Display.Brightness(15, 15));
            Transformation transform = new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(1.0f, 1.0f, 1.0f), new Quaternionf());
            d.setTransformation(transform);
        });
        ItemDisplay marker = null;
        TextDisplay text = null;
        PendingFlare flareRef = null;
        if (fromFlare) {
            Location markerLoc = groundTarget.clone().add(0.5, 1.0, 0.5);
            marker = (ItemDisplay)world.spawn(markerLoc, ItemDisplay.class, id -> {
                id.setItemStack(new ItemStack(Material.REDSTONE_TORCH));
                id.setGlowing(true);
            });
            Location textLoc = groundTarget.clone().add(0.5, 2.2, 0.5);
            text = (TextDisplay)world.spawn(textLoc, TextDisplay.class, td -> {
                td.setBillboard(Display.Billboard.CENTER);
                td.setShadowed(true);
                td.setDefaultBackground(false);
                td.setBackgroundColor(Color.fromARGB(0));
                td.setBrightness(new Display.Brightness(15, 15));
            });
            flareRef = new PendingFlare(flareOwner == null ? null : flareOwner.getUniqueId(), marker, text, groundTarget.clone());
            this.pendingFlares.add(flareRef);
        }
        final PendingFlare flareFinal = flareRef;
        final ItemDisplay markerRef = marker;
        final TextDisplay textRef = text;
        new BukkitRunnable(){
            float spin = 0.0f;
            int ticks = 0;

            public void run() {
                if (!display.isValid() || fromFlare && (markerRef == null || !markerRef.isValid() || textRef == null || !textRef.isValid())) {
                    this.cancel();
                    MeteorService.this.cleanup(new Display[]{markerRef, textRef});
                    MeteorService.this.removePending(flareFinal, true);
                    return;
                }
                ++this.ticks;
                Location next = display.getLocation().add(step);
                this.spin += 18.0f;
                Transformation current = display.getTransformation();
                Quaternionf left = new Quaternionf().rotateX((float)Math.toRadians(this.spin)).rotateY((float)Math.toRadians((double)this.spin * 0.7)).rotateZ((float)Math.toRadians((double)this.spin * 1.1));
                Transformation updated = new Transformation(current.getTranslation(), left, current.getScale(), current.getRightRotation());
                display.setTransformation(updated);
                if (fromFlare && markerRef != null && textRef != null) {
                    Transformation markerTx = markerRef.getTransformation();
                    Quaternionf markerRot = new Quaternionf().rotateY((float)Math.toRadians(this.spin));
                    markerRef.setTransformation(new Transformation(markerTx.getTranslation(), markerRot, markerTx.getScale(), markerTx.getRightRotation()));
                    double secondsLeft = Math.max(0.0, (double)(travelTicks - this.ticks) / 20.0);
                    textRef.setText(Text.color("&c&lMeteor\n&c" + String.format("%.1fs", secondsLeft)));
                }
                if (this.ticks >= travelTicks) {
                    MeteorService.this.placeMeteor(landingSpot);
                    display.remove();
                    if (fromFlare && textRef != null) {
                        textRef.setText(Text.color("&c&lMeteor\n&c0.0s"));
                    }
                    MeteorService.this.cleanup(new Display[]{markerRef, textRef});
                    MeteorService.this.removePending(flareFinal, false);
                    this.cancel();
                    return;
                }
                display.teleport(next);
            }
        }.runTaskTimer((Plugin)this.plugin, 1L, 1L);
        return true;
    }

    public boolean spawnGKitFlareAt(Location targetLoc, final boolean fromFlare, Player flareOwner, GKitType gkitType) {
        if (gkitType == null) {
            return false;
        }
        if (!this.plugin.getFeatureToggleService().isEnabled(FeatureToggleService.Feature.METEORS)) {
            if (flareOwner != null) {
                this.plugin.getFeatureToggleService().checkEnabled(flareOwner, FeatureToggleService.Feature.METEORS);
            }
            return false;
        }
        if (targetLoc == null) {
            return false;
        }
        World world = targetLoc.getWorld();
        if (world == null) {
            return false;
        }
        if (!this.isMeteorWorld(world)) {
            if (fromFlare && flareOwner != null) {
                flareOwner.sendMessage(Text.color("&cGkit flares can only be used in the meteor world: &f" + this.meteorWorldName + "&c."));
            }
            return false;
        }
        Location groundTarget = fromFlare ? targetLoc.clone() : this.findSpawnOffset(targetLoc);
        double offsetX = this.random.nextDouble() * 6.0 - 3.0;
        double offsetZ = this.random.nextDouble() * 6.0 - 3.0;
        Location start = groundTarget.clone().add(offsetX, (double)this.fallHeight, offsetZ);
        Block surface = this.findSurfaceBlock(world, groundTarget.getBlockX(), groundTarget.getBlockZ());
        final Location landingSpot = (surface == null ? groundTarget : surface.getLocation().add(0.0, 1.0, 0.0)).add(0.5, 0.0, 0.5);
        Vector travel = landingSpot.clone().subtract(start).toVector();
        double distance = travel.length();
        final int travelTicks = Math.max(1, (int)Math.round(this.fallTimeSeconds * 20.0));
        final Vector step = travel.normalize().multiply(distance / (double)travelTicks);
        String msg = Text.color("&b&l" + gkitType.plainName() + " &7flare is landing at &f" + groundTarget.getBlockX() + " " + groundTarget.getBlockY() + " " + groundTarget.getBlockZ() + "&7!");
        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(msg));
        final BlockDisplay display = (BlockDisplay)world.spawn(start, BlockDisplay.class, d -> {
            d.setBlock(GKIT_BLOCKS.get(gkitType).createBlockData());
            d.setGlowing(true);
            d.setBrightness(new Display.Brightness(15, 15));
            Transformation transform = new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(1.0f, 1.0f, 1.0f), new Quaternionf());
            d.setTransformation(transform);
        });
        ItemDisplay marker = null;
        TextDisplay text = null;
        PendingFlare flareRef = null;
        if (fromFlare) {
            Location markerLoc = groundTarget.clone().add(0.5, 1.0, 0.5);
            marker = (ItemDisplay)world.spawn(markerLoc, ItemDisplay.class, id -> {
                id.setItemStack(this.createGKitFlareItem(gkitType, 1));
                id.setGlowing(true);
            });
            Location textLoc = groundTarget.clone().add(0.5, 2.2, 0.5);
            text = (TextDisplay)world.spawn(textLoc, TextDisplay.class, td -> {
                td.setBillboard(Display.Billboard.CENTER);
                td.setShadowed(true);
                td.setDefaultBackground(false);
                td.setBackgroundColor(Color.fromARGB(0));
                td.setBrightness(new Display.Brightness(15, 15));
            });
            flareRef = new PendingFlare(flareOwner == null ? null : flareOwner.getUniqueId(), marker, text, groundTarget.clone());
            this.pendingFlares.add(flareRef);
        }
        final PendingFlare flareFinal = flareRef;
        final ItemDisplay markerRef = marker;
        final TextDisplay textRef = text;
        final String blockKey = this.key(landingSpot.getBlock());
        new BukkitRunnable(){
            float spin = 0.0f;
            int ticks = 0;

            public void run() {
                if (!display.isValid() || fromFlare && (markerRef == null || !markerRef.isValid() || textRef == null || !textRef.isValid())) {
                    this.cancel();
                    MeteorService.this.cleanup(new Display[]{markerRef, textRef});
                    MeteorService.this.removePending(flareFinal, true);
                    return;
                }
                ++this.ticks;
                Location next = display.getLocation().add(step);
                this.spin += 18.0f;
                Transformation current = display.getTransformation();
                Quaternionf left = new Quaternionf().rotateX((float)Math.toRadians(this.spin)).rotateY((float)Math.toRadians((double)this.spin * 0.7)).rotateZ((float)Math.toRadians((double)this.spin * 1.1));
                Transformation updated = new Transformation(current.getTranslation(), left, current.getScale(), current.getRightRotation());
                display.setTransformation(updated);
                if (fromFlare && markerRef != null && textRef != null) {
                    Transformation markerTx = markerRef.getTransformation();
                    Quaternionf markerRot = new Quaternionf().rotateY((float)Math.toRadians(this.spin));
                    markerRef.setTransformation(new Transformation(markerTx.getTranslation(), markerRot, markerTx.getScale(), markerTx.getRightRotation()));
                    double secondsLeft = Math.max(0.0, (double)(travelTicks - this.ticks) / 20.0);
                    textRef.setText(Text.color("&b&l" + gkitType.plainName() + "\n&f" + String.format("%.1fs", secondsLeft)));
                }
                if (this.ticks >= travelTicks) {
                    MeteorService.this.placeGKitBlock(landingSpot, gkitType, blockKey, flareOwner == null ? null : flareOwner.getUniqueId());
                    display.remove();
                    if (fromFlare && textRef != null) {
                        textRef.setText(Text.color("&b&l" + gkitType.plainName() + "\n&f0.0s"));
                    }
                    MeteorService.this.cleanup(new Display[]{markerRef, textRef});
                    MeteorService.this.removePending(flareFinal, false);
                    this.cancel();
                    return;
                }
                display.teleport(next);
            }
        }.runTaskTimer((Plugin)this.plugin, 1L, 1L);
        return true;
    }

    private boolean isMeteorWorld(World world) {
        return world != null && world.getName().equalsIgnoreCase(this.meteorWorldName);
    }

    public String getMeteorWorldName() {
        return this.meteorWorldName;
    }

    public void setMeteorWorld(World world) {
        if (world == null) {
            return;
        }
        this.meteorWorldName = world.getName();
        this.plugin.getConfig().set("meteor.world", this.meteorWorldName);
        this.plugin.saveConfig();
    }

    public Material getOreForPlayer(Player player) {
        if (player == null) {
            return this.getOreForLevel(1);
        }
        return this.getOreForLevel(this.levelService.getLevel(player));
    }

    private void placeMeteor(Location loc) {
        Location base = loc.clone();
        Block block = base.getBlock();
        this.clearPendingRegen(block);
        block.setType(this.resolveMeteorOreMaterial(), false);
        this.hitsRemaining.put(this.key(block), this.maxHits);
        this.startMeteorEffects(block);
        this.scheduleMeteorExpiry(block);
        block.getWorld().spawnParticle(Particle.END_ROD, base.clone().add(0.5, 0.5, 0.5), 30, 0.4, 0.4, 0.4, 0.01);
        block.getWorld().playSound(base, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.8f);
    }

    private void placeGKitBlock(Location loc, GKitType gkitType, String blockKey, UUID owner) {
        if (loc == null || gkitType == null) {
            return;
        }
        Location base = loc.clone();
        Block block = base.getBlock();
        this.removeGKitStand(blockKey);
        this.removeGKitHologram(this.gkitHologramId(block));
        this.clearPendingRegen(block);
        block.setType(GKIT_BLOCKS.get(gkitType), false);
        this.gkitBlocks.put(blockKey, gkitType);
        if (owner != null) {
            this.gkitBlockOwners.put(blockKey, owner);
        }
        this.spawnGKitHologram(base, gkitType);
        this.spawnGKitStand(base, gkitType, blockKey);
        this.spawnGKitBurst(base, gkitType);
        block.getWorld().spawnParticle(Particle.END_ROD, base.clone().add(0.5, 0.5, 0.5), 30, 0.4, 0.4, 0.4, 0.01);
        block.getWorld().playSound(base, Sound.ENTITY_GENERIC_EXPLODE, 1.0f, 0.8f);
    }

    private void spawnGKitHologram(Location base, GKitType gkitType) {
        if (base == null || base.getWorld() == null || gkitType == null || this.plugin.getHologramService() == null) {
            return;
        }
        String id = this.gkitHologramId(base.getBlock());
        this.removeGKitHologram(id);
        Location holoLoc = base.getBlock().getLocation().add(0.5, 2.0, 0.5);
        this.plugin.getHologramService().createHologram(id, holoLoc, List.of("&b&l" + gkitType.plainName() + " Flare"));
    }

    private void spawnGKitStand(Location base, GKitType gkitType, String blockKey) {
        if (base == null || base.getWorld() == null || gkitType == null || blockKey == null) {
            return;
        }
        this.removeGKitStand(blockKey);
        Location standLoc = base.getBlock().getLocation().add(0.5, GKIT_STAND_HEIGHT_OFFSET, 0.5);
        ItemStack helmet = new ItemStack(GKIT_BLOCKS.get(gkitType));
        helmet.addUnsafeEnchantment(Enchantment.UNBREAKING, 1);
        ArmorStand stand = (ArmorStand)base.getWorld().spawn(standLoc, ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setGravity(false);
            as.setSilent(true);
            as.setMarker(false);
            as.setSmall(true);
            as.setArms(false);
            as.setBasePlate(false);
            as.setInvulnerable(true);
            as.setCollidable(false);
            as.setCustomNameVisible(false);
            if (as.getEquipment() != null) {
                as.getEquipment().setHelmet(helmet);
            }
        });
        this.gkitBlockStands.put(blockKey, stand.getUniqueId());
        BukkitTask task = new BukkitRunnable(){
            float yaw = 0.0f;

            public void run() {
                if (!stand.isValid() || !MeteorService.this.gkitBlocks.containsKey(blockKey)) {
                    MeteorService.this.removeGKitStand(blockKey);
                    this.cancel();
                    return;
                }
                this.yaw += 12.0f;
                Location next = stand.getLocation();
                next.setYaw(this.yaw);
                next.setPitch(0.0f);
                stand.teleport(next);
            }
        }.runTaskTimer((Plugin)this.plugin, 1L, 1L);
        this.gkitStandTasks.put(blockKey, task);
    }

    private void spawnGKitBurst(Location base, GKitType gkitType) {
        if (base == null || base.getWorld() == null || gkitType == null) {
            return;
        }
        Material burstMaterial = GKIT_BLOCKS.get(gkitType);
        if (burstMaterial == null) {
            return;
        }
        Location origin = base.clone().add(0.5, GKIT_STAND_HEIGHT_OFFSET, 0.5);
        World world = base.getWorld();
        for (int i = 0; i < GKIT_BURST_STAND_COUNT; ++i) {
            Location spawnLoc = origin.clone();
            ArmorStand burstStand = world.spawn(spawnLoc, ArmorStand.class, as -> {
                as.setInvisible(true);
                as.setGravity(false);
                as.setSilent(true);
                as.setMarker(true);
                as.setSmall(true);
                as.setArms(false);
                as.setBasePlate(false);
                as.setInvulnerable(true);
                as.setCollidable(false);
                as.setCustomNameVisible(false);
                if (as.getEquipment() != null) {
                    as.getEquipment().setHelmet(new ItemStack(burstMaterial));
                }
            });
            double angle = this.random.nextDouble() * Math.PI * 2.0;
            double horizontalSpeed = 0.30 + this.random.nextDouble() * 0.48;
            Vector velocity = new Vector(Math.cos(angle) * horizontalSpeed, 0.42 + this.random.nextDouble() * 0.30, Math.sin(angle) * horizontalSpeed);
            velocity.add(new Vector((this.random.nextDouble() - 0.5) * 0.14, 0.0, (this.random.nextDouble() - 0.5) * 0.14));
            new BukkitRunnable(){
                int lifeTicks = 0;

                public void run() {
                    if (!burstStand.isValid() || ++this.lifeTicks > GKIT_BURST_LIFETIME_TICKS) {
                        burstStand.remove();
                        this.cancel();
                        return;
                    }
                    Location next = burstStand.getLocation().add(velocity);
                    burstStand.teleport(next);
                    velocity.multiply(0.965D);
                    velocity.setY(velocity.getY() - 0.012D);
                }
            }.runTaskTimer((Plugin)MeteorService.this.plugin, 1L, 1L);
        }
    }

    private void removeGKitHologram(String id) {
        if (id == null || this.plugin.getHologramService() == null) {
            return;
        }
        this.plugin.getHologramService().removeHologram(id);
    }

    private void removeGKitStand(String blockKey) {
        if (blockKey == null) {
            return;
        }
        BukkitTask task = this.gkitStandTasks.remove(blockKey);
        if (task != null) {
            task.cancel();
        }
        UUID standId = this.gkitBlockStands.remove(blockKey);
        if (standId == null) {
            return;
        }
        Entity entity = Bukkit.getEntity(standId);
        if (entity != null) {
            entity.remove();
        }
    }

    private String gkitHologramId(Block block) {
        return "gkit-flare-" + this.key(block);
    }

    private void placeOreField(Location center) {
        World world = center.getWorld();
        if (world == null) {
            return;
        }
        int radius = 8;
        int oreIndex = this.random.nextInt(METEOR_ORES.size());
        int baseX = center.getBlockX();
        int baseZ = center.getBlockZ();
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dz = -radius; dz <= radius; ++dz) {
                Block target;
                Block surface;
                if (dx == 0 && dz == 0 || dx * dx + dz * dz > radius * radius || (surface = this.findSurfaceBlock(world, baseX + dx, baseZ + dz)) == null || !(target = surface.getRelative(0, 1, 0)).getType().isAir()) continue;
                Material ore = METEOR_ORES.get(oreIndex % METEOR_ORES.size());
                ++oreIndex;
                this.clearPendingRegen(target);
                target.setType(ore, false);
                String k = this.key(target);
                this.meteorOres.add(k);
                this.scheduleOreExpiry(target, k);
            }
        }
    }

    private Block findSurfaceBlock(World world, int x, int z) {
        for (int y = world.getMaxHeight() - 1; y >= world.getMinHeight(); --y) {
            Block block = world.getBlockAt(x, y, z);
            if (!block.getType().isSolid()) continue;
            return block;
        }
        return null;
    }

    public boolean isMeteorOre(Block block) {
        return block != null && this.meteorOres.contains(this.key(block));
    }

    public void clearMeteorOre(Block block) {
        if (block == null) {
            return;
        }
        this.meteorOres.remove(this.key(block));
    }

    private void scheduleOreExpiry(Block block, String key) {
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            if (!this.meteorOres.contains(key)) {
                return;
            }
            this.meteorOres.remove(key);
            if (block.getType().isAir()) {
                return;
            }
            this.clearPendingRegen(block);
            block.setType(Material.AIR, false);
            block.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, block.getLocation().add(0.5, 0.5, 0.5), 8, 0.2, 0.2, 0.2, 0.01);
        }, 6000L);
    }

    private void scheduleMeteorExpiry(Block block) {
        if (block == null) {
            return;
        }
        String key = this.key(block);
        this.cancelMeteorExpiry(key);
        BukkitTask task = Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            if (!this.hitsRemaining.containsKey(key)) {
                this.cancelMeteorExpiry(key);
                return;
            }
            Block current = this.blockFromKey(key);
            this.hitsRemaining.remove(key);
            this.cancelMeteorExpiry(key);
            this.stopMeteorEffects(key);
            if (current == null || current.getType().isAir()) {
                return;
            }
            this.clearPendingRegen(current);
            current.setType(Material.AIR, false);
            current.getWorld().spawnParticle(Particle.EXPLOSION, current.getLocation().add(0.5, 0.5, 0.5), 12, 0.3, 0.3, 0.3, 0.02);
            current.getWorld().playSound(current.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 0.8f);
        }, METEOR_LIFETIME_TICKS);
        this.meteorExpiryTasks.put(key, task);
    }

    private void cancelMeteorExpiry(String key) {
        if (key == null) {
            return;
        }
        BukkitTask task = this.meteorExpiryTasks.remove(key);
        if (task != null) {
            task.cancel();
        }
    }

    private void cleanup(Display ... displays) {
        for (Display d : displays) {
            if (d == null || !d.isValid()) continue;
            d.remove();
        }
    }

    private void clearPendingRegen(Block block) {
        if (block == null || this.oreRegenService == null) {
            return;
        }
        this.oreRegenService.removePending(block);
    }

    public void despawnAll() {
        Block b;
        for (String k : new ArrayList<String>(this.hitsRemaining.keySet())) {
            b = this.blockFromKey(k);
            if (b == null || b.getType().isAir()) continue;
            this.clearPendingRegen(b);
            b.setType(Material.AIR, false);
            this.cancelMeteorExpiry(k);
            this.stopMeteorEffects(k);
        }
        this.hitsRemaining.clear();
        for (String k : new ArrayList<String>(this.meteorExpiryTasks.keySet())) {
            this.cancelMeteorExpiry(k);
        }
        for (String k : new ArrayList<String>(this.meteorEffectTasks.keySet())) {
            this.stopMeteorEffects(k);
        }
        for (String k : new ArrayList<String>(this.meteorOres)) {
            b = this.blockFromKey(k);
            if (b == null || b.getType().isAir()) continue;
            this.clearPendingRegen(b);
            b.setType(Material.AIR, false);
        }
        this.meteorOres.clear();
        for (String k : new ArrayList<String>(this.gkitBlocks.keySet())) {
            b = this.blockFromKey(k);
            this.removeGKitStand(k);
            this.removeGKitHologram("gkit-flare-" + k);
            if (b == null || b.getType().isAir()) continue;
            this.clearPendingRegen(b);
            b.setType(Material.AIR, false);
        }
        this.gkitBlocks.clear();
        this.gkitBlockOwners.clear();
        this.gkitBlockStands.clear();
        for (PendingFlare flare : new ArrayList<PendingFlare>(this.pendingFlares)) {
            this.cleanup(new Display[]{flare.marker(), flare.text()});
            this.refundFlare(flare);
        }
        this.pendingFlares.clear();
    }

    private Block blockFromKey(String key) {
        int z;
        int y;
        int x;
        UUID worldId;
        String[] parts = key.split(":");
        if (parts.length != 4) {
            return null;
        }
        try {
            worldId = UUID.fromString(parts[0]);
        }
        catch (IllegalArgumentException e) {
            return null;
        }
        World world = Bukkit.getWorld((UUID)worldId);
        if (world == null) {
            return null;
        }
        try {
            x = Integer.parseInt(parts[1]);
            y = Integer.parseInt(parts[2]);
            z = Integer.parseInt(parts[3]);
        }
        catch (NumberFormatException e) {
            return null;
        }
        return world.getBlockAt(x, y, z);
    }

    private void removePending(PendingFlare flare, boolean refund) {
        if (flare == null) {
            return;
        }
        if (this.pendingFlares.remove(flare) && refund) {
            this.refundFlare(flare);
        }
    }

    private void refundFlare(PendingFlare flare) {
        Player p;
        ItemStack flareItem = this.createFlare(1);
        if (flare.owner() != null && (p = Bukkit.getPlayer((UUID)flare.owner())) != null && p.isOnline()) {
            p.getInventory().addItem(new ItemStack[]{flareItem});
            return;
        }
        Location drop = flare.location();
        World w = drop.getWorld();
        if (w != null) {
            w.dropItem(drop, flareItem);
        }
    }

    private Location findSpawnOffset(Location targetLoc) {
        World world = targetLoc.getWorld();
        if (world == null) {
            return targetLoc.clone();
        }
        int i = 0;
        if (i < 10) {
            double angle = this.random.nextDouble() * Math.PI * 2.0;
            double radius = (double)this.minDistance + (double)(this.maxDistance - this.minDistance) * this.random.nextDouble();
            double dx = Math.cos(angle) * radius;
            double dz = Math.sin(angle) * radius;
            Location attempt = targetLoc.clone().add(dx, 0.0, dz);
            return attempt;
        }
        return targetLoc.clone();
    }

    public boolean isMeteorBlock(Block block) {
        return block != null && this.hitsRemaining.containsKey(this.key(block));
    }

    public boolean isGKitBlock(Block block) {
        return block != null && this.gkitBlocks.containsKey(this.key(block));
    }

    public GKitType getGKitBlockType(Block block) {
        if (block == null) {
            return null;
        }
        return this.gkitBlocks.get(this.key(block));
    }

    public boolean canMineGKitBlock(Block block, Player player) {
        if (block == null || player == null) {
            return false;
        }
        String key = this.key(block);
        UUID owner = this.gkitBlockOwners.get(key);
        return owner == null || owner.equals(player.getUniqueId()) || player.hasPermission("prisons.gkit.admin");
    }

    public int hit(Block block) {
        String key = this.key(block);
        int remaining = this.hitsRemaining.getOrDefault(key, 0);
        if (remaining <= 0) {
            return 0;
        }
        if (--remaining <= 0) {
            this.hitsRemaining.remove(key);
            return 0;
        }
        this.hitsRemaining.put(key, remaining);
        return remaining;
    }

    public void clear(Block block) {
        String key = this.key(block);
        this.hitsRemaining.remove(key);
        this.cancelMeteorExpiry(key);
        this.stopMeteorEffects(key);
    }

    public boolean handleGKitBlockBreak(Block block, Player player) {
        if (block == null) {
            return false;
        }
        String key = this.key(block);
        if (!this.canMineGKitBlock(block, player)) {
            if (player != null) {
                player.sendMessage(Text.color("&cYou do not own this Gkit Flare."));
            }
            return false;
        }
        GKitType type = this.gkitBlocks.remove(key);
        if (type == null) {
            return false;
        }
        this.gkitBlockOwners.remove(key);
        this.removeGKitStand(key);
        this.removeGKitHologram(this.gkitHologramId(block));
        this.clearPendingRegen(block);
        block.setType(Material.AIR, false);
        if (player != null) {
            this.giveGKitToken(player, type);
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        }
        return true;
    }

    public int getMeteorOreCount(Block block) {
        if (block == null) {
            return 0;
        }
        return this.hitsRemaining.getOrDefault(this.key(block), 0);
    }

    public ItemStack createGKitFlareItem(GKitType gkitType, int amount) {
        if (gkitType == null) {
            return null;
        }
        ItemStack item = new ItemStack(Material.REDSTONE_TORCH, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String displayName = switch (gkitType) {
                case DEEPFORGE -> "&3&lDeep Forge &3Gkit Flare";
                case IRONHIDE -> "&b&lIronhide &bGkit Flare";
                case STORMSTRIDE -> "&9&lStormstride &9Gkit Flare";
            };
            meta.setDisplayName(Text.color(displayName));
            meta.setLore(List.of(
                    Text.color("&7Spawns a Gkit Meteor to fall from the sky!"),
                    "",
                    Text.color("&c&lDrops the Gkit Gem 100% of the time.")
            ));
            meta.getPersistentDataContainer().set(Keys.gkitFlareType(this.plugin), PersistentDataType.STRING, gkitType.id());
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isGKitFlare(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(Keys.gkitFlareType(this.plugin), PersistentDataType.STRING);
    }

    public GKitType getGKitFlareType(ItemStack item) {
        if (!this.isGKitFlare(item)) {
            return null;
        }
        String id = item.getItemMeta().getPersistentDataContainer().get(Keys.gkitFlareType(this.plugin), PersistentDataType.STRING);
        if (id == null) {
            return null;
        }
        try {
            return GKitType.valueOf(id.toUpperCase());
        }
        catch (IllegalArgumentException illegalArgumentException) {
            return null;
        }
    }

    private void giveGKitToken(Player player, GKitType type) {
        if (player == null || type == null || this.plugin.getKitService() == null) {
            return;
        }
        ItemStack token = this.plugin.getKitService().createGKitToken(type);
        if (token == null) {
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(token);
        for (ItemStack stack : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), stack);
        }
    }

    public Material getOreForLevel(int level) {
        if (level < 20) {
            return Material.COAL_ORE;
        }
        if (level < 30) {
            return Material.IRON_ORE;
        }
        if (level < 40) {
            return Material.LAPIS_ORE;
        }
        if (level < 60) {
            return Material.GOLD_ORE;
        }
        if (level < 80) {
            return Material.REDSTONE_ORE;
        }
        if (level < 90) {
            return Material.DIAMOND_ORE;
        }
        return Material.EMERALD_ORE;
    }

    private Material resolveMeteorOreMaterial() {
        Material quartz = Material.matchMaterial("QUARTZ_ORE");
        return quartz != null ? quartz : Material.NETHER_QUARTZ_ORE;
    }

    private void startMeteorEffects(Block block) {
        if (block == null || block.getWorld() == null) {
            return;
        }
        String key = this.key(block);
        this.stopMeteorEffects(key);
        BukkitTask task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, new Runnable(){
            private int ticks;

            @Override
            public void run() {
                Block current = MeteorService.this.blockFromKey(key);
                if (current == null || current.getType().isAir() || !MeteorService.this.isMeteorBlock(current)) {
                    MeteorService.this.stopMeteorEffects(key);
                    return;
                }
                World world = current.getWorld();
                if (world == null) {
                    MeteorService.this.stopMeteorEffects(key);
                    return;
                }
                ++this.ticks;
                Location center = current.getLocation().add(0.5, 0.5, 0.5);
                world.spawnParticle(Particle.DUST, center, 10, 0.18D, 0.24D, 0.18D, 0.0D, METEOR_PURPLE_DUST);
                if (this.ticks % 4 == 0) {
                    Particle witch = MeteorService.this.resolveParticle("SPELL_WITCH");
                    world.spawnParticle(witch, center, 4, 0.22D, 0.3D, 0.22D, 0.0D);
                }
                if (this.ticks % 6 == 0) {
                    Sound slimeAttack = MeteorService.this.resolveSound("ENTITY_SLIME_ATTACK", "SLIME_ATTACK");
                    world.playSound(center, slimeAttack, 0.35f, 0.9f + MeteorService.this.random.nextFloat() * 0.2f);
                }
            }
        }, 20L, 20L);
        this.meteorEffectTasks.put(key, task);
    }

    private void stopMeteorEffects(String key) {
        if (key == null) {
            return;
        }
        BukkitTask task = this.meteorEffectTasks.remove(key);
        if (task != null) {
            task.cancel();
        }
    }

    private Particle resolveParticle(String... candidates) {
        if (candidates == null) {
            return Particle.DUST;
        }
        for (String name : candidates) {
            if (name == null || name.isBlank()) {
                continue;
            }
            try {
                return Particle.valueOf(name);
            }
            catch (IllegalArgumentException ignored) {
            }
        }
        return Particle.DUST;
    }

    private Sound resolveSound(String... candidates) {
        if (candidates == null) {
            return Sound.BLOCK_SLIME_BLOCK_HIT;
        }
        for (String name : candidates) {
            if (name == null || name.isBlank()) {
                continue;
            }
            try {
                return Sound.valueOf(name);
            }
            catch (IllegalArgumentException ignored) {
            }
        }
        return Sound.BLOCK_SLIME_BLOCK_HIT;
    }

    public ItemStack createFlare(int amount) {
        ItemStack item = new ItemStack(Material.REDSTONE_TORCH, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&dMeteor Flare"));
            meta.setLore(List.of(Text.color("&7Right-click to call a meteor.")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private String key(Block block) {
        Location l = block.getLocation();
        return String.valueOf(l.getWorld().getUID()) + ":" + l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }

    private record PendingFlare(UUID owner, ItemDisplay marker, TextDisplay text, Location location) {
    }
}
