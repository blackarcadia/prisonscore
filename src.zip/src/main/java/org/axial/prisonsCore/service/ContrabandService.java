package org.axial.prisonsCore.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.cell.guard.CellGuardService;
import org.axial.prisonsCore.cell.guard.CellGuardTier;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.skins.skin.SkinManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class ContrabandService {
    private final PrisonsCore plugin;
    private final NamespacedKey contrabandMarkerKey;
    private final NamespacedKey contrabandTypeKey;
    private final NamespacedKey contrabandTierKey;
    private final EnergyItemService energyItemService;
    private final ShardService shardService;
    private final ChargeOrbService chargeOrbService;
    private final SatchelManager satchelManager;
    private final EconomyService economyService;
    private final BankNoteService bankNoteService;
    private final CellGuardService cellGuardService;
    private final Map<String, TierDefinition> tiers = new LinkedHashMap<String, TierDefinition>();
    private File file;
    private YamlConfiguration cfg;

    public ContrabandService(PrisonsCore plugin, EnergyItemService energyItemService, ShardService shardService, ChargeOrbService chargeOrbService, SatchelManager satchelManager, EconomyService economyService, BankNoteService bankNoteService, CellGuardService cellGuardService) {
        this.plugin = plugin;
        this.contrabandMarkerKey = Keys.contrabandMarker(plugin);
        this.contrabandTypeKey = Keys.contrabandType(plugin);
        this.contrabandTierKey = Keys.contrabandTier(plugin);
        this.energyItemService = energyItemService;
        this.shardService = shardService;
        this.chargeOrbService = chargeOrbService;
        this.satchelManager = satchelManager;
        this.economyService = economyService;
        this.bankNoteService = bankNoteService;
        this.cellGuardService = cellGuardService;
        this.load();
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public void load() {
        this.file = new File(this.plugin.getDataFolder(), "contraband.yml");
        if (!this.file.exists()) {
            this.plugin.saveResource("contraband.yml", false);
        }
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.tiers.clear();
        ConfigurationSection tiersSection = this.cfg.getConfigurationSection("tiers");
        if (tiersSection == null) {
            return;
        }
        for (String id : tiersSection.getKeys(false)) {
            ConfigurationSection section = tiersSection.getConfigurationSection(id);
            if (section == null) {
                continue;
            }
            Material material = Material.matchMaterial(section.getString("material", "CHEST"));
            if (material == null) {
                material = Material.CHEST;
            }
            String displayName = section.getString("display-name", "&fContraband");
            List<String> lore = section.getStringList("lore");
            ArrayList<RewardDefinition> rewards = new ArrayList<RewardDefinition>();
            ConfigurationSection rewardsSection = section.getConfigurationSection("rewards");
            if (rewardsSection != null) {
                for (String rewardId : rewardsSection.getKeys(false)) {
                    ConfigurationSection reward = rewardsSection.getConfigurationSection(rewardId);
                    if (reward == null) {
                        continue;
                    }
                    RewardType type = RewardType.from(reward.getString("type", "command"));
                    String skinId = reward.getString("skin-id", null);
                    Material rewardMaterial = Material.matchMaterial(reward.getString("material", type == RewardType.ITEM ? "CHEST" : "PAPER"));
                    if (rewardMaterial == null) {
                        rewardMaterial = type == RewardType.ITEM ? Material.CHEST : Material.PAPER;
                    }
                    double weight = reward.getDouble("weight", reward.getDouble("chance", 0.0));
                    if (weight <= 0.0) {
                        continue;
                    }
                    rewards.add(new RewardDefinition(
                            rewardId,
                            type,
                            rewardMaterial,
                            Math.max(1, reward.getInt("amount", 1)),
                            weight,
                            reward.getString("label", "&fReward"),
                            reward.getString("command", ""),
                            reward.getInt("random-min", 0),
                            reward.getInt("random-max", 0),
                            reward.getStringList("lore"),
                            skinId
                    ));
                }
            }
            this.addDefaultScrollRewards(id, rewards);
            this.tiers.put(id.toLowerCase(Locale.ENGLISH), new TierDefinition(id.toLowerCase(Locale.ENGLISH), displayName, material, lore, rewards));
        }
    }

    private void addDefaultScrollRewards(String tierId, ArrayList<RewardDefinition> rewards) {
        if (tierId == null || rewards == null) {
            return;
        }
        String normalized = tierId.toLowerCase(Locale.ENGLISH);
        if (this.hasReward(rewards, "protection_scroll")) {
            // already present
        } else {
            rewards.add(new RewardDefinition(
                    "protection_scroll",
                    RewardType.COMMAND,
                    Material.MAP,
                    1,
                    2.0D,
                    "&f&lProtection Scroll",
                    "protectionscroll give {player_name} 1",
                    0,
                    0,
                    List.of("&7Drag and Drop onto an item to", "&7keep it upon death. The scroll", "&7will be destroyed upon use."),
                    null
            ));
        }
        if (!this.hasReward(rewards, "destruction_scroll")) {
            int min;
            int max;
            switch (normalized) {
                case "basic_cont" -> {
                    min = 5;
                    max = 15;
                }
                case "rare_cont" -> {
                    min = 10;
                    max = 20;
                }
                case "elite_cont" -> {
                    min = 15;
                    max = 25;
                }
                default -> {
                    min = 20;
                    max = 30;
                }
            }
            rewards.add(new RewardDefinition(
                    "destruction_scroll",
                    RewardType.COMMAND,
                    Material.INK_SAC,
                    1,
                    2.0D,
                    "&8&lDestruction Scroll &7({percent}%)",
                    "destructionscroll give {player_name} {random_number} 1",
                    min,
                    max,
                    List.of("&7Drag and Drop onto an item", "&7to remove a random enchant."),
                    null
            ));
        }
    }

    private boolean hasReward(List<RewardDefinition> rewards, String id) {
        if (rewards == null || id == null) {
            return false;
        }
        for (RewardDefinition reward : rewards) {
            if (reward != null && id.equalsIgnoreCase(reward.id)) {
                return true;
            }
        }
        return false;
    }

    public void reload() {
        this.load();
    }

    public boolean hasTier(String id) {
        return this.getTier(id) != null;
    }

    public List<String> tierIds() {
        return new ArrayList<String>(this.tiers.keySet());
    }

    public String displayName(String id) {
        TierDefinition tier = this.getTier(id);
        return tier == null ? "&fContraband" : tier.displayName;
    }

    public String menuTitle(String id) {
        TierDefinition tier = this.getTier(id);
        if (tier == null) {
            return "&8Contraband";
        }
        return "&8" + Text.strip(tier.displayName);
    }

    public ItemStack createContraband(String id) {
        TierDefinition tier = this.getTier(id);
        if (tier == null) {
            return null;
        }
        ItemStack stack = new ItemStack(tier.material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(Text.color(tier.displayName));
        ArrayList<String> lore = new ArrayList<String>(this.buildLore(tier));
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(this.contrabandMarkerKey, PersistentDataType.BYTE, (byte)1);
        meta.getPersistentDataContainer().set(this.contrabandTypeKey, PersistentDataType.STRING, this.toContrabandType(tier.id));
        meta.getPersistentDataContainer().set(this.contrabandTierKey, PersistentDataType.STRING, tier.id);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isContraband(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        return item.getItemMeta().getPersistentDataContainer().has(this.contrabandMarkerKey, PersistentDataType.BYTE) || this.getTierId(item) != null;
    }

    public String getTierId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer().get(this.contrabandTierKey, PersistentDataType.STRING);
    }

    public String getContrabandType(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        String type = item.getItemMeta().getPersistentDataContainer().get(this.contrabandTypeKey, PersistentDataType.STRING);
        if (type != null) {
            return type;
        }
        String tierId = this.getTierId(item);
        return tierId == null ? null : this.toContrabandType(tierId);
    }

    public RewardRoll rollReward(String id) {
        TierDefinition tier = this.getTier(id);
        if (tier == null || tier.rewards.isEmpty()) {
            return null;
        }
        double totalWeight = 0.0;
        for (RewardDefinition reward : tier.rewards) {
            totalWeight += reward.weight;
        }
        if (totalWeight <= 0.0) {
            return null;
        }
        double pick = this.plugin.getRandom().nextDouble() * totalWeight;
        double cursor = 0.0;
        for (RewardDefinition reward : tier.rewards) {
            cursor += reward.weight;
            if (pick <= cursor) {
                int randomNumber = reward.resolveRandom(this.plugin);
                return new RewardRoll(tier, reward, randomNumber);
            }
        }
        RewardDefinition fallback = tier.rewards.get(tier.rewards.size() - 1);
        return new RewardRoll(tier, fallback, fallback.resolveRandom(this.plugin));
    }

    public ItemStack previewItem(RewardRoll roll) {
        if (roll == null) {
            return this.namedItem(Material.BARRIER, "&cNo reward", List.of("&7This contraband has no configured rewards."));
        }
        ItemStack item = this.buildPreviewStack(roll.reward, roll.randomNumber);
        if (item != null) {
            return item;
        }
        RewardDefinition reward = roll.reward;
        String range = reward.hasRandomRange() ? "&7Value: &f" + roll.randomNumber : "&7Click to reveal";
        return this.namedItem(reward.material, reward.label, List.of(range));
    }

    public void award(Player player, RewardRoll roll) {
        if (player == null || roll == null) {
            return;
        }
        RewardDefinition reward = roll.reward;
        if (this.isMoneyReward(reward)) {
            ItemStack bankNote = this.bankNoteService.createBankNote(Math.max(1, roll.randomNumber));
            if (this.plugin.getStashService() != null) {
                this.plugin.getStashService().giveOrStash(player, bankNote);
            } else {
                Map<Integer, ItemStack> leftover = player.getInventory().addItem(bankNote);
                for (ItemStack stack : leftover.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), stack);
                }
            }
            return;
        }
        if (reward.type == RewardType.ITEM) {
            ItemStack stack = new ItemStack(reward.material, reward.amount);
            if (this.plugin.getStashService() != null) {
                this.plugin.getStashService().giveOrStash(player, stack);
            } else {
                Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
                for (ItemStack item : leftover.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), item);
                }
            }
            return;
        }
        if (reward.type == RewardType.SKIN) {
            Skin skin = this.resolveSkin(reward.skinId);
            if (skin == null || this.skinManager() == null) {
                this.plugin.getLogger().warning("Skin reward '" + reward.id + "' references unknown skin '" + reward.skinId + "'");
                return;
            }
            ItemStack stack = this.skinManager().createSkinItem(skin);
            if (this.plugin.getStashService() != null) {
                this.plugin.getStashService().giveOrStash(player, stack);
            } else {
                Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
                for (ItemStack item : leftover.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), item);
                }
            }
            return;
        }
        if (reward.command != null && reward.command.toLowerCase(Locale.ENGLISH).startsWith("satchel give ")) {
            String[] parts = reward.command.split("\\s+");
            if (parts.length >= 3) {
                Material material = Material.matchMaterial(parts[2]);
                if (material != null) {
                    ItemStack satchel = this.satchelManager.createSatchel(material);
                    if (satchel != null) {
                        if (this.plugin.getStashService() != null) {
                            this.plugin.getStashService().giveOrStash(player, satchel);
                        } else {
                            Map<Integer, ItemStack> leftover = player.getInventory().addItem(satchel);
                            for (ItemStack item : leftover.values()) {
                                player.getWorld().dropItemNaturally(player.getLocation(), item);
                            }
                        }
                        return;
                    }
                }
            }
        }
        String command = reward.command
                .replace("{player}", player.getName())
                .replace("{player_name}", player.getName())
                .replace("{random_number}", String.valueOf(roll.randomNumber));
        this.plugin.getServer().dispatchCommand(this.plugin.getServer().getConsoleSender(), command);
    }

    public String rewardSummary(RewardRoll roll) {
        if (roll == null) {
            return "&cUnknown reward";
        }
        RewardDefinition reward = roll.reward;
        String label = this.renderRewardLabel(reward, roll.randomNumber);
        if (reward.command != null && reward.command.toLowerCase(Locale.ENGLISH).startsWith("destructionscroll give ")) {
            return label;
        }
        if (reward.hasRandomRange()) {
            if (this.isMoneyReward(reward)) {
                return label + Text.color(" &7x&f$" + String.format(Locale.ENGLISH, "%,d", roll.randomNumber));
            }
            return label + Text.color(" &7x&f" + String.format(Locale.ENGLISH, "%,d", roll.randomNumber));
        }
        if (reward.type == RewardType.ITEM) {
            return label + Text.color(" &7x&f" + String.format(Locale.ENGLISH, "%,d", reward.amount));
        }
        return label;
    }

    public ItemStack tierPreview(String id) {
        ItemStack item = this.createContraband(id);
        if (item != null) {
            return item;
        }
        return this.namedItem(Material.CHEST, "&fContraband", Collections.singletonList("&7Unconfigured contraband tier."));
    }

    private ItemStack namedItem(Material material, String name, List<String> lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Text.color(name));
        if (lore != null && !lore.isEmpty()) {
            ArrayList<String> colored = new ArrayList<String>();
            for (String line : lore) {
                colored.add(Text.color(line));
            }
            meta.setLore(colored);
        }
        item.setItemMeta(meta);
        return item;
    }

    private List<String> buildLore(TierDefinition tier) {
        ArrayList<String> lore = new ArrayList<String>();
        if (tier.lore == null || tier.lore.isEmpty()) {
            lore.add(Text.color("&7Right-click to open contraband."));
            return lore;
        }
        double totalWeight = 0.0;
        for (RewardDefinition reward : tier.rewards) {
            totalWeight += reward.weight;
        }
        for (String line : tier.lore) {
            if ("{rewards}".equalsIgnoreCase(line)) {
                for (RewardDefinition reward : tier.rewards) {
                    lore.add(Text.color(" &8&l* &r" + this.describeRewardForLore(reward) + " &7(" + this.formatChance(reward.weight, totalWeight) + "%)"));
                }
                continue;
            }
            lore.add(Text.color(line));
        }
        return lore;
    }

    private String describeRewardForLore(RewardDefinition reward) {
        if (reward == null) {
            return "&cUnknown reward";
        }
        ItemStack preview = this.buildPreviewStack(reward, reward.previewAmount());
        String displayName = this.loreDisplayName(reward, preview, reward.label);
        if (reward.hasRandomRange()) {
            return displayName + " &7(" + this.formatRewardRange(reward) + "&7)";
        }
        if (reward.type == RewardType.ITEM) {
            return displayName + " &7x" + String.format(Locale.ENGLISH, "%,d", reward.amount);
        }
        return displayName;
    }

    private String formatRewardRange(RewardDefinition reward) {
        if (this.isMoneyReward(reward)) {
            return "&f$" + String.format(Locale.ENGLISH, "%,d", reward.randomMin) + "&7-&f$" + String.format(Locale.ENGLISH, "%,d", reward.randomMax);
        }
        if (this.isPercentReward(reward)) {
            return "&f" + reward.randomMin + "%&7-&f" + reward.randomMax + "%";
        }
        return "&f" + String.format(Locale.ENGLISH, "%,d", reward.randomMin) + "&7-&f" + String.format(Locale.ENGLISH, "%,d", reward.randomMax);
    }

    private String formatChance(double weight, double totalWeight) {
        if (weight <= 0.0 || totalWeight <= 0.0) {
            return "0";
        }
        double percent = weight * 100.0 / totalWeight;
        if (Math.abs(percent - Math.rint(percent)) < 0.05) {
            return String.valueOf((int)Math.round(percent));
        }
        return String.format(Locale.ENGLISH, "%.1f", percent);
    }

    private boolean isMoneyReward(RewardDefinition reward) {
        if (reward == null) {
            return false;
        }
        String id = reward.id == null ? "" : reward.id.toLowerCase(Locale.ENGLISH);
        String command = reward.command == null ? "" : reward.command.toLowerCase(Locale.ENGLISH);
        return id.contains("money") || command.startsWith("eco add ");
    }

    private boolean isPercentReward(RewardDefinition reward) {
        if (reward == null) {
            return false;
        }
        String id = reward.id == null ? "" : reward.id.toLowerCase(Locale.ENGLISH);
        String command = reward.command == null ? "" : reward.command.toLowerCase(Locale.ENGLISH);
        return id.contains("orb") || command.startsWith("chargeorb give ") || command.startsWith("destructionscroll give ");
    }

    private ItemStack buildPreviewStack(RewardDefinition reward, int value) {
        if (reward == null) {
            return null;
        }
        if (reward.type == RewardType.ITEM) {
            ItemStack item = new ItemStack(reward.material, Math.max(1, reward.amount));
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(Text.color(reward.label));
            if (!reward.lore.isEmpty()) {
                ArrayList<String> lore = new ArrayList<String>();
                for (String line : reward.lore) {
                    lore.add(Text.color(line));
                }
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
            return item;
        }
        if (reward.type == RewardType.SKIN) {
            Skin skin = this.resolveSkin(reward.skinId);
            if (skin != null && this.skinManager() != null) {
                return this.skinManager().createSkinItem(skin);
            }
            return this.namedItem(Material.BARRIER, reward.label, List.of("&cSkin unavailable."));
        }
        String command = reward.command == null ? "" : reward.command.toLowerCase(Locale.ENGLISH);
        if (command.startsWith("energy give ")) {
            return this.energyItemService.createEnergyItem(Math.max(1, value));
        }
        if (command.startsWith("eco add ")) {
            return this.bankNoteService.createBankNote(Math.max(1, value));
        }
        if (command.startsWith("fragment give ")) {
            String[] parts = reward.command.split("\\s+");
            if (parts.length >= 3) {
                try {
                    ShardService.Tier tier = ShardService.Tier.valueOf(parts[2].toUpperCase(Locale.ENGLISH));
                    ItemStack shard = this.shardService.createShard(tier);
                    shard.setAmount(Math.max(1, Math.min(shard.getMaxStackSize(), value)));
                    return shard;
                }
                catch (IllegalArgumentException ignored) {
                    return null;
                }
            }
        }
        if (command.startsWith("chargeorb give ")) {
            return this.chargeOrbService.createOrb(Math.max(1, value));
        }
        if (command.startsWith("destructionscroll give ")) {
            return this.plugin.getDestructionScrollService() == null ? null : this.plugin.getDestructionScrollService().createScroll(Math.max(1, value));
        }
        if (command.startsWith("protectionscroll give ")) {
            return this.plugin.getProtectionScrollService() == null ? null : this.plugin.getProtectionScrollService().createScroll();
        }
        if (command.startsWith("satchel give ")) {
            String[] parts = reward.command.split("\\s+");
            if (parts.length >= 3) {
                Material material = Material.matchMaterial(parts[2]);
                if (material != null) {
                    return this.satchelManager.createSatchel(material);
                }
            }
        }
        if (command.startsWith("cell guard give ")) {
            String[] parts = reward.command.split("\\s+");
            if (parts.length >= 4) {
                try {
                    CellGuardTier tier = CellGuardTier.valueOf(parts[3].toUpperCase(Locale.ENGLISH));
                    return this.cellGuardService == null ? null : this.cellGuardService.createGuardAnchor(tier, Math.max(1, reward.amount));
                }
                catch (IllegalArgumentException ignored) {
                    return null;
                }
            }
        }
        if (command.startsWith("masks give ")) {
            String[] parts = reward.command.split("\\s+");
            if (parts.length >= 4 && this.plugin.getMaskModule() != null && this.plugin.getMaskModule().getMaskManager() != null) {
                return this.plugin.getMaskModule().getMaskManager().createMaskItem(parts[3]);
            }
        }
        return null;
    }

    private String extractDisplayName(ItemStack item, String fallback) {
        if (item != null && item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            return item.getItemMeta().getDisplayName();
        }
        return fallback;
    }

    private String loreDisplayName(RewardDefinition reward, ItemStack item, String fallback) {
        String displayName = this.extractDisplayName(item, fallback);
        if (this.isMoneyReward(reward)) {
            return Text.color("&a&lBank Note");
        }
        if (this.isEnergyReward(reward)) {
            return Text.color("&d&lRaw Charge");
        }
        if (this.isPercentReward(reward)) {
            return Text.color("&6&lCharge Orb");
        }
        return displayName;
    }

    private String renderRewardLabel(RewardDefinition reward, int value) {
        if (reward == null) {
            return "";
        }
        String label = reward.label == null ? "" : reward.label;
        if (label.contains("{percent}")) {
            label = label.replace("{percent}", String.valueOf(value));
        }
        return Text.color(label);
    }

    private boolean isEnergyReward(RewardDefinition reward) {
        if (reward == null) {
            return false;
        }
        String id = reward.id == null ? "" : reward.id.toLowerCase(Locale.ENGLISH);
        String command = reward.command == null ? "" : reward.command.toLowerCase(Locale.ENGLISH);
        return id.contains("charge") && !id.contains("orb") || command.startsWith("energy give ");
    }

    private SkinManager skinManager() {
        return this.plugin.getAxialSkinsModule() == null ? null : this.plugin.getAxialSkinsModule().skinManager();
    }

    private Skin resolveSkin(String skinId) {
        SkinManager manager = this.skinManager();
        if (manager == null || skinId == null) {
            return null;
        }
        return manager.get(skinId).orElse(null);
    }

    private String toContrabandType(String tierId) {
        if (tierId == null || tierId.isEmpty()) {
            return "UNKNOWN";
        }
        String normalized = tierId.toLowerCase(Locale.ENGLISH);
        if (normalized.endsWith("_cont")) {
            normalized = normalized.substring(0, normalized.length() - 5);
        }
        return normalized.toUpperCase(Locale.ENGLISH);
    }

    private TierDefinition getTier(String id) {
        if (id == null) {
            return null;
        }
        return this.tiers.get(id.toLowerCase(Locale.ENGLISH));
    }

    private enum RewardType {
        ITEM,
        SKIN,
        COMMAND;

        private static RewardType from(String raw) {
            if (raw == null) {
                return COMMAND;
            }
            try {
                return RewardType.valueOf(raw.toUpperCase(Locale.ENGLISH));
            }
            catch (IllegalArgumentException ignored) {
                return COMMAND;
            }
        }
    }

    private static class TierDefinition {
        private final String id;
        private final String displayName;
        private final Material material;
        private final List<String> lore;
        private final List<RewardDefinition> rewards;

        private TierDefinition(String id, String displayName, Material material, List<String> lore, List<RewardDefinition> rewards) {
            this.id = id;
            this.displayName = displayName;
            this.material = material;
            this.lore = lore == null ? List.of("&7Right-click to open.") : lore;
            this.rewards = rewards;
        }
    }

    private static class RewardDefinition {
        private final String id;
        private final RewardType type;
        private final Material material;
        private final int amount;
        private final double weight;
        private final String label;
        private final String command;
        private final int randomMin;
        private final int randomMax;
        private final List<String> lore;
        private final String skinId;

        private RewardDefinition(String id, RewardType type, Material material, int amount, double weight, String label, String command, int randomMin, int randomMax, List<String> lore, String skinId) {
            this.id = id;
            this.type = type;
            this.material = material;
            this.amount = amount;
            this.weight = weight;
            this.label = label;
            this.command = command == null ? "" : command;
            this.randomMin = randomMin;
            this.randomMax = randomMax;
            this.lore = lore == null ? List.of() : lore;
            this.skinId = skinId;
        }

        private boolean hasRandomRange() {
            return this.randomMax > this.randomMin;
        }

        private int resolveRandom(PrisonsCore plugin) {
            if (!this.hasRandomRange()) {
                return this.randomMax > 0 ? this.randomMax : this.amount;
            }
            return this.randomMin + plugin.getRandom().nextInt(this.randomMax - this.randomMin + 1);
        }

        private int previewAmount() {
            if (this.hasRandomRange()) {
                return this.randomMax;
            }
            return this.amount;
        }
    }

    public static class RewardRoll {
        private final String tierId;
        private final RewardDefinition reward;
        private final int randomNumber;
        private final String displayName;

        private RewardRoll(TierDefinition tier, RewardDefinition reward, int randomNumber) {
            this.tierId = tier.id;
            this.reward = reward;
            this.randomNumber = randomNumber;
            this.displayName = tier.displayName;
        }

        public String tierId() {
            return this.tierId;
        }

        public int randomNumber() {
            return this.randomNumber;
        }

        public String displayName() {
            return this.displayName;
        }
    }
}
