/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.PickaxeType;
import org.axial.prisonsCore.service.ChargeOrbService;
import org.axial.prisonsCore.service.EnergyItemService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class ShardService {
    private final PrisonsCore plugin;
    private final NamespacedKey fragmentKey;
    private final NamespacedKey legacyShardKey;
    private final NamespacedKey rewardWeightKey;
    private final PickaxeManager pickaxeManager;
    private final EnergyItemService energyItemService;
    private final ChargeOrbService chargeOrbService;
    private File file;
    private YamlConfiguration cfg;
    private final Map<Tier, Double> dropChances = new EnumMap<Tier, Double>(Tier.class);
    private final Map<Tier, String> displayNames = new EnumMap<Tier, String>(Tier.class);
    private final Map<Tier, List<String>> lores = new EnumMap<Tier, List<String>>(Tier.class);
    private final Map<Tier, List<WeightedReward>> weightedRewards = new EnumMap<Tier, List<WeightedReward>>(Tier.class);

    public ShardService(PrisonsCore plugin, PickaxeManager pickaxeManager, EnergyItemService energyItemService, ChargeOrbService chargeOrbService) {
        this.plugin = plugin;
        this.fragmentKey = new NamespacedKey((Plugin)plugin, "fragment-tier");
        this.legacyShardKey = new NamespacedKey((Plugin)plugin, "shard-tier");
        this.rewardWeightKey = new NamespacedKey((Plugin)plugin, "fragment-reward-weight");
        this.pickaxeManager = pickaxeManager;
        this.energyItemService = energyItemService;
        this.chargeOrbService = chargeOrbService;
        this.load();
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public void load() {
        this.dropChances.clear();
        this.displayNames.clear();
        this.lores.clear();
        this.weightedRewards.clear();
        this.file = new File(this.plugin.getDataFolder(), "fragments.yml");
        File legacy = new File(this.plugin.getDataFolder(), "shards.yml");
        if (!this.file.exists()) {
            if (legacy.exists()) {
                legacy.renameTo(this.file);
            } else {
                this.plugin.saveResource("fragments.yml", false);
            }
        }
        this.cfg = YamlConfiguration.loadConfiguration((File)this.file);
        for (Tier t : Tier.values()) {
            this.dropChances.put(t, this.cfg.getDouble("drop-chances." + t.name(), 0.0));
            if (!this.cfg.isList("rewards." + t.name())) {
                this.cfg.set("rewards." + t.name(), new ArrayList());
            }
            this.displayNames.put(t, this.cfg.getString("item." + t.name() + ".name", t.display()));
            List<String> loreList = this.cfg.getStringList("item." + t.name() + ".lore");
            if (loreList == null || loreList.isEmpty()) {
                loreList = List.of("&7Right-click to open fragment");
            }
            this.lores.put(t, loreList);
        }
        this.ensureDefaultRewards();
        for (Tier t : Tier.values()) {
            this.weightedRewards.put(t, this.loadWeightedRewards(t));
        }
        this.save();
    }

    public void reload() {
        this.load();
    }

    public void save() {
        this.sanitizeRewards();
        try {
            this.cfg.save(this.file);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save fragments.yml: " + e.getMessage());
        }
    }

    public ItemStack createShard(Tier tier) {
        ItemStack item = new ItemStack(tier.material());
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Text.color(this.displayNames.getOrDefault((Object)tier, tier.display())));
        meta.getPersistentDataContainer().set(this.fragmentKey, PersistentDataType.STRING, tier.name());
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        ArrayList<String> lore = new ArrayList<String>();
        for (String line : this.lores.getOrDefault((Object)tier, List.of("&7Right-click to open fragment"))) {
            if ("{rewards}".equalsIgnoreCase(line)) {
                double totalWeight = this.totalWeight(tier);
                for (WeightedReward reward : this.weightedRewards.getOrDefault(tier, List.of())) {
                    lore.add(Text.color(" &8&l* &r" + this.describeRewardForLore(reward) + " &7(" + this.formatChance(reward.weight, totalWeight) + "%)"));
                }
                continue;
            }
            lore.add(Text.color(line));
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public boolean isShard(ItemStack item) {
        return this.getTier(item) != null;
    }

    public Tier getTier(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        String s = (String)item.getItemMeta().getPersistentDataContainer().get(this.fragmentKey, PersistentDataType.STRING);
        if (s == null) {
            s = (String)item.getItemMeta().getPersistentDataContainer().get(this.legacyShardKey, PersistentDataType.STRING);
        }
        if (s == null) {
            return null;
        }
        try {
            return Tier.valueOf(s);
        }
        catch (Exception e) {
            return null;
        }
    }

    public List<ItemStack> getRewards(Tier tier) {
        ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        List raw = this.cfg.getList("rewards." + tier.name(), List.of());
        for (Object o : raw) {
            if (!(o instanceof ItemStack)) continue;
            ItemStack stack = (ItemStack)o;
            list.add(stack.clone());
        }
        return list;
    }

    public void addReward(Tier tier, ItemStack stack) {
        List<ItemStack> list = this.getRewards(tier);
        list.add(stack.clone());
        this.cfg.set("rewards." + tier.name(), list);
        this.save();
    }

    public ItemStack rollReward(Tier tier) {
        List<ItemStack> rewards = this.getRewards(tier);
        if (rewards.isEmpty()) {
            return null;
        }
        return rewards.get(this.plugin.getRandom().nextInt(rewards.size())).clone();
    }

    public String getDisplayName(Tier tier) {
        if (tier == null) {
            return "&fFragment";
        }
        return this.displayNames.getOrDefault(tier, tier.display());
    }

    public Tier rollDrop(Material blockType) {
        return this.rollDrop(blockType, 1.0D);
    }

    public Tier rollDrop(Material blockType, double bonusMultiplier) {
        if (blockType == null) {
            return null;
        }
        double r = this.plugin.getRandom().nextDouble();
        double boosterMultiplier = this.plugin.getGlobalBoosterService() != null ? this.plugin.getGlobalBoosterService().getShardChanceMultiplier() : 1.0D;
        double multiplier = Math.max(0.0D, bonusMultiplier) * boosterMultiplier;
        switch (blockType) {
            case COAL_ORE: 
            case DEEPSLATE_COAL_ORE: {
                return r < Math.min(1.0D, this.dropChances.getOrDefault((Object)Tier.BASIC, 0.0) * multiplier) ? Tier.BASIC : null;
            }
            case IRON_ORE: 
            case DEEPSLATE_IRON_ORE: 
            case LAPIS_ORE: 
            case DEEPSLATE_LAPIS_ORE: {
                return r < Math.min(1.0D, this.dropChances.getOrDefault((Object)Tier.RARE, 0.0) * multiplier) ? Tier.RARE : null;
            }
            case REDSTONE_ORE: 
            case DEEPSLATE_REDSTONE_ORE: 
            case GOLD_ORE: 
            case DEEPSLATE_GOLD_ORE: {
                return r < Math.min(1.0D, this.dropChances.getOrDefault((Object)Tier.ELITE, 0.0) * multiplier) ? Tier.ELITE : null;
            }
            case DIAMOND_ORE: 
            case DEEPSLATE_DIAMOND_ORE: 
            case EMERALD_ORE: 
            case DEEPSLATE_EMERALD_ORE: {
                return r < Math.min(1.0D, this.dropChances.getOrDefault((Object)Tier.LEGENDARY, 0.0) * multiplier) ? Tier.LEGENDARY : null;
            }
        }
        return null;
    }

    private void ensureDefaultRewards() {
        this.cfg.set("rewards.BASIC", this.basicDefaults());
        this.cfg.set("rewards.RARE", this.rareDefaults());
        this.cfg.set("rewards.ELITE", this.eliteDefaults());
        this.cfg.set("rewards.LEGENDARY", this.legendaryDefaults());
        this.addContrabandReward("BASIC", "basic_cont", 0.1);
        this.addContrabandReward("RARE", "rare_cont", 0.1);
        this.addContrabandReward("ELITE", "elite_cont", 0.1);
        this.addContrabandReward("LEGENDARY", "legendary_cont", 0.1);
    }

    private void addContrabandReward(String tierName, String contrabandId, double weight) {
        if (this.plugin.getContrabandService() == null) {
            return;
        }
        ItemStack contraband = this.plugin.getContrabandService().createContraband(contrabandId);
        if (contraband == null) {
            return;
        }
        ItemMeta meta = contraband.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(this.rewardWeightKey, PersistentDataType.DOUBLE, weight);
            contraband.setItemMeta(meta);
        }
        List<ItemStack> rewards = this.getRewards(Tier.valueOf(tierName));
        rewards.add(contraband);
        this.cfg.set("rewards." + tierName, rewards);
    }

    private ItemStack defaultStack(Material mat, int amount) {
        ItemStack item = new ItemStack(mat, Math.min(amount, 64));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setLore(List.of(Text.color("&7Amount: &f" + amount)));
            item.setItemMeta(meta);
        }
        return item;
    }

    private List<ItemStack> basicDefaults() {
        ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        list.add(this.defaultStack(Material.COAL_ORE, 100));
        list.add(this.defaultStack(Material.COAL_ORE, 200));
        list.add(this.defaultStack(Material.COAL_ORE, 300));
        list.add(this.defaultStack(Material.IRON_ORE, 50));
        list.add(this.defaultStack(Material.IRON_ORE, 70));
        list.add(this.defaultStack(Material.COAL_ORE, 150));
        list.add(this.defaultStack(Material.IRON_ORE, 90));
        list.add(this.energyItemService.createEnergyItem(500));
        list.add(this.energyItemService.createEnergyItem(1000));
        list.add(this.energyItemService.createEnergyItem(1500));
        list.add(this.chargeOrb(1));
        list.add(this.chargeOrb(2));
        list.add(this.extractor());
        list.add(this.chargeOrb(1));
        list.add(this.chargeOrb(2));
        list.add(this.chargeOrb(3));
        return list;
    }

    private List<ItemStack> rareDefaults() {
        ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        list.add(this.defaultStack(Material.IRON_ORE, 100));
        list.add(this.defaultStack(Material.IRON_ORE, 200));
        list.add(this.defaultStack(Material.IRON_ORE, 300));
        list.add(this.defaultStack(Material.LAPIS_ORE, 50));
        list.add(this.defaultStack(Material.LAPIS_ORE, 70));
        list.add(this.defaultStack(Material.LAPIS_ORE, 120));
        list.add(this.defaultStack(Material.IRON_ORE, 150));
        list.add(this.energyItemService.createEnergyItem(2500));
        list.add(this.energyItemService.createEnergyItem(5000));
        list.add(this.energyItemService.createEnergyItem(7500));
        list.add(this.chargeOrb(3));
        list.add(this.chargeOrb(4));
        list.add(this.chargeOrb(5));
        list.add(this.extractor());
        return list;
    }

    private List<ItemStack> eliteDefaults() {
        ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        list.add(this.defaultStack(Material.LAPIS_ORE, 100));
        list.add(this.defaultStack(Material.LAPIS_ORE, 200));
        list.add(this.defaultStack(Material.LAPIS_ORE, 300));
        list.add(this.defaultStack(Material.REDSTONE_ORE, 80));
        list.add(this.defaultStack(Material.REDSTONE_ORE, 100));
        list.add(this.defaultStack(Material.GOLD_ORE, 100));
        list.add(this.defaultStack(Material.GOLD_ORE, 200));
        list.add(this.energyItemService.createEnergyItem(10000));
        list.add(this.energyItemService.createEnergyItem(15000));
        list.add(this.energyItemService.createEnergyItem(20000));
        list.add(this.chargeOrb(5));
        list.add(this.chargeOrb(6));
        list.add(this.chargeOrb(7));
        list.add(this.pickaxe("golden"));
        list.add(this.createShard(Tier.RARE));
        list.add(this.extractor());
        return list;
    }

    private List<ItemStack> legendaryDefaults() {
        ArrayList<ItemStack> list = new ArrayList<ItemStack>();
        list.add(this.defaultStack(Material.GOLD_ORE, 100));
        list.add(this.defaultStack(Material.GOLD_ORE, 200));
        list.add(this.defaultStack(Material.DIAMOND_ORE, 100));
        list.add(this.defaultStack(Material.DIAMOND_ORE, 200));
        list.add(this.defaultStack(Material.DIAMOND_ORE, 300));
        list.add(this.defaultStack(Material.EMERALD_ORE, 100));
        list.add(this.defaultStack(Material.EMERALD_ORE, 200));
        list.add(this.defaultStack(Material.EMERALD_ORE, 300));
        list.add(this.energyItemService.createEnergyItem(25000));
        list.add(this.energyItemService.createEnergyItem(50000));
        list.add(this.energyItemService.createEnergyItem(75000));
        list.add(this.chargeOrb(8));
        list.add(this.chargeOrb(9));
        list.add(this.chargeOrb(10));
        list.add(this.pickaxe("diamond"));
        list.add(this.createShard(Tier.ELITE));
        list.add(this.extractor());
        return list;
    }

    private ItemStack extractor() {
        return this.energyItemService.createExtractorItem();
    }

    private ItemStack chargeOrb(int percent) {
        return this.chargeOrbService.createOrb(percent);
    }

    private ItemStack pickaxe(String id) {
        PickaxeType type = this.pickaxeManager.getType(id);
        if (type == null) {
            return this.defaultStack(Material.BARRIER, 1);
        }
        return this.pickaxeManager.createPickaxe(type, 0);
    }

    private void sanitizeRewards() {
        for (Tier t : Tier.values()) {
            List raw = this.cfg.getList("rewards." + t.name(), List.of());
            ArrayList<ItemStack> cleaned = new ArrayList<ItemStack>();
            for (Object o : raw) {
                if (!(o instanceof ItemStack)) continue;
                ItemStack stack = (ItemStack)o;
                if (stack.getAmount() > 64) {
                    stack.setAmount(64);
                }
                cleaned.add(stack);
            }
            this.cfg.set("rewards." + t.name(), cleaned);
        }
    }

    private List<WeightedReward> loadWeightedRewards(Tier tier) {
        ArrayList<WeightedReward> rewards = new ArrayList<WeightedReward>();
        List raw = this.cfg.getList("rewards." + tier.name(), List.of());
        LinkedHashMap<String, WeightedReward> counts = new LinkedHashMap<String, WeightedReward>();
        for (Object o : raw) {
            if (!(o instanceof ItemStack stack)) {
                continue;
            }
            String key;
            String name;
            int minValue = 0;
            int maxValue = 0;
            RewardKind kind = RewardKind.STANDARD;
            double configuredWeight = 1.0;
            if (stack.hasItemMeta()) {
                Double storedWeight = (Double)stack.getItemMeta().getPersistentDataContainer().get(this.rewardWeightKey, PersistentDataType.DOUBLE);
                if (storedWeight != null && storedWeight > 0.0) {
                    configuredWeight = storedWeight;
                }
            }
            if (this.energyItemService.isEnergyItem(stack)) {
                key = "energy";
                name = "&d&lRaw Charge";
                minValue = this.energyItemService.getAmount(stack);
                maxValue = minValue;
                kind = RewardKind.ENERGY;
            } else if (this.chargeOrbService.isChargeOrb(stack)) {
                key = "charge_orb";
                name = "&6&lCharge Orb";
                minValue = this.chargeOrbService.getPercent(stack);
                maxValue = minValue;
                kind = RewardKind.CHARGE_ORB;
            } else {
                name = this.displayNameOf(stack);
                if (name == null || name.isBlank()) {
                    name = this.prettyName(stack.getType(), stack.getAmount());
                }
                key = "standard:" + name;
            }
            WeightedReward reward = counts.get(key);
            if (reward == null) {
                counts.put(key, new WeightedReward(name, configuredWeight, kind, minValue, maxValue));
                continue;
            }
            reward.weight += configuredWeight;
            if (kind != RewardKind.STANDARD) {
                reward.minValue = reward.minValue <= 0 ? minValue : Math.min(reward.minValue, minValue);
                reward.maxValue = Math.max(reward.maxValue, maxValue);
            }
        }
        rewards.addAll(counts.values());
        return rewards;
    }

    private String describeRewardForLore(WeightedReward reward) {
        if (reward.kind == RewardKind.ENERGY) {
            return reward.displayName + " &7(" + this.formatValueRange(reward.minValue, reward.maxValue, false) + "&7)";
        }
        if (reward.kind == RewardKind.CHARGE_ORB) {
            return reward.displayName + " &7(" + this.formatValueRange(reward.minValue, reward.maxValue, true) + "&7)";
        }
        return reward.displayName;
    }

    private String displayNameOf(ItemStack stack) {
        if (stack == null) {
            return null;
        }
        if (stack.hasItemMeta() && stack.getItemMeta().hasDisplayName()) {
            return stack.getItemMeta().getDisplayName();
        }
        return this.prettyName(stack.getType(), stack.getAmount());
    }

    private String prettyName(Material material, int amount) {
        String base = material == null ? "Reward" : material.name().toLowerCase(Locale.ENGLISH).replace('_', ' ');
        String[] words = base.split(" ");
        StringBuilder builder = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(" ");
            }
            builder.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        if (amount > 1) {
            builder.append(" x").append(amount);
        }
        return "&f" + builder;
    }

    private double totalWeight(Tier tier) {
        double total = 0.0;
        for (WeightedReward reward : this.weightedRewards.getOrDefault(tier, List.of())) {
            total += reward.weight;
        }
        return total;
    }

    private String formatValueRange(int min, int max, boolean percent) {
        if (min <= 0 && max <= 0) {
            return "&f0";
        }
        String minText = this.formatValue(min, percent);
        String maxText = this.formatValue(max, percent);
        if (min == max || max <= 0) {
            return minText;
        }
        return minText + "&7-&f" + maxText;
    }

    private String formatValue(int value, boolean percent) {
        String formatted = String.format(Locale.ENGLISH, "%,d", value);
        if (percent) {
            return "&f" + formatted + "%";
        }
        return "&f" + formatted;
    }

    private String formatChance(double weight, double totalWeight) {
        if (weight <= 0.0 || totalWeight <= 0.0) {
            return "0";
        }
        double percent = weight * 100.0 / totalWeight;
        if (Math.abs(percent - Math.rint(percent)) < 0.05) {
            return String.valueOf((int)Math.round(percent));
        }
        return String.format(Locale.ENGLISH, "%.1f", percent);
    }

    private static class WeightedReward {
        private final String displayName;
        private double weight;
        private final RewardKind kind;
        private int minValue;
        private int maxValue;

        private WeightedReward(String displayName, double weight, RewardKind kind, int minValue, int maxValue) {
            this.displayName = displayName;
            this.weight = weight;
            this.kind = kind;
            this.minValue = minValue;
            this.maxValue = maxValue;
        }
    }

    private static enum RewardKind {
        STANDARD,
        ENERGY,
        CHARGE_ORB;

    }

    public static enum Tier {
        BASIC("&7&lBasic Fragment", Material.QUARTZ),
        RARE("&9&lRare Fragment", Material.QUARTZ),
        ELITE("&d&lElite Fragment", Material.QUARTZ),
        LEGENDARY("&6&lLegendary Fragment", Material.QUARTZ);

        private final String display;
        private final Material material;

        private Tier(String display, Material material) {
            this.display = display;
            this.material = material;
        }

        public String display() {
            return this.display;
        }

        public Material material() {
            return this.material;
        }
    }
}
