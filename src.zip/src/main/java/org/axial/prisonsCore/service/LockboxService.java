package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.gui.LockboxMenu;
import org.axial.prisonsCore.service.CustomBlockService.BlockPos;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class LockboxService implements Listener {
    private static final long DAY_MILLIS = 86_400_000L;
    private static final double TASK_PROGRESS_STEP = 10.0D;
    private static final double DAILY_PROGRESS_STEP = 15.0D;
    private static final List<LockboxTask> TASK_POOL = buildTaskPool();
    private static final Map<String, LockboxTask> TASK_LOOKUP = buildLookup(TASK_POOL);
    private final PrisonsCore plugin;
    private final MeteorService meteorService;
    private final LockboxMenu menu;
    private final File dataFile;
    private final Random random = new Random();
    private final Map<BlockPos, LockboxState> states = new ConcurrentHashMap<BlockPos, LockboxState>();
    private final Map<Material, Boolean> oreCache = new ConcurrentHashMap<Material, Boolean>();
    private final org.bukkit.NamespacedKey snapshotOwnerKey;
    private final org.bukkit.NamespacedKey snapshotProgressKey;
    private final org.bukkit.NamespacedKey snapshotActiveIndexKey;
    private final org.bukkit.NamespacedKey snapshotActiveProgressKey;
    private final org.bukkit.NamespacedKey snapshotActiveDueKey;
    private final org.bukkit.NamespacedKey snapshotDailyDueKey;
    private final org.bukkit.NamespacedKey snapshotTasksKey;
    private int tickTaskId = -1;

    public LockboxService(PrisonsCore plugin, MeteorService meteorService, ContrabandService contrabandService) {
        this.plugin = plugin;
        this.meteorService = meteorService;
        this.dataFile = new File(plugin.getDataFolder(), "lockbox-data.yml");
        this.snapshotOwnerKey = new org.bukkit.NamespacedKey((Plugin)plugin, "lockbox-owner");
        this.snapshotProgressKey = new org.bukkit.NamespacedKey((Plugin)plugin, "lockbox-progress");
        this.snapshotActiveIndexKey = new org.bukkit.NamespacedKey((Plugin)plugin, "lockbox-active-index");
        this.snapshotActiveProgressKey = new org.bukkit.NamespacedKey((Plugin)plugin, "lockbox-active-progress");
        this.snapshotActiveDueKey = new org.bukkit.NamespacedKey((Plugin)plugin, "lockbox-active-due");
        this.snapshotDailyDueKey = new org.bukkit.NamespacedKey((Plugin)plugin, "lockbox-daily-due");
        this.snapshotTasksKey = new org.bukkit.NamespacedKey((Plugin)plugin, "lockbox-tasks");
        this.menu = new LockboxMenu(plugin, this);
        this.loadData();
        this.startTicker();
    }

    public LockboxMenu getMenu() {
        return this.menu;
    }

    public boolean isLockboxId(String id) {
        return id != null && id.equalsIgnoreCase("lockbox");
    }

    public boolean isOwner(BlockPos pos, UUID owner) {
        LockboxState state = this.states.get(pos);
        return state != null && owner != null && owner.equals(state.owner());
    }

    public LockboxState getState(BlockPos pos) {
        return this.states.get(pos);
    }

    public void place(BlockPos pos, Player placer, ItemStack stack) {
        if (pos == null || placer == null) {
            return;
        }
        LockboxSnapshot snapshot = this.readSnapshot(stack);
        LockboxState state = snapshot != null ? LockboxState.fromSnapshot(snapshot) : LockboxState.create(placer.getUniqueId(), this.pickTasks());
        if (state.owner() == null) {
            state.setOwner(placer.getUniqueId());
        }
        state.ensureTimers();
        this.states.put(pos, state);
        this.saveData();
    }

    public ItemStack createDropItem(BlockPos pos, ItemStack template) {
        if (template == null) {
            return null;
        }
        ItemStack item = template.clone();
        LockboxState state = this.states.get(pos);
        if (state == null) {
            return item;
        }
        LockboxSnapshot snapshot = state.snapshot();
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(this.snapshotOwnerKey, PersistentDataType.STRING, snapshot.owner() == null ? "" : snapshot.owner().toString());
            meta.getPersistentDataContainer().set(this.snapshotProgressKey, PersistentDataType.DOUBLE, snapshot.progress());
            meta.getPersistentDataContainer().set(this.snapshotActiveIndexKey, PersistentDataType.INTEGER, snapshot.activeIndex());
            meta.getPersistentDataContainer().set(this.snapshotActiveProgressKey, PersistentDataType.INTEGER, snapshot.activeProgress());
            meta.getPersistentDataContainer().set(this.snapshotActiveDueKey, PersistentDataType.LONG, snapshot.activeDueAt());
            meta.getPersistentDataContainer().set(this.snapshotDailyDueKey, PersistentDataType.LONG, snapshot.nextDailyAwardAt());
            meta.getPersistentDataContainer().set(this.snapshotTasksKey, PersistentDataType.STRING, String.join(",", snapshot.tasks()));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    public LockboxSnapshot readSnapshot(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return null;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return null;
        }
        Double progress = meta.getPersistentDataContainer().get(this.snapshotProgressKey, PersistentDataType.DOUBLE);
        Integer activeIndex = meta.getPersistentDataContainer().get(this.snapshotActiveIndexKey, PersistentDataType.INTEGER);
        Integer activeProgress = meta.getPersistentDataContainer().get(this.snapshotActiveProgressKey, PersistentDataType.INTEGER);
        Long activeDueAt = meta.getPersistentDataContainer().get(this.snapshotActiveDueKey, PersistentDataType.LONG);
        Long nextDailyAt = meta.getPersistentDataContainer().get(this.snapshotDailyDueKey, PersistentDataType.LONG);
        String tasksRaw = meta.getPersistentDataContainer().get(this.snapshotTasksKey, PersistentDataType.STRING);
        if (progress == null || activeIndex == null || activeProgress == null || activeDueAt == null || nextDailyAt == null || tasksRaw == null) {
            return null;
        }
        String ownerRaw = meta.getPersistentDataContainer().get(this.snapshotOwnerKey, PersistentDataType.STRING);
        UUID owner = null;
        if (ownerRaw != null && !ownerRaw.isBlank()) {
            try {
                owner = UUID.fromString(ownerRaw);
            } catch (IllegalArgumentException ignored) {
                owner = null;
            }
        }
        ArrayList<String> tasks = new ArrayList<String>();
        for (String raw : tasksRaw.split(",")) {
            if (raw == null || raw.isBlank()) {
                continue;
            }
            tasks.add(raw.trim().toLowerCase(Locale.ROOT));
        }
        if (tasks.isEmpty()) {
            return null;
        }
        return new LockboxSnapshot(owner, Math.max(0.0D, Math.min(100.0D, progress.doubleValue())), tasks, Math.max(0, activeIndex.intValue()), Math.max(0, activeProgress.intValue()), activeDueAt.longValue(), nextDailyAt.longValue());
    }

    public void remove(BlockPos pos) {
        if (pos == null) {
            return;
        }
        this.states.remove(pos);
        this.saveData();
    }

    public void recordMeteorMine(Player player, Block block) {
        this.forEachOwnedState(player, (pos, state) -> {
            if (state.isCompleted() || state.currentTask() == null) {
                return;
            }
            LockboxTask task = state.currentTask();
            if (task.type() != TaskType.METEOR_BLOCK && task.type() != TaskType.METEOR_ORE) {
                return;
            }
            if (!task.matches(block, this.meteorService)) {
                return;
            }
            this.tryAdvanceProgress(player, pos, state, 1);
        });
    }

    public void recordOreBreak(Player player, Block block) {
        this.forEachOwnedState(player, (pos, state) -> {
            if (state.isCompleted() || state.currentTask() == null) {
                return;
            }
            LockboxTask task = state.currentTask();
            if (task.type() != TaskType.ANY_ORE) {
                return;
            }
            if (!task.matches(block, this.meteorService)) {
                return;
            }
            this.tryAdvanceProgress(player, pos, state, 1);
        });
    }

    public void recordContrabandOpen(Player player, String tierId) {
        if (player == null || tierId == null) {
            return;
        }
        String normalized = tierId.toLowerCase(Locale.ROOT);
        this.forEachOwnedState(player, (pos, state) -> {
            if (state.isCompleted() || state.currentTask() == null) {
                return;
            }
            LockboxTask task = state.currentTask();
            if (task.type() != TaskType.CONTRABAND_OPEN || !normalized.equals(task.contrabandTier())) {
                return;
            }
            this.tryAdvanceProgress(player, pos, state, 1);
        });
    }

    public void openMenu(Player player, BlockPos pos) {
        this.menu.open(player, pos);
    }

    public void refreshMenu(BlockPos pos) {
        this.menu.refresh(pos);
    }

    public String taskText(BlockPos pos) {
        LockboxState state = this.states.get(pos);
        if (state == null || state.isCompleted() || state.currentTask() == null) {
            return "&a&lCompleted";
        }
        LockboxTask task = state.currentTask();
        return "&7" + task.displayName() + " &8(&f" + state.activeProgress() + "&7/&f" + task.required() + "&8)";
    }

    public String progressText(BlockPos pos) {
        LockboxState state = this.states.get(pos);
        return "&7" + this.progressBar(state == null ? 0.0D : state.progress());
    }

    public double progress(BlockPos pos) {
        LockboxState state = this.states.get(pos);
        return state == null ? 0.0D : state.progress();
    }

    public int completedTasks(BlockPos pos) {
        LockboxState state = this.states.get(pos);
        return state == null ? 0 : state.completedTasks();
    }

    public String progressBar(double progress) {
        int filled = Math.max(0, Math.min(20, (int)Math.round(Math.max(0.0D, Math.min(100.0D, progress)) / 5.0D)));
        StringBuilder builder = new StringBuilder(40);
        for (int i = 0; i < filled; ++i) {
            builder.append("&a|");
        }
        for (int i = filled; i < 20; ++i) {
            builder.append("&7|");
        }
        return builder.toString();
    }

    public String formatDuration(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        long days = totalSeconds / 86400L;
        long hours = totalSeconds % 86400L / 3600L;
        long minutes = totalSeconds % 3600L / 60L;
        long seconds = totalSeconds % 60L;
        StringBuilder sb = new StringBuilder();
        if (days > 0L) {
            sb.append(days).append("d ");
        }
        if (hours > 0L || days > 0L) {
            sb.append(hours).append("h ");
        }
        if (minutes > 0L || hours > 0L || days > 0L) {
            sb.append(minutes).append("m ");
        }
        sb.append(seconds).append("s");
        return sb.toString().trim();
    }

    public void shutdown() {
        if (this.tickTaskId != -1) {
            Bukkit.getScheduler().cancelTask(this.tickTaskId);
            this.tickTaskId = -1;
        }
        this.saveData();
    }

    private void startTicker() {
        this.tickTaskId = Bukkit.getScheduler().scheduleSyncRepeatingTask((Plugin)this.plugin, this::tick, 20L, 20L);
    }

    private void tick() {
        boolean changed = false;
        long now = System.currentTimeMillis();
        for (Map.Entry<BlockPos, LockboxState> entry : this.states.entrySet()) {
            LockboxState state = entry.getValue();
            if (state == null || state.isCompleted()) {
                continue;
            }
            boolean stateChanged = state.applyDailyProgress(now) | state.expireTaskIfNeeded(now, this.random);
            if (stateChanged) {
                changed = true;
                this.menu.refresh(entry.getKey());
            }
        }
        if (changed) {
            this.saveData();
        }
    }

    private void tryAdvanceProgress(Player player, BlockPos pos, LockboxState state, int amount) {
        if (player == null || pos == null || state == null || amount <= 0 || state.isCompleted()) {
            return;
        }
        LockboxTask task = state.currentTask();
        if (task == null) {
            return;
        }
        int updated = state.activeProgress() + amount;
        if (updated < task.required()) {
            state.setActiveProgress(updated);
            this.menu.refresh(pos);
            this.saveData();
            return;
        }
        state.setActiveProgress(task.required());
        state.addProgress(TASK_PROGRESS_STEP);
        player.sendTitle(Text.color("&a&lTask Complete"), Text.color("&7Lockbox task complete"), 5, 35, 10);
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.9f, 1.15f);
        if (state.progress() >= 100.0D) {
            state.completeAll();
        } else {
            state.advanceTask(this.random);
        }
        this.menu.refresh(pos);
        this.saveData();
    }

    private void forEachOwnedState(Player player, BiConsumer<BlockPos, LockboxState> consumer) {
        if (player == null || consumer == null) {
            return;
        }
        UUID owner = player.getUniqueId();
        for (Map.Entry<BlockPos, LockboxState> entry : this.states.entrySet()) {
            LockboxState state = entry.getValue();
            if (state == null || !owner.equals(state.owner())) {
                continue;
            }
            consumer.accept(entry.getKey(), state);
        }
    }

    private void loadData() {
        this.states.clear();
        if (!this.dataFile.exists()) {
            return;
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(this.dataFile);
        List<Map<?, ?>> entries = cfg.getMapList("lockboxes");
        for (Map<?, ?> raw : entries) {
            String world = this.stringVal(raw.get("world"));
            Integer x = this.intVal(raw.get("x"));
            Integer y = this.intVal(raw.get("y"));
            Integer z = this.intVal(raw.get("z"));
            if (world == null || x == null || y == null || z == null) {
                continue;
            }
            UUID owner = this.uuidVal(raw.get("owner"));
            Double progress = this.doubleVal(raw.get("progress"));
            Integer activeIndex = this.intVal(raw.get("active-index"));
            Integer activeProgress = this.intVal(raw.get("active-progress"));
            Long activeDue = this.longVal(raw.get("active-due-at"));
            Long nextDaily = this.longVal(raw.get("next-daily-award-at"));
            List<String> tasks = this.stringList(raw.get("tasks"));
            if (tasks.isEmpty()) {
                tasks = this.pickTasks();
            }
            LockboxState state = new LockboxState(owner, tasks, progress == null ? 0.0D : progress.doubleValue(), activeIndex == null ? 0 : activeIndex.intValue(), activeProgress == null ? 0 : activeProgress.intValue(), activeDue == null ? System.currentTimeMillis() + DAY_MILLIS : activeDue.longValue(), nextDaily == null ? System.currentTimeMillis() + DAY_MILLIS : nextDaily.longValue());
            this.states.put(new BlockPos(world, x.intValue(), y.intValue(), z.intValue()), state);
        }
    }

    private void saveData() {
        YamlConfiguration cfg = new YamlConfiguration();
        ArrayList<Map<String, Object>> entries = new ArrayList<Map<String, Object>>();
        for (Map.Entry<BlockPos, LockboxState> entry : this.states.entrySet()) {
            BlockPos pos = entry.getKey();
            LockboxState state = entry.getValue();
            if (pos == null || state == null) {
                continue;
            }
            Map<String, Object> raw = new LinkedHashMap<String, Object>();
            raw.put("world", pos.world());
            raw.put("x", pos.x());
            raw.put("y", pos.y());
            raw.put("z", pos.z());
            raw.put("owner", state.owner() == null ? null : state.owner().toString());
            raw.put("progress", state.progress());
            raw.put("tasks", new ArrayList<String>(state.tasks()));
            raw.put("active-index", state.activeIndex());
            raw.put("active-progress", state.activeProgress());
            raw.put("active-due-at", state.activeDueAt());
            raw.put("next-daily-award-at", state.nextDailyAwardAt());
            entries.add(raw);
        }
        cfg.set("lockboxes", entries);
        try {
            cfg.save(this.dataFile);
        } catch (IOException ex) {
            this.plugin.getLogger().warning("Failed to save lockbox data: " + ex.getMessage());
        }
    }

    private List<String> pickTasks() {
        ArrayList<LockboxTask> pool = new ArrayList<LockboxTask>(TASK_POOL);
        Collections.shuffle(pool, this.random);
        ArrayList<String> out = new ArrayList<String>(10);
        int count = Math.min(10, pool.size());
        for (int i = 0; i < count; ++i) {
            out.add(pool.get(i).id());
        }
        return out;
    }

    private String stringVal(Object value) {
        return value instanceof String ? (String)value : null;
    }

    private Integer intVal(Object value) {
        return value instanceof Number ? ((Number)value).intValue() : null;
    }

    private Long longVal(Object value) {
        return value instanceof Number ? ((Number)value).longValue() : null;
    }

    private Double doubleVal(Object value) {
        return value instanceof Number ? ((Number)value).doubleValue() : null;
    }

    private UUID uuidVal(Object value) {
        String raw = this.stringVal(value);
        if (raw == null || raw.isBlank()) {
            return null;
        }
        try {
            return UUID.fromString(raw);
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private List<String> stringList(Object value) {
        ArrayList<String> out = new ArrayList<String>();
        if (value instanceof List<?> list) {
            for (Object entry : list) {
                String raw = this.stringVal(entry);
                if (raw == null || raw.isBlank()) {
                    continue;
                }
                out.add(raw.trim().toLowerCase(Locale.ROOT));
            }
        }
        return out;
    }

    private static boolean isOre(Material material) {
        return material != null && (material.name().endsWith("_ORE") || material == Material.ANCIENT_DEBRIS);
    }

    private static Map<String, LockboxTask> buildLookup(List<LockboxTask> tasks) {
        Map<String, LockboxTask> lookup = new HashMap<String, LockboxTask>();
        for (LockboxTask task : tasks) {
            lookup.put(task.id().toLowerCase(Locale.ROOT), task);
        }
        return lookup;
    }

    private static List<LockboxTask> buildTaskPool() {
        ArrayList<LockboxTask> tasks = new ArrayList<LockboxTask>();
        tasks.add(new LockboxTask("mine_meteors_5", "&fMine &a5 &fmeteors", TaskType.METEOR_BLOCK, 5, null));
        tasks.add(new LockboxTask("mine_meteors_10", "&fMine &a10 &fmeteors", TaskType.METEOR_BLOCK, 10, null));
        tasks.add(new LockboxTask("mine_meteor_ores_25", "&fBreak &a25 &fmeteor ores", TaskType.METEOR_ORE, 25, null));
        tasks.add(new LockboxTask("mine_ores_100", "&fMine &a100 &fores", TaskType.ANY_ORE, 100, null));
        tasks.add(new LockboxTask("mine_ores_250", "&fMine &a250 &fores", TaskType.ANY_ORE, 250, null));
        tasks.add(new LockboxTask("mine_ores_500", "&fMine &a500 &fores", TaskType.ANY_ORE, 500, null));
        tasks.add(new LockboxTask("mine_ores_1000", "&fMine &a1,000 &fores", TaskType.ANY_ORE, 1000, null));
        tasks.add(new LockboxTask("open_basic_25", "&fOpen &a25 &fbasic contraband", TaskType.CONTRABAND_OPEN, 25, "basic_cont"));
        tasks.add(new LockboxTask("open_rare_20", "&fOpen &a20 &frare contraband", TaskType.CONTRABAND_OPEN, 20, "rare_cont"));
        tasks.add(new LockboxTask("open_elite_15", "&fOpen &a15 &felite contraband", TaskType.CONTRABAND_OPEN, 15, "elite_cont"));
        tasks.add(new LockboxTask("open_legendary_10", "&fOpen &a10 &flegendary contraband", TaskType.CONTRABAND_OPEN, 10, "legendary_cont"));
        tasks.add(new LockboxTask("open_legendary_5", "&fOpen &a5 &flegendary contraband", TaskType.CONTRABAND_OPEN, 5, "legendary_cont"));
        tasks.add(new LockboxTask("open_elite_10", "&fOpen &a10 &felite contraband", TaskType.CONTRABAND_OPEN, 10, "elite_cont"));
        tasks.add(new LockboxTask("open_rare_10", "&fOpen &a10 &frare contraband", TaskType.CONTRABAND_OPEN, 10, "rare_cont"));
        tasks.add(new LockboxTask("open_basic_50", "&fOpen &a50 &fbasic contraband", TaskType.CONTRABAND_OPEN, 50, "basic_cont"));
        return tasks;
    }

    private static LockboxTask lookupTask(String id) {
        if (id == null) {
            return null;
        }
        return TASK_LOOKUP.get(id.toLowerCase(Locale.ROOT));
    }

    public record LockboxSnapshot(UUID owner, double progress, List<String> tasks, int activeIndex, int activeProgress, long activeDueAt, long nextDailyAwardAt) {
    }

    public static final class LockboxState {
        private UUID owner;
        private final List<String> tasks;
        private double progress;
        private int activeIndex;
        private int activeProgress;
        private long activeDueAt;
        private long nextDailyAwardAt;

        private LockboxState(UUID owner, List<String> tasks, double progress, int activeIndex, int activeProgress, long activeDueAt, long nextDailyAwardAt) {
            this.owner = owner;
            this.tasks = new ArrayList<String>(tasks == null ? List.of() : tasks);
            this.progress = Math.max(0.0D, Math.min(100.0D, progress));
            this.activeIndex = Math.max(0, activeIndex);
            this.activeProgress = Math.max(0, activeProgress);
            this.activeDueAt = activeDueAt;
            this.nextDailyAwardAt = nextDailyAwardAt;
            if (this.activeIndex > this.tasks.size()) {
                this.activeIndex = this.tasks.size();
            }
        }

        static LockboxState create(UUID owner, List<String> tasks) {
            long now = System.currentTimeMillis();
            return new LockboxState(owner, tasks, 0.0D, 0, 0, now + DAY_MILLIS, now + DAY_MILLIS);
        }

        static LockboxState fromSnapshot(LockboxSnapshot snapshot) {
            return new LockboxState(snapshot.owner(), snapshot.tasks(), snapshot.progress(), snapshot.activeIndex(), snapshot.activeProgress(), snapshot.activeDueAt(), snapshot.nextDailyAwardAt());
        }

        private void setOwner(UUID owner) {
            this.owner = owner;
        }

        private void setActiveProgress(int activeProgress) {
            this.activeProgress = Math.max(0, activeProgress);
        }

        private void addProgress(double amount) {
            this.progress = Math.max(0.0D, Math.min(100.0D, this.progress + amount));
        }

        private void completeAll() {
            this.progress = 100.0D;
            this.activeIndex = this.tasks.size();
            this.activeProgress = 0;
        }

        private void ensureTimers() {
            long now = System.currentTimeMillis();
            if (this.activeDueAt <= 0L) {
                this.activeDueAt = now + DAY_MILLIS;
            }
            if (this.nextDailyAwardAt <= 0L) {
                this.nextDailyAwardAt = now + DAY_MILLIS;
            }
        }

        private boolean applyDailyProgress(long now) {
            if (this.isCompleted() || now < this.nextDailyAwardAt) {
                return false;
            }
            boolean changed = false;
            while (now >= this.nextDailyAwardAt && !this.isCompleted()) {
                double before = this.progress;
                this.progress = Math.min(100.0D, this.progress + DAILY_PROGRESS_STEP);
                this.nextDailyAwardAt += DAY_MILLIS;
                changed |= before != this.progress;
                if (this.progress >= 100.0D) {
                    this.completeAll();
                }
            }
            return changed;
        }

        private boolean expireTaskIfNeeded(long now, Random random) {
            if (this.isCompleted() || now < this.activeDueAt || this.currentTask() == null) {
                return false;
            }
            LockboxTask replacement = this.pickReplacement(random);
            if (replacement == null) {
                return false;
            }
            if (this.activeIndex < this.tasks.size()) {
                this.tasks.set(this.activeIndex, replacement.id());
            }
            this.activeProgress = 0;
            this.activeDueAt = now + DAY_MILLIS;
            return true;
        }

        private void advanceTask(Random random) {
            if (this.activeIndex + 1 >= this.tasks.size()) {
                this.completeAll();
                return;
            }
            ++this.activeIndex;
            this.activeProgress = 0;
            this.activeDueAt = System.currentTimeMillis() + DAY_MILLIS;
            if (this.currentTask() == null) {
                LockboxTask replacement = this.pickReplacement(random);
                if (replacement != null && this.activeIndex < this.tasks.size()) {
                    this.tasks.set(this.activeIndex, replacement.id());
                }
            }
        }

        private LockboxTask pickReplacement(Random random) {
            ArrayList<LockboxTask> options = new ArrayList<LockboxTask>(TASK_POOL);
            String currentId = this.currentTask() == null ? null : this.currentTask().id();
            options.removeIf(task -> task.id().equals(currentId));
            if (options.isEmpty()) {
                return null;
            }
            return options.get(random.nextInt(options.size()));
        }

        private boolean isCompletedInternal() {
            return this.progress >= 100.0D || this.activeIndex >= this.tasks.size();
        }

        private int completedTasksInternal() {
            int byProgress = (int)Math.floor(this.progress / 10.0D);
            return Math.min(10, Math.max(this.activeIndex, byProgress));
        }

        private LockboxTask currentTaskInternal() {
            if (this.activeIndex < 0 || this.activeIndex >= this.tasks.size()) {
                return null;
            }
            return LockboxService.lookupTask(this.tasks.get(this.activeIndex));
        }

        private LockboxSnapshot snapshot() {
            return new LockboxSnapshot(this.owner, this.progress, new ArrayList<String>(this.tasks), this.activeIndex, this.activeProgress, this.activeDueAt, this.nextDailyAwardAt);
        }

        public UUID owner() {
            return this.owner;
        }

        public List<String> tasks() {
            return this.tasks;
        }

        public double progress() {
            return this.progress;
        }

        public int activeIndex() {
            return this.activeIndex;
        }

        public int activeProgress() {
            return this.activeProgress;
        }

        public long activeDueAt() {
            return this.activeDueAt;
        }

        public long nextDailyAwardAt() {
            return this.nextDailyAwardAt;
        }

        public boolean isCompleted() {
            return this.isCompletedInternal();
        }

        public int completedTasks() {
            return this.completedTasksInternal();
        }

        public LockboxTask currentTask() {
            return this.currentTaskInternal();
        }
    }

    public record LockboxTask(String id, String displayName, TaskType type, int required, String contrabandTier) {
        private boolean matches(Block block, MeteorService meteorService) {
            if (block == null) {
                return false;
            }
            return switch (this.type) {
                case ANY_ORE -> LockboxService.isOre(block.getType());
                case METEOR_BLOCK -> meteorService != null && meteorService.isMeteorBlock(block);
                case METEOR_ORE -> meteorService != null && meteorService.isMeteorOre(block);
                case CONTRABAND_OPEN -> false;
            };
        }
    }

    public enum TaskType {
        ANY_ORE,
        METEOR_BLOCK,
        METEOR_ORE,
        CONTRABAND_OPEN
    }
}
