/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.EnchantRarity;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class EnchantDustService {
    private final PrisonsCore plugin;
    private final NamespacedKey rarityKey;
    private final NamespacedKey percentKey;
    private final NamespacedKey powderKey;
    private final Map<EnchantRarity, DustTemplate> templates = new EnumMap<EnchantRarity, DustTemplate>(EnchantRarity.class);
    private final Map<EnchantRarity, PowderTemplate> powderTemplates = new EnumMap<EnchantRarity, PowderTemplate>(EnchantRarity.class);
    private int powderMin = 1;
    private int powderMax = 25;

    public EnchantDustService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.rarityKey = new NamespacedKey((Plugin)plugin, "dust-rarity");
        this.percentKey = new NamespacedKey((Plugin)plugin, "dust-percent");
        this.powderKey = new NamespacedKey((Plugin)plugin, "dust-powder");
        this.load(plugin);
    }

    public ItemStack createDust(EnchantRarity rarity, int percent) {
        int pct = Math.max(1, Math.min(100, percent));
        DustTemplate tpl = this.templates.getOrDefault((Object)rarity, DustTemplate.defaultFor(rarity));
        ItemStack stack = new ItemStack(tpl.material());
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(Text.color(this.format(tpl.displayName(), rarity, pct)));
        List<String> loreLines = tpl.lore().stream().map(line -> Text.color(this.format((String)line, rarity, pct))).toList();
        meta.setLore(loreLines);
        PersistentDataContainer c = meta.getPersistentDataContainer();
        c.set(this.rarityKey, PersistentDataType.STRING, rarity.name());
        c.set(this.percentKey, PersistentDataType.INTEGER, pct);
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemStack createPowder(EnchantRarity rarity) {
        PowderTemplate tpl = this.powderTemplates.getOrDefault((Object)rarity, PowderTemplate.defaultFor(rarity));
        ItemStack stack = new ItemStack(tpl.material());
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(Text.color(this.format(tpl.displayName(), rarity, 0)));
        List<String> loreLines = tpl.lore().stream().map(line -> Text.color(this.format((String)line, rarity, 0))).toList();
        meta.setLore(loreLines);
        meta.getPersistentDataContainer().set(this.powderKey, PersistentDataType.STRING, rarity.name());
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isDust(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return false;
        }
        PersistentDataContainer c = stack.getItemMeta().getPersistentDataContainer();
        return c.has(this.rarityKey, PersistentDataType.STRING) && c.has(this.percentKey, PersistentDataType.INTEGER);
    }

    public EnchantRarity getRarity(ItemStack stack) {
        if (!this.isDust(stack)) {
            return null;
        }
        String raw = (String)stack.getItemMeta().getPersistentDataContainer().get(this.rarityKey, PersistentDataType.STRING);
        try {
            return EnchantRarity.valueOf(raw);
        }
        catch (Exception e) {
            return null;
        }
    }

    public int getPercent(ItemStack stack) {
        if (!this.isDust(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.percentKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public boolean isPowder(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.powderKey, PersistentDataType.STRING);
    }

    public EnchantRarity getPowderRarity(ItemStack stack) {
        if (!this.isPowder(stack)) {
            return null;
        }
        String raw = (String)stack.getItemMeta().getPersistentDataContainer().get(this.powderKey, PersistentDataType.STRING);
        try {
            return EnchantRarity.valueOf(raw);
        }
        catch (Exception e) {
            return null;
        }
    }

    public ItemStack convertPowderToDust(ItemStack powder) {
        EnchantRarity rarity = this.getPowderRarity(powder);
        if (rarity == null) {
            return null;
        }
        int pct = this.biasedPercent();
        return this.createDust(rarity, pct);
    }

    public void reload(PrisonsCore plugin) {
        this.load(plugin);
    }

    private int biasedPercent() {
        int min = Math.max(1, this.powderMin);
        int max = Math.min(5, this.powderMax);
        int range = max - min + 1;
        int a = ThreadLocalRandom.current().nextInt(range);
        int b = ThreadLocalRandom.current().nextInt(range);
        int c = ThreadLocalRandom.current().nextInt(range);
        int lowBias = Math.min(a, Math.min(b, c));
        return min + lowBias;
    }

    private String colorFor(EnchantRarity rarity) {
        return switch (rarity) {
            case EnchantRarity.BASIC -> "&7";
            case EnchantRarity.UNCOMMON -> "&b";
            case EnchantRarity.UNIQUE -> "&3";
            case EnchantRarity.RARE -> "&a";
            case EnchantRarity.ELITE -> "&e";
            case EnchantRarity.LEGENDARY -> "&6";
        };
    }

    private String format(String raw, EnchantRarity rarity, int pct) {
        return raw.replace("{rarity}", rarity.name()).replace("{rarity_lower}", rarity.name().toLowerCase()).replace("{percent}", String.valueOf(pct));
    }

    private void load(PrisonsCore plugin) {
        this.templates.clear();
        this.powderTemplates.clear();
        File file = new File(plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection sec = cfg.getConfigurationSection("items.enchant-dust");
        ConfigurationSection powderSec = cfg.getConfigurationSection("items.charge-powder");
        this.powderMin = Math.max(1, cfg.getInt("items.charge-powder.percent-min", 1));
        this.powderMax = Math.max(this.powderMin, cfg.getInt("items.charge-powder.percent-max", 25));
        for (EnchantRarity rarity : EnchantRarity.values()) {
            String path = rarity.name().toLowerCase();
            Material mat = Material.GLOWSTONE_DUST;
            Object name = this.colorFor(rarity) + rarity.name() + " Dust &f({percent}%)";
            List<String> lore = List.of("&7Apply to a {rarity_lower} enchant option", "&7to increase success chance by &a{percent}%");
            if (sec != null) {
                Material confMat = Material.matchMaterial((String)sec.getString(path + ".material", "GLOWSTONE_DUST"));
                if (confMat != null) {
                    mat = confMat;
                }
                name = sec.getString(path + ".display-name", (String)name);
                lore = sec.getStringList(path + ".lore");
                if (lore == null || lore.isEmpty()) {
                    lore = List.of("&7Apply to a {rarity_lower} enchant option", "&7to increase success chance by &a{percent}%");
                }
            }
            this.templates.put(rarity, new DustTemplate(mat, (String)name, lore));
            Material pMat = Material.GUNPOWDER;
            Object pName = this.colorFor(rarity) + rarity.name() + " Charge Powder";
            List pLore = List.of("&7Right-click to convert into", "&7a random {rarity_lower} dust.");
            if (powderSec != null) {
                Material confMat = Material.matchMaterial((String)powderSec.getString(path + ".material", "GUNPOWDER"));
                if (confMat != null) {
                    pMat = confMat;
                }
                pName = powderSec.getString(path + ".display-name", (String)pName);
                List loreList = powderSec.getStringList(path + ".lore");
                if (loreList != null && !loreList.isEmpty()) {
                    pLore = loreList;
                }
            }
            this.powderTemplates.put(rarity, new PowderTemplate(pMat, (String)pName, pLore));
        }
    }

    private record DustTemplate(Material material, String displayName, List<String> lore) {
        static DustTemplate defaultFor(EnchantRarity rarity) {
            return new DustTemplate(Material.GLOWSTONE_DUST, switch (rarity) {
                case EnchantRarity.BASIC -> "&7BASIC Dust &f({percent}%)";
                case EnchantRarity.UNCOMMON -> "&bUNCOMMON Dust &f({percent}%)";
                case EnchantRarity.UNIQUE -> "&3UNIQUE Dust &f({percent}%)";
                case EnchantRarity.RARE -> "&aRARE Dust &f({percent}%)";
                case EnchantRarity.ELITE -> "&eELITE Dust &f({percent}%)";
                case EnchantRarity.LEGENDARY -> "&6LEGENDARY Dust &f({percent}%)";
            }, List.of("&7Apply to a {rarity_lower} enchant option", "&7to increase success chance by &a{percent}%"));
        }
    }

    private record PowderTemplate(Material material, String displayName, List<String> lore) {
        static PowderTemplate defaultFor(EnchantRarity rarity) {
            return new PowderTemplate(Material.GUNPOWDER, switch (rarity) {
                case EnchantRarity.BASIC -> "&7Basic Charge Powder";
                case EnchantRarity.UNCOMMON -> "&bUncommon Charge Powder";
                case EnchantRarity.UNIQUE -> "&3Unique Charge Powder";
                case EnchantRarity.RARE -> "&aRare Charge Powder";
                case EnchantRarity.ELITE -> "&eElite Charge Powder";
                case EnchantRarity.LEGENDARY -> "&6Legendary Charge Powder";
            }, List.of("&7Right-click to convert into", "&7a random {rarity_lower} dust."));
        }
    }
}
