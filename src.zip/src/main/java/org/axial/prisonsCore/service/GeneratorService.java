/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.cell.Cell;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.Vector;

public class GeneratorService
implements Listener {
    private static final int LINK_RADIUS = 3;
    private static final int LINK_RADIUS_SQUARED = 9;
    private final PrisonsCore plugin;
    private final Map<BlockPos, GeneratorTier> generators = new ConcurrentHashMap<BlockPos, GeneratorTier>();
    private final Map<BlockPos, ManagedRefined> refinedNodes = new ConcurrentHashMap<BlockPos, ManagedRefined>();
    private final Map<BlockPos, UUID> generatorLabels = new ConcurrentHashMap<BlockPos, UUID>();
    private final NamespacedKey generatorKey;
    private final NamespacedKey refinedKey;
    private final CellService cellService;
    private final FeatureToggleService featureToggleService;

    public GeneratorService(PrisonsCore plugin, CellService cellService, FeatureToggleService featureToggleService) {
        this.plugin = plugin;
        this.cellService = cellService;
        this.featureToggleService = featureToggleService;
        this.generatorKey = new NamespacedKey((Plugin)plugin, "generator-item");
        this.refinedKey = new NamespacedKey((Plugin)plugin, "refined-item");
    }

    public boolean isGeneratedOre(Block block) {
        ManagedRefined node = this.refinedNodes.get(BlockPos.of(block));
        return node != null && node.hitsRemaining > 0;
    }

    public boolean isRefinedBase(Block block) {
        ManagedRefined node = this.refinedNodes.get(BlockPos.of(block));
        return node != null && node.hitsRemaining <= 0 && block.getType() == node.refinedTier.refinedBlock;
    }

    public boolean handleRefinedBaseBroken(Block block, Player player) {
        ManagedRefined node = this.refinedNodes.get(BlockPos.of(block));
        if (node == null || node.hitsRemaining > 0 || block.getType() != node.refinedTier.refinedBlock) {
            return false;
        }
        this.refinedNodes.remove(BlockPos.of(block));
        this.cancelTask(node);
        this.giveOrDrop(player, this.createRefinedItem(node.refinedTier), block.getLocation());
        if (this.cellService != null) {
            this.cellService.unmarkPlayerPlacedBlock(block);
        }
        block.setType(Material.AIR, false);
        return true;
    }

    public void handleGeneratedOreMined(Block block, Player player) {
        ManagedRefined node = this.refinedNodes.get(BlockPos.of(block));
        if (node == null) {
            return;
        }
        if (node.hitsRemaining > 0) {
            --node.hitsRemaining;
        }
        GeneratorTier liveGenerator = node.generatorPos != null ? this.generators.get(node.generatorPos) : null;
        node.generatorTier = liveGenerator;
        if (liveGenerator == null) {
            node.generatorPos = null;
        }
        Block live = this.blockAt(node.location);
        if (live != null) {
            if (node.hitsRemaining > 0 && liveGenerator != null) {
                live.setType(liveGenerator.oreBlock, false);
            } else {
                live.setType(node.refinedTier.refinedBlock, false);
            }
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onPlace(BlockPlaceEvent event) {
        Block block = event.getBlockPlaced();
        Material type = block.getType();
        BlockPos pos = BlockPos.of(block);
        ItemStack hand = event.getItemInHand();
        Player player = event.getPlayer();
        GeneratorTier genTier = GeneratorTier.byGenerator(type);
        RefinedTier refTier = this.resolveRefinedTier(hand, type);
        if (genTier != null && !this.featureToggleService.checkEnabled(player, FeatureToggleService.Feature.GENERATORS)) {
            event.setCancelled(true);
            return;
        }
        if (refTier != null && !this.featureToggleService.checkEnabled(player, FeatureToggleService.Feature.REFINED)) {
            event.setCancelled(true);
            return;
        }
        if (genTier != null || refTier != null) {
            Cell cell = this.cellService.getCellAt(block.getLocation());
            if (cell == null) {
                event.setCancelled(true);
                player.sendMessage(Text.color("&cGenerators and refined ore can only be placed inside a cell."));
                return;
            }
            if (!(player.hasPermission("cells.admin") || cell.isOwned() && this.cellService.hasAccess(cell, player.getUniqueId()))) {
                event.setCancelled(true);
                player.sendMessage(Text.color("&cYou don't have permission to place that here."));
                return;
            }
        }
        if (genTier != null) {
            if (!this.isGeneratorItem(hand, genTier)) {
                return;
            }
            this.generators.put(pos, genTier);
            this.linkNearbyRefined(block, genTier);
            this.spawnLabel(block, genTier);
        } else if (refTier != null) {
            if (!this.isRefinedItem(hand, refTier)) {
                return;
            }
            if (block.getType() != refTier.refinedBlock) {
                block.setType(refTier.refinedBlock, false);
            }
            ManagedRefined node = this.refinedNodes.get(pos);
            if (node != null) {
                return;
            }
            GeneratorNearby nearby = this.findNearbyGenerator(block.getLocation());
            ManagedRefined created = new ManagedRefined(pos, nearby != null ? nearby.tier : null, refTier, nearby != null ? nearby.pos : null);
            this.refinedNodes.put(pos, created);
            if (nearby != null) {
                this.schedule(created);
            }
        }
    }

    private RefinedTier resolveRefinedTier(ItemStack hand, Material type) {
        RefinedTier tier = RefinedTier.byRefined(type);
        if (tier != null) {
            return tier;
        }
        if (hand == null) {
            return null;
        }
        for (RefinedTier candidate : RefinedTier.values()) {
            if (this.isRefinedItem(hand, candidate)) {
                return candidate;
            }
        }
        return null;
    }

    @EventHandler(ignoreCancelled=true)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.LEFT_CLICK_BLOCK && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        Player player = event.getPlayer();
        BlockPos pos = BlockPos.of(block);
        GeneratorTier genTier = this.generators.get(pos);
        ManagedRefined node = this.refinedNodes.get(pos);
        ItemStack hand = player.getInventory().getItemInMainHand();
        RefinedTier heldRefinedTier = this.resolveRefinedTier(hand, hand != null ? hand.getType() : null);
        if (action == Action.RIGHT_CLICK_BLOCK && node != null) {
            if (heldRefinedTier != null) {
                return;
            }
            event.setCancelled(true);
            if (node.hitsRemaining > 0) {
                player.sendMessage(Text.color("&aThis refined ore has &f" + node.hitsRemaining + "&a stacked ore" + (node.hitsRemaining == 1 ? "" : "s") + "&a out of &f" + node.refinedTier.stackCap + "&a."));
                return;
            }
            if (node.generatorPos == null) {
                player.sendMessage(Text.color("&cThis refined ore is not linked to a generator."));
                return;
            }
            long remainingMillis = Math.max(0L, node.nextOreAtMillis - System.currentTimeMillis());
            player.sendMessage(Text.color("&aNext ore generation in &f" + this.formatDuration(remainingMillis) + "&a."));
            return;
        }
        if (hand != null && !hand.getType().isAir()) {
            return;
        }
        if (!player.isSneaking()) {
            return;
        }
        if (action == Action.LEFT_CLICK_BLOCK) {
            if (genTier != null) {
                if (this.hasLinkedRefinedForGenerator(pos)) {
                    event.setCancelled(true);
                    player.sendMessage(Text.color("&cRemove the refined ore linked to this generator first."));
                    return;
                }
                event.setCancelled(true);
                this.generators.remove(pos);
                this.removeLabel(pos);
                this.unlinkRefinedForGenerator(pos);
                this.giveOrDrop(player, this.createGeneratorItem(genTier), block.getLocation());
                if (this.cellService != null) {
                    this.cellService.unmarkPlayerPlacedBlock(block);
                }
                block.setType(Material.AIR, false);
                return;
            }
            if (node != null && node.hitsRemaining <= 0 && block.getType() == node.refinedTier.refinedBlock) {
                event.setCancelled(true);
                this.refinedNodes.remove(pos);
                this.cancelTask(node);
                this.giveOrDrop(player, this.createRefinedItem(node.refinedTier), block.getLocation());
                if (this.cellService != null) {
                    this.cellService.unmarkPlayerPlacedBlock(block);
                }
                block.setType(Material.AIR, false);
            }
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onBreak(BlockBreakEvent event) {
        boolean isRefinedBase;
        Block block = event.getBlock();
        BlockPos pos = BlockPos.of(block);
        Player player = event.getPlayer();
        GeneratorTier genTier = this.generators.get(pos);
        ManagedRefined node = this.refinedNodes.get(pos);
        Material type = block.getType();
        boolean bl = isRefinedBase = node != null && type == node.refinedTier.refinedBlock;
        if ((genTier != null || isRefinedBase) && !player.isSneaking()) {
            event.setCancelled(true);
            return;
        }
        if (genTier != null) {
            if (this.hasLinkedRefinedForGenerator(pos)) {
                event.setCancelled(true);
                player.sendMessage(Text.color("&cRemove the refined ore linked to this generator first."));
                return;
            }
            this.generators.remove(pos);
            this.removeLabel(pos);
            this.unlinkRefinedForGenerator(pos);
            this.giveOrDrop(player, this.createGeneratorItem(genTier), block.getLocation());
            event.setDropItems(false);
        }
        if (isRefinedBase) {
            this.refinedNodes.remove(pos);
            this.cancelTask(node);
            this.giveOrDrop(player, this.createRefinedItem(node.refinedTier), block.getLocation());
            event.setDropItems(false);
        }
    }

    public void shutdown() {
        this.generatorLabels.forEach((pos, id) -> this.removeLabel((BlockPos)pos));
        for (ManagedRefined node : this.refinedNodes.values()) {
            this.cancelTask(node);
            Block block = this.blockAt(node.location);
            if (block == null) continue;
            if (node.hitsRemaining > 0 && node.generatorTier != null) {
                block.setType(node.generatorTier.oreBlock, false);
            } else {
                block.setType(node.refinedTier.refinedBlock, false);
            }
        }
        this.refinedNodes.clear();
        this.generators.clear();
    }

    private void linkNearbyRefined(Block generator, GeneratorTier tier) {
        BlockPos generatorPos = BlockPos.of(generator);
        for (ManagedRefined node : this.refinedNodes.values()) {
            if (node == null || node.generatorPos != null) {
                continue;
            }
            if (!this.isWithinRadius(generatorPos, node.location, 3)) {
                continue;
            }
            node.generatorTier = tier;
            node.generatorPos = generatorPos;
            this.schedule(node);
        }
    }

    private void unlinkRefinedForGenerator(BlockPos generatorPos) {
        ConcurrentHashMap.KeySetView toRemove = ConcurrentHashMap.newKeySet();
        for (ManagedRefined node : this.refinedNodes.values()) {
            if (node.generatorPos == null || !node.generatorPos.equals(generatorPos)) continue;
            this.cancelTask(node);
            toRemove.add(node.location);
        }
        toRemove.forEach(this.refinedNodes::remove);
    }

    private boolean hasLinkedRefinedForGenerator(BlockPos generatorPos) {
        for (ManagedRefined node : this.refinedNodes.values()) {
            if (node.generatorPos == null || !node.generatorPos.equals(generatorPos)) continue;
            return true;
        }
        return false;
    }

    private boolean isWithinRadius(BlockPos center, BlockPos pos, int radius) {
        if (center == null || pos == null || !center.world().equals(pos.world())) {
            return false;
        }
        int dx = pos.x() - center.x();
        int dy = pos.y() - center.y();
        int dz = pos.z() - center.z();
        return dx * dx + dy * dy + dz * dz <= radius * radius;
    }

    private void schedule(ManagedRefined node) {
        this.schedule(node, Math.max(1L, node.refinedTier.regenTicks));
    }

    private void schedule(ManagedRefined node, long delay) {
        this.cancelTask(node);
        if (node.generatorPos == null) {
            node.nextOreAtMillis = -1L;
            return;
        }
        node.nextOreAtMillis = System.currentTimeMillis() + delay * 50L;
        node.taskId = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin)this.plugin, () -> {
            node.taskId = -1;
            this.advanceOreStack(node);
        }, delay);
    }

    private void advanceOreStack(ManagedRefined node) {
        GeneratorTier genTier = node.generatorTier != null ? node.generatorTier : this.generators.get(node.generatorPos);
        if (genTier == null) {
            node.nextOreAtMillis = -1L;
            return;
        }
        Block block = this.blockAt(node.location);
        if (block == null || block.getType().isAir()) {
            node.nextOreAtMillis = -1L;
            return;
        }
        if (block.getType() != node.refinedTier.refinedBlock && block.getType() != genTier.oreBlock) {
            node.nextOreAtMillis = -1L;
            return;
        }
        if (node.hitsRemaining < node.refinedTier.stackCap) {
            node.hitsRemaining = Math.min(node.refinedTier.stackCap, node.hitsRemaining + node.refinedTier.stackAmount);
        }
        if (block.getType() != genTier.oreBlock) {
            block.setType(genTier.oreBlock, false);
        }
        this.schedule(node, Math.max(1L, node.refinedTier.regenTicks));
    }

    private void cancelTask(ManagedRefined node) {
        if (node.taskId != -1) {
            Bukkit.getScheduler().cancelTask(node.taskId);
            node.taskId = -1;
        }
    }

    private void spawnLabel(Block generator, GeneratorTier tier) {
        BlockPos pos = BlockPos.of(generator);
        this.removeLabel(pos);
        Location loc = generator.getLocation().add(0.5, 2.0, 0.5);
        ArmorStand stand = (ArmorStand)generator.getWorld().spawn(loc, ArmorStand.class, as -> {
            as.setInvisible(true);
            as.setMarker(true);
            as.setGravity(false);
            as.setCustomNameVisible(true);
            as.setSmall(true);
            String tierName = tier.name().charAt(0) + tier.name().substring(1).toLowerCase();
            as.setCustomName(Text.color("&e&l" + tierName + " Generator"));
        });
        this.generatorLabels.put(pos, stand.getUniqueId());
    }

    private void removeLabel(BlockPos pos) {
        UUID id = this.generatorLabels.remove(pos);
        if (id == null) {
            return;
        }
        World world = this.getWorld(pos);
        if (world == null) {
            return;
        }
        world.getEntitiesByClass(ArmorStand.class).stream().filter(as -> as.getUniqueId().equals(id)).forEach(Entity::remove);
    }

    private void giveOrDrop(Player player, ItemStack item, Location dropLoc) {
        Map<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack[]{item});
        left.values().forEach(it -> player.getWorld().dropItemNaturally(dropLoc, it));
    }

    public ItemStack createGeneratorItem(GeneratorTier tier) {
        ItemStack item = new ItemStack(tier.generatorBlock);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String basePath = "generator-items." + tier.name().toLowerCase();
            String name = this.plugin.getConfig().getString(basePath + ".name", "&e" + tier.name().charAt(0) + tier.name().substring(1).toLowerCase() + " Generator");
            meta.setDisplayName(Text.color(this.applyTier(name, tier.name())));
            List lore = this.plugin.getConfig().getStringList(basePath + ".lore");
            if (!lore.isEmpty()) {
                meta.setLore(lore.stream().map(line -> Text.color(this.applyTier((String)line, tier.name()))).toList());
            }
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
            meta.getPersistentDataContainer().set(this.generatorKey, PersistentDataType.STRING, tier.name());
            item.setItemMeta(meta);
        }
        return item;
    }

    public ItemStack createRefinedItem(RefinedTier tier) {
        ItemStack item = new ItemStack(tier.refinedBlock);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String basePath = "refined-items." + tier.name().toLowerCase();
            String name = this.plugin.getConfig().getString(basePath + ".name", "&b" + tier.name().charAt(0) + tier.name().substring(1).toLowerCase() + " Refined Ore");
            meta.setDisplayName(Text.color(this.applyTier(name, tier.name())));
            List lore = this.plugin.getConfig().getStringList(basePath + ".lore");
            if (!lore.isEmpty()) {
                meta.setLore(lore.stream().map(line -> Text.color(this.applyRefinedPlaceholders(this.applyTier((String)line, tier.name()), tier))).toList());
            }
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
            meta.getPersistentDataContainer().set(this.refinedKey, PersistentDataType.STRING, tier.name());
            item.setItemMeta(meta);
        }
        return item;
    }

    public boolean isGeneratorBlock(Block block) {
        return block != null && this.generators.containsKey(BlockPos.of(block));
    }

    public boolean hasManagedBossBlocks(Cell cell) {
        if (cell == null || cell.getRegion() == null) {
            return false;
        }
        for (BlockPos pos : this.generators.keySet()) {
            if (this.isInside(cell, pos)) {
                return true;
            }
        }
        for (BlockPos pos : this.refinedNodes.keySet()) {
            if (this.isInside(cell, pos)) {
                return true;
            }
        }
        return false;
    }

    public int getGangPoints(Cell cell) {
        if (cell == null || cell.getRegion() == null) {
            return 0;
        }
        int total = 0;
        for (Map.Entry<BlockPos, GeneratorTier> entry : this.generators.entrySet()) {
            if (!this.isInside(cell, entry.getKey())) {
                continue;
            }
            total += switch (entry.getValue()) {
                case BASIC -> 10;
                case UNCOMMON -> 15;
                case UNIQUE -> 20;
                case RARE -> 40;
                case ELITE -> 50;
                case LEGENDARY -> 80;
                case MYTHICAL -> 100;
            };
        }
        return total;
    }

    public Map<String, String> captureBossGenerators(Cell cell) {
        Map<String, String> out = new HashMap<String, String>();
        if (cell == null || cell.getRegion() == null) {
            return out;
        }
        for (Map.Entry<BlockPos, GeneratorTier> entry : this.generators.entrySet()) {
            if (!this.isInside(cell, entry.getKey())) {
                continue;
            }
            out.put(this.key(entry.getKey()), entry.getValue().name());
        }
        return out;
    }

    public Map<String, String> captureBossRefined(Cell cell) {
        Map<String, String> out = new HashMap<String, String>();
        if (cell == null || cell.getRegion() == null) {
            return out;
        }
        for (Map.Entry<BlockPos, ManagedRefined> entry : this.refinedNodes.entrySet()) {
            if (!this.isInside(cell, entry.getKey())) {
                continue;
            }
            out.put(this.key(entry.getKey()), this.encodeRefinedNode(entry.getValue()));
        }
        return out;
    }

    public void restoreBossCellState(Cell cell, Map<String, String> generators, Map<String, String> refined) {
        if (cell == null || cell.getRegion() == null) {
            return;
        }
        this.generators.entrySet().removeIf(entry -> this.isInside(cell, entry.getKey()));
        this.refinedNodes.entrySet().removeIf(entry -> this.isInside(cell, entry.getKey()));
        if (generators != null) {
            for (Map.Entry<String, String> entry : generators.entrySet()) {
                BlockPos pos = this.parseKey(entry.getKey());
                if (pos == null || !this.isInside(cell, pos)) {
                    continue;
                }
                GeneratorTier tier = this.parseGeneratorTier(entry.getValue());
                if (tier == null) {
                    continue;
                }
                this.generators.put(pos, tier);
                Block block = this.blockAt(pos);
                if (block != null) {
                    this.spawnLabel(block, tier);
                }
            }
        }
        if (refined != null) {
            for (Map.Entry<String, String> entry : refined.entrySet()) {
                BlockPos pos = this.parseKey(entry.getKey());
                if (pos == null || !this.isInside(cell, pos)) {
                    continue;
                }
                RefinedSnapshot snapshot = this.parseRefinedSnapshot(entry.getValue());
                RefinedTier tier = snapshot.refinedTier;
                if (tier == null) {
                    continue;
                }
                World world = Bukkit.getWorld((String)pos.world());
                if (world == null) {
                    continue;
                }
                GeneratorTier genTier = snapshot.generatorTier;
                BlockPos generatorPos = snapshot.generatorPos;
                if (genTier == null && generatorPos != null) {
                    genTier = this.generators.get(generatorPos);
                }
                if (genTier == null || generatorPos == null) {
                    GeneratorNearby nearby = this.findNearbyGenerator(pos.toLocation(world));
                    if (nearby != null) {
                        if (genTier == null) {
                            genTier = nearby.tier;
                        }
                        if (generatorPos == null) {
                            generatorPos = nearby.pos;
                        }
                    }
                }
                ManagedRefined node = new ManagedRefined(pos, genTier, tier, generatorPos);
                node.hitsRemaining = Math.min(tier.stackCap, Math.max(0, snapshot.stackCount));
                node.nextOreAtMillis = snapshot.nextOreAtMillis;
                this.refinedNodes.put(pos, node);
                Block block = this.blockAt(pos);
                if (block != null) {
                    if (node.hitsRemaining > 0 && node.generatorTier != null) {
                        block.setType(node.generatorTier.oreBlock, false);
                    } else {
                        block.setType(node.refinedTier.refinedBlock, false);
                    }
                }
                if (node.nextOreAtMillis > 0L) {
                    long remaining = node.nextOreAtMillis - System.currentTimeMillis();
                    if (remaining <= 0L) {
                        this.advanceOreStack(node);
                    } else {
                        this.schedule(node, Math.max(1L, (remaining + 49L) / 50L));
                    }
                } else if (genTier != null) {
                    this.schedule(node);
                }
            }
        }
    }

    private String encodeRefinedNode(ManagedRefined node) {
        String generatorTier = node.generatorTier != null ? node.generatorTier.name() : "-";
        String generatorPos = node.generatorPos != null ? this.key(node.generatorPos) : "-";
        return String.join("|", node.refinedTier.name(), generatorTier, Integer.toString(node.hitsRemaining), Long.toString(node.nextOreAtMillis), generatorPos);
    }

    private RefinedSnapshot parseRefinedSnapshot(String value) {
        if (value == null) {
            return new RefinedSnapshot(null, null, 0, -1L, null);
        }
        String[] parts = value.split("\\|", -1);
        RefinedTier refinedTier = this.parseRefinedTier(parts.length > 0 ? parts[0] : null);
        if (parts.length < 5) {
            return new RefinedSnapshot(refinedTier, null, 0, -1L, null);
        }
        GeneratorTier generatorTier = this.parseGeneratorTier("-".equals(parts[1]) ? null : parts[1]);
        int stackCount = 0;
        long nextOreAtMillis = -1L;
        try {
            if (parts.length >= 6) {
                stackCount = Boolean.parseBoolean(parts[2]) ? 1 : 0;
                nextOreAtMillis = Long.parseLong(parts[4]);
            } else {
                stackCount = Integer.parseInt(parts[2]);
                nextOreAtMillis = Long.parseLong(parts[3]);
            }
        }
        catch (NumberFormatException ignored) {
        }
        BlockPos generatorPos = "-".equals(parts.length >= 6 ? parts[5] : parts[4]) ? null : this.parseKey(parts.length >= 6 ? parts[5] : parts[4]);
        return new RefinedSnapshot(refinedTier, generatorTier, stackCount, nextOreAtMillis, generatorPos);
    }

    private boolean isGeneratorItem(ItemStack item, GeneratorTier tier) {
        return this.hasTag(item, this.generatorKey, tier.name());
    }

    private boolean isRefinedItem(ItemStack item, RefinedTier tier) {
        return this.hasTag(item, this.refinedKey, tier.name());
    }

    private boolean hasTag(ItemStack item, NamespacedKey key, String value) {
        if (item == null) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return false;
        }
        String stored = (String)meta.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        return value.equals(stored);
    }

    private boolean isInside(Cell cell, BlockPos pos) {
        if (cell == null || cell.getRegion() == null || pos == null) {
            return false;
        }
        World world = Bukkit.getWorld((String)cell.getRegion().getWorldName());
        if (world == null || !world.getName().equals(pos.world())) {
            return false;
        }
        Vector min = cell.getRegion().getMin();
        Vector max = cell.getRegion().getMax();
        return pos.x() >= (int)Math.floor(min.getX()) && pos.x() <= (int)Math.ceil(max.getX()) && pos.y() >= (int)Math.floor(min.getY()) && pos.y() <= (int)Math.ceil(max.getY()) && pos.z() >= (int)Math.floor(min.getZ()) && pos.z() <= (int)Math.ceil(max.getZ());
    }

    private String key(BlockPos pos) {
        return pos.world() + ":" + pos.x() + ":" + pos.y() + ":" + pos.z();
    }

    private BlockPos parseKey(String key) {
        if (key == null) {
            return null;
        }
        String[] parts = key.split(":");
        if (parts.length != 4) {
            return null;
        }
        try {
            return new BlockPos(Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]), parts[0]);
        }
        catch (NumberFormatException ex) {
            return null;
        }
    }

    private GeneratorTier parseGeneratorTier(String name) {
        if (name == null) {
            return null;
        }
        try {
            return GeneratorTier.valueOf(name.toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private RefinedTier parseRefinedTier(String name) {
        if (name == null) {
            return null;
        }
        try {
            return RefinedTier.valueOf(name.toUpperCase(Locale.ROOT));
        }
        catch (IllegalArgumentException ex) {
            return null;
        }
    }

    private String applyTier(String input, String tier) {
        return input.replace("{tier}", tier.toLowerCase());
    }

    private String applyRefinedPlaceholders(String input, RefinedTier tier) {
        if (input == null) {
            return null;
        }
        return input.replace("{time}", this.formatDuration(tier.regenTicks * 50L)).replace("{amount of ore}", Integer.toString(tier.stackAmount)).replace("{max stack}", Integer.toString(tier.stackCap)).replace("{regen_time}", this.formatDuration(tier.regenTicks * 50L)).replace("{stack_size}", Integer.toString(tier.stackAmount)).replace("{stack_cap}", Integer.toString(tier.stackCap));
    }

    private String formatDuration(long millis) {
        long totalSeconds = Math.max(0L, (millis + 999L) / 1000L);
        long hours = totalSeconds / 3600L;
        long minutes = totalSeconds % 3600L / 60L;
        long seconds = totalSeconds % 60L;
        if (hours > 0L) {
            return hours + "h " + minutes + "m " + seconds + "s";
        }
        if (minutes > 0L) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }

    private World getWorld(BlockPos pos) {
        return Bukkit.getWorld((String)pos.world());
    }

    private Block blockAt(BlockPos pos) {
        World w = this.getWorld(pos);
        return w == null ? null : w.getBlockAt(pos.x(), pos.y(), pos.z());
    }

    private GeneratorNearby findNearbyGenerator(Location loc) {
        World world = loc.getWorld();
        if (world == null) {
            return null;
        }
        int originX = loc.getBlockX();
        int originY = loc.getBlockY();
        int originZ = loc.getBlockZ();
        GeneratorNearby closest = null;
        int closestDistance = Integer.MAX_VALUE;
        for (Map.Entry<BlockPos, GeneratorTier> entry : this.generators.entrySet()) {
            int distance;
            BlockPos pos = entry.getKey();
            if (!pos.world().equals(world.getName()) || (distance = this.distanceSquared(originX, originY, originZ, pos)) > 9 || distance >= closestDistance) continue;
            closestDistance = distance;
            closest = new GeneratorNearby(pos, entry.getValue());
        }
        return closest;
    }

    private Set<BlockPos> nearby(World world, int x, int y, int z, int radius) {
        ConcurrentHashMap.KeySetView out = ConcurrentHashMap.newKeySet();
        int radiusSquared = radius * radius;
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dy = -radius; dy <= radius; ++dy) {
                for (int dz = -radius; dz <= radius; ++dz) {
                    if (dx * dx + dy * dy + dz * dz > radiusSquared) continue;
                    out.add(new BlockPos(x + dx, y + dy, z + dz, world.getName()));
                }
            }
        }
        return out;
    }

    private int distanceSquared(int x, int y, int z, BlockPos pos) {
        int dx = pos.x() - x;
        int dy = pos.y() - y;
        int dz = pos.z() - z;
        return dx * dx + dy * dy + dz * dz;
    }

    private record BlockPos(int x, int y, int z, String world) {
        static BlockPos of(Block block) {
            return new BlockPos(block.getX(), block.getY(), block.getZ(), block.getWorld().getName());
        }

        Location toLocation(World world) {
            return new Location(world, (double)this.x, (double)this.y, (double)this.z);
        }
    }

    private static class ManagedRefined {
        final BlockPos location;
        GeneratorTier generatorTier;
        final RefinedTier refinedTier;
        BlockPos generatorPos;
        int hitsRemaining = 0;
        int taskId = -1;
        long nextOreAtMillis = -1L;

        ManagedRefined(BlockPos loc, GeneratorTier gen, RefinedTier refined, BlockPos generatorPos) {
            this.location = loc;
            this.generatorTier = gen;
            this.refinedTier = refined;
            this.generatorPos = generatorPos;
        }
    }

    private static class RefinedSnapshot {
        final RefinedTier refinedTier;
        final GeneratorTier generatorTier;
        final int stackCount;
        final long nextOreAtMillis;
        final BlockPos generatorPos;

        private RefinedSnapshot(RefinedTier refinedTier, GeneratorTier generatorTier, int stackCount, long nextOreAtMillis, BlockPos generatorPos) {
            this.refinedTier = refinedTier;
            this.generatorTier = generatorTier;
            this.stackCount = stackCount;
            this.nextOreAtMillis = nextOreAtMillis;
            this.generatorPos = generatorPos;
        }
    }

    public static enum RefinedTier {
        BASIC(Material.ROOTED_DIRT, 3600L, 5, 1),
        UNCOMMON(Material.COBBLESTONE, 6000L, 10, 2),
        UNIQUE(Material.RAW_COPPER_BLOCK, 6000L, 15, 3),
        RARE(Material.LIGHT_GRAY_TERRACOTTA, 8400L, 40, 5),
        ELITE(Material.AMETHYST_BLOCK, 12000L, 60, 15),
        LEGENDARY(Material.SEA_LANTERN, 18000L, 100, 20),
        MYTHICAL(Material.PRISMARINE, 24000L, 200, 50);

        public final Material refinedBlock;
        public final long regenTicks;
        public final int stackCap;
        public final int stackAmount;

        private RefinedTier(Material refinedBlock, long regenTicks, int stackCap, int stackAmount) {
            this.refinedBlock = refinedBlock;
            this.regenTicks = regenTicks;
            this.stackCap = stackCap;
            this.stackAmount = stackAmount;
        }

        public static RefinedTier byRefined(Material m) {
            for (RefinedTier t : RefinedTier.values()) {
                if (t.refinedBlock != m) continue;
                return t;
            }
            return null;
        }
    }

    public static enum GeneratorTier {
        BASIC(Material.COAL_BLOCK, Material.COAL_ORE),
        UNCOMMON(Material.IRON_BLOCK, Material.IRON_ORE),
        UNIQUE(Material.LAPIS_BLOCK, Material.LAPIS_ORE),
        RARE(Material.GOLD_BLOCK, Material.GOLD_ORE),
        ELITE(Material.REDSTONE_BLOCK, Material.REDSTONE_ORE),
        LEGENDARY(Material.DIAMOND_BLOCK, Material.DIAMOND_ORE),
        MYTHICAL(Material.EMERALD_BLOCK, Material.EMERALD_ORE);

        public final Material generatorBlock;
        public final Material oreBlock;

        private GeneratorTier(Material generatorBlock, Material oreBlock) {
            this.generatorBlock = generatorBlock;
            this.oreBlock = oreBlock;
        }

        public static GeneratorTier byGenerator(Material m) {
            for (GeneratorTier t : GeneratorTier.values()) {
                if (t.generatorBlock != m) continue;
                return t;
            }
            return null;
        }
    }

    public record GeneratorNearby(BlockPos pos, GeneratorTier tier) {
    }
}
