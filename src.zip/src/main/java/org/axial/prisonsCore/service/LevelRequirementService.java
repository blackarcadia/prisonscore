/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.FileConfiguration
 */
package org.axial.prisonsCore.service;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class LevelRequirementService {
    private final Map<Material, Integer> blockRequirements = new HashMap<Material, Integer>();
    private final Map<Material, Integer> toolRequirements = new HashMap<Material, Integer>();
    private static final Map<Material, Integer> DEFAULT_BLOCK_REQUIREMENTS = Map.of(
            Material.IRON_ORE, 20,
            Material.LAPIS_ORE, 30,
            Material.GOLD_ORE, 40,
            Material.REDSTONE_ORE, 60,
            Material.DIAMOND_ORE, 70,
            Material.EMERALD_ORE, 90
    );
    private static final Map<Material, Integer> DEFAULT_TOOL_REQUIREMENTS = Map.of(
            Material.WOODEN_PICKAXE, 2,
            Material.STONE_PICKAXE, 20,
            Material.IRON_PICKAXE, 30,
            Material.GOLDEN_PICKAXE, 50,
            Material.DIAMOND_PICKAXE, 75
    );

    public LevelRequirementService(FileConfiguration config) {
        ConfigurationSection toolSec;
        ConfigurationSection blockSec = config.getConfigurationSection("block-levels");
        if (blockSec != null) {
            for (String key : blockSec.getKeys(false)) {
                Material mat = Material.matchMaterial((String)key);
                if (mat == null) continue;
                this.blockRequirements.put(mat, blockSec.getInt(key));
            }
        }
        this.applyDefaults(this.blockRequirements, DEFAULT_BLOCK_REQUIREMENTS);
        if ((toolSec = config.getConfigurationSection("pickaxe-levels")) != null) {
            for (String key : toolSec.getKeys(false)) {
                Material mat = Material.matchMaterial((String)key);
                if (mat == null) continue;
                this.toolRequirements.put(mat, toolSec.getInt(key));
            }
        }
        this.applyDefaults(this.toolRequirements, DEFAULT_TOOL_REQUIREMENTS);
        this.toolRequirements.put(Material.WOODEN_PICKAXE, 2);
    }

    public int getRequiredLevelForBlock(Material material) {
        return this.blockRequirements.getOrDefault(material, 0);
    }

    public int getRequiredLevelForTool(Material material) {
        return this.toolRequirements.getOrDefault(material, 0);
    }

    private void applyDefaults(Map<Material, Integer> target, Map<Material, Integer> defaults) {
        for (Map.Entry<Material, Integer> entry : defaults.entrySet()) {
            if (!target.containsKey(entry.getKey())) {
                target.put(entry.getKey(), entry.getValue());
            }
        }
    }
}
