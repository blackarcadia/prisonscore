/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.Damageable
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.config.EnergyBarConfig;
import org.axial.prisonsCore.util.Text;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;

public class GearManager {
    private final PrisonsCore plugin;
    private final EnergyBarConfig barConfig;
    private final NamespacedKey typeKey;
    private final NamespacedKey energyKey;
    private final NamespacedKey levelKey;
    private final NamespacedKey enchantsKey;
    private final NamespacedKey brokenKey;
    private final int startLevel;
    private final double percentPerLevel;

    public GearManager(PrisonsCore plugin, EnergyBarConfig barConfig) {
        this.plugin = plugin;
        this.barConfig = barConfig;
        this.typeKey = Keys.gearType(plugin);
        this.energyKey = Keys.gearEnergy(plugin);
        this.levelKey = Keys.gearLevel(plugin);
        this.enchantsKey = Keys.gearEnchants(plugin);
        this.brokenKey = new NamespacedKey((Plugin)plugin, "gear-broken");
        this.startLevel = Math.max(1, plugin.getConfig().getInt("gear-level.start-level", 1));
        this.percentPerLevel = plugin.getConfig().getDouble("gear-level.percent-per-level", 20.0D);
    }

    public boolean isGear(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return false;
        }
        return stack.getItemMeta().getPersistentDataContainer().has(this.typeKey, PersistentDataType.STRING) || this.isApplicableMaterial(stack.getType());
    }

    public boolean isApplicableMaterial(Material mat) {
        if (mat == null) {
            return false;
        }
        return mat.name().endsWith("_SWORD") || mat.name().endsWith("_AXE") || mat.name().endsWith("_HOE") || mat.name().endsWith("_SHOVEL") || mat.name().endsWith("_HELMET") || mat.name().endsWith("_CHESTPLATE") || mat.name().endsWith("_LEGGINGS") || mat.name().endsWith("_BOOTS") || mat == Material.TRIDENT || mat == Material.SHIELD || mat == Material.BOW || mat == Material.CROSSBOW;
    }

    public ItemStack wrap(ItemStack base, String id) {
        if (base == null || !this.isApplicableMaterial(base.getType())) {
            return base;
        }
        ItemStack stack = base.clone();
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.typeKey, PersistentDataType.STRING, id.toLowerCase(Locale.ROOT));
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, this.startLevel);
        meta.getPersistentDataContainer().set(this.brokenKey, PersistentDataType.BYTE, (byte)0);
        meta.displayName(Text.componentNoItalics(this.buildName(stack, this.startLevel)));
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setEnchantmentGlintOverride(Boolean.valueOf(false));
        this.clearVanillaEnchants(stack);
        stack.setItemMeta(meta);
        this.updateLore(stack);
        return stack;
    }

    private void ensureTagged(ItemStack stack) {
        if (stack == null || !this.isApplicableMaterial(stack.getType())) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        boolean changed = false;
        if (!meta.getPersistentDataContainer().has(this.typeKey, PersistentDataType.STRING)) {
            meta.getPersistentDataContainer().set(this.typeKey, PersistentDataType.STRING, stack.getType().name().toLowerCase(Locale.ROOT));
            meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, 0);
            changed = true;
        }
        if (!meta.getPersistentDataContainer().has(this.levelKey, PersistentDataType.INTEGER)) {
            meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, this.startLevel);
            changed = true;
        }
        if (!meta.getPersistentDataContainer().has(this.brokenKey, PersistentDataType.BYTE)) {
            meta.getPersistentDataContainer().set(this.brokenKey, PersistentDataType.BYTE, (byte)0);
            changed = true;
        }
        if (meta.getPersistentDataContainer().has(this.typeKey, PersistentDataType.STRING)) {
            Integer level = (Integer)meta.getPersistentDataContainer().get(this.levelKey, PersistentDataType.INTEGER);
            meta.displayName(Text.componentNoItalics(this.buildName(stack, level == null ? this.startLevel : level)));
            changed = true;
        }
        if (changed) {
            stack.setItemMeta(meta);
        }
    }

    public int getEnergy(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return 0;
        }
        this.ensureTagged(stack);
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.energyKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public void setEnergy(ItemStack stack, int value) {
        if (!this.isGear(stack)) {
            return;
        }
        this.ensureTagged(stack);
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, Math.max(0, Math.min(value, this.getMaxEnergy(stack))));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public int getMaxEnergy(ItemStack stack) {
        if (stack == null) {
            return this.plugin.getConfig().getInt("gear-energy.max", 1000);
        }
        String typeName = stack.getType().name();
        if (typeName.startsWith("CHAINMAIL_")) {
            return this.scaleEnergy(this.plugin.getConfig().getInt("gear-energy.chainmail", 7000), this.getLevel(stack));
        }
        if (typeName.startsWith("GOLDEN_")) {
            return this.scaleEnergy(this.plugin.getConfig().getInt("gear-energy.golden", 11000), this.getLevel(stack));
        }
        if (typeName.startsWith("IRON_")) {
            return this.scaleEnergy(this.plugin.getConfig().getInt("gear-energy.iron", 9000), this.getLevel(stack));
        }
        if (typeName.startsWith("DIAMOND_")) {
            return this.scaleEnergy(this.plugin.getConfig().getInt("gear-energy.diamond", 13000), this.getLevel(stack));
        }
        return this.scaleEnergy(this.plugin.getConfig().getInt("gear-energy.max", 1000), this.getLevel(stack));
    }

    public int getLevel(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return this.startLevel;
        }
        this.ensureTagged(stack);
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.levelKey, PersistentDataType.INTEGER);
        return val == null ? this.startLevel : Math.max(1, val);
    }

    public void setLevel(ItemStack stack, int level) {
        if (!this.isGear(stack)) {
            return;
        }
        int oldMax = this.getMaxEnergy(stack);
        int currentEnergy = this.getEnergy(stack);
        this.ensureTagged(stack);
        ItemMeta meta = stack.getItemMeta();
        int clamped = Math.max(1, level);
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, clamped);
        meta.displayName(Text.componentNoItalics(this.buildName(stack, clamped)));
        stack.setItemMeta(meta);
        int newMax = this.getMaxEnergy(stack);
        int rescaledEnergy = oldMax > 0 ? (int)Math.round((double)currentEnergy * (double)newMax / (double)oldMax) : currentEnergy;
        this.setEnergy(stack, Math.max(0, Math.min(newMax, rescaledEnergy)));
    }

    public void levelUp(ItemStack stack) {
        this.setLevel(stack, this.getLevel(stack) + 1);
    }

    public boolean isFull(ItemStack stack) {
        return this.getEnergy(stack) >= this.getMaxEnergy(stack);
    }

    public int getRequiredLevel(ItemStack stack) {
        return stack == null ? -1 : this.getRequiredLevel(stack.getType());
    }

    public int getRequiredLevel(Material material) {
        ConfigurationSection section = this.plugin.getConfig().getConfigurationSection("gear-levels");
        if (section != null && section.contains(material.name())) {
            return section.getInt(material.name(), -1);
        }
        return switch (material) {
            case CHAINMAIL_HELMET, CHAINMAIL_CHESTPLATE, CHAINMAIL_LEGGINGS, CHAINMAIL_BOOTS -> 20;
            case GOLDEN_HELMET, GOLDEN_CHESTPLATE, GOLDEN_LEGGINGS, GOLDEN_BOOTS -> 45;
            case IRON_HELMET, IRON_CHESTPLATE, IRON_LEGGINGS, IRON_BOOTS -> 60;
            case DIAMOND_HELMET, DIAMOND_CHESTPLATE, DIAMOND_LEGGINGS, DIAMOND_BOOTS -> 75;
            case GOLDEN_SWORD, GOLDEN_AXE, GOLDEN_HOE, GOLDEN_SHOVEL -> 30;
            case IRON_SWORD, IRON_AXE, IRON_HOE, IRON_SHOVEL -> 60;
            case DIAMOND_SWORD, DIAMOND_AXE, DIAMOND_HOE, DIAMOND_SHOVEL -> 80;
            default -> -1;
        };
    }

    public void setDamage(ItemStack stack, int damage) {
        if (stack == null) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta instanceof Damageable) {
            Damageable dmg = (Damageable)meta;
            dmg.setDamage(Math.max(0, damage));
            stack.setItemMeta(meta);
        }
    }

    public Map<String, Integer> getEnchants(ItemStack stack) {
        if (!this.isGear(stack)) {
            return Collections.emptyMap();
        }
        this.ensureTagged(stack);
        String raw = (String)stack.getItemMeta().getPersistentDataContainer().get(this.enchantsKey, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) {
            return Collections.emptyMap();
        }
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        for (String pair : raw.split(";")) {
            String[] parts = pair.split(":");
            if (parts.length != 2) continue;
            try {
                map.put(parts[0], Integer.parseInt(parts[1]));
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return map;
    }

    public void setEnchants(ItemStack stack, Map<String, Integer> enchants) {
        if (!this.isGear(stack)) {
            return;
        }
        String serialized = enchants.entrySet().stream().map(e -> (String)e.getKey() + ":" + String.valueOf(e.getValue())).collect(Collectors.joining(";"));
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.enchantsKey, PersistentDataType.STRING, serialized);
        this.clearVanillaEnchants(stack);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setEnchantmentGlintOverride(Boolean.valueOf(!enchants.isEmpty()));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public boolean applyEnchant(ItemStack stack, String id, int level, int maxLevel) {
        HashMap<String, Integer> enchants = new HashMap<String, Integer>(this.getEnchants(stack));
        int current = enchants.getOrDefault(id, 0);
        int newLevel = Math.min(maxLevel, Math.max(current, level));
        enchants.put(id, newLevel);
        this.setEnchants(stack, enchants);
        return newLevel != current;
    }

    public void updateLore(ItemStack stack) {
        Map<String, Integer> enchants;
        if (!this.isGear(stack)) {
            return;
        }
        this.ensureTagged(stack);
        this.clearVanillaEnchants(stack);
        ItemMeta meta = stack.getItemMeta();
        ArrayList<String> lore = new ArrayList<String>();
        if (this.isBroken(stack)) {
            lore.add(Text.color("&cBroken - repair in enchanter"));
        }
        if (!(enchants = this.getEnchants(stack)).isEmpty()) {
            for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
                String line = this.plugin.getConfig().getString("gear.enchant-format", "&d{enchant}").replace("{enchant}", this.resolveEnchantDisplayName(entry.getKey(), entry.getValue())).replace("{level}", String.valueOf(entry.getValue()));
                lore.add(Text.color(line));
            }
        }
        int energy = this.getEnergy(stack);
        int maxEnergy = this.getMaxEnergy(stack);
        double percent = Math.min(1.0, Math.max(0.0, (double)energy / (double)maxEnergy));
        int filled = (int)Math.round(percent * (double)this.barConfig.getLength());
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < this.barConfig.getLength(); ++i) {
            if (i < filled) {
                bar.append(this.barConfig.getFilledColor()).append(this.barConfig.getFilledChar());
                continue;
            }
            bar.append(this.barConfig.getEmptyColor()).append(this.barConfig.getEmptyChar());
        }
        lore.add("");
        lore.add(Text.color("&d&lGear Charge"));
        Object barLine = this.barConfig.getFormat().replace("{bar}", ChatColor.translateAlternateColorCodes((char)'&', (String)bar.toString())).replace("{current}", String.valueOf(energy)).replace("{max}", String.valueOf(maxEnergy));
        double percentDisplay = (double)Math.round(percent * 1000.0) / 10.0;
        barLine = (String)barLine + Text.color(" &f&l" + percentDisplay + "%");
        lore.add(Text.color((String)barLine));
        boolean overflow = energy > maxEnergy;
        String currentColor = overflow ? "&d" : "&f";
        lore.add(Text.color("&7(" + currentColor + energy + " &7/ &f" + maxEnergy + ")"));
        int requiredLevel = this.getRequiredLevel(stack);
        if (requiredLevel > 0) {
            lore.add("");
            lore.add(Text.color("&eRequired Level &f&l" + requiredLevel));
        }
        if (this.plugin.getProtectionScrollService() != null && this.plugin.getProtectionScrollService().isProtected(stack)) {
            if (!lore.isEmpty() && !Text.strip(lore.get(lore.size() - 1)).isEmpty()) {
                lore.add("");
            }
            lore.add(Text.color("&f&lPROTECTED"));
        }
        meta.setLore(lore);
        if (meta.getDisplayName() == null || meta.getDisplayName().isBlank()) {
            meta.displayName(Text.componentNoItalics(this.buildName(stack, this.getLevel(stack))));
        }
        meta.setEnchantmentGlintOverride(Boolean.valueOf(!this.getEnchants(stack).isEmpty()));
        stack.setItemMeta(meta);
    }

    private void clearVanillaEnchants(ItemStack stack) {
        if (stack == null) {
            return;
        }
        for (Enchantment ench : new ArrayList<>(stack.getEnchantments().keySet())) {
            stack.removeEnchantment(ench);
        }
    }

    private int scaleEnergy(int base, int level) {
        int lvl = Math.max(1, level);
        double multiplier = Math.pow(1.25D, Math.max(0, lvl - 1));
        return (int)Math.round((double)base * multiplier);
    }

    private String resolveEnchantDisplayName(String id, int level) {
        if (id == null || id.isBlank()) {
            return "";
        }
        if (this.plugin.getGearEnchantService() != null) {
            org.axial.prisonsCore.model.CustomEnchant enchant = this.plugin.getGearEnchantService().getById(id);
            if (enchant != null) {
                return enchant.getDisplayNameForLevel(level);
            }
        }
        return id;
    }

    private String buildName(ItemStack stack, int level) {
        return this.prettyName(stack != null ? stack.getType() : null) + " &a&l" + Math.max(1, level);
    }

    private String prettyName(Material material) {
        if (material == null) {
            return "Gear";
        }
        String[] parts = material.name().toLowerCase(Locale.ROOT).split("_");
        StringBuilder builder = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return builder.length() == 0 ? "Gear" : builder.toString();
    }

    public void markBroken(ItemStack stack) {
        this.ensureTagged(stack);
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.brokenKey, PersistentDataType.BYTE, (byte)1);
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public boolean isBroken(ItemStack stack) {
        if (!this.isGear(stack)) {
            return false;
        }
        this.ensureTagged(stack);
        Byte val = (Byte)stack.getItemMeta().getPersistentDataContainer().get(this.brokenKey, PersistentDataType.BYTE);
        return val != null && val == 1;
    }

    public void repair(ItemStack stack) {
        if (!this.isGear(stack)) {
            return;
        }
        this.ensureTagged(stack);
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.brokenKey, PersistentDataType.BYTE, (byte)0);
        if (meta instanceof Damageable) {
            Damageable dmg = (Damageable)meta;
            dmg.setDamage(0);
        }
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }
}
