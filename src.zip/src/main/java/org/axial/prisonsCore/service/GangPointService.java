package org.axial.prisonsCore.service;

import java.io.File;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class GangPointService {
    private final PrisonsCore plugin;
    private final org.bukkit.NamespacedKey voucherKey;
    private Material voucherMaterial = Material.PAPER;
    private String voucherDisplay = "&bGang Points Voucher";
    private List<String> voucherLore = List.of("&7Right-click to add &f{amount} &7points to your gang.", "&8(Requires you to be in a gang)");

    public GangPointService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.voucherKey = Keys.gangPointVoucher(plugin);
        this.reload();
    }

    public void reload() {
        File file = new File(this.plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = cfg.getConfigurationSection("items.gang-points");
        if (section == null) {
            return;
        }
        Material configured = Material.matchMaterial(section.getString("material", "PAPER"));
        if (configured != null) {
            this.voucherMaterial = configured;
        }
        this.voucherDisplay = section.getString("display-name", this.voucherDisplay);
        List<String> configuredLore = section.getStringList("lore");
        if (configuredLore != null && !configuredLore.isEmpty()) {
            this.voucherLore = configuredLore;
        }
    }

    public ItemStack createGangPointNote(int amount) {
        ItemStack stack = new ItemStack(this.voucherMaterial);
        ItemMeta meta = stack.getItemMeta();
        int safeAmount = Math.max(1, amount);
        String formatted = String.format(Locale.ENGLISH, "%,d", safeAmount);
        meta.setDisplayName(Text.color(this.voucherDisplay.replace("{amount}", formatted)));
        meta.setLore(this.voucherLore.stream().map(line -> line.replace("{amount}", formatted)).map(Text::color).collect(Collectors.toList()));
        meta.getPersistentDataContainer().set(this.voucherKey, PersistentDataType.INTEGER, safeAmount);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isGangPointNote(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(this.voucherKey, PersistentDataType.INTEGER);
    }

    public int getAmount(ItemStack item) {
        if (!this.isGangPointNote(item)) {
            return 0;
        }
        Integer amount = item.getItemMeta().getPersistentDataContainer().get(this.voucherKey, PersistentDataType.INTEGER);
        return amount == null ? 0 : Math.max(0, amount);
    }

    public void giveGangPointNote(Player player, int amount) {
        if (player == null || amount <= 0) {
            return;
        }
        ItemStack note = this.createGangPointNote(amount);
        PlayerInventory inventory = player.getInventory();
        Map<Integer, ItemStack> leftover = inventory.addItem(note);
        if (this.plugin.getStashService() != null) {
            leftover.values().forEach(stack -> this.plugin.getStashService().giveOrStash(player, stack));
            return;
        }
        leftover.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
    }
}
