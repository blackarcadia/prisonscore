/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.command.CommandSender
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.entity.Player
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.config.PlayerLevelConfig;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class PlayerLevelService {
    private static final long LEVEL_CAP_MESSAGE_COOLDOWN_MILLIS = 120000L;
    private static final int MAX_PRESTIGE_LEVEL = 5;
    private final PrisonsCore plugin;
    private final PlayerLevelConfig config;
    private ContrabandService contrabandService;
    private ShardService shardService;
    private final NamespacedKey levelKey;
    private final NamespacedKey expKey;
    private final NamespacedKey prestigeKey;
    private final NamespacedKey expTotalKey;
    private final Map<UUID, Long> lastLevelCapMessageTimes = new HashMap<UUID, Long>();
    private int globalCap;
    private static final int[] MILESTONE_LEVELS = new int[]{10, 20, 30, 50, 75, 100};

    public PlayerLevelService(PrisonsCore plugin, PlayerLevelConfig config) {
        this.plugin = plugin;
        this.config = config;
        this.levelKey = Keys.playerLevel(plugin);
        this.expKey = Keys.playerExp(plugin);
        this.prestigeKey = Keys.playerPrestige(plugin);
        this.expTotalKey = Keys.playerExpTotal(plugin);
        this.globalCap = config.getMaxLevel();
    }

    public static Map<Material, Integer> readOreExp(ConfigurationSection section) {
        HashMap<Material, Integer> map = new HashMap<Material, Integer>();
        if (section == null) {
            return map;
        }
        for (String key : section.getKeys(false)) {
            Material mat = Material.matchMaterial((String)key);
            if (mat == null) continue;
            map.put(mat, section.getInt(key));
        }
        return map;
    }

    public int getOreExp(Material material) {
        if (material == null) {
            return 0;
        }
        Integer value = this.config.getOreExp().get(material);
        return value == null ? 0 : Math.max(0, value);
    }

    public int getLevel(Player player) {
        Integer lvl = (Integer)player.getPersistentDataContainer().get(this.levelKey, PersistentDataType.INTEGER);
        return lvl == null ? 1 : Math.max(1, Math.min(this.getCurrentLevelCap(), lvl));
    }

    public boolean isPrestigeUnlocked(Player player) {
        return this.getPrestigeLevel(player) > 0;
    }

    public void unlockPrestige(Player player) {
        this.setPrestigeLevel(player, Math.max(1, this.getPrestigeLevel(player)));
    }

    public int getPrestigeLevel(Player player) {
        Integer level = (Integer)player.getPersistentDataContainer().get(this.prestigeKey, PersistentDataType.INTEGER);
        if (level != null) {
            return Math.max(0, Math.min(MAX_PRESTIGE_LEVEL, level));
        }
        Byte legacy = (Byte)player.getPersistentDataContainer().get(this.prestigeKey, PersistentDataType.BYTE);
        if (legacy != null && legacy == 1) {
            return 1;
        }
        return 0;
    }

    public void setPrestigeLevel(Player player, int prestigeLevel) {
        if (player == null) {
            return;
        }
        int clamped = Math.max(0, Math.min(MAX_PRESTIGE_LEVEL, prestigeLevel));
        player.getPersistentDataContainer().set(this.prestigeKey, PersistentDataType.INTEGER, clamped);
    }

    public boolean canPrestige(Player player) {
        return this.getPrestigeLevel(player) < MAX_PRESTIGE_LEVEL && this.getLevel(player) >= this.getRequiredLevelForPrestige(player);
    }

    public int getRequiredLevelForPrestige(Player player) {
        return this.config.getPrestigeStart() + this.getPrestigeLevel(player);
    }

    public int getPrestigeCap(Player player) {
        return this.config.getPrestigeStart() + Math.max(0, Math.min(MAX_PRESTIGE_LEVEL, this.getPrestigeLevel(player)));
    }

    public int getExp(Player player) {
        Integer exp = (Integer)player.getPersistentDataContainer().get(this.expKey, PersistentDataType.INTEGER);
        return exp == null ? 0 : Math.max(0, exp);
    }

    public long getTotalExp(Player player) {
        Long exp = (Long)player.getPersistentDataContainer().get(this.expTotalKey, PersistentDataType.LONG);
        return exp == null ? 0L : Math.max(0L, exp);
    }

    public void setTotalExp(Player player, long amount) {
        if (player == null) {
            return;
        }
        player.getPersistentDataContainer().set(this.expTotalKey, PersistentDataType.LONG, Math.max(0L, amount));
    }

    public long addTotalExp(Player player, long amount) {
        if (player == null || amount <= 0L) {
            return player == null ? 0L : this.getTotalExp(player);
        }
        long updated = this.getTotalExp(player) + amount;
        this.setTotalExp(player, updated);
        return updated;
    }

    public long removeTotalExp(Player player, long amount) {
        if (player == null || amount <= 0L) {
            return player == null ? 0L : this.getTotalExp(player);
        }
        long updated = Math.max(0L, this.getTotalExp(player) - amount);
        this.setTotalExp(player, updated);
        return updated;
    }

    public void resetTotalExp(Player player) {
        this.setTotalExp(player, 0L);
    }

    public void setGlobalCap(int cap) {
        this.globalCap = Math.max(1, Math.min(this.config.getMaxLevel(), cap));
    }

    public int getGlobalCap() {
        return this.globalCap;
    }

    public void setLevel(Player player, int level) {
        int previousLevel = this.getLevel(player);
        int clamped = Math.max(1, Math.min(this.getCurrentLevelCap(), level));
        player.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, clamped);
        player.getPersistentDataContainer().set(this.expKey, PersistentDataType.INTEGER, 0);
        this.handleLevelThresholds(player, previousLevel, clamped, true);
    }

    public PlayerLevelConfig getConfig() {
        return this.config;
    }

    public int expNeededForNext(Player player) {
        int level = this.getLevel(player);
        if (level >= this.getCurrentLevelCap()) {
            return 0;
        }
        return this.expNeededForNextLevel(level, this.getCurrentLevelCap());
    }

    public long getTotalExpRequiredForLevel(int targetLevel) {
        int capped = Math.max(1, targetLevel);
        int maxLevel = Math.max(this.config.getMaxLevel(), capped);
        long total = 0L;
        for (int level = 1; level < capped; ++level) {
            total += this.expNeededForNextLevel(level, maxLevel);
        }
        return total;
    }

    public void addExp(Player player, int amount) {
        int exp;
        int needed;
        int level;
        if (amount <= 0) {
            return;
        }
        long total = this.getTotalExp(player) + (long)amount;
        player.getPersistentDataContainer().set(this.expTotalKey, PersistentDataType.LONG, total);
        int startingLevel = level = this.getLevel(player);
        int effectiveMax = this.getCurrentLevelCap();
        for (exp = this.getExp(player) + amount; level < effectiveMax && exp >= (needed = this.expNeededForNextLevel(level, effectiveMax)); exp -= needed) {
            int newLevel = ++level;
            this.showLevelUpTitle(player, newLevel);
            this.handleLevelThresholds(player, newLevel - 1, newLevel, true);
            effectiveMax = this.getCurrentLevelCap();
        }
        if (level >= effectiveMax) {
            exp = Math.min(exp, this.expNeededForNextLevel(level, effectiveMax));
            this.sendLevelCapMessage(player);
        }
        player.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, level);
        player.getPersistentDataContainer().set(this.expKey, PersistentDataType.INTEGER, exp);
    }

    private void sendLevelCapMessage(Player player) {
        long now = System.currentTimeMillis();
        Long lastSent = this.lastLevelCapMessageTimes.get(player.getUniqueId());
        if (lastSent != null && now - lastSent < LEVEL_CAP_MESSAGE_COOLDOWN_MILLIS) {
            return;
        }
        this.lastLevelCapMessageTimes.put(player.getUniqueId(), now);
        player.sendMessage(Lang.msg("level.cap", "&eYou have reached the current level cap."));
    }

    private void showLevelUpTitle(Player player, int newLevel) {
        String title = Lang.msg("level.up.title", "&6&l&n{level}").replace("{level}", String.valueOf(newLevel));
        String subtitle = Lang.msg("level.up.subtitle", "&7You are now level {level}").replace("{level}", String.valueOf(newLevel));
        int duration = this.plugin.getConfig().getInt("messages.level-up-duration", 40);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.sendTitle(Text.color(title), Text.color(subtitle), 10, duration, 10);
    }

    private void handleLevelThresholds(Player player, int previousLevel, int newLevel, boolean showRewardMessages) {
        if (player == null || newLevel <= previousLevel) {
            return;
        }
        for (int level = previousLevel + 1; level <= newLevel; ++level) {
            if (this.isMilestoneLevel(level)) {
                this.playMilestoneEffect(player, level);
            }
            Bukkit.broadcastMessage(Text.color("&7&l* &f&l" + player.getName() + " &7&lLEVELED UP - &f&l" + level + " &7&l*"));
            this.giveLevelRewards(player, level, showRewardMessages);
        }
    }

    private boolean isMilestoneLevel(int level) {
        for (int milestone : MILESTONE_LEVELS) {
            if (milestone == level) {
                return true;
            }
        }
        return false;
    }

    private void playMilestoneEffect(Player player, int level) {
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, player.getLocation().add(0.0, 1.0, 0.0), 30, 0.5, 0.5, 0.5, 0.05);
    }

    private void giveLevelRewards(Player player, int level, boolean showRewardMessages) {
        List<String> rewards = new ArrayList<String>();
        switch (level) {
            case 5 -> {
                this.giveFragment(player, ShardService.Tier.BASIC, 1);
                rewards.add("1x Basic Fragment");
            }
            case 15 -> {
                this.giveFragment(player, ShardService.Tier.BASIC, 5);
                rewards.add("5x Basic Fragment");
            }
            case 20 -> {
                this.giveContraband(player, "basic_cont", 2);
                rewards.add("2x Basic Contraband");
            }
            case 25 -> {
                this.giveFragment(player, ShardService.Tier.RARE, 2);
                rewards.add("2x Rare Fragment");
            }
            case 30 -> {
                this.giveContraband(player, "rare_cont", 1);
                rewards.add("1x Rare Contraband");
            }
            case 35 -> {
                this.giveFragment(player, ShardService.Tier.RARE, 5);
                rewards.add("5x Rare Fragment");
            }
            case 40 -> {
                this.giveContraband(player, "rare_cont", 2);
                rewards.add("2x Rare Contraband");
            }
            case 45 -> {
                this.giveFragment(player, ShardService.Tier.RARE, 5);
                rewards.add("5x Rare Fragment");
            }
            case 50 -> {
                this.giveContraband(player, "elite_cont", 1);
                rewards.add("1x Elite Contraband");
            }
            case 55 -> {
                this.giveFragment(player, ShardService.Tier.ELITE, 3);
                rewards.add("3x Elite Fragment");
            }
            case 60 -> {
                this.giveContraband(player, "elite_cont", 2);
                rewards.add("2x Elite Contraband");
            }
            case 65 -> {
                this.giveFragment(player, ShardService.Tier.ELITE, 5);
                rewards.add("5x Elite Fragment");
            }
            case 70 -> {
                this.giveContraband(player, "legendary_cont", 1);
                rewards.add("1x Legendary Contraband");
            }
            case 75 -> {
                this.giveFragment(player, ShardService.Tier.LEGENDARY, 5);
                rewards.add("5x Legendary Fragment");
            }
            case 80 -> {
                this.giveFragment(player, ShardService.Tier.LEGENDARY, 5);
                this.giveFragment(player, ShardService.Tier.ELITE, 3);
                rewards.add("5x Legendary Fragment");
                rewards.add("3x Elite Fragment");
            }
            case 85 -> {
                this.giveFragment(player, ShardService.Tier.LEGENDARY, 5);
                this.giveFragment(player, ShardService.Tier.ELITE, 3);
                rewards.add("5x Legendary Fragment");
                rewards.add("3x Elite Fragment");
            }
            case 90 -> {
                this.giveContraband(player, "legendary_cont", 3);
                rewards.add("3x Legendary Contraband");
            }
            case 95 -> {
                this.giveContraband(player, "legendary_cont", 3);
                this.giveContraband(player, "elite_cont", 2);
                rewards.add("3x Legendary Contraband");
                rewards.add("2x Elite Contraband");
            }
            case 100 -> {
                this.giveContraband(player, "legendary_cont", 5);
                this.giveContraband(player, "elite_cont", 3);
                rewards.add("5x Legendary Contraband");
                rewards.add("3x Elite Contraband");
            }
        }
    }

    private int expNeededForNextLevel(int level, int maxLevel) {
        if (level >= maxLevel) {
            return Integer.MAX_VALUE;
        }
        return (int)Math.round((double)this.config.getBaseExp() * Math.pow(this.config.getMultiplier(), level - 1));
    }

    private void giveContraband(Player player, String contrabandId, int amount) {
        if (amount <= 0) {
            return;
        }
        if (this.contrabandService == null) {
            this.plugin.getLogger().warning("Contraband service not available; unable to give " + contrabandId + " to " + player.getName());
            return;
        }
        ItemStack contraband = this.contrabandService.createContraband(contrabandId);
        if (contraband == null) {
            this.plugin.getLogger().warning("Contraband tier " + contrabandId + " not configured; unable to give level-up contraband to " + player.getName());
            return;
        }
        contraband.setAmount(Math.min(amount, contraband.getMaxStackSize()));
        this.giveItem(player, contraband);
        int remaining = amount - contraband.getAmount();
        while (remaining > 0) {
            ItemStack extra = this.contrabandService.createContraband(contrabandId);
            if (extra == null) {
                break;
            }
            extra.setAmount(Math.min(remaining, extra.getMaxStackSize()));
            this.giveItem(player, extra);
            remaining -= extra.getAmount();
        }
    }

    private void giveFragment(Player player, ShardService.Tier tier, int amount) {
        if (amount <= 0) {
            return;
        }
        if (this.shardService == null) {
            this.plugin.getLogger().warning("Shard service not available; unable to give " + tier.name() + " fragment(s) to " + player.getName());
            return;
        }
        ItemStack shard = this.shardService.createShard(tier);
        shard.setAmount(Math.min(amount, shard.getMaxStackSize()));
        this.giveItem(player, shard);
        int remaining = amount - shard.getAmount();
        while (remaining > 0) {
            ItemStack extra = this.shardService.createShard(tier);
            extra.setAmount(Math.min(remaining, extra.getMaxStackSize()));
            this.giveItem(player, extra);
            remaining -= extra.getAmount();
        }
    }

    private void giveItem(Player player, ItemStack item) {
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, item);
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
        for (ItemStack stack : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), stack);
        }
    }

    public void setContrabandService(ContrabandService contrabandService) {
        this.contrabandService = contrabandService;
    }

    public void setShardService(ShardService shardService) {
        this.shardService = shardService;
    }

    public int getEffectiveMaxLevel(Player player) {
        return this.getCurrentLevelCap();
    }

    public int getCurrentLevelCap() {
        int cap = this.globalCap;
        SeasonService seasonService = this.plugin.getSeasonService();
        if (seasonService != null) {
            cap = Math.min(cap, seasonService.getCurrentLevelCap());
        }
        return Math.max(1, cap);
    }

    public boolean claimPrestige(Player player) {
        if (player == null) {
            return false;
        }
        int currentPrestige = this.getPrestigeLevel(player);
        if (currentPrestige >= MAX_PRESTIGE_LEVEL) {
            return false;
        }
        int requiredLevel = this.config.getPrestigeStart() + currentPrestige;
        if (this.getLevel(player) < requiredLevel) {
            return false;
        }
        int claimedLevel = currentPrestige + 1;
        this.setPrestigeLevel(player, claimedLevel);
        this.setLevel(player, 1);
        this.resetTotalExp(player);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        Bukkit.broadcastMessage(Text.color("&6&l* &f&l" + player.getName() + " &6&lPRESTIGED - " + this.getPrestigeTag(claimedLevel) + " &6&l*"));
        this.givePrestigeRewards(player, claimedLevel);
        return true;
    }

    public String getPrestigeRomanNumeral(int level) {
        return switch (Math.max(1, Math.min(MAX_PRESTIGE_LEVEL, level))) {
            case 1 -> "I";
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            default -> "V";
        };
    }

    public String getPrestigeTag(int prestigeLevel) {
        return switch (Math.max(0, Math.min(MAX_PRESTIGE_LEVEL, prestigeLevel))) {
            case 1 -> "&d&l<&6&lI&d&l>";
            case 2 -> "&d&l<&6&lII&d&l>";
            case 3 -> "&d&l<&6&lIII&d&L>";
            case 4 -> "&d&l<&6&lIV&d&L>";
            case 5 -> "&d&L<&6&LV&d&l>";
            default -> "";
        };
    }

    public String getPrestigeTag(Player player) {
        return this.getPrestigeTag(this.getPrestigeLevel(player));
    }

    private void givePrestigeRewards(Player player, int claimedLevel) {
        this.giveContraband(player, "legendary_cont", 15);
        this.giveContraband(player, "elite_cont", 10);
        this.giveFragment(player, ShardService.Tier.LEGENDARY, 64);
        player.sendMessage(Text.color("&a&lPrestige " + this.getPrestigeRomanNumeral(claimedLevel) + " claimed."));
    }
}
