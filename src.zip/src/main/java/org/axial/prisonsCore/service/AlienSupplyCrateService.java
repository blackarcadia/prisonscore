package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Supplier;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.KitService.GKitType;
import org.axial.prisonsCore.model.PickaxeType;
import org.axial.prisonsCore.service.RankTokenService.RankType;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class AlienSupplyCrateService {
    private static final String CRATE_ID = "alien_supply_crate";
    private static final String KEY_ID = "alien_key";
    private static final String LOCKED = "locked";
    private static final String UNLOCKED = "unlocked";
    private final PrisonsCore plugin;
    private final NamespacedKey crateKey;
    private final NamespacedKey crateStateKey;
    private final NamespacedKey crateIdKey;
    private final NamespacedKey keyKey;
    private final List<RewardDefinition> rewards = new ArrayList<RewardDefinition>();

    public AlienSupplyCrateService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.crateKey = Keys.alienSupplyCrate(plugin);
        this.crateStateKey = Keys.alienSupplyCrateState(plugin);
        this.crateIdKey = Keys.alienSupplyCrateId(plugin);
        this.keyKey = Keys.alienKey(plugin);
        this.loadRewards();
    }

    public ItemStack createCrate(boolean unlocked) {
        ItemStack stack = new ItemStack(Material.CHEST);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        meta.setDisplayName(Text.color("&a&lAlien &2&lSupply Crate &7(" + (unlocked ? "Unlocked" : "Locked") + ")"));
        meta.setLore(this.buildLore(unlocked));
        meta.getPersistentDataContainer().set(this.crateKey, PersistentDataType.BYTE, (byte)1);
        meta.getPersistentDataContainer().set(this.crateStateKey, PersistentDataType.STRING, unlocked ? UNLOCKED : LOCKED);
        meta.getPersistentDataContainer().set(this.crateIdKey, PersistentDataType.STRING, UUID.randomUUID().toString());
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        this.applyGlint(meta);
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemStack createKey(int amount) {
        ItemStack stack = new ItemStack(Material.TRIPWIRE_HOOK, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        meta.setDisplayName(Text.color("&a&lAlien Supply Key"));
        meta.setLore(List.of(
                Text.color("&7Drag and Drop onto a"),
                Text.color("&7Locked &a&lAlien &2&lSupply Box"),
                Text.color("&7to unlock it.")
        ));
        meta.getPersistentDataContainer().set(this.keyKey, PersistentDataType.BYTE, (byte)1);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        this.applyGlint(meta);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isAlienSupplyCrate(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(this.crateKey, PersistentDataType.BYTE);
    }

    public boolean isAlienKey(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(this.keyKey, PersistentDataType.BYTE);
    }

    public boolean isLocked(ItemStack item) {
        String state = this.getState(item);
        return state == null || !UNLOCKED.equalsIgnoreCase(state);
    }

    public String getState(ItemStack item) {
        if (!this.isAlienSupplyCrate(item)) {
            return null;
        }
        return item.getItemMeta().getPersistentDataContainer().get(this.crateStateKey, PersistentDataType.STRING);
    }

    public ItemStack setUnlocked(ItemStack item) {
        if (!this.isAlienSupplyCrate(item)) {
            return item;
        }
        ItemStack copy = item.clone();
        ItemMeta meta = copy.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&a&lAlien &2&lSupply Crate &7(Unlocked)"));
            meta.setLore(this.buildLore(true));
            meta.getPersistentDataContainer().set(this.crateStateKey, PersistentDataType.STRING, UNLOCKED);
            if (!meta.getPersistentDataContainer().has(this.crateIdKey, PersistentDataType.STRING)) {
                meta.getPersistentDataContainer().set(this.crateIdKey, PersistentDataType.STRING, UUID.randomUUID().toString());
            }
            copy.setItemMeta(meta);
        }
        return copy;
    }

    public RewardRoll rollReward() {
        if (this.rewards.isEmpty()) {
            return null;
        }
        double total = 0.0D;
        for (RewardDefinition reward : this.rewards) {
            total += reward.weight();
        }
        if (total <= 0.0D) {
            return null;
        }
        double pick = this.plugin.getRandom().nextDouble() * total;
        double cursor = 0.0D;
        for (RewardDefinition reward : this.rewards) {
            cursor += reward.weight();
            if (pick <= cursor) {
                ItemStack item = reward.create();
                return new RewardRoll(reward, item);
            }
        }
        RewardDefinition fallback = this.rewards.get(this.rewards.size() - 1);
        return new RewardRoll(fallback, fallback.create());
    }

    public ItemStack previewItem(RewardRoll roll) {
        if (roll == null || roll.item() == null) {
            return new ItemStack(Material.BARRIER);
        }
        return roll.item().clone();
    }

    public void award(Player player, RewardRoll roll) {
        if (player == null || roll == null || roll.item() == null) {
            return;
        }
        ItemStack item = roll.item().clone();
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, item);
            return;
        }
        player.getInventory().addItem(item).values().forEach(leftover -> player.getWorld().dropItemNaturally(player.getLocation(), leftover));
    }

    public String rewardSummary(RewardRoll roll) {
        if (roll == null || roll.item() == null) {
            return "&cUnknown reward";
        }
        String name = this.displayNameOf(roll.item());
        if (roll.item().getAmount() > 1) {
            return name + Text.color(" &7x&f" + roll.item().getAmount());
        }
        return name;
    }

    public List<String> rewardLoreLines() {
        ArrayList<String> lines = new ArrayList<String>();
        for (RewardDefinition reward : this.rewards) {
            ItemStack preview = reward.create();
            String name = this.displayNameOf(preview);
            if (preview != null && preview.getAmount() > 1) {
                name += Text.color(" &7x&f" + preview.getAmount());
            }
            lines.add(Text.color("&a&l* " + name));
        }
        return lines;
    }

    private void loadRewards() {
        this.rewards.clear();
        this.rewards.add(new RewardDefinition("rank_vanguard", 1.0D, () -> this.plugin.getRankTokenService().createToken(RankType.VANGUARD)));
        this.rewards.add(new RewardDefinition("gkit_stormstride", 1.0D, () -> this.plugin.getKitService().createGKitToken(GKitType.STORMSTRIDE)));
        this.rewards.add(new RewardDefinition("gkit_ironhide", 1.0D, () -> this.plugin.getKitService().createGKitToken(GKitType.IRONHIDE)));
        this.rewards.add(new RewardDefinition("gkit_deepforge", 1.0D, () -> this.plugin.getKitService().createGKitToken(GKitType.DEEPFORGE)));
        this.rewards.add(new RewardDefinition("legendary_contraband", 1.0D, () -> this.randomSized(this.plugin.getContrabandService().createContraband("legendary_cont"), 5, 7)));
        this.rewards.add(new RewardDefinition("raw_charge", 1.0D, () -> this.plugin.getEnergyItemService().createEnergyItem(this.randomRange(100000, 10000000))));
        this.rewards.add(new RewardDefinition("turkey_mask", 1.0D, () -> this.maskItem("turkey")));
        this.rewards.add(new RewardDefinition("purge_mask", 1.0D, () -> this.maskItem("purge")));
        this.rewards.add(new RewardDefinition("excavator_mask", 1.0D, () -> this.maskItem("excavator")));
        this.rewards.add(new RewardDefinition("frozen_wastelands_powerbox", 1.0D, () -> this.plugin.getPowerboxService().createPowerbox("frozen_wastelands", 1)));
        this.rewards.add(new RewardDefinition("prison_coins", 1.0D, () -> this.plugin.getPrisonCoinService().createCoinToken(this.randomRange(10000, 20000))));
        this.rewards.add(new RewardDefinition("pickaxe_prestige_tokens", 1.0D, () -> this.createPrestigeTokens(this.randomRange(1, 5))));
        this.rewards.add(new RewardDefinition("meteor_flares", 1.0D, () -> this.createFlareStack(this.randomRange(1, 5))));
        this.rewards.add(new RewardDefinition("skin_box", 1.0D, () -> this.createSkinBoxStack(this.randomRange(1, 3))));
        this.rewards.add(new RewardDefinition("iron_pickaxe", 1.0D, () -> this.createHighLevelPickaxe("iron")));
        this.rewards.add(new RewardDefinition("diamond_pickaxe", 1.0D, () -> this.createHighLevelPickaxe("diamond")));
    }

    private ItemStack maskItem(String maskId) {
        if (this.plugin.getMaskModule() == null || this.plugin.getMaskModule().getMaskManager() == null) {
            return new ItemStack(Material.PLAYER_HEAD);
        }
        ItemStack stack = this.plugin.getMaskModule().getMaskManager().createMaskItem(maskId);
        return stack == null ? new ItemStack(Material.PLAYER_HEAD) : stack;
    }

    private ItemStack createFlareStack(int amount) {
        if (this.plugin.getMeteorService() == null) {
            return new ItemStack(Material.BLAZE_ROD);
        }
        ItemStack item = this.plugin.getMeteorService().createFlare(Math.max(1, amount));
        return item == null ? new ItemStack(Material.BLAZE_ROD) : item;
    }

    private ItemStack createSkinBoxStack(int amount) {
        if (this.plugin.getPowerboxService() == null) {
            return new ItemStack(Material.BEACON);
        }
        ItemStack item = this.plugin.getPowerboxService().createSkinBoxItem(Math.max(1, amount));
        return item == null ? new ItemStack(Material.BEACON) : item;
    }

    private ItemStack createPrestigeTokens(int amount) {
        ItemStack item = new ItemStack(Material.SUNFLOWER, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&6&lPickaxe Prestige Token"));
            meta.setLore(List.of(
                    Text.color("&7Right-click a prison pickaxe"),
                    Text.color("&7to unlock the prestige menu.")
            ));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            meta.setEnchantmentGlintOverride(Boolean.TRUE);
            meta.getPersistentDataContainer().set(Keys.pickaxePrestigeToken(this.plugin), PersistentDataType.BYTE, (byte)1);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createHighLevelPickaxe(String typeId) {
        if (this.plugin.getPickaxeManager() == null) {
            return new ItemStack(Material.DIAMOND_PICKAXE);
        }
        PickaxeType type = this.plugin.getPickaxeManager().getType(typeId);
        if (type == null) {
            return new ItemStack(Material.DIAMOND_PICKAXE);
        }
        ItemStack pickaxe = this.plugin.getPickaxeManager().createPickaxe(type, 0);
        int itemLevel = this.randomRange(30, 50);
        this.plugin.getPickaxeManager().setLevel(pickaxe, itemLevel);
        ItemMeta meta = pickaxe.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(null);
            pickaxe.setItemMeta(meta);
        }
        List<CustomEnchant> enchants = this.plugin.getCustomEnchantService() == null ? List.of() : this.plugin.getCustomEnchantService().pickRandomOptions(5);
        for (CustomEnchant enchant : enchants) {
            int enchantLevel = this.randomRange(1, Math.max(1, enchant.getMaxLevel()));
            this.plugin.getPickaxeManager().applyEnchant(pickaxe, enchant.getId(), enchantLevel, enchant.getMaxLevel());
        }
        meta = pickaxe.getItemMeta();
        if (meta != null) {
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            pickaxe.setItemMeta(meta);
        }
        return pickaxe;
    }

    private ItemStack randomSized(ItemStack item, int min, int max) {
        if (item == null) {
            return new ItemStack(Material.CHEST);
        }
        item.setAmount(this.randomRange(min, max));
        return item;
    }

    private String displayNameOf(ItemStack item) {
        if (item == null) {
            return "&fUnknown";
        }
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            return item.getItemMeta().getDisplayName();
        }
        return Text.color("&f" + item.getType().name().toLowerCase(Locale.ROOT).replace('_', ' '));
    }

    private List<String> buildLore(boolean unlocked) {
        ArrayList<String> lore = new ArrayList<String>();
        lore.add(Text.color("&7Open this supply crate to recieve"));
        lore.add(Text.color("&f1x &7Legendary reward from the loot below."));
        lore.add("");
        lore.add(Text.color("&7Contains:"));
        lore.addAll(this.rewardLoreLines());
        if (!unlocked) {
            lore.add("");
            lore.add(Text.color("&7Drag an &aAlien Key &7onto this crate to unlock it."));
        }
        return lore;
    }

    private int randomRange(int min, int max) {
        int safeMin = Math.max(1, min);
        int safeMax = Math.max(safeMin, max);
        if (safeMin == safeMax) {
            return safeMin;
        }
        return safeMin + this.plugin.getRandom().nextInt(safeMax - safeMin + 1);
    }

    private void applyGlint(ItemMeta meta) {
        if (meta == null) {
            return;
        }
        try {
            meta.setEnchantmentGlintOverride(Boolean.TRUE);
        } catch (Exception ignored) {
            Enchantment enchantment = Enchantment.getByName("DURABILITY");
            if (enchantment != null && !meta.hasEnchant(enchantment)) {
                meta.addEnchant(enchantment, 1, true);
            }
        }
    }

    public record RewardRoll(RewardDefinition reward, ItemStack item) {
    }

    public static final class RewardDefinition {
        private final String id;
        private final double weight;
        private final Supplier<ItemStack> supplier;

        public RewardDefinition(String id, double weight, Supplier<ItemStack> supplier) {
            this.id = id;
            this.weight = weight;
            this.supplier = supplier;
        }

        public String id() {
            return this.id;
        }

        public double weight() {
            return this.weight;
        }

        public ItemStack create() {
            if (this.supplier == null) {
                return null;
            }
            ItemStack item = this.supplier.get();
            return item == null ? null : item.clone();
        }
    }
}
