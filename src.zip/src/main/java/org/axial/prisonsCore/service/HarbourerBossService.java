package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Evoker;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.TextDisplay;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class HarbourerBossService implements Listener {
    private static final String PILLAR_NAME = "&d&lHarbourer Alter";
    private static final int RING_SEGMENTS = 12;
    private static final double RING_RADIUS = 2.35D;
    private static final double RING_HEIGHT = 0.85D;
    private static final double HOVER_HEIGHT = 4.0D;
    private static final double IDLE_BOB_AMPLITUDE = 0.28D;
    private static final double WANDER_RADIUS = 6.0D;
    private static final double WANDER_STEP = 0.12D;
    private static final int WANDER_RETARGET_MIN_TICKS = 35;
    private static final int WANDER_RETARGET_MAX_TICKS = 70;
    private static final double MAX_HEALTH = 500.0D;
    private static final double TARGET_RANGE = 32.0D;
    private static final double SHOCKWAVE_RADIUS = 14.0D;
    private static final double ATTACK_DAMAGE = 12.0D;
    private static final double ATTACK_DAMAGE_MULTIPLIER = 0.75D;
    private static final int ATTACK_COOLDOWN_TICKS = 80;
    private static final int SHOCKWAVE_COOLDOWN_TICKS = 200;
    private static final long VULNERABLE_WINDOW_MS = 10_000L;
    private static final int PILLAR_COUNT = 5;
    private static final int PILLAR_HEIGHT = 3;
    private static final int PILLAR_WIDTH = 2;
    private static final int PILLAR_LENGTH = 2;
    private static final int PILLAR_BLOCKS = PILLAR_HEIGHT * PILLAR_WIDTH * PILLAR_LENGTH;
    private static final double PILLAR_RING_RADIUS = 8.0D;
    private static final double PILLAR_HOLOGRAM_OFFSET = 1.6D;
    private static final double BOSS_HEALTH_OFFSET = 2.6D;
    private static final double MAX_ENTITY_HEALTH = 1024.0D;
    private static final double HARBOURER_SPAWN_MIN_RADIUS = 50.0D;
    private static final double HARBOURER_SPAWN_MAX_RADIUS = 96.0D;
    private static final int HARBOURER_SPAWN_ATTEMPTS = 96;
    private static final double HARBOURER_SPAWN_FALLBACK_MIN_RADIUS = 96.0D;
    private static final double HARBOURER_SPAWN_FALLBACK_MAX_RADIUS = 160.0D;
    private static final int HARBOURER_SPAWN_FALLBACK_ATTEMPTS = 128;
    private static final int AUTO_RESPAWN_MIN_MINUTES = 20;
    private static final int AUTO_RESPAWN_MAX_MINUTES = 45;
    private static final Particle.DustOptions PURPLE_DUST = new Particle.DustOptions(Color.fromRGB(180, 70, 255), 1.45f);
    private static final int[][] PILLAR_SHAPE = new int[][]{
            new int[]{0, 0, 0},
            new int[]{1, 0, 0},
            new int[]{0, 0, 1},
            new int[]{1, 0, 1},
            new int[]{0, 1, 0},
            new int[]{1, 1, 0},
            new int[]{2, 1, 0},
            new int[]{1, 1, 1},
            new int[]{0, 2, 0},
            new int[]{1, 2, 0},
            new int[]{2, 2, 0},
            new int[]{1, 2, 1}
    };
    private static final List<Material> PILLAR_ORES = List.of(
            Material.COAL_ORE,
            Material.IRON_ORE
    );

    private final PrisonsCore plugin;
    private final List<ItemDisplay> ringDisplays = new ArrayList<ItemDisplay>();
    private final List<Pillar> pillars = new ArrayList<Pillar>();
    private final Map<String, Pillar> pillarLookup = new HashMap<String, Pillar>();
    private final Map<UUID, Double> damageByPlayer = new LinkedHashMap<UUID, Double>();
    private UUID harbourerId;
    private Location anchorLocation;
    private Location wanderTarget;
    private HarbourerVariant variant = HarbourerVariant.IRON;
    private TextDisplay healthDisplay;
    private BukkitTask tickTask;
    private BukkitTask beamTask;
    private BukkitTask respawnTask;
    private double ringAngle;
    private long tickCounter;
    private int wanderTicksRemaining;
    private int attackCooldownTicks;
    private int shockwaveCooldownTicks;
    private long vulnerableUntilMillis;
    private double harbourerHealth;
    private double harbourerMaxHealth;
    private long nextSpawnAtMillis;
    private HarbourerVariant nextSpawnVariant;

    public HarbourerBossService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.scheduleNextHarbourerSpawn();
    }

    public synchronized Evoker spawnHarbourer(Location location) {
        return this.spawnHarbourer(location, HarbourerVariant.IRON);
    }

    public synchronized Evoker spawnHarbourer(Location location, HarbourerVariant variant) {
        HarbourerVariant resolvedVariant = variant == null ? HarbourerVariant.IRON : variant;
        Location spawnAnchor = this.resolveSpawnAnchor(location, resolvedVariant);
        if (spawnAnchor == null || spawnAnchor.getWorld() == null) {
            return null;
        }
        double maxHealth = resolvedVariant.maxHealth();
        double spawnHealth = Math.min(maxHealth, MAX_ENTITY_HEALTH);
        this.cancelNextHarbourerSpawn();
        this.clearCurrentHarbourer();
        this.harbourerMaxHealth = maxHealth;
        this.harbourerHealth = maxHealth;
        World world = spawnAnchor.getWorld();
        Location spawn = spawnAnchor.clone();
        Evoker boss = (Evoker)world.spawn(spawn, Evoker.class, evoker -> {
            evoker.setCustomName(Text.color(resolvedVariant.displayName()));
            evoker.setCustomNameVisible(true);
            evoker.setAI(false);
            evoker.setGravity(false);
            evoker.setSilent(true);
            evoker.setCollidable(false);
            evoker.setRemoveWhenFarAway(false);
            evoker.setPersistent(true);
            evoker.getPersistentDataContainer().set(Keys.harbourerBoss(this.plugin), PersistentDataType.BYTE, (byte)1);
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance healthAttribute = maxHealthAttribute != null ? evoker.getAttribute(maxHealthAttribute) : null;
            if (healthAttribute != null) {
                healthAttribute.setBaseValue(spawnHealth);
            }
            evoker.setHealth(spawnHealth);
            if (evoker.getEquipment() != null) {
                evoker.getEquipment().clear();
                evoker.getEquipment().setItemInMainHand(new ItemStack(Material.AIR));
                evoker.getEquipment().setItemInOffHand(new ItemStack(Material.AIR));
            }
        });
        this.harbourerId = boss.getUniqueId();
        this.anchorLocation = spawn.clone();
        this.wanderTarget = null;
        this.variant = resolvedVariant;
        this.ringAngle = 0.0D;
        this.tickCounter = 0L;
        this.wanderTicksRemaining = 0;
        this.attackCooldownTicks = 0;
        this.shockwaveCooldownTicks = SHOCKWAVE_COOLDOWN_TICKS;
        this.vulnerableUntilMillis = 0L;
        this.damageByPlayer.clear();
        this.spawnPillars(spawn);
        this.spawnRing(boss.getLocation(), resolvedVariant.ringMaterial());
        this.spawnHealthDisplay(boss.getLocation());
        this.updateRing(boss.getLocation());
        this.updateHealthDisplay(boss.getLocation(), this.harbourerHealth);
        this.broadcastSpawnMessage(spawn, resolvedVariant);
        this.startTask();
        return boss;
    }

    public synchronized boolean isActive() {
        return this.getHarbourerEntity() != null;
    }

    public synchronized long getNextSpawnAtMillis() {
        return this.nextSpawnAtMillis;
    }

    public synchronized long getTimeUntilNextSpawnMillis() {
        if (this.nextSpawnAtMillis <= 0L) {
            return -1L;
        }
        return Math.max(0L, this.nextSpawnAtMillis - System.currentTimeMillis());
    }

    public synchronized HarbourerVariant getNextSpawnVariant() {
        return this.nextSpawnVariant;
    }

    public synchronized Location getAnchorLocation() {
        return this.anchorLocation == null ? null : this.anchorLocation.clone();
    }

    public synchronized HarbourerVariant getVariant() {
        return this.variant;
    }

    public synchronized boolean hasBrokenAllPillars() {
        return !this.pillars.isEmpty() && this.pillars.stream().allMatch(pillar -> pillar.broken);
    }

    public synchronized boolean isVulnerable() {
        return this.hasBrokenAllPillars() || System.currentTimeMillis() <= this.vulnerableUntilMillis;
    }

    public synchronized String formatCoordinates(Location location) {
        if (location == null) {
            return "&7(unknown)";
        }
        return "&7(" + Math.round(location.getX()) + ", " + Math.round(location.getY()) + ", " + Math.round(location.getZ()) + ")";
    }

    public String formatDuration(long millis) {
        long safeMillis = Math.max(0L, millis);
        long totalSeconds = safeMillis / 1000L;
        long hours = totalSeconds / 3600L;
        long minutes = totalSeconds % 3600L / 60L;
        long seconds = totalSeconds % 60L;
        if (hours > 0L) {
            return hours + "h " + minutes + "m " + seconds + "s";
        }
        if (minutes > 0L) {
            return minutes + "m " + seconds + "s";
        }
        return seconds + "s";
    }

    public synchronized boolean handlePillarBreak(BlockBreakEvent event) {
        if (event == null) {
            return false;
        }
        return this.handlePillarMine(event.getBlock());
    }

    public synchronized boolean isPillarBlock(Block block) {
        if (block == null || block.getLocation().getWorld() == null) {
            return false;
        }
        Pillar pillar = this.pillarLookup.get(this.blockKey(block.getLocation()));
        return pillar != null && !pillar.broken;
    }

    public synchronized boolean handlePillarMine(Block block) {
        if (block == null || block.getLocation().getWorld() == null) {
            return false;
        }
        Pillar pillar = this.pillarLookup.get(this.blockKey(block.getLocation()));
        if (pillar == null || pillar.broken || block.getType() == Material.AIR) {
            return false;
        }
        if (pillar.breakBlock(block.getLocation())) {
            this.applyPillarBreakVulnerability();
            this.updatePillarDisplay(pillar);
            if (pillar.broken) {
                this.removePillarVisuals(pillar);
            }
            return true;
        }
        return false;
    }

    public synchronized void despawnHarbourer() {
        this.clearCurrentHarbourer();
        this.scheduleNextHarbourerSpawn();
    }

    public synchronized void shutdown() {
        this.cancelNextHarbourerSpawn();
        this.clearCurrentHarbourer();
    }

    @EventHandler
    public synchronized void onBossDeath(EntityDeathEvent event) {
        Entity entity = event.getEntity();
        if (this.harbourerId != null && entity.getUniqueId().equals(this.harbourerId)) {
            this.handleHarbourerDefeat();
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public synchronized void onBossDamage(EntityDamageByEntityEvent event) {
        Entity entity = event.getEntity();
        if (this.harbourerId == null || !entity.getUniqueId().equals(this.harbourerId)) {
            return;
        }
        if (this.isBossDamageSource(event.getDamager())) {
            if (!this.isVulnerable()) {
                event.setCancelled(true);
                return;
            }
            Player dealer = this.resolveDamageDealer(event.getDamager());
            if (dealer != null) {
                this.damageByPlayer.merge(dealer.getUniqueId(), Math.max(0.0D, event.getFinalDamage()), Double::sum);
            }
            event.setCancelled(true);
            this.applyHarbourerDamage(Math.max(0.0D, event.getFinalDamage()));
            return;
        }
        event.setCancelled(true);
    }

    private boolean isBossDamageSource(Entity damager) {
        if (damager instanceof Player) {
            return true;
        }
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player) {
            return true;
        }
        return false;
    }

    private Player resolveDamageDealer(Entity damager) {
        if (damager instanceof Player player) {
            return player;
        }
        if (damager instanceof Projectile projectile && projectile.getShooter() instanceof Player player) {
            return player;
        }
        return null;
    }

    private void startTask() {
        this.stopTask();
        this.tickTask = Bukkit.getScheduler().runTaskTimer(this.plugin, this::tick, 1L, 1L);
    }

    private double getAttackDamage() {
        HarbourerVariant active = this.variant == null ? HarbourerVariant.IRON : this.variant;
        return ATTACK_DAMAGE * active.attackMultiplier() * ATTACK_DAMAGE_MULTIPLIER;
    }

    private void stopTask() {
        if (this.tickTask != null) {
            this.tickTask.cancel();
            this.tickTask = null;
        }
    }

    private void clearCurrentHarbourer() {
        this.stopTask();
        this.removeBeamTask();
        this.removeRing();
        this.removeHealthDisplay();
        this.removePillars();
        Entity boss = this.getHarbourerEntity();
        if (boss != null && !boss.isDead()) {
            boss.remove();
        }
        this.harbourerId = null;
        this.anchorLocation = null;
        this.wanderTarget = null;
        this.variant = HarbourerVariant.IRON;
        this.ringAngle = 0.0D;
        this.tickCounter = 0L;
        this.wanderTicksRemaining = 0;
        this.attackCooldownTicks = 0;
        this.shockwaveCooldownTicks = SHOCKWAVE_COOLDOWN_TICKS;
        this.vulnerableUntilMillis = 0L;
        this.damageByPlayer.clear();
        this.harbourerHealth = 0.0D;
        this.harbourerMaxHealth = 0.0D;
    }

    private void scheduleNextHarbourerSpawn() {
        this.cancelNextHarbourerSpawn();
        int minutes = ThreadLocalRandom.current().nextInt(AUTO_RESPAWN_MIN_MINUTES, AUTO_RESPAWN_MAX_MINUTES + 1);
        long delayMillis = minutes * 60_000L;
        this.nextSpawnAtMillis = System.currentTimeMillis() + delayMillis;
        this.nextSpawnVariant = this.pickRandomVariant();
        long delayTicks = minutes * 60L * 20L;
        this.respawnTask = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
            synchronized (HarbourerBossService.this) {
                HarbourerBossService.this.respawnTask = null;
                if (HarbourerBossService.this.isActive()) {
                    return;
                }
                HarbourerVariant scheduledVariant = HarbourerBossService.this.nextSpawnVariant == null ? HarbourerVariant.IRON : HarbourerBossService.this.nextSpawnVariant;
                HarbourerBossService.this.nextSpawnAtMillis = 0L;
                HarbourerBossService.this.nextSpawnVariant = null;
                if (HarbourerBossService.this.spawnHarbourer(null, scheduledVariant) == null) {
                    HarbourerBossService.this.scheduleNextHarbourerSpawn();
                }
            }
        }, delayTicks);
    }

    private void cancelNextHarbourerSpawn() {
        if (this.respawnTask != null) {
            this.respawnTask.cancel();
            this.respawnTask = null;
        }
        this.nextSpawnAtMillis = 0L;
        this.nextSpawnVariant = null;
    }

    private HarbourerVariant pickRandomVariant() {
        HarbourerVariant[] variants = HarbourerVariant.values();
        return variants[ThreadLocalRandom.current().nextInt(variants.length)];
    }

    private void removeBeamTask() {
        if (this.beamTask != null) {
            this.beamTask.cancel();
            this.beamTask = null;
        }
    }

    private void tick() {
        Evoker boss = this.getHarbourerEntity();
        if (boss == null || boss.isDead() || !boss.isValid()) {
            this.despawnHarbourer();
            return;
        }
        if (this.harbourerHealth <= 0.0D) {
            this.handleHarbourerDefeat();
            return;
        }
        ++this.tickCounter;
        Location patrolCenter = this.anchorLocation != null ? this.anchorLocation.clone() : boss.getLocation().clone();
        Location current = boss.getLocation().clone();
        if (this.wanderTarget == null || this.wanderTicksRemaining <= 0 || this.wanderTarget.getWorld() == null || !this.wanderTarget.getWorld().equals(current.getWorld()) || current.distanceSquared(this.wanderTarget) < 1.5D) {
            this.wanderTarget = this.pickWanderTarget(patrolCenter);
            this.wanderTicksRemaining = ThreadLocalRandom.current().nextInt(WANDER_RETARGET_MIN_TICKS, WANDER_RETARGET_MAX_TICKS + 1);
        } else {
            --this.wanderTicksRemaining;
        }
        Location base = this.stepToward(current, this.wanderTarget, WANDER_STEP);
        base = this.hoverAtGroundHeight(base);
        Player targetPlayer = this.findNearestPlayer(base, TARGET_RANGE * TARGET_RANGE);
        if (targetPlayer != null) {
            boss.setTarget(targetPlayer);
            base.setYaw(this.yawTo(base, targetPlayer.getLocation()));
        } else {
            boss.setTarget(null);
        }
        base = this.applyIdleBob(base);
        boss.setVelocity(new Vector());
        boss.teleport(base);
        this.updateRing(base);
        this.updatePillars(boss, base);
        this.updateHealthDisplay(base, this.harbourerHealth);
        this.tickAttack(boss, targetPlayer);
        this.tickShockwave(boss);
    }

    private void tickAttack(Evoker boss, Player target) {
        if (this.attackCooldownTicks > 0) {
            --this.attackCooldownTicks;
        }
        if (target == null || this.attackCooldownTicks > 0) {
            return;
        }
        this.attackCooldownTicks = ATTACK_COOLDOWN_TICKS;
        this.startBeamAttack(boss, target);
    }

    private void tickShockwave(Evoker boss) {
        if (this.shockwaveCooldownTicks > 0) {
            --this.shockwaveCooldownTicks;
            return;
        }
        this.shockwaveCooldownTicks = SHOCKWAVE_COOLDOWN_TICKS;
        this.shockwave(boss);
    }

    private void startBeamAttack(Evoker boss, Player target) {
        this.removeBeamTask();
        this.beamTask = new BukkitRunnable() {
            private int ticks;

            @Override
            public void run() {
                Evoker currentBoss = HarbourerBossService.this.getHarbourerEntity();
                Player currentTarget = target != null && target.isOnline() && !target.isDead() ? target : null;
                if (currentBoss == null || currentBoss.isDead() || currentTarget == null || currentTarget.isDead()) {
                    if (currentBoss != null && !currentBoss.isDead()) {
                        currentBoss.setCurrentSpell(Evoker.Spell.NONE);
                    }
                    HarbourerBossService.this.removeBeamTask();
                    this.cancel();
                    return;
                }
                Location start = currentBoss.getLocation().clone().add(0.0D, 1.25D, 0.0D);
                Location end = currentTarget.getLocation().clone().add(0.0D, 1.0D, 0.0D);
                if (this.ticks == 0) {
                    currentBoss.setSpell(org.bukkit.entity.Spellcaster.Spell.FANGS);
                    currentBoss.setCurrentSpell(Evoker.Spell.FANGS);
                }
                HarbourerBossService.this.spawnBeamLine(start, end);
                if (this.ticks == 0) {
                    currentBoss.getWorld().playSound(start, Sound.ENTITY_EVOKER_PREPARE_ATTACK, 1.0f, 0.8f);
                }
                ++this.ticks;
                if (this.ticks < 8) {
                    return;
                }
                double distanceSquared = currentBoss.getLocation().distanceSquared(currentTarget.getLocation());
                if (distanceSquared <= TARGET_RANGE * TARGET_RANGE) {
                    currentTarget.damage(HarbourerBossService.this.getAttackDamage(), currentBoss);
                }
                currentBoss.getWorld().playSound(start, Sound.ENTITY_EVOKER_CAST_SPELL, 1.0f, 0.7f);
                currentBoss.setSpell(org.bukkit.entity.Spellcaster.Spell.NONE);
                currentBoss.setCurrentSpell(Evoker.Spell.NONE);
                HarbourerBossService.this.removeBeamTask();
                this.cancel();
            }
        }.runTaskTimer(this.plugin, 0L, 1L);
    }

    private void shockwave(Evoker boss) {
        if (boss == null || boss.isDead() || boss.getWorld() == null) {
            return;
        }
        World world = boss.getWorld();
        Location source = boss.getLocation().clone().add(0.0D, 1.0D, 0.0D);
        world.playSound(source, Sound.ENTITY_WITHER_SHOOT, 1.0f, 1.6f);
        world.spawnParticle(Particle.DUST, source, 140, 3.5D, 1.2D, 3.5D, 0.0D, PURPLE_DUST);
        for (Pillar pillar : this.pillars) {
            if (pillar.broken) {
                continue;
            }
            Location center = pillar.linkPoint();
            world.spawnParticle(Particle.DUST, center, 60, 1.2D, 0.8D, 1.2D, 0.0D, PURPLE_DUST);
        }
        for (Player player : world.getPlayers()) {
            if (player == null || !player.isOnline() || player.isDead()) {
                continue;
            }
            if (player.getLocation().distanceSquared(source) > SHOCKWAVE_RADIUS * SHOCKWAVE_RADIUS) {
                continue;
            }
            Vector push = new Vector();
            push = push.add(this.repulsion(player.getLocation(), source, 0.9D));
            for (Pillar pillar : this.pillars) {
                if (pillar.broken) {
                    continue;
                }
                push = push.add(this.repulsion(player.getLocation(), pillar.linkPoint(), 0.55D));
            }
            if (push.lengthSquared() > 0.0D) {
                push.setY(Math.max(push.getY(), 0.38D));
                player.setVelocity(push.normalize().multiply(1.25D));
            }
        }
    }

    private Vector repulsion(Location from, Location source, double strength) {
        if (from == null || source == null || from.getWorld() == null || source.getWorld() == null || !from.getWorld().equals(source.getWorld())) {
            return new Vector();
        }
        double dx = from.getX() - source.getX();
        double dz = from.getZ() - source.getZ();
        double distance = Math.sqrt(dx * dx + dz * dz);
        if (distance < 0.01D) {
            return new Vector(0.0D, 0.0D, 0.0D);
        }
        double scale = strength / Math.max(1.0D, distance);
        return new Vector(dx / distance * scale, 0.0D, dz / distance * scale);
    }

    private void spawnPillars(Location bossLocation) {
        this.removePillars();
        if (bossLocation == null || bossLocation.getWorld() == null) {
            return;
        }
        World world = bossLocation.getWorld();
        for (int i = 0; i < PILLAR_COUNT; ++i) {
            double angle = (Math.PI * 2.0D / (double)PILLAR_COUNT) * (double)i - Math.PI / 2.0D;
            int blockX = (int)Math.round(bossLocation.getX() + Math.cos(angle) * PILLAR_RING_RADIUS);
            int blockZ = (int)Math.round(bossLocation.getZ() + Math.sin(angle) * PILLAR_RING_RADIUS);
            int groundY = this.findPillarBaseY(world, blockX, blockZ, i);
            Pillar pillar = new Pillar("pillar-" + i, new Location(world, blockX, groundY, blockZ), this.randomOreBlocks(world, blockX, groundY, blockZ, i));
            pillar.spawn(world);
            this.pillars.add(pillar);
            for (PillarBlock block : pillar.blocks) {
                this.pillarLookup.put(this.blockKey(block.location), pillar);
            }
        }
    }

    private int findPillarBaseY(World world, int originX, int originZ, int rotation) {
        int highestY = Integer.MIN_VALUE;
        for (int[] offset : PILLAR_SHAPE) {
            int x = offset[0];
            int z = offset[2];
            int rotatedX = x;
            int rotatedZ = z;
            switch (Math.floorMod(rotation, 4)) {
                case 1 -> {
                    rotatedX = z;
                    rotatedZ = 2 - x;
                }
                case 2 -> {
                    rotatedX = 2 - x;
                    rotatedZ = 2 - z;
                }
                case 3 -> {
                    rotatedX = 2 - z;
                    rotatedZ = x;
                }
                default -> {
                }
            }
            highestY = Math.max(highestY, world.getHighestBlockYAt(originX + rotatedX, originZ + rotatedZ));
        }
        return highestY + 1;
    }

    private List<PillarBlock> randomOreBlocks(World world, int originX, int originY, int originZ, int rotation) {
        List<PillarBlock> blocks = new ArrayList<PillarBlock>();
        for (int[] offset : PILLAR_SHAPE) {
            int x = offset[0];
            int y = offset[1];
            int z = offset[2];
            int rotatedX = x;
            int rotatedZ = z;
            switch (Math.floorMod(rotation, 4)) {
                case 1 -> {
                    rotatedX = z;
                    rotatedZ = 2 - x;
                }
                case 2 -> {
                    rotatedX = 2 - x;
                    rotatedZ = 2 - z;
                }
                case 3 -> {
                    rotatedX = 2 - z;
                    rotatedZ = x;
                }
                default -> {
                }
            }
            Location location = new Location(world, originX + rotatedX, originY + y, originZ + rotatedZ);
            int oreIndex = Math.floorMod(rotatedX + y + rotatedZ, PILLAR_ORES.size());
            blocks.add(new PillarBlock(location, this.randomOre(oreIndex)));
        }
        return blocks;
    }

    private Material randomOre(int index) {
        return PILLAR_ORES.get(Math.floorMod(index, PILLAR_ORES.size()));
    }

    private void updatePillars(Evoker boss, Location bossLocation) {
        if (boss == null || bossLocation == null || bossLocation.getWorld() == null) {
            return;
        }
        for (Pillar pillar : this.pillars) {
            if (pillar.broken) {
                continue;
            }
            this.updatePillarDisplay(pillar);
            this.drawPillarLink(bossLocation, pillar);
        }
    }

    private void drawPillarLink(Location bossLocation, Pillar pillar) {
        if (bossLocation == null || pillar == null || pillar.broken || bossLocation.getWorld() == null) {
            return;
        }
        this.spawnBeamLine(pillar.linkPoint(), bossLocation.clone().add(0.0D, 1.1D, 0.0D));
    }

    private void spawnBeamLine(Location start, Location end) {
        if (start == null || end == null || start.getWorld() == null || end.getWorld() == null || !start.getWorld().equals(end.getWorld())) {
            return;
        }
        World world = start.getWorld();
        Vector step = end.clone().subtract(start).toVector();
        double distance = step.length();
        if (distance < 0.01D) {
            return;
        }
        step.normalize().multiply(0.45D);
        Location cursor = start.clone();
        int points = Math.max(1, (int)Math.ceil(distance / 0.45D));
        for (int i = 0; i <= points; ++i) {
            world.spawnParticle(Particle.DUST, cursor.getX(), cursor.getY(), cursor.getZ(), 1, 0.0D, 0.0D, 0.0D, 0.0D, PURPLE_DUST);
            cursor.add(step);
        }
    }

    private void updatePillarDisplay(Pillar pillar) {
        if (pillar == null || pillar.display == null || pillar.display.isDead()) {
            return;
        }
        String bar = this.progressBar(pillar.remainingBlocks, pillar.totalBlocks);
        pillar.display.setText(Text.color(PILLAR_NAME + "\n&7" + bar));
        pillar.display.teleport(pillar.hologramLocation());
    }

    private String progressBar(int remaining, int total) {
        int filled = total <= 0 ? 0 : (int)Math.round((double)remaining / (double)total * 12.0D);
        StringBuilder builder = new StringBuilder(24);
        for (int i = 0; i < filled; ++i) {
            builder.append("&d|");
        }
        for (int i = filled; i < 12; ++i) {
            builder.append("&7|");
        }
        return builder.toString();
    }

    private void applyPillarBreakVulnerability() {
        long now = System.currentTimeMillis();
        this.vulnerableUntilMillis = Math.max(this.vulnerableUntilMillis, now + VULNERABLE_WINDOW_MS);
        if (this.hasBrokenAllPillars()) {
            this.vulnerableUntilMillis = Long.MAX_VALUE;
        }
    }

    private void spawnRing(Location center, Material ringMaterial) {
        this.removeRing();
        if (center == null || center.getWorld() == null) {
            return;
        }
        ItemStack item = new ItemStack(ringMaterial == null ? Material.WHITE_STAINED_GLASS_PANE : ringMaterial);
        for (int i = 0; i < RING_SEGMENTS; ++i) {
            final int ringIndex = i;
            ItemDisplay display = (ItemDisplay)center.getWorld().spawn(center, ItemDisplay.class, spawned -> {
                spawned.setItemStack(item);
                spawned.setGlowing(true);
                spawned.setGlowColorOverride(Color.WHITE);
                spawned.setBillboard(Display.Billboard.CENTER);
                spawned.setSilent(true);
                spawned.setGravity(false);
                spawned.setInvulnerable(true);
                spawned.setPersistent(false);
                spawned.setInterpolationDuration(1);
                spawned.setInterpolationDelay(0);
                spawned.setBrightness(new Display.Brightness(15, 15));
                spawned.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0.65f, 0.65f, 0.65f), new Quaternionf()));
                try {
                    spawned.getClass().getMethod("setItemDisplayTransform", ItemDisplay.ItemDisplayTransform.class).invoke(spawned, ItemDisplay.ItemDisplayTransform.FIXED);
                }
                catch (ReflectiveOperationException ignored) {
                }
                spawned.getPersistentDataContainer().set(Keys.harbourerRing(this.plugin), PersistentDataType.INTEGER, Integer.valueOf(ringIndex));
            });
            this.ringDisplays.add(display);
        }
    }

    private void updateRing(Location center) {
        if (center == null || center.getWorld() == null) {
            return;
        }
        if (this.ringDisplays.isEmpty()) {
            return;
        }
        double step = (Math.PI * 2.0D) / (double)this.ringDisplays.size();
        this.ringAngle += 0.08D;
        for (int i = 0; i < this.ringDisplays.size(); ++i) {
            ItemDisplay display = this.ringDisplays.get(i);
            if (display == null || display.isDead() || !display.isValid()) {
                continue;
            }
            double angle = this.ringAngle + step * (double)i;
            double x = center.getX() + Math.cos(angle) * RING_RADIUS;
            double z = center.getZ() + Math.sin(angle) * RING_RADIUS;
            double y = center.getY() + RING_HEIGHT + Math.sin(angle * 2.0D) * 0.12D;
            display.teleport(new Location(center.getWorld(), x, y, z, center.getYaw(), 0.0f));
        }
    }

    private void removeRing() {
        for (ItemDisplay display : this.ringDisplays) {
            if (display != null && !display.isDead()) {
                display.remove();
            }
        }
        this.ringDisplays.clear();
    }

    private void spawnHealthDisplay(Location center) {
        this.removeHealthDisplay();
        if (center == null || center.getWorld() == null) {
            return;
        }
        this.healthDisplay = (TextDisplay)center.getWorld().spawn(center.clone().add(0.0D, BOSS_HEALTH_OFFSET, 0.0D), TextDisplay.class, td -> {
            td.setBillboard(Display.Billboard.CENTER);
            td.setShadowed(true);
            td.setDefaultBackground(false);
            td.setBackgroundColor(Color.fromARGB(0));
            td.setPersistent(false);
            td.setInterpolationDuration(1);
            td.setInterpolationDelay(0);
        });
    }

    private void updateHealthDisplay(Location center, double health) {
        if (this.healthDisplay == null || this.healthDisplay.isDead() || !this.healthDisplay.isValid()) {
            return;
        }
        this.healthDisplay.teleport(center.clone().add(0.0D, BOSS_HEALTH_OFFSET, 0.0D));
        double maxHealth = this.harbourerMaxHealth > 0.0D ? this.harbourerMaxHealth : this.variant == null ? MAX_HEALTH : this.variant.maxHealth();
        this.healthDisplay.setText(Text.color("&c&l" + (int)Math.ceil(health) + " &7/ &f" + (int)Math.ceil(maxHealth) + " &c❤"));
    }

    private void removeHealthDisplay() {
        if (this.healthDisplay != null && !this.healthDisplay.isDead()) {
            this.healthDisplay.remove();
        }
        this.healthDisplay = null;
    }

    private void broadcastSpawnMessage(Location spawn, HarbourerVariant variant) {
        if (spawn == null || spawn.getWorld() == null || variant == null) {
            return;
        }
        String article = this.startsWithVowel(variant.plainName()) ? "An" : "A";
        Bukkit.broadcastMessage(Text.color("&7&l(!) " + article + " " + variant.displayName() + " has spawned at " + this.formatCoordinates(spawn)));
        Bukkit.broadcastMessage(Text.color("&7Defeat it to unlock legendary rewards and contraband!"));
    }

    private Location resolveSpawnAnchor(Location location, HarbourerVariant variant) {
        if (variant != null) {
            Location warp = this.plugin.getTeleportService() == null ? null : this.plugin.getTeleportService().getWarp(variant.id());
            if (warp != null && warp.getWorld() != null) {
                Location spawn = this.findHarbourerSpawnLocation(warp, HARBOURER_SPAWN_MIN_RADIUS, HARBOURER_SPAWN_MAX_RADIUS, HARBOURER_SPAWN_ATTEMPTS);
                if (spawn != null) {
                    return spawn;
                }
                spawn = this.findHarbourerSpawnLocation(warp, HARBOURER_SPAWN_FALLBACK_MIN_RADIUS, HARBOURER_SPAWN_FALLBACK_MAX_RADIUS, HARBOURER_SPAWN_FALLBACK_ATTEMPTS);
                if (spawn != null) {
                    return spawn;
                }
                this.plugin.getLogger().warning("Unable to find a valid Harbourer spawn near warp " + variant.id() + ".");
                return null;
            }
        }
        Location spawn = this.plugin.getTeleportService() == null ? null : this.plugin.getTeleportService().getSpawn();
        if (spawn != null && spawn.getWorld() != null) {
            Location candidate = this.findHarbourerSpawnLocation(spawn, HARBOURER_SPAWN_MIN_RADIUS, HARBOURER_SPAWN_MAX_RADIUS, HARBOURER_SPAWN_ATTEMPTS);
            if (candidate != null) {
                return candidate;
            }
        }
        if (location != null && location.getWorld() != null) {
            Location candidate = this.findHarbourerSpawnLocation(location, HARBOURER_SPAWN_MIN_RADIUS, HARBOURER_SPAWN_MAX_RADIUS, HARBOURER_SPAWN_ATTEMPTS);
            if (candidate != null) {
                return candidate;
            }
        }
        if (!Bukkit.getWorlds().isEmpty()) {
            World fallbackWorld = Bukkit.getWorlds().get(0);
            if (fallbackWorld != null) {
                Location candidate = this.findHarbourerSpawnLocation(fallbackWorld.getSpawnLocation(), HARBOURER_SPAWN_MIN_RADIUS, HARBOURER_SPAWN_MAX_RADIUS, HARBOURER_SPAWN_ATTEMPTS);
                if (candidate != null) {
                    return candidate;
                }
            }
        }
        this.plugin.getLogger().warning("Unable to resolve a Harbourer spawn anchor. Check that the configured prison world or warps exist.");
        return null;
    }

    private Location findHarbourerSpawnLocation(Location center, double minRadius, double maxRadius, int attempts) {
        if (center == null || center.getWorld() == null) {
            return null;
        }
        ThreadLocalRandom random = ThreadLocalRandom.current();
        int tries = Math.max(1, attempts);
        double min = Math.max(0.0D, minRadius);
        double max = Math.max(min, maxRadius);
        for (int i = 0; i < tries; ++i) {
            double angle = random.nextDouble(0.0D, Math.PI * 2.0D);
            double radius = random.nextDouble(min, max);
            double offsetX = Math.cos(angle) * radius;
            double offsetZ = Math.sin(angle) * radius;
            if (Math.abs(offsetX) < 0.001D && Math.abs(offsetZ) < 0.001D) {
                continue;
            }
            Location candidate = center.clone().add(offsetX, 0.0D, offsetZ);
            Location spawn = this.findStandingLocation(candidate);
            if (spawn != null && !this.isSafezone(spawn)) {
                return spawn;
            }
        }
        return null;
    }

    private Location findStandingLocation(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        World world = location.getWorld();
        int blockX = location.getBlockX();
        int blockZ = location.getBlockZ();
        int startY = Math.min(world.getMaxHeight() - 1, world.getHighestBlockYAt(blockX, blockZ));
        for (int y = startY; y >= world.getMinHeight(); --y) {
            Block below = world.getBlockAt(blockX, y, blockZ);
            if (below.getType().isAir() || !below.getType().isSolid()) {
                continue;
            }
            if (y + 2 >= world.getMaxHeight()) {
                continue;
            }
            if (!world.getBlockAt(blockX, y + 1, blockZ).getType().isAir()) {
                continue;
            }
            if (!world.getBlockAt(blockX, y + 2, blockZ).getType().isAir()) {
                continue;
            }
            return new Location(world, blockX + 0.5D, y + 1.0D, blockZ + 0.5D, location.getYaw(), 0.0f);
        }
        return null;
    }

    private boolean isSafezone(Location location) {
        return this.plugin.getSafezoneService() != null && this.plugin.getSafezoneService().isInSafezone(location);
    }

    private boolean startsWithVowel(String value) {
        if (value == null || value.isEmpty()) {
            return false;
        }
        char first = Character.toLowerCase(value.charAt(0));
        return first == 'a' || first == 'e' || first == 'i' || first == 'o' || first == 'u';
    }

    private void awardKillRewards() {
        if (this.variant == null || this.damageByPlayer.isEmpty()) {
            return;
        }
        double threshold = this.variant.maxHealth() * 0.25D;
        List<UUID> qualified = new ArrayList<UUID>();
        for (Map.Entry<UUID, Double> entry : this.damageByPlayer.entrySet()) {
            if (entry.getValue() != null && entry.getValue().doubleValue() >= threshold) {
                qualified.add(entry.getKey());
            }
        }
        if (qualified.isEmpty()) {
            return;
        }
        for (UUID uniqueId : qualified) {
            Player player = Bukkit.getPlayer(uniqueId);
            if (player == null || !player.isOnline()) {
                continue;
            }
            this.grantRewards(player, this.variant.rewards());
        }
    }

    private void applyHarbourerDamage(double amount) {
        if (amount <= 0.0D) {
            return;
        }
        if (this.harbourerId == null) {
            return;
        }
        this.harbourerHealth = Math.max(0.0D, this.harbourerHealth - amount);
        Evoker boss = this.getHarbourerEntity();
        if (boss != null && !boss.isDead() && boss.isValid()) {
            double visibleHealth = Math.min(this.harbourerHealth, MAX_ENTITY_HEALTH);
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance maxHealth = maxHealthAttribute != null ? boss.getAttribute(maxHealthAttribute) : null;
            if (maxHealth != null && maxHealth.getBaseValue() != visibleHealth) {
                maxHealth.setBaseValue(Math.max(1.0D, visibleHealth));
            }
            if (this.harbourerHealth > 0.0D) {
                boss.setHealth(Math.max(1.0D, visibleHealth));
            }
            this.updateHealthDisplay(boss.getLocation(), this.harbourerHealth);
        }
        if (this.harbourerHealth <= 0.0D) {
            this.handleHarbourerDefeat();
        }
    }

    private Attribute resolveMaxHealthAttribute() {
        try {
            return Attribute.valueOf("GENERIC_MAX_HEALTH");
        }
        catch (IllegalArgumentException ignored) {
            try {
                return Attribute.valueOf("MAX_HEALTH");
            }
            catch (IllegalArgumentException ex) {
                return null;
            }
        }
    }

    private void handleHarbourerDefeat() {
        if (this.harbourerId == null) {
            return;
        }
        this.awardKillRewards();
        this.despawnHarbourer();
    }

    private void grantRewards(Player player, List<RewardGrant> rewards) {
        if (player == null || rewards == null || rewards.isEmpty()) {
            return;
        }
        for (RewardGrant reward : rewards) {
            if (reward == null) {
                continue;
            }
            ItemStack item = null;
            if (reward.type() == RewardType.CONTRABAND && this.plugin.getContrabandService() != null) {
                item = this.plugin.getContrabandService().createContraband(reward.id());
                if (item != null) {
                    item.setAmount(Math.max(1, reward.amount()));
                }
            } else if (reward.type() == RewardType.ENERGY && this.plugin.getEnergyItemService() != null) {
                item = this.plugin.getEnergyItemService().createEnergyItem(Math.max(1, reward.amount()));
            }
            if (item == null) {
                continue;
            }
            if (this.plugin.getStashService() != null) {
                this.plugin.getStashService().giveOrStash(player, item);
            } else {
                Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
                for (ItemStack stack : leftover.values()) {
                    player.getWorld().dropItemNaturally(player.getLocation(), stack);
                }
            }
        }
    }

    private void removePillars() {
        for (Pillar pillar : this.pillars) {
            this.removePillarVisuals(pillar);
            pillar.clearBlocks();
        }
        this.pillars.clear();
        this.pillarLookup.clear();
    }

    private void removePillarVisuals(Pillar pillar) {
        if (pillar == null) {
            return;
        }
        if (pillar.display != null && !pillar.display.isDead()) {
            pillar.display.remove();
        }
        pillar.display = null;
    }

    private Player findNearestPlayer(Location from, double maxDistanceSquared) {
        if (from == null || from.getWorld() == null) {
            return null;
        }
        Player nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (Player player : from.getWorld().getPlayers()) {
            if (player == null || !player.isOnline() || player.isDead()) {
                continue;
            }
            double distance = player.getLocation().distanceSquared(from);
            if (distance > maxDistanceSquared) {
                continue;
            }
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = player;
            }
        }
        return nearest;
    }

    private Location hoverAtGroundHeight(Location location) {
        World world = location.getWorld();
        if (world == null) {
            return location;
        }
        int blockX = location.getBlockX();
        int blockZ = location.getBlockZ();
        double groundY = world.getHighestBlockYAt(blockX, blockZ);
        double y = groundY + HOVER_HEIGHT;
        return new Location(world, location.getX(), y, location.getZ(), location.getYaw(), 0.0f);
    }

    private Location pickWanderTarget(Location center) {
        if (center == null || center.getWorld() == null) {
            return center;
        }
        double angle = ThreadLocalRandom.current().nextDouble(0.0D, Math.PI * 2.0D);
        double radius = ThreadLocalRandom.current().nextDouble(1.5D, WANDER_RADIUS);
        double x = center.getX() + Math.cos(angle) * radius;
        double z = center.getZ() + Math.sin(angle) * radius;
        return new Location(center.getWorld(), x, center.getY(), z, center.getYaw(), 0.0f);
    }

    private Location stepToward(Location current, Location target, double maxStep) {
        if (current == null || target == null || current.getWorld() == null || target.getWorld() == null || !current.getWorld().equals(target.getWorld())) {
            return current;
        }
        Vector delta = target.toVector().subtract(current.toVector());
        delta.setY(0.0D);
        double distance = delta.length();
        if (distance <= maxStep) {
            return target.clone();
        }
        return current.clone().add(delta.normalize().multiply(maxStep));
    }

    private Location applyIdleBob(Location location) {
        if (location == null) {
            return null;
        }
        double bob = Math.sin((double)this.tickCounter * 0.16D) * IDLE_BOB_AMPLITUDE;
        return location.clone().add(0.0D, bob, 0.0D);
    }

    private float yawTo(Location from, Location to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        return (float)Math.toDegrees(Math.atan2(-dx, dz));
    }

    private Evoker getHarbourerEntity() {
        if (this.harbourerId == null) {
            return null;
        }
        Entity entity = Bukkit.getEntity(this.harbourerId);
        if (!(entity instanceof Evoker)) {
            return null;
        }
        Evoker boss = (Evoker)entity;
        if (!boss.getPersistentDataContainer().has(Keys.harbourerBoss(this.plugin), PersistentDataType.BYTE)) {
            return null;
        }
        return boss;
    }

    private String blockKey(Location location) {
        Location block = location.toBlockLocation();
        return block.getWorld().getName() + ":" + block.getBlockX() + ":" + block.getBlockY() + ":" + block.getBlockZ();
    }

    private final class Pillar {
        private final String id;
        private final Location origin;
        private final List<PillarBlock> blocks;
        private final int totalBlocks;
        private int remainingBlocks;
        private TextDisplay display;
        private boolean broken;

        private Pillar(String id, Location origin, List<PillarBlock> blocks) {
            this.id = id;
            this.origin = origin;
            this.blocks = blocks;
            this.totalBlocks = blocks.size();
            this.remainingBlocks = blocks.size();
        }

        private void spawn(World world) {
            for (PillarBlock block : this.blocks) {
                world.getBlockAt(block.location.getBlockX(), block.location.getBlockY(), block.location.getBlockZ()).setType(block.material, false);
            }
            this.display = (TextDisplay)world.spawn(this.hologramLocation(), TextDisplay.class, td -> {
                td.setBillboard(Display.Billboard.CENTER);
                td.setShadowed(true);
                td.setDefaultBackground(false);
                td.setBackgroundColor(Color.fromARGB(0));
                td.setPersistent(false);
                td.setInterpolationDuration(1);
                td.setInterpolationDelay(0);
            });
            this.display.setText(Text.color(PILLAR_NAME + "\n&7" + HarbourerBossService.this.progressBar(this.remainingBlocks, this.totalBlocks)));
        }

        private boolean breakBlock(Location location) {
            if (this.broken) {
                return false;
            }
            String key = HarbourerBossService.this.blockKey(location);
            for (PillarBlock block : this.blocks) {
                if (!HarbourerBossService.this.blockKey(block.location).equals(key)) {
                    continue;
                }
                HarbourerBossService.this.pillarLookup.remove(key);
                --this.remainingBlocks;
                if (this.remainingBlocks <= 0) {
                    this.remainingBlocks = 0;
                    this.broken = true;
                }
                return true;
            }
            return false;
        }

        private void clearBlocks() {
            for (PillarBlock block : this.blocks) {
                if (block.location.getWorld() == null) {
                    continue;
                }
                Block worldBlock = block.location.getWorld().getBlockAt(block.location.getBlockX(), block.location.getBlockY(), block.location.getBlockZ());
                worldBlock.setType(Material.AIR, false);
            }
        }

        private Location linkPoint() {
            return this.origin.clone().add(1.0D, PILLAR_HEIGHT + 0.8D, 1.0D);
        }

        private Location hologramLocation() {
            return this.origin.clone().add(1.0D, PILLAR_HEIGHT + PILLAR_HOLOGRAM_OFFSET, 1.0D);
        }
    }

    private record PillarBlock(Location location, Material material) {
    }

    public enum HarbourerVariant {
        IRON("iron", "&7&lIron Harbourer", Material.WHITE_STAINED_GLASS_PANE, 1.0D, 1.0D, List.of(
                RewardGrant.contraband("basic_cont", 3)
        )),
        LAPIS("lapis", "&9&lLapis Harbourer", Material.BLUE_STAINED_GLASS_PANE, 1.5D, 1.0005D, List.of(
                RewardGrant.contraband("rare_cont", 1),
                RewardGrant.contraband("basic_cont", 1)
        )),
        GOLD("gold", "&6&lGold Harbourer", Material.ORANGE_STAINED_GLASS_PANE, 2.0D, 1.001D, List.of(
                RewardGrant.contraband("rare_cont", 2)
        )),
        REDSTONE("redstone", "&c&lRedstone Harbourer", Material.RED_STAINED_GLASS_PANE, 2.5D, 1.0015D, List.of(
                RewardGrant.contraband("elite_cont", 3),
                RewardGrant.energy(20000)
        )),
        DIAMOND("diamond", "&b&lDiamond Harbourer", Material.LIGHT_BLUE_STAINED_GLASS_PANE, 3.0D, 1.002D, List.of(
                RewardGrant.contraband("legendary_cont", 1),
                RewardGrant.energy(35000)
        )),
        EMERALD("emerald", "&a&lEmerald Harbourer", Material.LIME_STAINED_GLASS_PANE, 3.5D, 1.0025D, List.of(
                RewardGrant.contraband("legendary_cont", 3),
                RewardGrant.energy(50000)
        ));

        private final String id;
        private final String displayName;
        private final String plainName;
        private final Material ringMaterial;
        private final double healthMultiplier;
        private final double attackMultiplier;
        private final List<RewardGrant> rewards;

        HarbourerVariant(String id, String displayName, Material ringMaterial, double healthMultiplier, double attackMultiplier, List<RewardGrant> rewards) {
            this.id = id;
            this.displayName = displayName;
            this.plainName = Text.strip(displayName);
            this.ringMaterial = ringMaterial;
            this.healthMultiplier = healthMultiplier;
            this.attackMultiplier = attackMultiplier;
            this.rewards = rewards;
        }

        public String id() {
            return this.id;
        }

        public String displayName() {
            return this.displayName;
        }

        public String plainName() {
            return this.plainName;
        }

        public Material ringMaterial() {
            return this.ringMaterial;
        }

        public double maxHealth() {
            return MAX_HEALTH * this.healthMultiplier;
        }

        public double attackMultiplier() {
            return this.attackMultiplier;
        }

        public List<RewardGrant> rewards() {
            return this.rewards;
        }

        public static HarbourerVariant fromId(String input) {
            if (input == null || input.isEmpty()) {
                return null;
            }
            String normalized = input.toLowerCase(java.util.Locale.ROOT);
            for (HarbourerVariant variant : values()) {
                if (variant.id.equals(normalized) || variant.name().equalsIgnoreCase(normalized)) {
                    return variant;
                }
            }
            return null;
        }
    }

    private enum RewardType {
        CONTRABAND,
        ENERGY
    }

    public record RewardGrant(RewardType type, String id, int amount) {
        public static RewardGrant contraband(String id, int amount) {
            return new RewardGrant(RewardType.CONTRABAND, id, amount);
        }

        public static RewardGrant energy(int amount) {
            return new RewardGrant(RewardType.ENERGY, null, amount);
        }
    }
}
