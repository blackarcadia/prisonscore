/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package org.axial.prisonsCore.service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.persistence.PersistentDataType;

public class GuardDisplayService {
    private final PrisonsCore plugin;
    private final GuardService guardService;
    private final Map<UUID, ArmorStand> stands = new HashMap<UUID, ArmorStand>();
    private BukkitTask task;
    private static final double OFFSET = 0.2;
    private int sweepTicks = 0;

    public GuardDisplayService(PrisonsCore plugin, GuardService guardService) {
        this.plugin = plugin;
        this.guardService = guardService;
    }

    public void start() {
        if (this.task != null) {
            return;
        }
        this.purgeOrphanStands();
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::tick, 0L, 1L);
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
        }
        this.task = null;
        this.clearAll();
    }

    private void tick() {
        this.guardService.getGuardIds().forEach(this::ensureStand);
        this.stands.forEach((uuid, stand) -> {
            LivingEntity guard;
            Entity ent = Bukkit.getEntity((UUID)uuid);
            if (!(ent instanceof LivingEntity) || (guard = (LivingEntity)ent).isDead()) {
                stand.remove();
                return;
            }
            double hp = Math.max(0.0, guard.getHealth());
            stand.setCustomName(Text.color("&f" + this.format(hp) + " &c\u2764"));
            Location loc = guard.getLocation().add(0.0, guard.getHeight() + 0.2, 0.0);
            stand.teleport(loc);
        });
        this.stands.entrySet().removeIf(e -> ((ArmorStand)e.getValue()).isDead() || Bukkit.getEntity((UUID)((UUID)e.getKey())) == null || Bukkit.getEntity((UUID)((UUID)e.getKey())).isDead());
        if (++this.sweepTicks >= 20) {
            this.sweepTicks = 0;
            this.purgeOrphanStands();
        }
    }

    private void ensureStand(UUID guardId) {
        LivingEntity guard;
        if (this.stands.containsKey(guardId)) {
            return;
        }
        Entity ent = Bukkit.getEntity((UUID)guardId);
        if (!(ent instanceof LivingEntity) || (guard = (LivingEntity)ent).isDead()) {
            return;
        }
        ArmorStand as = (ArmorStand)guard.getWorld().spawn(guard.getLocation().add(0.0, guard.getHeight() + 0.2, 0.0), ArmorStand.class, stand -> {
            stand.setVisible(false);
            stand.setMarker(true);
            stand.setGravity(false);
            stand.setSmall(true);
            stand.setCustomNameVisible(true);
            stand.setCollidable(false);
            stand.setPersistent(true);
            stand.getPersistentDataContainer().set(Keys.guardHealthStand(this.plugin), PersistentDataType.BYTE, (byte)1);
            stand.getPersistentDataContainer().set(Keys.guardHealthStandOwner(this.plugin), PersistentDataType.STRING, guardId.toString());
        });
        this.stands.put(guardId, as);
    }

    private void clearAll() {
        this.stands.values().forEach(as -> {
            if (as != null && !as.isDead()) {
                as.remove();
            }
        });
        this.stands.clear();
    }

    public void purgeOrphanStands() {
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : new java.util.ArrayList<>(world.getEntities())) {
                if (!(entity instanceof ArmorStand stand)) {
                    continue;
                }
                if (stand.getPersistentDataContainer().has(Keys.guardHealthStand(this.plugin), PersistentDataType.BYTE)) {
                    String owner = stand.getPersistentDataContainer().get(Keys.guardHealthStandOwner(this.plugin), PersistentDataType.STRING);
                    if (owner != null) {
                        try {
                            UUID guardId = UUID.fromString(owner);
                            if (this.guardService.getGuardIds().contains(guardId)) {
                                continue;
                            }
                        } catch (IllegalArgumentException ignored) {
                            // fall through to remove
                        }
                    }
                    stand.remove();
                    continue;
                }
                if (!this.looksLikeGuardHealthStand(stand)) {
                    continue;
                }
                stand.remove();
            }
        }
    }

    private boolean looksLikeGuardHealthStand(ArmorStand stand) {
        if (stand == null) {
            return false;
        }
        if (!stand.isMarker()) {
            return false;
        }
        String name = stand.getCustomName();
        if (name == null) {
            return false;
        }
        String plain = Text.color(name);
        if (plain == null) {
            return false;
        }
        return plain.contains("❤");
    }

    private String format(double val) {
        if (val == (double)((int)val)) {
            return String.valueOf((int)val);
        }
        return String.format("%.1f", val);
    }
}
