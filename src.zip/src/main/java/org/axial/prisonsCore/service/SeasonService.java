package org.axial.prisonsCore.service;

import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import java.time.Duration;
import java.time.LocalDate;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.TreeMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.cell.CellTier;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class SeasonService {
    private static final double DAILY_PRICE_INCREASE = 0.10;
    private static final double ORE_WORTH_MULTIPLIER = 3.0;
    private static final ZoneId SEASON_ZONE = ZoneId.systemDefault();
    private final PrisonsCore plugin;
    private final TreeMap<Integer, DayDefinition> days = new TreeMap<Integer, DayDefinition>();
    private long seasonStartTime = -1L;
    private boolean seasonActive = false;
    private int manualDayOverride = 0;
    private long manualDayOverrideStartTime = -1L;
    private int lastObservedDay = 0;
    private BukkitTask dayMonitorTask;

    public SeasonService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.setupDays();
        this.load();
        this.lastObservedDay = this.currentDayForTracking();
        this.startDayMonitor();
    }

    private void setupDays() {
        this.days.clear();
        this.days.put(1, new DayDefinition(1, 20, List.of("Wooden Pickaxe", "Chainmail Tools", "Chainmail Armor", "Rank Kits")));
        this.days.put(2, new DayDefinition(2, 30, List.of()));
        this.days.put(3, new DayDefinition(3, 30, List.of("Iron Pickaxes")));
        this.days.put(4, new DayDefinition(4, 45, List.of("Gold Armor")));
        this.days.put(5, new DayDefinition(5, 45, List.of("Inmate Cells")));
        this.days.put(6, new DayDefinition(6, 60, List.of("Gold Pickaxes")));
        this.days.put(7, new DayDefinition(7, 60, List.of("Iron Armor", "Iron Tools")));
        this.days.put(8, new DayDefinition(8, 60, List.of("Trustee Cells")));
        this.days.put(9, new DayDefinition(9, 75, List.of("Diamond Pickaxes")));
        this.days.put(10, new DayDefinition(10, 75, List.of("Diamond Armor", "Masks")));
        this.days.put(11, new DayDefinition(11, 80, List.of("Diamond Tools", "Meteor Flares")));
        this.days.put(12, new DayDefinition(12, 100, List.of()));
        this.days.put(13, new DayDefinition(13, 101, List.of("Prestige I")));
        this.days.put(14, new DayDefinition(14, 102, List.of("Prestige II")));
    }

    public void startSeason() {
        this.seasonActive = true;
        ZonedDateTime todayMidnight = LocalDate.now(SEASON_ZONE).atStartOfDay(SEASON_ZONE);
        this.seasonStartTime = todayMidnight.toInstant().toEpochMilli();
        this.save();
    }

    public void stopSeason() {
        this.seasonActive = false;
        this.seasonStartTime = -1L;
        this.manualDayOverride = 0;
        this.manualDayOverrideStartTime = -1L;
        this.lastObservedDay = 0;
        this.save();
    }

    public boolean isSeasonActive() {
        return this.seasonActive;
    }

    public int getCurrentLevelCap() {
        if (!this.seasonActive && this.manualDayOverride <= 0) {
            return Math.max(105, this.plugin.getConfig().getInt("player-level.max-level", 105));
        }
        return this.getCapForDay(this.getCurrentDay());
    }

    public int getCurrentDay() {
        if (this.manualDayOverride > 0) {
            if (this.manualDayOverrideStartTime > 0L) {
                LocalDate anchorDate = Instant.ofEpochMilli(this.manualDayOverrideStartTime).atZone(SEASON_ZONE).toLocalDate();
                long elapsedDays = ChronoUnit.DAYS.between(anchorDate, LocalDate.now(SEASON_ZONE));
                return this.clampDay((int)elapsedDays + this.manualDayOverride);
            }
            return this.clampDay(this.manualDayOverride);
        }
        if (!this.seasonActive) {
            return this.getHighestDay();
        }
        if (this.seasonStartTime <= 0L) {
            return 1;
        }
        LocalDate startDate = Instant.ofEpochMilli(this.seasonStartTime).atZone(SEASON_ZONE).toLocalDate();
        LocalDate currentDate = LocalDate.now(SEASON_ZONE);
        long elapsedDays = ChronoUnit.DAYS.between(startDate, currentDate);
        if (elapsedDays < 0L) {
            return 1;
        }
        int currentDay = (int)elapsedDays + 1;
        return this.clampDay(currentDay);
    }

    public int getHighestDay() {
        return this.days.isEmpty() ? 1 : this.days.lastKey();
    }

    public int getCapForDay(int day) {
        DayDefinition definition = this.days.get(this.clampDay(day));
        return definition == null ? 100 : definition.levelCap();
    }

    public DayDefinition getDayDefinition(int day) {
        return this.days.get(this.clampDay(day));
    }

    public DayStatus getStatusForDay(int day) {
        int clamped = this.clampDay(day);
        if (!this.seasonActive && this.manualDayOverride <= 0) {
            return DayStatus.UNLOCKED;
        }
        int currentDay = this.getCurrentDay();
        if (clamped < currentDay) {
            return DayStatus.UNLOCKED;
        }
        if (clamped == currentDay) {
            return DayStatus.CURRENT;
        }
        return DayStatus.LOCKED;
    }

    public boolean isDayUnlocked(int day) {
        return this.getStatusForDay(day) != DayStatus.LOCKED;
    }

    public String getTimeUntilUnlock(int day) {
        if (this.getStatusForDay(day) != DayStatus.LOCKED) {
            return "Unlocked";
        }
        if (!this.seasonActive || this.seasonStartTime <= 0L) {
            return "Season not started";
        }
        long targetTime = this.getUnlockTimestamp(this.clampDay(day));
        long remainingMillis = targetTime - Instant.now().toEpochMilli();
        if (remainingMillis <= 0L) {
            return "Unlocked";
        }
        Duration duration = Duration.ofMillis(remainingMillis);
        long hours = duration.toHours();
        long minutes = duration.toMinutesPart();
        long seconds = duration.toSecondsPart();
        return String.format("%02dh %02dm %02ds", hours, minutes, seconds);
    }

    private long getUnlockTimestamp(int day) {
        int clampedDay = this.clampDay(day);
        if (this.manualDayOverride > 0) {
            int currentDay = this.getCurrentDay();
            int daysUntilUnlock = clampedDay - currentDay;
            if (daysUntilUnlock <= 0) {
                return Instant.now().toEpochMilli();
            }
            LocalDate targetDate = LocalDate.now(SEASON_ZONE).plusDays((long)daysUntilUnlock);
            return targetDate.atStartOfDay(SEASON_ZONE).toInstant().toEpochMilli();
        }
        LocalDate startDate = Instant.ofEpochMilli(this.seasonStartTime).atZone(SEASON_ZONE).toLocalDate();
        return startDate.plusDays((long)(clampedDay - 1)).atStartOfDay(SEASON_ZONE).toInstant().toEpochMilli();
    }

    public double getWorthMultiplier() {
        if (!this.seasonActive && this.manualDayOverride <= 0) {
            return 1.0;
        }
        return this.getWorthMultiplierForDay(this.getCurrentDay());
    }

    public double getWorthMultiplierForDay(int day) {
        return 1.0 + DAILY_PRICE_INCREASE * (double)(this.clampDay(day) - 1);
    }

    public double scalePriceForCurrentDay(double basePrice) {
        return basePrice * this.getWorthMultiplier() * ORE_WORTH_MULTIPLIER;
    }

    public double scalePriceForDay(double basePrice, int day) {
        return basePrice * this.getWorthMultiplierForDay(day) * ORE_WORTH_MULTIPLIER;
    }

    public boolean isFeatureUnlocked(UnlockFeature feature) {
        if (feature == null) {
            return true;
        }
        return this.getCurrentDay() >= feature.unlockDay();
    }

    public int getUnlockDay(UnlockFeature feature) {
        return feature == null ? 1 : feature.unlockDay();
    }

    public UnlockFeature getFeature(Material material) {
        if (material == null) {
            return null;
        }
        return switch (material) {
            case WOODEN_PICKAXE -> UnlockFeature.WOODEN_PICKAXES;
            case GOLDEN_PICKAXE -> UnlockFeature.GOLD_PICKAXES;
            case IRON_PICKAXE -> UnlockFeature.IRON_PICKAXES;
            case DIAMOND_PICKAXE -> UnlockFeature.DIAMOND_PICKAXES;
            case GOLDEN_SWORD, GOLDEN_AXE, GOLDEN_SHOVEL, GOLDEN_HOE -> UnlockFeature.GOLD_TOOLS;
            case IRON_SWORD, IRON_AXE, IRON_SHOVEL, IRON_HOE -> UnlockFeature.IRON_TOOLS;
            case DIAMOND_SWORD, DIAMOND_AXE, DIAMOND_SHOVEL, DIAMOND_HOE -> UnlockFeature.DIAMOND_TOOLS;
            case CHAINMAIL_HELMET, CHAINMAIL_CHESTPLATE, CHAINMAIL_LEGGINGS, CHAINMAIL_BOOTS -> UnlockFeature.CHAINMAIL_ARMOR;
            case GOLDEN_HELMET, GOLDEN_CHESTPLATE, GOLDEN_LEGGINGS, GOLDEN_BOOTS -> UnlockFeature.GOLD_ARMOR;
            case IRON_HELMET, IRON_CHESTPLATE, IRON_LEGGINGS, IRON_BOOTS -> UnlockFeature.IRON_ARMOR;
            case DIAMOND_HELMET, DIAMOND_CHESTPLATE, DIAMOND_LEGGINGS, DIAMOND_BOOTS -> UnlockFeature.DIAMOND_ARMOR;
            default -> null;
        };
    }

    public UnlockFeature getFeature(CellTier tier) {
        if (tier == null) {
            return null;
        }
        return switch (tier) {
            case INMATE -> UnlockFeature.INMATE_CELLS;
            case TRUSTEE -> UnlockFeature.TRUSTEE_CELLS;
            case WARDEN -> null;
        };
    }

    public void setManualDayOverride(int day) {
        int previousDay = this.getCurrentDay();
        this.manualDayOverride = this.clampDay(day);
        this.manualDayOverrideStartTime = LocalDate.now(SEASON_ZONE).atStartOfDay(SEASON_ZONE).toInstant().toEpochMilli();
        int currentDay = this.getCurrentDay();
        if (currentDay > previousDay) {
            this.broadcastLevelCapIncrease();
        }
        this.lastObservedDay = currentDay;
        this.save();
    }

    public void clearManualDayOverride() {
        this.manualDayOverride = 0;
        this.manualDayOverrideStartTime = -1L;
        this.lastObservedDay = this.currentDayForTracking();
        this.save();
    }

    public int getManualDayOverride() {
        return this.manualDayOverride;
    }

    public boolean hasManualDayOverride() {
        return this.manualDayOverride > 0;
    }

    public void load() {
        FileConfiguration config = this.plugin.getConfig();
        this.seasonActive = config.getBoolean("season.active", false);
        this.seasonStartTime = config.getLong("season.start-time", -1L);
        this.manualDayOverride = Math.max(0, config.getInt("season.manual-day-override", 0));
        this.manualDayOverrideStartTime = config.getLong("season.manual-day-override-start-time", -1L);
        if (this.manualDayOverride > 0 && this.manualDayOverrideStartTime <= 0L) {
            this.manualDayOverrideStartTime = LocalDate.now(SEASON_ZONE).atStartOfDay(SEASON_ZONE).toInstant().toEpochMilli();
        }
    }

    public void save() {
        FileConfiguration config = this.plugin.getConfig();
        config.set("season.active", this.seasonActive);
        config.set("season.start-time", this.seasonStartTime);
        config.set("season.manual-day-override", this.manualDayOverride);
        config.set("season.manual-day-override-start-time", this.manualDayOverrideStartTime);
        this.plugin.saveConfig();
    }

    private void startDayMonitor() {
        this.dayMonitorTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::checkForDayIncrease, 20L, 1200L);
    }

    private void checkForDayIncrease() {
        int currentDay = this.currentDayForTracking();
        if (currentDay > this.lastObservedDay && this.lastObservedDay > 0) {
            this.broadcastLevelCapIncrease();
        }
        this.lastObservedDay = currentDay;
    }

    private int currentDayForTracking() {
        if (!this.seasonActive && this.manualDayOverride <= 0) {
            return 0;
        }
        return this.getCurrentDay();
    }

    private void broadcastLevelCapIncrease() {
        Bukkit.broadcastMessage(Text.color("&a&l(!) &aLevel Cap Increased\n&7/levelcap to see the current days unlocks!"));
    }

    private int clampDay(int day) {
        return Math.max(1, Math.min(this.getHighestDay(), day));
    }

    public enum DayStatus {
        UNLOCKED,
        CURRENT,
        LOCKED
    }

    public enum UnlockFeature {
        WOODEN_PICKAXES(1),
        CHAINMAIL_ARMOR(1),
        RANK_KITS(1),
        GOLD_PICKAXES(6),
        GOLD_TOOLS(3),
        GOLD_ARMOR(4),
        INMATE_CELLS(5),
        IRON_PICKAXES(3),
        IRON_ARMOR(7),
        IRON_TOOLS(7),
        TRUSTEE_CELLS(8),
        DIAMOND_PICKAXES(9),
        DIAMOND_ARMOR(10),
        MASKS(10),
        DIAMOND_TOOLS(11),
        METEOR_FLARES(11);

        private final int unlockDay;

        UnlockFeature(int unlockDay) {
            this.unlockDay = unlockDay;
        }

        public int unlockDay() {
            return this.unlockDay;
        }
    }

    public record DayDefinition(int day, int levelCap, List<String> unlocks) {
    }
}
