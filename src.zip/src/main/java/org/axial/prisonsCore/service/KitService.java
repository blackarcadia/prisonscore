package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class KitService {
    private static final long COOLDOWN_MILLIS = 172800000L;
    private static final long GKIT_COOLDOWN_MILLIS = 432000000L;
    private final PrisonsCore plugin;
    private final PlayerDataService playerDataService;
    private final PlayerLevelService playerLevelService;
    private final EnergyItemService energyItemService;
    private final ShardService shardService;
    private final GearManager gearManager;
    private final ContrabandService contrabandService;
    private final Random random = new Random();

    public KitService(PrisonsCore plugin, PlayerDataService playerDataService, PlayerLevelService playerLevelService, EnergyItemService energyItemService, ShardService shardService, GearManager gearManager, ContrabandService contrabandService) {
        this.plugin = plugin;
        this.playerDataService = playerDataService;
        this.playerLevelService = playerLevelService;
        this.energyItemService = energyItemService;
        this.shardService = shardService;
        this.gearManager = gearManager;
        this.contrabandService = contrabandService;
    }

    public List<KitType> kitTypes() {
        return List.of(KitType.STARTER, KitType.BETA);
    }

    public List<GKitType> gkitTypes() {
        return List.of(GKitType.DEEPFORGE, GKitType.IRONHIDE, GKitType.STORMSTRIDE);
    }

    public boolean hasAccess(Player player, KitType kitType) {
        return player != null && kitType != null && player.hasPermission(kitType.permission());
    }

    public boolean hasAccess(Player player, GKitType gkitType) {
        if (player == null || gkitType == null) {
            return false;
        }
        PlayerDataService.PlayerData data = this.playerDataService.get(player.getUniqueId());
        if (data.isGKitBlocked(gkitType.id())) {
            return false;
        }
        return player.hasPermission(gkitType.permission()) || data.hasUnlockedGKit(gkitType.id());
    }

    public long getCooldownExpiry(Player player, KitType kitType) {
        if (player == null || kitType == null) {
            return 0L;
        }
        return this.playerDataService.get(player.getUniqueId()).getKitCooldown(kitType.id());
    }

    public long getRemainingCooldown(Player player, KitType kitType) {
        return Math.max(0L, this.getCooldownExpiry(player, kitType) - System.currentTimeMillis());
    }

    public long getGKitCooldownExpiry(Player player, GKitType gkitType) {
        if (player == null || gkitType == null) {
            return 0L;
        }
        return this.playerDataService.get(player.getUniqueId()).getKitCooldown(gkitType.id());
    }

    public long getRemainingCooldown(Player player, GKitType gkitType) {
        return Math.max(0L, this.getGKitCooldownExpiry(player, gkitType) - System.currentTimeMillis());
    }

    public boolean isOnCooldown(Player player, GKitType gkitType) {
        return this.getRemainingCooldown(player, gkitType) > 0L;
    }

    public boolean isOnCooldown(Player player, KitType kitType) {
        return this.getRemainingCooldown(player, kitType) > 0L;
    }

    public RewardBracket resolveBracket(Player player) {
        int level = Math.max(0, this.playerLevelService.getLevel(player));
        if (level < 30) {
            return RewardBracket.ZERO_TO_THIRTY;
        }
        if (level < 50) {
            return RewardBracket.THIRTY_TO_FIFTY;
        }
        if (level < 70) {
            return RewardBracket.FIFTY_TO_SEVENTY;
        }
        return RewardBracket.SEVENTY_TO_HUNDRED;
    }

    public List<ItemStack> previewItems(Player player, KitType kitType) {
        RewardBracket bracket = this.resolveBracket(player);
        ArrayList<ItemStack> items = new ArrayList<ItemStack>();
        switch (kitType) {
            case STARTER -> {
                items.add(this.createPrisonGear(bracket.helmet()));
                items.add(this.createPrisonGear(bracket.chestplate()));
                items.add(this.createPrisonGear(bracket.leggings()));
                items.add(this.createPrisonGear(bracket.boots()));
                items.add(this.createPrisonGear(bracket.sword()));
                items.add(new ItemStack(Material.BREAD, 32));
                items.add(this.energyItemService.createEnergyItem(bracket.starterCharge()));
            }
            case BETA -> {
                ItemStack fragments = this.shardService.createShard(bracket.fragmentTier());
                fragments.setAmount(5);
                items.add(this.energyItemService.createEnergyItem(bracket.betaCharge()));
                items.add(fragments);
                items.add(this.createContrabandPreview(bracket));
            }
        }
        return items;
    }

    public List<ItemStack> previewGKitItems(Player player, GKitType gkitType) {
        RewardBracket bracket = this.resolveBracket(player);
        ArrayList<ItemStack> items = new ArrayList<ItemStack>();
        if (gkitType == null) {
            return items;
        }
        switch (gkitType) {
            case DEEPFORGE -> {
                items.add(this.createGearItem(bracket.chestplate(), this.rollGearEnchants("excavation", "ravenous_charge")));
                items.add(this.createGearItem(bracket.leggings(), this.rollGearEnchants("cactus", "erosion")));
                items.add(this.energyItemService.createEnergyItem(this.randomChargeAmount()));
            }
            case IRONHIDE -> {
                items.add(this.createGearItem(bracket.helmet(), this.rollGearEnchants("tank", "shockwave")));
                items.add(this.createGearItem(bracket.chestplate(), this.rollGearEnchants("protection", "tank")));
                items.add(this.createGearItem(bracket.leggings(), this.rollGearEnchants("shockwave", "tank", "hardened")));
                items.add(this.createGearItem(bracket.boots(), this.rollGearEnchants("springs", "tank", "protection")));
                items.add(this.createGearItem(bracket.sword(), this.rollGearEnchants("pummel", "bleed", "weakness")));
            }
            case STORMSTRIDE -> {
                items.add(this.createGearItem(bracket.boots(), this.rollGearEnchants("quick_feet", "tank", "hardened", "springs")));
                items.add(this.createGearItem(bracket.sword(), this.rollGearEnchants("poison", "frenzy", "paralyze", "execution")));
            }
        }
        return items;
    }

    public ClaimResult claim(Player player, KitType kitType) {
        if (!this.hasAccess(player, kitType)) {
            return ClaimResult.NO_PERMISSION;
        }
        if (this.isOnCooldown(player, kitType)) {
            return ClaimResult.ON_COOLDOWN;
        }
        RewardBracket bracket = this.resolveBracket(player);
        switch (kitType) {
            case STARTER -> this.giveStarterRewards(player, bracket);
            case BETA -> this.giveBetaRewards(player, bracket);
        }
        long expiresAt = System.currentTimeMillis() + COOLDOWN_MILLIS;
        this.playerDataService.update(player.getUniqueId(), data -> data.setKitCooldown(kitType.id(), expiresAt));
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.sendTitle(Text.color("&a&lKit Claimed"), "", 10, 40, 10);
        player.sendMessage(Text.color("&aYou claimed the " + kitType.menuLabel() + "."));
        return ClaimResult.CLAIMED;
    }

    public ClaimResult claimGKit(Player player, GKitType gkitType) {
        if (!this.hasAccess(player, gkitType)) {
            return ClaimResult.NO_PERMISSION;
        }
        if (this.isOnCooldown(player, gkitType)) {
            return ClaimResult.ON_COOLDOWN;
        }
        RewardBracket bracket = this.resolveBracket(player);
        switch (gkitType) {
            case DEEPFORGE -> this.giveDeepforgeRewards(player, bracket);
            case IRONHIDE -> this.giveIronhideRewards(player, bracket);
            case STORMSTRIDE -> this.giveStormstrideRewards(player, bracket);
        }
        long expiresAt = System.currentTimeMillis() + GKIT_COOLDOWN_MILLIS;
        this.playerDataService.update(player.getUniqueId(), data -> data.setKitCooldown(gkitType.id(), expiresAt));
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.sendTitle(Text.color("&a&lGKit Claimed"), "", 10, 40, 10);
        player.sendMessage(Text.color("&aYou claimed the " + gkitType.plainName() + " gkit."));
        return ClaimResult.CLAIMED;
    }

    public boolean resetCooldowns(OfflinePlayer target, KitType kitType) {
        if (target == null) {
            return false;
        }
        this.playerDataService.update(target.getUniqueId(), data -> {
            if (kitType == null) {
                data.clearAllKitCooldowns();
                return;
            }
            data.clearKitCooldown(kitType.id());
        });
        return true;
    }

    public CompletableFuture<Boolean> unlockGKit(OfflinePlayer target, GKitType gkitType) {
        return this.setGKitAccess(target, gkitType, true);
    }

    public CompletableFuture<Boolean> revokeGKit(OfflinePlayer target, GKitType gkitType) {
        return this.setGKitAccess(target, gkitType, false);
    }

    public ItemStack createGKitToken(GKitType gkitType) {
        if (gkitType == null) {
            return null;
        }
        ItemStack item = new ItemStack(Material.DIAMOND);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Text.color(switch (gkitType) {
            case DEEPFORGE -> "&3&lDeep Forge &3Gkit Gem";
            case IRONHIDE -> "&b&lIronhide &bGkit Gem";
            case STORMSTRIDE -> "&9&lStormstride &9Gkit Gem";
        }));
        meta.setLore(List.of(
                Text.color("&7Right-click to unlock this gkit."),
                Text.color("&7This gem is consumed on use.")
        ));
        meta.getPersistentDataContainer().set(Keys.gkitTokenType(this.plugin), PersistentDataType.STRING, gkitType.id());
        item.setItemMeta(meta);
        return item;
    }

    public boolean isGKitToken(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(Keys.gkitTokenType(this.plugin), PersistentDataType.STRING);
    }

    public GKitType getGKitTokenType(ItemStack stack) {
        if (!this.isGKitToken(stack)) {
            return null;
        }
        String id = stack.getItemMeta().getPersistentDataContainer().get(Keys.gkitTokenType(this.plugin), PersistentDataType.STRING);
        return this.parseGKit(id);
    }

    public GKitType parseGKit(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        String normalized = input.toLowerCase(Locale.ENGLISH);
        for (GKitType type : GKitType.values()) {
            if (type.id().equals(normalized)) {
                return type;
            }
        }
        return null;
    }

    public boolean hasUnlockedGKit(Player player, GKitType gkitType) {
        return player != null && gkitType != null && this.playerDataService.get(player.getUniqueId()).hasUnlockedGKit(gkitType.id());
    }

    public KitType parseKit(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        String normalized = input.toLowerCase(Locale.ENGLISH);
        for (KitType type : KitType.values()) {
            if (type.id().equals(normalized)) {
                return type;
            }
        }
        return null;
    }

    public String formatCooldown(long millis) {
        long totalSeconds = Math.max(0L, millis / 1000L);
        long days = totalSeconds / 86400L;
        long hours = totalSeconds % 86400L / 3600L;
        long minutes = totalSeconds % 3600L / 60L;
        long seconds = totalSeconds % 60L;
        ArrayList<String> parts = new ArrayList<String>();
        if (days > 0L) {
            parts.add(days + "d");
        }
        if (hours > 0L) {
            parts.add(hours + "h");
        }
        if (minutes > 0L) {
            parts.add(minutes + "m");
        }
        if (parts.isEmpty()) {
            parts.add(seconds + "s");
        }
        return String.join(" ", parts);
    }

    public String bracketDescription(Player player) {
        RewardBracket bracket = this.resolveBracket(player);
        return bracket.minLevel() + "-" + bracket.maxLevel();
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    private void giveStarterRewards(Player player, RewardBracket bracket) {
        this.giveItem(player, this.createPrisonGear(bracket.helmet()));
        this.giveItem(player, this.createPrisonGear(bracket.chestplate()));
        this.giveItem(player, this.createPrisonGear(bracket.leggings()));
        this.giveItem(player, this.createPrisonGear(bracket.boots()));
        this.giveItem(player, this.createPrisonGear(bracket.sword()));
        this.giveItem(player, new ItemStack(Material.BREAD, 32));
        this.energyItemService.giveEnergyItem(player, bracket.starterCharge());
    }

    private void giveBetaRewards(Player player, RewardBracket bracket) {
        this.energyItemService.giveEnergyItem(player, bracket.betaCharge());
        for (int i = 0; i < 5; ++i) {
            this.giveItem(player, this.shardService.createShard(bracket.fragmentTier()));
        }
        this.giveContraband(player, bracket.crateId());
    }

    private void giveDeepforgeRewards(Player player, RewardBracket bracket) {
        this.giveItem(player, this.createGearItem(bracket.chestplate(), this.rollGearEnchants("excavation", "ravenous_charge")));
        this.giveItem(player, this.createGearItem(bracket.leggings(), this.rollGearEnchants("cactus", "erosion")));
        this.energyItemService.giveEnergyItem(player, this.randomChargeAmount());
    }

    private void giveIronhideRewards(Player player, RewardBracket bracket) {
        this.giveItem(player, this.createGearItem(bracket.helmet(), this.rollGearEnchants("tank", "shockwave")));
        this.giveItem(player, this.createGearItem(bracket.chestplate(), this.rollGearEnchants("protection", "tank")));
        this.giveItem(player, this.createGearItem(bracket.leggings(), this.rollGearEnchants("shockwave", "tank", "hardened")));
        this.giveItem(player, this.createGearItem(bracket.boots(), this.rollGearEnchants("springs", "tank", "protection")));
        this.giveItem(player, this.createGearItem(bracket.sword(), this.rollGearEnchants("pummel", "bleed", "weakness")));
    }

    private void giveStormstrideRewards(Player player, RewardBracket bracket) {
        this.giveItem(player, this.createGearItem(bracket.boots(), this.rollGearEnchants("quick_feet", "tank", "hardened", "springs")));
        this.giveItem(player, this.createGearItem(bracket.sword(), this.rollGearEnchants("poison", "frenzy", "paralyze", "execution")));
    }

    private void giveItem(Player player, ItemStack item) {
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, item);
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
        for (ItemStack stack : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), stack);
        }
    }

    private void giveContraband(Player player, String crateId) {
        ItemStack contraband = this.contrabandService.createContraband(crateId);
        if (contraband == null) {
            this.plugin.getLogger().warning("Contraband tier not configured: " + crateId);
            return;
        }
        this.giveItem(player, contraband);
    }

    private ItemStack createGearItem(Material material, Map<String, Integer> enchants) {
        ItemStack item = this.createPrisonGear(material);
        if (enchants == null || enchants.isEmpty()) {
            return item;
        }
        for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
            org.axial.prisonsCore.model.CustomEnchant enchant = this.plugin.getGearEnchantService() != null ? this.plugin.getGearEnchantService().getById(entry.getKey()) : null;
            if (enchant == null) {
                continue;
            }
            this.gearManager.applyEnchant(item, enchant.getId(), entry.getValue().intValue(), enchant.getMaxLevel());
        }
        return item;
    }

    private Map<String, Integer> rollGearEnchants(String... ids) {
        LinkedHashMap<String, Integer> enchants = new LinkedHashMap<String, Integer>();
        if (ids == null) {
            return enchants;
        }
        for (String id : ids) {
            if (id == null || id.isBlank()) {
                continue;
            }
            org.axial.prisonsCore.model.CustomEnchant enchant = this.plugin.getGearEnchantService() != null ? this.plugin.getGearEnchantService().getById(id) : null;
            if (enchant == null) {
                continue;
            }
            enchants.put(enchant.getId(), Integer.valueOf(1 + this.random.nextInt(Math.max(1, enchant.getMaxLevel()))));
        }
        return enchants;
    }

    private int randomChargeAmount() {
        return 10000 + this.random.nextInt(140001);
    }

    private ItemStack createPrisonGear(Material material) {
        ItemStack base = new ItemStack(material);
        return this.gearManager.wrap(base, material.name().toLowerCase(Locale.ROOT));
    }

    private ItemStack createContrabandPreview(RewardBracket bracket) {
        ItemStack preview = this.contrabandService.tierPreview(bracket.crateId());
        if (preview != null) {
            return preview;
        }
        ItemStack item = new ItemStack(Material.CHEST);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Text.color(bracket.contrabandDisplayName()));
        meta.setLore(List.of(Text.color("&7Contraband tier: &f" + bracket.crateId())));
        item.setItemMeta(meta);
        return item;
    }

    public enum ClaimResult {
        CLAIMED,
        NO_PERMISSION,
        ON_COOLDOWN
    }

    public enum KitType {
        STARTER("starter", "Starter", "Starter", "prisons.kit.starter"),
        BETA("beta", "Vanguard", "Vanguard Kit", "prisons.kit.beta");

        private final String id;
        private final String plainName;
        private final String menuLabel;
        private final String permission;

        KitType(String id, String plainName, String menuLabel, String permission) {
            this.id = id;
            this.plainName = plainName;
            this.menuLabel = menuLabel;
            this.permission = permission;
        }

        public String id() {
            return this.id;
        }

        public String plainName() {
            return this.plainName;
        }

        public String menuLabel() {
            return this.menuLabel;
        }

        public String permission() {
            return this.permission;
        }
    }

    public enum GKitType {
        DEEPFORGE("deepforge", "Deepforge", "gkit.deepforge", Material.DIAMOND_PICKAXE),
        IRONHIDE("ironhide", "Ironhide", "gkit.ironhide", Material.IRON_AXE),
        STORMSTRIDE("stormstride", "Stormstride", "gkit.stormstride", Material.FEATHER);

        private final String id;
        private final String plainName;
        private final String permission;
        private final Material displayMaterial;

        GKitType(String id, String plainName, String permission, Material displayMaterial) {
            this.id = id;
            this.plainName = plainName;
            this.permission = permission;
            this.displayMaterial = displayMaterial;
        }

        public String id() {
            return this.id;
        }

        public String plainName() {
            return this.plainName;
        }

        public String permission() {
            return this.permission;
        }

        public Material displayMaterial() {
            return this.displayMaterial;
        }
    }

    public enum RewardBracket {
        ZERO_TO_THIRTY(0, 29, Material.CHAINMAIL_HELMET, Material.CHAINMAIL_CHESTPLATE, Material.CHAINMAIL_LEGGINGS, Material.CHAINMAIL_BOOTS, Material.STONE_SWORD, 200, 2500, ShardService.Tier.BASIC, "basic_cont", "&7Basic Contraband"),
        THIRTY_TO_FIFTY(30, 49, Material.GOLDEN_HELMET, Material.GOLDEN_CHESTPLATE, Material.GOLDEN_LEGGINGS, Material.GOLDEN_BOOTS, Material.GOLDEN_SWORD, 500, 15000, ShardService.Tier.RARE, "rare_cont", "&9Rare Contraband"),
        FIFTY_TO_SEVENTY(50, 69, Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS, Material.IRON_SWORD, 750, 50000, ShardService.Tier.ELITE, "elite_cont", "&dElite Contraband"),
        SEVENTY_TO_HUNDRED(70, 100, Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS, Material.DIAMOND_SWORD, 1000, 100000, ShardService.Tier.LEGENDARY, "legendary_cont", "&6Legendary Contraband");

        private final int minLevel;
        private final int maxLevel;
        private final Material helmet;
        private final Material chestplate;
        private final Material leggings;
        private final Material boots;
        private final Material sword;
        private final int starterCharge;
        private final int betaCharge;
        private final ShardService.Tier fragmentTier;
        private final String crateId;
        private final String contrabandDisplayName;

        RewardBracket(int minLevel, int maxLevel, Material helmet, Material chestplate, Material leggings, Material boots, Material sword, int starterCharge, int betaCharge, ShardService.Tier fragmentTier, String crateId, String contrabandDisplayName) {
            this.minLevel = minLevel;
            this.maxLevel = maxLevel;
            this.helmet = helmet;
            this.chestplate = chestplate;
            this.leggings = leggings;
            this.boots = boots;
            this.sword = sword;
            this.starterCharge = starterCharge;
            this.betaCharge = betaCharge;
            this.fragmentTier = fragmentTier;
            this.crateId = crateId;
            this.contrabandDisplayName = contrabandDisplayName;
        }

        public int minLevel() {
            return this.minLevel;
        }

        public int maxLevel() {
            return this.maxLevel;
        }

        public Material helmet() {
            return this.helmet;
        }

        public Material chestplate() {
            return this.chestplate;
        }

        public Material leggings() {
            return this.leggings;
        }

        public Material boots() {
            return this.boots;
        }

        public Material sword() {
            return this.sword;
        }

        public int starterCharge() {
            return this.starterCharge;
        }

        public int betaCharge() {
            return this.betaCharge;
        }

        public ShardService.Tier fragmentTier() {
            return this.fragmentTier;
        }

        public String crateId() {
            return this.crateId;
        }

        public String contrabandDisplayName() {
            return this.contrabandDisplayName;
        }
    }

    private CompletableFuture<Boolean> setGKitAccess(OfflinePlayer target, GKitType gkitType, boolean granted) {
        CompletableFuture<Boolean> future = new CompletableFuture<Boolean>();
        if (target == null || gkitType == null) {
            future.complete(Boolean.FALSE);
            return future;
        }
        Bukkit.getScheduler().runTask(this.plugin, () -> {
            if (Bukkit.getPluginManager().getPlugin("LuckPerms") != null) {
                String command = granted
                        ? "lp user " + target.getUniqueId() + " permission set " + gkitType.permission() + " true"
                        : "lp user " + target.getUniqueId() + " permission unset " + gkitType.permission();
                boolean dispatched = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
                if (!dispatched) {
                    future.completeExceptionally(new IllegalStateException("Failed to dispatch LuckPerms command for gkit access."));
                    return;
                }
            }
            this.playerDataService.update(target.getUniqueId(), data -> {
                if (granted) {
                    data.unblockGKit(gkitType.id());
                    data.unlockGKit(gkitType.id());
                } else {
                    data.removeGKit(gkitType.id());
                    data.blockGKit(gkitType.id());
                }
            });
            if (target.isOnline() && target.getPlayer() != null) {
                target.getPlayer().recalculatePermissions();
            }
            future.complete(Boolean.TRUE);
        });
        return future;
    }
}
