package org.axial.prisonsCore.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class ProtectionScrollService {
    private static final String PROTECTED_MARKER = "&f&lPROTECTED";
    private final PrisonsCore plugin;
    private final org.bukkit.NamespacedKey scrollKey;
    private final org.bukkit.NamespacedKey protectedKey;
    private Material material = Material.MAP;
    private String displayName = "&f&lProtection Scroll";
    private List<String> lore = List.of("&7Drag and Drop onto an item to", "&7keep it upon death. The scroll", "&7will be destroyed upon use.");

    public ProtectionScrollService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.scrollKey = Keys.protectionScroll(plugin);
        this.protectedKey = Keys.protectedItem(plugin);
        this.loadConfig();
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public ItemStack createScroll() {
        ItemStack stack = new ItemStack(this.material);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        meta.setDisplayName(Text.color(this.displayName));
        if (this.lore != null) {
            meta.setLore(this.lore.stream().map(Text::color).collect(Collectors.toList()));
        }
        meta.getPersistentDataContainer().set(this.scrollKey, PersistentDataType.BYTE, (byte)1);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isProtectionScroll(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.scrollKey, PersistentDataType.BYTE);
    }

    public boolean isProtected(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.protectedKey, PersistentDataType.BYTE);
    }

    public void protect(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.protectedKey, PersistentDataType.BYTE, (byte)1);
        stack.setItemMeta(meta);
        this.syncLore(stack);
    }

    public void unprotect(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().remove(this.protectedKey);
        stack.setItemMeta(meta);
        this.syncLore(stack);
    }

    public void syncLore(ItemStack stack) {
        if (stack == null || stack.getType().isAir() || !stack.hasItemMeta()) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        ArrayList<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<String>(meta.getLore()) : new ArrayList<String>();
        String marker = Text.color(PROTECTED_MARKER);
        lore.removeIf(line -> line != null && Text.strip(line).equalsIgnoreCase("PROTECTED"));
        if (this.isProtected(stack)) {
            if (!lore.isEmpty() && !Text.strip(lore.get(lore.size() - 1)).isEmpty()) {
                lore.add("");
            }
            lore.add(marker);
        }
        meta.setLore(lore.isEmpty() ? null : lore);
        stack.setItemMeta(meta);
    }

    public void refreshInventory(org.bukkit.entity.Player player) {
        if (player == null) {
            return;
        }
        for (ItemStack item : player.getInventory().getContents()) {
            this.syncLore(item);
        }
        for (ItemStack item : player.getInventory().getArmorContents()) {
            this.syncLore(item);
        }
        this.syncLore(player.getInventory().getItemInOffHand());
    }

    public void reload() {
        this.loadConfig();
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection section = cfg.getConfigurationSection("items.protection-scroll");
        if (section == null) {
            return;
        }
        Material mat = Material.matchMaterial(section.getString("material", this.material.name()));
        if (mat != null) {
            this.material = mat;
        }
        this.displayName = section.getString("display-name", this.displayName);
        this.lore = section.getStringList("lore");
        if (this.lore == null || this.lore.isEmpty()) {
            this.lore = List.of("&7Drag and Drop onto an item to", "&7keep it upon death. The scroll", "&7will be destroyed upon use.");
        }
    }
}
