/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.config.EnergyBarConfig;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.model.PickaxeType;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class PickaxeManager {
    private static final int MAX_LEVEL = 100;
    private static final double MAX_MINING_SPEED_BONUS = 0.10D;
    private static final int PRESTIGE_REQUIRED_LEVEL = 30;
    private static final int BASE_PRESTIGE_ORE_REQUIREMENT = 20000;
    private static final double PRESTIGE_ORE_MULTIPLIER = 1.1D;
    private final PrisonsCore plugin;
    private final Map<String, PickaxeType> types = new HashMap<String, PickaxeType>();
    private final EnergyBarConfig barConfig;
    private CustomEnchantService customEnchantService;
    private final NamespacedKey enchantsKey;
    private final NamespacedKey typeKey;
    private final NamespacedKey energyKey;
    private final NamespacedKey levelKey;
    private final NamespacedKey chargePercentsKey;
    private final NamespacedKey ironBrokenKey;
    private final NamespacedKey diamondBrokenKey;
    private final NamespacedKey emeraldBrokenKey;
    private final NamespacedKey customNameKey;
    private final NamespacedKey prestigeKey;
    private final NamespacedKey prestigeTokenKey;
    private final NamespacedKey prestigeIntensityKey;
    private final NamespacedKey prestigeDrillKey;
    private final NamespacedKey prestigeXpKey;
    private final NamespacedKey prestigeVanishKey;
    private final NamespacedKey prestigeHoarderKey;
    private final NamespacedKey prestigeFragmentFinderKey;
    private final NamespacedKey prestigePitRechargeKey;
    private final NamespacedKey drillBuffKey;
    private final NamespacedKey xpBuffKey;
    private final int defaultChargeSlots = 5;
    private final int maxChargeSlots = 8;
    private final int startLevel;
    private final double percentPerLevel;

    public PickaxeManager(PrisonsCore plugin, EnergyBarConfig barConfig, int startLevel, double percentPerLevel) {
        this.plugin = plugin;
        this.barConfig = barConfig;
        this.startLevel = startLevel;
        this.percentPerLevel = percentPerLevel;
        this.typeKey = Keys.pickaxeType(plugin);
        this.energyKey = Keys.pickaxeEnergy(plugin);
        this.enchantsKey = Keys.pickaxeEnchants(plugin);
        this.levelKey = Keys.pickaxeLevel(plugin);
        this.chargePercentsKey = Keys.pickaxeChargePercents(plugin);
        this.ironBrokenKey = Keys.pickaxeIronBroken(plugin);
        this.diamondBrokenKey = Keys.pickaxeDiamondBroken(plugin);
        this.emeraldBrokenKey = Keys.pickaxeEmeraldBroken(plugin);
        this.customNameKey = Keys.pickaxeCustomName(plugin);
        this.prestigeKey = Keys.pickaxePrestige(plugin);
        this.prestigeTokenKey = Keys.pickaxePrestigeToken(plugin);
        this.prestigeIntensityKey = Keys.pickaxePrestigeIntensity(plugin);
        this.prestigeDrillKey = Keys.pickaxePrestigeDrill(plugin);
        this.prestigeXpKey = Keys.pickaxePrestigeXp(plugin);
        this.prestigeVanishKey = Keys.pickaxePrestigeVanish(plugin);
        this.prestigeHoarderKey = Keys.pickaxePrestigeHoarder(plugin);
        this.prestigeFragmentFinderKey = Keys.pickaxePrestigeFragmentFinder(plugin);
        this.prestigePitRechargeKey = Keys.pickaxePrestigePitRecharge(plugin);
        this.drillBuffKey = Keys.pickaxeDrillBuff(plugin);
        this.xpBuffKey = Keys.pickaxeXpBuff(plugin);
        this.loadTypes();
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public void setCustomEnchantService(CustomEnchantService customEnchantService) {
        this.customEnchantService = customEnchantService;
    }

    public Collection<PickaxeType> getTypes() {
        return Collections.unmodifiableCollection(this.types.values());
    }

    public PickaxeType getType(String id) {
        return this.types.get(id.toLowerCase(Locale.ROOT));
    }

    public boolean isPrisonPickaxe(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return false;
        }
        PersistentDataContainer container = stack.getItemMeta().getPersistentDataContainer();
        return container.has(this.typeKey, PersistentDataType.STRING);
    }

    public String getPickaxeTypeId(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        return (String)stack.getItemMeta().getPersistentDataContainer().get(this.typeKey, PersistentDataType.STRING);
    }

    public int getEnergy(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return 0;
        }
        Integer value = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.energyKey, PersistentDataType.INTEGER);
        return value == null ? 0 : value;
    }

    public void setEnergy(ItemStack stack, int amount) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        String id = this.getPickaxeTypeId(stack);
        PickaxeType type = this.getType(id);
        if (type == null) {
            return;
        }
        int clamped = Math.max(0, Math.min(amount, this.getMaxEnergy(stack, type)));
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, clamped);
        stack.setItemMeta(meta);
        this.updateLore(stack, type, clamped);
    }

    public void setLevel(ItemStack stack, int level) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        int currentEnergy = this.getEnergy(stack);
        ItemMeta meta = stack.getItemMeta();
        int clampedLevel = Math.max(1, Math.min(MAX_LEVEL, level));
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, clampedLevel);
        String id = this.getPickaxeTypeId(stack);
        PickaxeType type = this.getType(id);
        if (type != null) {
            meta.setDisplayName(Text.color(this.buildName(stack, type, clampedLevel)));
        }
        stack.setItemMeta(meta);
        if (type != null) {
            this.updateLore(stack, type, currentEnergy);
        }
    }

    public void setEnergyOverflow(ItemStack stack, int amount) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        String id = this.getPickaxeTypeId(stack);
        PickaxeType type = this.getType(id);
        if (type == null) {
            return;
        }
        int value = Math.max(0, amount);
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, value);
        stack.setItemMeta(meta);
        this.updateLore(stack, type, value);
    }

    public int getLevel(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return this.startLevel;
        }
        Integer lvl = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.levelKey, PersistentDataType.INTEGER);
        return lvl == null ? this.startLevel : Math.max(1, Math.min(MAX_LEVEL, lvl));
    }

    public double getMiningSpeedMultiplier(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return 1.0D;
        }
        int level = this.getLevel(stack);
        if (level <= 1) {
            return 1.0D;
        }
        double progress = (double)(level - 1) / (double)(MAX_LEVEL - 1);
        return 1.0D + Math.min(MAX_MINING_SPEED_BONUS, progress * MAX_MINING_SPEED_BONUS);
    }

    public void levelUp(ItemStack stack) {
        String id = this.getPickaxeTypeId(stack);
        PickaxeType type = this.getType(id);
        if (type == null) {
            return;
        }
        int currentLevel = this.getLevel(stack);
        if (currentLevel >= MAX_LEVEL) {
            return;
        }
        int newLevel = Math.min(MAX_LEVEL, currentLevel + 1);
        int currentEnergy = this.getEnergy(stack);
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, newLevel);
        meta.setDisplayName(Text.color(this.buildName(stack, type, newLevel)));
        stack.setItemMeta(meta);
        this.updateLore(stack, type, currentEnergy);
    }

    public int getPrestige(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.prestigeKey, PersistentDataType.INTEGER);
        return val == null ? 0 : Math.max(0, val);
    }

    public void setPrestige(ItemStack stack, int level) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.prestigeKey, PersistentDataType.INTEGER, Math.max(0, level));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public boolean hasPrestigeToken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return false;
        }
        Byte b = (Byte)stack.getItemMeta().getPersistentDataContainer().get(this.prestigeTokenKey, PersistentDataType.BYTE);
        return b != null && b == 1;
    }

    public PrestigeTokenApplicationResult applyPrestigeToken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return PrestigeTokenApplicationResult.NOT_PICKAXE;
        }
        if (this.hasPrestigeToken(stack)) {
            return PrestigeTokenApplicationResult.ALREADY_APPLIED;
        }
        boolean meetsLevel = this.getLevel(stack) >= PRESTIGE_REQUIRED_LEVEL;
        int requiredOre = this.getPrestigeOreRequirement(stack);
        boolean meetsOre = requiredOre <= 0 || this.getPrestigeOreCount(stack) >= requiredOre;
        if (!meetsLevel && !meetsOre) {
            return PrestigeTokenApplicationResult.LEVEL_AND_ORE_TOO_LOW;
        }
        if (!meetsLevel) {
            return PrestigeTokenApplicationResult.LEVEL_TOO_LOW;
        }
        if (!meetsOre) {
            return PrestigeTokenApplicationResult.ORE_TOO_LOW;
        }
        this.setPrestigeToken(stack, true);
        return PrestigeTokenApplicationResult.SUCCESS;
    }

    public void setPrestigeToken(ItemStack stack, boolean ready) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.prestigeTokenKey, PersistentDataType.BYTE, (byte)(ready ? 1 : 0));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public int getPrestigeBuffLevel(ItemStack stack, PrestigeBuff buff) {
        if (!this.isPrisonPickaxe(stack) || buff == null) {
            return 0;
        }
        NamespacedKey key = this.getPrestigeBuffKey(buff);
        if (key == null) {
            return 0;
        }
        Integer value = (Integer)stack.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.INTEGER);
        if (value == null) {
            value = switch (buff) {
                case DRILL -> (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.drillBuffKey, PersistentDataType.INTEGER);
                case XP_MASTERY -> (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.xpBuffKey, PersistentDataType.INTEGER);
                default -> null;
            };
        }
        return value == null ? 0 : Math.max(0, Math.min(buff.getMaxLevel(), value));
    }

    public void setPrestigeBuffLevel(ItemStack stack, PrestigeBuff buff, int level) {
        if (!this.isPrisonPickaxe(stack) || buff == null) {
            return;
        }
        NamespacedKey key = this.getPrestigeBuffKey(buff);
        if (key == null) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        int clamped = Math.max(0, Math.min(buff.getMaxLevel(), level));
        meta.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, clamped);
        switch (buff) {
            case DRILL -> meta.getPersistentDataContainer().set(this.drillBuffKey, PersistentDataType.INTEGER, clamped);
            case XP_MASTERY -> meta.getPersistentDataContainer().set(this.xpBuffKey, PersistentDataType.INTEGER, clamped);
            default -> {
            }
        }
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public boolean addPrestigeBuffLevel(ItemStack stack, PrestigeBuff buff) {
        if (!this.isPrisonPickaxe(stack) || buff == null) {
            return false;
        }
        int current = this.getPrestigeBuffLevel(stack, buff);
        if (current >= buff.getMaxLevel()) {
            return false;
        }
        this.setPrestigeBuffLevel(stack, buff, current + 1);
        return true;
    }

    public boolean hasAnyPrestigeBuff(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return false;
        }
        for (PrestigeBuff buff : PrestigeBuff.values()) {
            if (this.getPrestigeBuffLevel(stack, buff) > 0) {
                return true;
            }
        }
        return false;
    }

    public boolean isPrestigeBuffMaxed(ItemStack stack, PrestigeBuff buff) {
        return this.getPrestigeBuffLevel(stack, buff) >= buff.getMaxLevel();
    }

    public String getPrestigeBuffDescription(ItemStack stack, PrestigeBuff buff) {
        int level = this.getPrestigeBuffLevel(stack, buff);
        if (buff == null || level <= 0) {
            return null;
        }
        return buff.describe(level);
    }

    public String getPrestigeBuffDisplayName(PrestigeBuff buff) {
        return buff == null ? null : buff.getDisplayName();
    }

    public double getIntensityDamageMultiplier(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.INTENSITY);
        return Math.max(0.0D, 1.0D - (double)level * 0.08D);
    }

    public double getDrillSpeedMultiplier(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.DRILL);
        return 1.0D + (double)level * 0.25D;
    }

    public double getDrillProgressBonus(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.DRILL);
        return (double)level * 0.03D;
    }

    public double getXpMasteryMultiplier(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.XP_MASTERY);
        return 1.0D + (double)level * 0.25D;
    }

    public double getVanishChance(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.VANISH);
        return Math.min(1.0D, (double)level * 0.05D);
    }

    public int getVanishDurationTicks(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.VANISH);
        if (level <= 0) {
            return 0;
        }
        return 40 + level * 20;
    }

    public double getHoarderMultiplier(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.HOARDER);
        return 1.0D + (double)level * 0.20D;
    }

    public double getFragmentFinderMultiplier(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.FRAGMENT_FINDER);
        return 1.0D + (double)level * 0.30D;
    }

    public int getFragmentFinderChanceBonusPercent(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.FRAGMENT_FINDER);
        return (int)Math.round((double)level * 30.0D);
    }

    public double getPitRechargeChance(ItemStack stack) {
        int level = this.getPrestigeBuffLevel(stack, PrestigeBuff.PIT_RECHARGE);
        return Math.min(1.0D, (double)level * 0.10D);
    }

    public boolean rollPitRecharge(ItemStack stack, Random random) {
        double chance = this.getPitRechargeChance(stack);
        return random != null && chance > 0.0D && random.nextDouble() < chance;
    }

    public boolean consumePrestigeTokenAndReset(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return false;
        }
        int currentPrestige = this.getPrestige(stack);
        this.setPrestige(stack, currentPrestige + 1);
        this.setPrestigeToken(stack, false);
        this.setLevel(stack, 1);
        this.setEnergy(stack, 0);
        this.resetBrokenOres(stack);
        return true;
    }

    public void resetBrokenOres(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.ironBrokenKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(this.diamondBrokenKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(this.emeraldBrokenKey, PersistentDataType.INTEGER, 0);
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public int getPrestigeRequirementLevel() {
        return PRESTIGE_REQUIRED_LEVEL;
    }

    public int getPrestigeOreRequirementBase() {
        return BASE_PRESTIGE_ORE_REQUIREMENT;
    }

    public void setDrillBuff(ItemStack stack, int percent) {
        this.setPrestigeBuffLevel(stack, PrestigeBuff.DRILL, percent);
    }

    public int getDrillBuff(ItemStack stack) {
        return this.getPrestigeBuffLevel(stack, PrestigeBuff.DRILL);
    }

    public void setXpBuff(ItemStack stack, int percent) {
        this.setPrestigeBuffLevel(stack, PrestigeBuff.XP_MASTERY, percent);
    }

    public int getXpBuff(ItemStack stack) {
        return this.getPrestigeBuffLevel(stack, PrestigeBuff.XP_MASTERY);
    }

    public int getMaxEnergy(ItemStack stack) {
        String id = this.getPickaxeTypeId(stack);
        PickaxeType type = this.getType(id);
        if (type == null) {
            return 0;
        }
        return this.getMaxEnergy(stack, type);
    }

    public boolean canPrestige(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return false;
        }
        if (this.getLevel(stack) < PRESTIGE_REQUIRED_LEVEL) {
            return false;
        }
        int requiredOre = this.getPrestigeOreRequirement(stack);
        return requiredOre <= 0 || this.getPrestigeOreCount(stack) >= requiredOre;
    }

    private int[] getChargePercentsArray(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return null;
        }
        return (int[])stack.getItemMeta().getPersistentDataContainer().get(this.chargePercentsKey, PersistentDataType.INTEGER_ARRAY);
    }

    public int getChargeSlotsTotal(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return 5;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(Keys.pickaxeChargeSlots(this.plugin), PersistentDataType.INTEGER);
        if (val == null || val <= 0) {
            return 5;
        }
        return Math.min(8, val);
    }

    public boolean addChargeSlot(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return false;
        }
        int current = this.getChargeSlotsTotal(stack);
        if (current >= 8) {
            return false;
        }
        int newTotal = Math.min(8, current + 1);
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(Keys.pickaxeChargeSlots(this.plugin), PersistentDataType.INTEGER, newTotal);
        stack.setItemMeta(meta);
        this.updateLore(stack);
        return true;
    }

    public int getTotalChargePercent(ItemStack stack) {
        int[] vals = this.getChargePercentsArray(stack);
        if (vals == null || vals.length == 0) {
            return 0;
        }
        int max = 0;
        for (int v : vals) {
            max = Math.max(max, v);
        }
        return max;
    }

    public double getChargeMultiplier(ItemStack stack) {
        return 1.0 + (double)this.getTotalChargePercent(stack) / 100.0;
    }

    public int getChargeSlotsUsed(ItemStack stack) {
        int[] vals = this.getChargePercentsArray(stack);
        return vals == null ? 0 : vals.length;
    }

    public boolean addChargeOrb(ItemStack stack, int percent, int maxSlots) {
        if (!this.isPrisonPickaxe(stack)) {
            return false;
        }
        int[] current = this.getChargePercentsArray(stack);
        if (current == null) {
            current = new int[]{};
        }
        int slots = Math.max(this.getChargeSlotsTotal(stack), maxSlots > 0 ? maxSlots : 5);
        slots = Math.min(slots, 8);
        int currentMax = this.getTotalChargePercent(stack);
        if (percent <= currentMax) {
            return false;
        }
        if (current.length >= slots) {
            return false;
        }
        int[] updated = Arrays.copyOf(current, current.length + 1);
        updated[updated.length - 1] = percent;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.chargePercentsKey, PersistentDataType.INTEGER_ARRAY, updated);
        stack.setItemMeta(meta);
        this.updateLore(stack);
        return true;
    }

    private int getMaxEnergy(ItemStack stack, PickaxeType type) {
        int level = this.getLevel(stack);
        if (level >= MAX_LEVEL) {
            return Integer.MAX_VALUE;
        }
        double multiplier = Math.pow(1.25D, Math.max(0, level - 1));
        return (int)Math.round((double)type.getMaxEnergy() * multiplier);
    }

    public String getCustomName(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return null;
        }
        return (String)stack.getItemMeta().getPersistentDataContainer().get(this.customNameKey, PersistentDataType.STRING);
    }

    public void setCustomName(ItemStack stack, String rawName) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        String id = this.getPickaxeTypeId(stack);
        PickaxeType type = this.getType(id);
        if (type == null) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        if (rawName == null || rawName.isBlank()) {
            meta.getPersistentDataContainer().remove(this.customNameKey);
        } else {
            meta.getPersistentDataContainer().set(this.customNameKey, PersistentDataType.STRING, rawName);
        }
        String base = rawName != null && !rawName.isBlank() ? rawName : type.getDisplayName();
        meta.setDisplayName(Text.color(base + " &a&l" + this.getLevel(stack)));
        stack.setItemMeta(meta);
        this.updateLore(stack, type, this.getEnergy(stack));
    }

    private String buildName(ItemStack stack, PickaxeType type, int level) {
        String raw = this.getCustomName(stack);
        String base = raw != null && !raw.isBlank() ? raw : type.getDisplayName();
        return base + " &a&l" + level;
    }

    private String toRoman(int number) {
        String[] romans = new String[]{"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        if (number >= 1 && number < romans.length) {
            return romans[number];
        }
        return String.valueOf(number);
    }

    public ItemStack createPickaxe(PickaxeType type, int startingEnergy) {
        ItemStack stack = new ItemStack(type.getMaterial());
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(this.buildName(stack, type, this.startLevel)));
            meta.getPersistentDataContainer().set(this.typeKey, PersistentDataType.STRING, type.getId());
            meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, Math.max(startingEnergy, 0));
            meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, this.startLevel);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_UNBREAKABLE});
            meta.setUnbreakable(true);
            meta.setEnchantmentGlintOverride(Boolean.valueOf(false));
            stack.setItemMeta(meta);
        }
        this.updateLore(stack, type, startingEnergy);
        return stack;
    }

    public boolean givePickaxe(Player player, String typeId) {
        PickaxeType type = this.getType(typeId);
        if (type == null) {
            return false;
        }
        ItemStack stack = this.createPickaxe(type, 0);
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, stack);
        } else {
            player.getInventory().addItem(new ItemStack[]{stack});
        }
        return true;
    }

    public int addEnergy(ItemStack stack, int amount) {
        String id = this.getPickaxeTypeId(stack);
        if (id == null) {
            return 0;
        }
        PickaxeType type = this.getType(id);
        if (type == null) {
            return 0;
        }
        int current = this.getEnergy(stack);
        long target = (long)current + Math.max(0, amount);
        int newAmount = (int)Math.min((long)this.getMaxEnergy(stack, type), target);
        this.setEnergy(stack, newAmount);
        return newAmount - current;
    }

    public int addEnergyOverflow(ItemStack stack, int amount) {
        String id = this.getPickaxeTypeId(stack);
        if (id == null) {
            return 0;
        }
        PickaxeType type = this.getType(id);
        if (type == null) {
            return 0;
        }
        int current = this.getEnergy(stack);
        int target = current + Math.max(0, amount);
        this.setEnergyOverflow(stack, target);
        return target - current;
    }

    public int getMaxLevel() {
        return MAX_LEVEL;
    }

    public boolean isAllowedBlock(ItemStack stack, Material block) {
        String id = this.getPickaxeTypeId(stack);
        if (id == null) {
            return false;
        }
        if (this.isQuartzOre(block)) {
            return true;
        }
        PickaxeType type = this.getType(id);
        return type != null && type.getAllowedBlocks().contains(this.normalizeBlock(block));
    }

    public int energyForBlock(ItemStack stack, Material block) {
        String id = this.getPickaxeTypeId(stack);
        if (id == null) {
            return 0;
        }
        PickaxeType type = this.getType(id);
        if (type == null) {
            return 0;
        }
        return type.getEnergyValues().getOrDefault(this.normalizeBlock(block), 0);
    }

    private Material normalizeBlock(Material block) {
        if (block == null) {
            return null;
        }
        return switch (block) {
            case DEEPSLATE_COAL_ORE -> Material.COAL_ORE;
            case DEEPSLATE_IRON_ORE -> Material.IRON_ORE;
            case DEEPSLATE_COPPER_ORE -> Material.COPPER_ORE;
            case DEEPSLATE_GOLD_ORE -> Material.GOLD_ORE;
            case NETHER_GOLD_ORE -> Material.GOLD_ORE;
            case DEEPSLATE_REDSTONE_ORE -> Material.REDSTONE_ORE;
            case DEEPSLATE_LAPIS_ORE -> Material.LAPIS_ORE;
            case DEEPSLATE_DIAMOND_ORE -> Material.DIAMOND_ORE;
            case DEEPSLATE_EMERALD_ORE -> Material.EMERALD_ORE;
            default -> block;
        };
    }

    private boolean isQuartzOre(Material block) {
        if (block == null) {
            return false;
        }
        if (block == Material.NETHER_QUARTZ_ORE) {
            return true;
        }
        Material quartz = Material.matchMaterial("QUARTZ_ORE");
        return quartz != null && block == quartz;
    }

    public boolean isFull(ItemStack stack) {
        String id = this.getPickaxeTypeId(stack);
        if (id == null) {
            return false;
        }
        PickaxeType type = this.getType(id);
        return type != null && this.getEnergy(stack) >= this.getMaxEnergy(stack, type);
    }

    public Map<String, Integer> getEnchants(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return Collections.emptyMap();
        }
        String raw = (String)stack.getItemMeta().getPersistentDataContainer().get(this.enchantsKey, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) {
            return Collections.emptyMap();
        }
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        for (String pair : raw.split(";")) {
            String[] parts = pair.split(":");
            if (parts.length != 2) continue;
            try {
                map.put(parts[0], Integer.parseInt(parts[1]));
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return map;
    }

    public void setEnchants(ItemStack stack, Map<String, Integer> enchants) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        String serialized = enchants.entrySet().stream().map(e -> (String)e.getKey() + ":" + String.valueOf(e.getValue())).collect(Collectors.joining(";"));
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.enchantsKey, PersistentDataType.STRING, serialized);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setEnchantmentGlintOverride(Boolean.valueOf(!enchants.isEmpty()));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public void clearAllEnchantments(ItemStack stack) {
        if (stack == null) {
            return;
        }
        for (Enchantment ench : new ArrayList<>(stack.getEnchantments().keySet())) {
            stack.removeEnchantment(ench);
        }
    }

    public int getIronBroken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.ironBrokenKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public void incrementIronBroken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        int current = this.getIronBroken(stack);
        meta.getPersistentDataContainer().set(this.ironBrokenKey, PersistentDataType.INTEGER, current + 1);
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public void addIronBroken(ItemStack stack, int amount) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        int current = this.getIronBroken(stack);
        meta.getPersistentDataContainer().set(this.ironBrokenKey, PersistentDataType.INTEGER, Math.max(0, current + amount));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public int getDiamondBroken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.diamondBrokenKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public void incrementDiamondBroken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        int current = this.getDiamondBroken(stack);
        meta.getPersistentDataContainer().set(this.diamondBrokenKey, PersistentDataType.INTEGER, current + 1);
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public void addDiamondBroken(ItemStack stack, int amount) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        int current = this.getDiamondBroken(stack);
        meta.getPersistentDataContainer().set(this.diamondBrokenKey, PersistentDataType.INTEGER, Math.max(0, current + amount));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public int getEmeraldBroken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.emeraldBrokenKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public int getPrestigeOreCount(ItemStack stack) {
        Material material = this.getPrestigeOreMaterial(stack);
        if (material == null) {
            return 0;
        }
        return switch (material) {
            case Material.IRON_ORE -> this.getIronBroken(stack);
            case Material.DIAMOND_ORE -> this.getDiamondBroken(stack);
            case Material.EMERALD_ORE -> this.getEmeraldBroken(stack);
            default -> 0;
        };
    }

    public int getPrestigeOreRequirement(ItemStack stack) {
        Material material = this.getPrestigeOreMaterial(stack);
        if (material == null) {
            return 0;
        }
        double scaled = (double)BASE_PRESTIGE_ORE_REQUIREMENT * Math.pow(PRESTIGE_ORE_MULTIPLIER, this.getPrestige(stack));
        return (int)Math.round(scaled);
    }

    public String getPrestigeOreLabel(ItemStack stack) {
        Material material = this.getPrestigeOreMaterial(stack);
        if (material == null) {
            return null;
        }
        return switch (material) {
            case Material.IRON_ORE -> "Iron";
            case Material.DIAMOND_ORE -> "Diamond";
            case Material.EMERALD_ORE -> "Emerald";
            default -> null;
        };
    }

    private Material getPrestigeOreMaterial(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return null;
        }
        String id = this.getPickaxeTypeId(stack);
        if (id == null) {
            return null;
        }
        PickaxeType type = this.getType(id);
        if (type == null) {
            return null;
        }
        return switch (type.getMaterial()) {
            case Material.WOODEN_PICKAXE -> Material.IRON_ORE;
            case Material.GOLDEN_PICKAXE -> Material.DIAMOND_ORE;
            case Material.DIAMOND_PICKAXE -> Material.EMERALD_ORE;
            default -> null;
        };
    }

    public void incrementEmeraldBroken(ItemStack stack) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        int current = this.getEmeraldBroken(stack);
        meta.getPersistentDataContainer().set(this.emeraldBrokenKey, PersistentDataType.INTEGER, current + 1);
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public void addEmeraldBroken(ItemStack stack, int amount) {
        if (!this.isPrisonPickaxe(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        int current = this.getEmeraldBroken(stack);
        meta.getPersistentDataContainer().set(this.emeraldBrokenKey, PersistentDataType.INTEGER, Math.max(0, current + amount));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public boolean applyEnchant(ItemStack stack, String id, int level, int maxLevel) {
        HashMap<String, Integer> enchants = new HashMap<String, Integer>(this.getEnchants(stack));
        int current = enchants.getOrDefault(id, 0);
        int newLevel = Math.min(maxLevel, Math.max(current, level));
        enchants.put(id, newLevel);
        this.setEnchants(stack, enchants);
        return newLevel != current;
    }

    public void updateLore(ItemStack stack) {
        String id = this.getPickaxeTypeId(stack);
        if (id == null) {
            return;
        }
        PickaxeType type = this.getType(id);
        if (type == null) {
            return;
        }
        this.updateLore(stack, type, this.getEnergy(stack));
    }

    private void updateLore(ItemStack stack, PickaxeType type, int energy) {
        ItemMeta meta = stack.getItemMeta();
        ArrayList<String> lore = new ArrayList<String>();
        Map<String, Integer> enchants = this.getEnchants(stack);
        if (!enchants.isEmpty()) {
            for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
                CustomEnchant ce;
                int lvl = entry.getValue();
                String chosen = this.customEnchantService != null ? ((ce = this.customEnchantService.getById(entry.getKey())) != null ? ce.getLoreLine(lvl, "&d{enchant} {level}") : "&d{enchant} {level}") : "&d{enchant} {level}";
                String line = chosen.replace("{enchant}", entry.getKey()).replace("{level}", this.toRoman(lvl));
                lore.add(Text.color(line));
            }
        }
        if (this.hasAnyPrestigeBuff(stack) || this.hasPrestigeToken(stack)) {
            lore.add("");
            for (PrestigeBuff buff : PrestigeBuff.values()) {
                int level = this.getPrestigeBuffLevel(stack, buff);
                if (level <= 0) {
                    continue;
                }
                lore.add(Text.color("&b&l" + buff.getDisplayName() + " " + level + " &f- " + buff.describe(level)));
            }
        }
        int maxEnergy = this.getMaxEnergy(stack, type);
        double percent = Math.min(1.0, Math.max(0.0, (double)energy / (double)maxEnergy));
        int filled = (int)Math.round(percent * (double)this.barConfig.getLength());
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < this.barConfig.getLength(); ++i) {
            if (i < filled) {
                bar.append(this.barConfig.getFilledColor()).append(this.barConfig.getFilledChar());
                continue;
            }
            bar.append(this.barConfig.getEmptyColor()).append(this.barConfig.getEmptyChar());
        }
        lore.add("");
        lore.add(Text.color(this.plugin.getConfig().getString("energy.label", "&d&lPickaxe Charge")));
        String maxDisplay = this.getLevel(stack) >= MAX_LEVEL ? "MAX" : Text.formatNumber(maxEnergy);
        String barLine = this.barConfig.getFormat()
                .replace("{bar}", ChatColor.translateAlternateColorCodes((char)'&', bar.toString()))
                .replace("{current}", Text.formatNumber(energy))
                .replace("{max}", maxDisplay)
                .replace("{percent}", String.format("%.1f", percent * 100.0));
        double percentDisplay = Math.round(percent * 1000.0) / 10.0;
        barLine = barLine + Text.color(" &f&l" + percentDisplay + "%");
        lore.add(Text.color(barLine));
        boolean overflow = energy > maxEnergy;
        String currentColor = overflow ? "&d" : "&f";
        lore.add(Text.color("&7(" + currentColor + Text.formatNumber(energy) + " &7/ &f" + maxDisplay + ")"));
        lore.add("");
        int chargeBonus = this.getTotalChargePercent(stack);
        int chargeSlotsUsed = this.getChargeSlotsUsed(stack);
        int chargeSlotsTotal = this.getChargeSlotsTotal(stack);
        int chargeSlotsAvailable = Math.max(0, chargeSlotsTotal - chargeSlotsUsed);
        if (chargeBonus > 0) {
            lore.add(Text.color("&f&n" + chargeSlotsUsed + "&r&7/&f&n" + chargeSlotsAvailable + "&r &7charge slots available."));
            lore.add(Text.color("&7Pickaxe earning a &d+" + chargeBonus + "% &7gain."));
        } else {
            lore.add(Text.color("&f&n" + chargeSlotsAvailable + "&r&7/&f&n" + chargeSlotsTotal + "&r &7charge slots available."));
            lore.add(Text.color("&7apply a charge orb to unlock"));
            lore.add(Text.color("&d+ energy gain."));
        }
        if (type.getBaseLore() != null) {
            lore.addAll(type.getBaseLore().stream().map(Text::color).collect(Collectors.toList()));
        }
        int requiredOre = this.getPrestigeOreRequirement(stack);
        if (type.getMaterial() == Material.WOODEN_PICKAXE) {
            lore.add("");
            lore.add(Text.color("&eIron ore broken: &f" + Text.formatNumber(this.getIronBroken(stack)) + " &7/ &f" + Text.formatNumber(requiredOre)));
        } else if (type.getMaterial() == Material.GOLDEN_PICKAXE) {
            lore.add("");
            lore.add(Text.color("&eDiamond ore broken: &f" + Text.formatNumber(this.getDiamondBroken(stack)) + " &7/ &f" + Text.formatNumber(requiredOre)));
        } else if (type.getMaterial() == Material.DIAMOND_PICKAXE) {
            lore.add("");
            lore.add(Text.color("&eEmerald ore broken: &f" + Text.formatNumber(this.getEmeraldBroken(stack)) + " &7/ &f" + Text.formatNumber(requiredOre)));
        }
        int reqLevel = -1;
        ConfigurationSection lvlSec = this.plugin.getConfig().getConfigurationSection("pickaxe-levels");
        if (lvlSec != null && lvlSec.contains(type.getMaterial().name())) {
            reqLevel = lvlSec.getInt(type.getMaterial().name(), -1);
        }
        if (reqLevel < 0) {
            reqLevel = this.defaultRequiredLevel(type.getMaterial());
        }
        if (type.getMaterial() == Material.WOODEN_PICKAXE) {
            reqLevel = 2;
        }
        if (reqLevel >= 0) {
            lore.add("");
            lore.add(Text.color("&eRequired Level &f&l" + reqLevel));
        }
        if (this.hasPrestigeToken(stack)) {
            lore.add("");
            lore.add(Text.color("&6&lPrestige Token Applied"));
        }
        meta.setLore(lore);
        stack.setItemMeta(meta);
    }

    private int defaultRequiredLevel(Material material) {
        return switch (material) {
            case Material.WOODEN_PICKAXE -> 2;
            case Material.STONE_PICKAXE -> 20;
            case Material.IRON_PICKAXE -> 30;
            case Material.GOLDEN_PICKAXE -> 50;
            case Material.DIAMOND_PICKAXE -> 75;
            default -> -1;
        };
    }

    public void reloadTypes() {
        this.loadTypes();
    }

    private void loadTypes() {
        YamlConfiguration cfg;
        ConfigurationSection section;
        this.types.clear();
        File file = new File(this.plugin.getDataFolder(), "pickaxes.yml");
        if (!file.exists()) {
            this.plugin.saveResource("pickaxes.yml", false);
        }
        if ((section = (cfg = YamlConfiguration.loadConfiguration((File)file)).getConfigurationSection("pickaxes")) == null) {
            this.plugin.getLogger().warning("No pickaxe types configured in pickaxes.yml");
            return;
        }
        for (String id : section.getKeys(false)) {
            ConfigurationSection node = section.getConfigurationSection(id);
            if (node == null) continue;
            Material material = Material.matchMaterial((String)node.getString("material", "DIAMOND_PICKAXE"));
            if (material == null) {
                this.plugin.getLogger().warning("Unknown material for pickaxe " + id);
                continue;
            }
            String display = node.getString("display-name", id);
            int maxEnergy = node.getInt("max-energy", 1000);
            HashSet<Material> allowedBlocks = new HashSet<Material>();
            for (String mat : node.getStringList("allowed-blocks")) {
                Material block = Material.matchMaterial((String)mat);
                if (block == null) continue;
                allowedBlocks.add(block);
            }
            HashMap<Material, Integer> energyValues = new HashMap<Material, Integer>();
            ConfigurationSection energySec = node.getConfigurationSection("energy-per-block");
            if (energySec != null) {
                for (String key : energySec.getKeys(false)) {
                    Material block = Material.matchMaterial((String)key);
                    if (block == null) continue;
                    energyValues.put(block, energySec.getInt(key));
                }
            }
            List baseLore = node.getStringList("lore");
            this.applyOreDefaults(id.toLowerCase(Locale.ROOT), allowedBlocks, energyValues);
            PickaxeType type = new PickaxeType(id.toLowerCase(Locale.ROOT), material, display, maxEnergy, allowedBlocks, energyValues, baseLore);
            this.types.put(type.getId(), type);
        }
        Bukkit.getLogger().info("Loaded " + this.types.size() + " pickaxe types.");
    }

    private void applyOreDefaults(String id, Set<Material> allowedBlocks, Map<Material, Integer> energyValues) {
        if (allowedBlocks == null || energyValues == null) {
            return;
        }
        if ("iron".equals(id)) {
            allowedBlocks.add(Material.GOLD_ORE);
            allowedBlocks.remove(Material.REDSTONE_ORE);
            allowedBlocks.remove(Material.DEEPSLATE_REDSTONE_ORE);
            energyValues.putIfAbsent(Material.GOLD_ORE, 260);
            energyValues.remove(Material.REDSTONE_ORE);
            energyValues.remove(Material.DEEPSLATE_REDSTONE_ORE);
        } else if ("golden".equals(id)) {
            allowedBlocks.add(Material.REDSTONE_ORE);
            allowedBlocks.add(Material.DEEPSLATE_REDSTONE_ORE);
            allowedBlocks.remove(Material.GOLD_ORE);
            allowedBlocks.remove(Material.DEEPSLATE_GOLD_ORE);
            allowedBlocks.remove(Material.NETHER_GOLD_ORE);
            energyValues.putIfAbsent(Material.REDSTONE_ORE, 130);
            energyValues.remove(Material.GOLD_ORE);
            energyValues.remove(Material.DEEPSLATE_GOLD_ORE);
            energyValues.remove(Material.NETHER_GOLD_ORE);
        } else if ("diamond".equals(id)) {
            allowedBlocks.add(Material.GOLD_ORE);
            allowedBlocks.add(Material.DEEPSLATE_GOLD_ORE);
            allowedBlocks.add(Material.NETHER_GOLD_ORE);
            energyValues.putIfAbsent(Material.GOLD_ORE, 165);
        }
    }

    private NamespacedKey getPrestigeBuffKey(PrestigeBuff buff) {
        return switch (buff) {
            case INTENSITY -> this.prestigeIntensityKey;
            case DRILL -> this.prestigeDrillKey;
            case XP_MASTERY -> this.prestigeXpKey;
            case VANISH -> this.prestigeVanishKey;
            case HOARDER -> this.prestigeHoarderKey;
            case FRAGMENT_FINDER -> this.prestigeFragmentFinderKey;
            case PIT_RECHARGE -> this.prestigePitRechargeKey;
        };
    }

    public enum PrestigeBuff {
        INTENSITY("Intensity", 5) {
            @Override
            public String describe(int level) {
                return "Take " + this.percentText(level, 8.0D) + " less damage while holding this pickaxe.";
            }
        },
        DRILL("Drill", 6) {
            @Override
            public String describe(int level) {
                return "Mining speed increased by " + this.percentText(level, 25.0D) + ".";
            }
        },
        XP_MASTERY("Xp Mastery", 3) {
            @Override
            public String describe(int level) {
                return "Gain " + this.percentText(level, 25.0D) + " more mining XP.";
            }
        },
        VANISH("Vanish", 5) {
            @Override
            public String describe(int level) {
                return "Mining ores can briefly hide you for " + (2 + level) + "s.";
            }
        },
        HOARDER("Hoarder", 6) {
            @Override
            public String describe(int level) {
                return "Gain more ores while mining.";
            }
        },
        FRAGMENT_FINDER("Fragment Finder", 5) {
            @Override
            public String describe(int level) {
                return "Gain " + this.percentText(level, 30.0D) + " more fragment discovery chance while mining.";
            }
        },
        PIT_RECHARGE("Pit Recharge", 3) {
            @Override
            public String describe(int level) {
                return "Gain " + this.percentText(level, 10.0D) + " chance to not consume charge when enchanting.";
            }
        };

        private final String displayName;
        private final int maxLevel;

        PrestigeBuff(String displayName, int maxLevel) {
            this.displayName = displayName;
            this.maxLevel = maxLevel;
        }

        public String getDisplayName() {
            return this.displayName;
        }

        public int getMaxLevel() {
            return this.maxLevel;
        }

        public abstract String describe(int level);

        protected String percentText(int level, double perLevel) {
            int scaled = (int)Math.round(Math.min(150.0D, (double)level * perLevel));
            return scaled + "%";
        }
    }

    public enum PrestigeTokenApplicationResult {
        SUCCESS,
        NOT_PICKAXE,
        ALREADY_APPLIED,
        LEVEL_TOO_LOW,
        ORE_TOO_LOW,
        LEVEL_AND_ORE_TOO_LOW
    }
}
