package org.axial.prisonsCore.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.messaging.Messenger;
import org.bukkit.plugin.messaging.PluginMessageListener;
import org.bukkit.scheduler.BukkitTask;

public class AxialModVerificationService implements PluginMessageListener {
    private static final String CHANNEL = "axialutils:mod_verification";
    private static final String CURRENT_VERSION = "Version 1.1";
    private static final double AXIAL_XP_MULTIPLIER = 2.0D;
    private static final int AXIAL_XP_DURATION_SECONDS = Integer.MAX_VALUE;
    private static final long CHALLENGE_TIMEOUT_MS = 15_000L;
    private static final long CHALLENGE_RESEND_MS = 5_000L;
    private static final long ACTIVE_SESSION_TTL_MS = 45_000L;

    private final PrisonsCore plugin;
    private final BoosterService boosterService;
    private final Map<UUID, Session> sessions = new HashMap<>();
    private BukkitTask cleanupTask;

    public AxialModVerificationService(PrisonsCore plugin, BoosterService boosterService) {
        this.plugin = plugin;
        this.boosterService = boosterService;
    }

    public void start() {
        if (this.cleanupTask != null) {
            return;
        }

        Messenger messenger = this.plugin.getServer().getMessenger();
        messenger.registerOutgoingPluginChannel((Plugin) this.plugin, CHANNEL);
        messenger.registerIncomingPluginChannel((Plugin) this.plugin, CHANNEL, this);
        this.cleanupTask = Bukkit.getScheduler().runTaskTimer((Plugin) this.plugin, this::cleanup, 20L, 20L);
    }

    public void stop() {
        if (this.cleanupTask != null) {
            this.cleanupTask.cancel();
        }
        this.cleanupTask = null;

        Messenger messenger = this.plugin.getServer().getMessenger();
        messenger.unregisterIncomingPluginChannel((Plugin) this.plugin, CHANNEL, this);
        messenger.unregisterOutgoingPluginChannel((Plugin) this.plugin, CHANNEL);
        this.sessions.clear();
    }

    public void beginVerification(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }

        long nonce = generateNonce();
        this.sessions.put(player.getUniqueId(), new Session(nonce, System.currentTimeMillis()));
        this.sendChallenge(player, nonce);
    }

    public void clear(Player player) {
        if (player != null) {
            this.sessions.remove(player.getUniqueId());
        }
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!CHANNEL.equals(channel) || player == null || message == null || message.length == 0) {
            return;
        }

        Session session = this.sessions.get(player.getUniqueId());
        if (session == null) {
            return;
        }

        String version;
        Long nonce = null;
        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(message))) {
            version = readMinecraftString(input);
            if (input.available() >= Long.BYTES) {
                nonce = input.readLong();
            }
        } catch (IOException ignored) {
            return;
        }

        session.lastHeartbeatAt = System.currentTimeMillis();
        if (!CURRENT_VERSION.equals(version)) {
            this.handleOutdatedMod(player);
            this.sessions.remove(player.getUniqueId());
            return;
        }

        if (nonce != null && nonce.longValue() != session.nonce) {
            return;
        }

        if (!session.confirmed) {
            session.confirmed = true;
            this.grantReward(player);
        }
    }

    private void cleanup() {
        long now = System.currentTimeMillis();
        this.sessions.entrySet().removeIf(entry -> {
            Player player = this.plugin.getServer().getPlayer(entry.getKey());
            Session session = entry.getValue();
            if (player == null || !player.isOnline()) {
                return true;
            }

            if (!session.confirmed) {
                if (now - session.createdAt > CHALLENGE_TIMEOUT_MS) {
                    this.sendNotDetectedMessage(player);
                    return true;
                }

                if (now - session.lastChallengeAt >= CHALLENGE_RESEND_MS) {
                    this.sendChallenge(player, session.nonce);
                }
                return false;
            }

            return now - session.lastHeartbeatAt > ACTIVE_SESSION_TTL_MS;
        });
    }

    private void sendChallenge(Player player, long nonce) {
        if (player == null || !player.isOnline()) {
            return;
        }

        Session session = this.sessions.get(player.getUniqueId());
        if (session == null) {
            return;
        }

        byte[] payload;
        try (ByteArrayOutputStream output = new ByteArrayOutputStream(Long.BYTES);
             DataOutputStream dataOutput = new DataOutputStream(output)) {
            writeMinecraftString(dataOutput, CURRENT_VERSION);
            dataOutput.writeLong(nonce);
            dataOutput.flush();
            payload = output.toByteArray();
        } catch (IOException ignored) {
            return;
        }

        player.sendPluginMessage((Plugin) this.plugin, CHANNEL, payload);
        session.lastChallengeAt = System.currentTimeMillis();
    }

    private void grantReward(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }

        if (this.boosterService.getXpMultiplier(player) < AXIAL_XP_MULTIPLIER) {
            this.boosterService.activateBooster(player, BoosterService.BoosterType.XP, AXIAL_XP_MULTIPLIER, AXIAL_XP_DURATION_SECONDS, false);
        }

        this.sendActiveMessage(player);
    }

    private void handleOutdatedMod(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }

        player.sendTitle(Text.color("&c&lUPDATE AVAILABLE"), Text.color("&fNew Mod Version /mod to update"), 10, 60, 10);
        player.sendMessage(Text.color(
                "&c&l(!) &c&lAxial Mod Update Available\n"
                        + "&fUpdate at axialmc.com/mod\n"
                        + "\n"
                        + "&7Players using the Official Axial Mod recieve a 2x Mining XP Boost while mining."
        ));
    }

    private void sendActiveMessage(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }

        player.sendMessage(Text.color(
                "&a&l(!) Axial Mod Active\n"
                        + "&fThank you for using the Official Axial Mod.\n"
                        + "\n"
                        + "&7You have been granted a 2x Mining XP Boost."
        ));
    }

    private void sendNotDetectedMessage(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }

        player.sendMessage(Text.color(
                "&c&l(!) Axial Mod Not Detected\n"
                        + "&fYou appear to not be using the Official Axial Mod. Download it here &f&naxialmc.com/mod\n"
                        + "\n"
                        + "&7Players using the Official Axial Mod recieve a 2x Mining XP Boost while mining."
        ));
    }

    private static long generateNonce() {
        long nonce;
        do {
            nonce = ThreadLocalRandom.current().nextLong();
        } while (nonce == Long.MIN_VALUE);
        return nonce;
    }

    private static void writeMinecraftString(DataOutputStream output, String value) throws IOException {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        writeVarInt(output, bytes.length);
        output.write(bytes);
    }

    private static String readMinecraftString(DataInputStream input) throws IOException {
        int length = readVarInt(input);
        if (length < 0) {
            throw new IOException("Negative string length");
        }
        byte[] bytes = new byte[length];
        input.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    private static void writeVarInt(DataOutputStream output, int value) throws IOException {
        while ((value & -128) != 0) {
            output.writeByte(value & 127 | 128);
            value >>>= 7;
        }
        output.writeByte(value);
    }

    private static int readVarInt(DataInputStream input) throws IOException {
        int numRead = 0;
        int result = 0;
        byte read;
        do {
            read = input.readByte();
            int value = read & 0x7F;
            result |= value << 7 * numRead;
            ++numRead;
            if (numRead > 5) {
                throw new IOException("VarInt too big");
            }
        } while ((read & 0x80) != 0);
        return result;
    }

    private static final class Session {
        private final long nonce;
        private final long createdAt;
        private long lastChallengeAt;
        private long lastHeartbeatAt;
        private boolean confirmed;

        private Session(long nonce, long createdAt) {
            this.nonce = nonce;
            this.createdAt = createdAt;
            this.lastChallengeAt = createdAt;
            this.lastHeartbeatAt = createdAt;
        }
    }
}
