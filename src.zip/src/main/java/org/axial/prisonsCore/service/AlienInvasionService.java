package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.WitherSkeleton;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.persistence.PersistentDataHolder;
import org.bukkit.scheduler.BukkitTask;

public final class AlienInvasionService implements Listener {
    private static final int MIN_ALIENS_PER_ZONE = 20;
    private static final int MAX_ALIENS_PER_ZONE = 40;
    private static final int RESPAWN_DELAY_TICKS = 60;
    private static final long MAINTENANCE_PERIOD_TICKS = 20L;
    private static final double ENTRY_SOUND_VOLUME = 1.0D;
    private static final float ENTRY_SOUND_PITCH = 0.8F;
    private static final String COMMON_SUBTITLE = "&fYou will lose gear if you die here";
    private static final String RED_HEART = "\u2764";

    private final PrisonsCore plugin;
    private final Map<String, InvasionZone> zones = new LinkedHashMap<>();
    private final Map<UUID, String> activeAliens = new LinkedHashMap<>();
    private final Map<UUID, Selection> selections = new LinkedHashMap<>();
    private final Map<UUID, String> playerZoneState = new HashMap<>();
    private final NamespacedKeys keys;
    private File file;
    private YamlConfiguration cfg;
    private BukkitTask maintenanceTask;

    public AlienInvasionService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.keys = new NamespacedKeys(plugin);
    }

    public void start() {
        this.reload();
        this.startMaintenanceTask();
        this.rescanLoadedEntities();
        this.ensurePopulation();
    }

    public void shutdown() {
        this.cancelMaintenanceTask();
        this.save();
        this.playerZoneState.clear();
    }

    public void reload() {
        this.load();
        this.rescanLoadedEntities();
        this.ensurePopulation();
    }

    public Collection<InvasionZone> getZones() {
        return Collections.unmodifiableCollection(this.zones.values());
    }

    public Selection getSelection(UUID uuid) {
        return this.selections.computeIfAbsent(uuid, ignored -> new Selection());
    }

    public void setPos1(UUID uuid, Location location) {
        this.getSelection(uuid).setPos1(this.toBlockLocation(location));
    }

    public void setPos2(UUID uuid, Location location) {
        this.getSelection(uuid).setPos2(this.toBlockLocation(location));
    }

    public boolean createZone(String id, Tier tier, Selection selection) {
        if (id == null || id.isBlank() || tier == null || selection == null || !selection.isComplete()) {
            return false;
        }
        String normalized = id.toLowerCase(Locale.ROOT);
        InvasionZone existing = this.zones.remove(normalized);
        if (existing != null) {
            this.despawnZone(existing.id());
        }
        this.zones.put(normalized, new InvasionZone(id, tier.id(), selection.getPos1(), selection.getPos2()));
        this.save();
        this.ensurePopulation();
        return true;
    }

    public boolean setTier(String id, Tier tier) {
        if (id == null || tier == null) {
            return false;
        }
        InvasionZone zone = this.zones.get(id.toLowerCase(Locale.ROOT));
        if (zone == null) {
            return false;
        }
        zone.setTierId(tier.id());
        this.save();
        this.ensurePopulation();
        return true;
    }

    public boolean deleteZone(String id) {
        if (id == null) {
            return false;
        }
        InvasionZone removed = this.zones.remove(id.toLowerCase(Locale.ROOT));
        if (removed == null) {
            return false;
        }
        this.despawnZone(removed.id());
        this.save();
        return true;
    }

    public InvasionZone getZone(String id) {
        if (id == null) {
            return null;
        }
        return this.zones.get(id.toLowerCase(Locale.ROOT));
    }

    public InvasionZone getZoneAt(Location location) {
        if (location == null || location.getWorld() == null) {
            return null;
        }
        for (InvasionZone zone : this.zones.values()) {
            if (zone.contains(location)) {
                return zone;
            }
        }
        return null;
    }

    public boolean isInvasionWand(ItemStack stack) {
        return stack != null
                && stack.hasItemMeta()
                && stack.getItemMeta().getPersistentDataContainer().has(this.keys.wand, PersistentDataType.BYTE);
    }

    public ItemStack createWand() {
        ItemStack wand = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = wand.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&6&lInvasion Wand"));
            meta.setLore(List.of(
                    Text.color("&7Left click a block to set &fpos1"),
                    Text.color("&7Right click a block to set &fpos2"),
                    Text.color("&7Use &f/invasion create <id> <tier> &7to save")
            ));
            meta.getPersistentDataContainer().set(this.keys.wand, PersistentDataType.BYTE, (byte)1);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
            wand.setItemMeta(meta);
        }
        return wand;
    }

    public List<String> tierIds() {
        ArrayList<String> ids = new ArrayList<>();
        for (Tier tier : Tier.values()) {
            ids.add(tier.id());
        }
        return ids;
    }

    public Tier getTier(String id) {
        return Tier.fromId(id);
    }

    @EventHandler(ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent event) {
        this.handleZoneEntry(event.getPlayer(), event.getPlayer().getLocation(), true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        this.handleZoneEntry(event.getPlayer(), event.getTo(), false);
    }

    @EventHandler(ignoreCancelled = true)
    public void onWandUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.isInvasionWand(item)) {
            return;
        }
        Player player = event.getPlayer();
        if (!player.hasPermission("prisons.invasion.admin")) {
            return;
        }
        if (event.getAction() != Action.LEFT_CLICK_BLOCK && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getClickedBlock() == null) {
            return;
        }
        event.setCancelled(true);
        Location location = event.getClickedBlock().getLocation();
        if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
            this.setPos1(player.getUniqueId(), location);
            player.sendMessage(Text.color("&aSet invasion pos1 to &f" + this.format(location)));
            return;
        }
        this.setPos2(player.getUniqueId(), location);
        player.sendMessage(Text.color("&aSet invasion pos2 to &f" + this.format(location)));
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        this.handleZoneEntry(event.getPlayer(), event.getTo(), false);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.playerZoneState.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
    public void onAlienDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (!this.isAlien(entity)) {
            return;
        }
        event.getDrops().clear();
        event.setDroppedExp(0);

        UUID entityId = entity.getUniqueId();
        String zoneId = this.getAlienZoneId(entity);
        this.activeAliensRemove(entityId);
        this.save();

        Player killer = entity.getKiller();
        InvasionZone zone = zoneId == null ? null : this.getZone(zoneId);
        Tier tier = zone == null ? null : this.getTier(zone.tierId());
        if (killer != null && tier != null) {
            this.giveKillRewards(killer, tier);
            this.addAlienProgress(killer);
            this.tryDropAlienSupplyCrate(killer);
            this.tryDropAlienKey(killer);
            killer.playSound(killer.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
        }

        if (zoneId != null && this.zones.containsKey(zoneId.toLowerCase(Locale.ROOT))) {
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
                InvasionZone respawnZone = this.getZone(zoneId);
                if (respawnZone != null) {
                    this.ensurePopulation(respawnZone);
                }
            }, RESPAWN_DELAY_TICKS);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAlienDamage(EntityDamageByEntityEvent event) {
        if (event.getEntity() == null || !this.isAlien(event.getEntity())) {
            return;
        }
        Player player = this.resolvePlayer(event.getDamager());
        if (player == null) {
            return;
        }
        String zoneId = this.getAlienZoneId(event.getEntity());
        InvasionZone zone = zoneId == null ? null : this.getZone(zoneId);
        String tierId = zone != null ? zone.tierId() : this.getAlienTierId(event.getEntity());
        Tier tier = tierId == null ? Tier.IRON : this.getTier(tierId);
        if (tier == null) {
            tier = Tier.IRON;
        }
        if (!this.canDamageTier(player, tier)) {
            event.setCancelled(true);
            player.sendMessage(Text.color("&c&l(!) &cYou are not the right Alien level to hurt this Alien"));
            return;
        }
        event.setDamage(event.getDamage() * this.alienDamageMultiplier(player));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onAlienEnvironmentalDamage(EntityDamageEvent event) {
        if (event.getEntity() == null || !this.isAlien(event.getEntity()) || event instanceof EntityDamageByEntityEvent) {
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onChunkLoad(org.bukkit.event.world.ChunkLoadEvent event) {
        boolean changed = false;
        for (Entity entity : event.getChunk().getEntities()) {
            if (!this.isAlien(entity)) {
                continue;
            }
            String zoneId = this.getAlienZoneId(entity);
            if (zoneId == null || !this.zones.containsKey(zoneId.toLowerCase(Locale.ROOT))) {
                entity.remove();
                this.activeAliensRemove(entity.getUniqueId());
                changed = true;
                continue;
            }
            changed |= this.activeAliensPut(entity.getUniqueId(), zoneId);
            this.applyAlienProfile(entity);
        }
        if (changed) {
            this.save();
        }
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.ensurePopulation(), 1L);
    }

    public void ensurePopulation() {
        for (InvasionZone zone : this.zones.values()) {
            this.ensurePopulation(zone);
        }
    }

    public void ensurePopulation(InvasionZone zone) {
        if (zone == null) {
            return;
        }
        int current = this.countAliens(zone.id());
        while (current < MIN_ALIENS_PER_ZONE) {
            if (!this.spawnAlien(zone)) {
                break;
            }
            ++current;
        }
    }

    private void startMaintenanceTask() {
        this.cancelMaintenanceTask();
        this.maintenanceTask = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            boolean changed = false;
            for (UUID entityId : new ArrayList<>(this.activeAliens.keySet())) {
                Entity entity = Bukkit.getEntity(entityId);
                if (!(entity instanceof LivingEntity living)) {
                    continue;
                }
                String zoneId = this.activeAliens.get(entityId);
                InvasionZone zone = zoneId == null ? null : this.getZone(zoneId);
                if (zone == null) {
                    entity.remove();
                    this.activeAliensRemove(entityId);
                    changed = true;
                    continue;
                }
                if (!zone.contains(entity.getLocation())) {
                    Location target = this.pickSpawnLocation(zone);
                    if (target != null) {
                        entity.teleport(target);
                    }
                }
                this.applyAlienProfile(living);
                this.updateAlienName(living);
                Tier tier = this.getTier(zone.tierId());
                Player nearby = this.findNearbyPlayer(zone, living.getLocation(), tier);
                if (nearby != null && living instanceof org.bukkit.entity.Mob mob) {
                    mob.setTarget(nearby);
                } else if (living instanceof org.bukkit.entity.Mob mob) {
                    mob.setTarget(null);
                }
            }
            if (changed) {
                this.save();
            }
            this.ensurePopulation();
        }, 20L, MAINTENANCE_PERIOD_TICKS);
    }

    private void cancelMaintenanceTask() {
        if (this.maintenanceTask != null) {
            this.maintenanceTask.cancel();
            this.maintenanceTask = null;
        }
    }

    private void load() {
        this.file = new File(this.plugin.getDataFolder(), "invasion-zones.yml");
        this.zones.clear();
        this.activeAliens.clear();
        if (!this.file.exists()) {
            this.cfg = new YamlConfiguration();
            this.save();
        } else {
            this.cfg = YamlConfiguration.loadConfiguration(this.file);
        }
        ConfigurationSection section = this.cfg.getConfigurationSection("zones");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                ConfigurationSection node = section.getConfigurationSection(key);
                if (node == null) {
                    continue;
                }
                String tierId = node.getString("tier", Tier.IRON.id());
                Tier tier = this.getTier(tierId);
                if (tier == null) {
                    tier = Tier.IRON;
                }
                String world = node.getString("world");
                Location pos1 = new Location(null, node.getDouble("x1"), node.getDouble("y1"), node.getDouble("z1"));
                Location pos2 = new Location(null, node.getDouble("x2"), node.getDouble("y2"), node.getDouble("z2"));
                this.zones.put(key.toLowerCase(Locale.ROOT), new InvasionZone(key, tier.id(), world, pos1, pos2));
                List<String> active = node.getStringList("active-aliens");
                if (active != null) {
                    for (String raw : active) {
                        try {
                            this.activeAliens.put(UUID.fromString(raw), key.toLowerCase(Locale.ROOT));
                        } catch (IllegalArgumentException ignored) {
                            // Skip malformed UUIDs.
                        }
                    }
                }
            }
        }
    }

    public void save() {
        if (this.cfg == null) {
            this.cfg = new YamlConfiguration();
        }
        this.cfg.set("zones", null);
        for (InvasionZone zone : this.zones.values()) {
            String base = "zones." + zone.id();
            this.cfg.set(base + ".tier", zone.tierId());
            this.cfg.set(base + ".world", zone.world());
            this.cfg.set(base + ".x1", zone.minX());
            this.cfg.set(base + ".y1", zone.minY());
            this.cfg.set(base + ".z1", zone.minZ());
            this.cfg.set(base + ".x2", zone.maxX());
            this.cfg.set(base + ".y2", zone.maxY());
            this.cfg.set(base + ".z2", zone.maxZ());
            List<String> active = new ArrayList<>();
            for (Map.Entry<UUID, String> entry : this.activeAliens.entrySet()) {
                if (zone.id().equalsIgnoreCase(entry.getValue())) {
                    active.add(entry.getKey().toString());
                }
            }
            this.cfg.set(base + ".active-aliens", active);
        }
        try {
            this.cfg.save(this.file);
        } catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save invasion-zones.yml: " + e.getMessage());
        }
    }

    private void rescanLoadedEntities() {
        boolean changed = false;
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : world.getEntities()) {
                if (!this.isAlien(entity)) {
                    continue;
                }
                String zoneId = this.getAlienZoneId(entity);
                if (zoneId == null || !this.zones.containsKey(zoneId.toLowerCase(Locale.ROOT))) {
                    entity.remove();
                    this.activeAliensRemove(entity.getUniqueId());
                    changed = true;
                    continue;
                }
                changed |= this.activeAliensPut(entity.getUniqueId(), zoneId);
                this.applyAlienProfile(entity);
            }
        }
        if (changed) {
            this.save();
        }
    }

    private boolean spawnAlien(InvasionZone zone) {
        if (zone == null) {
            return false;
        }
        World world = Bukkit.getWorld(zone.world());
        if (world == null) {
            return false;
        }
        Location location = this.pickSpawnLocation(zone);
        if (location == null) {
            return false;
        }
        WitherSkeleton skeleton;
        try {
            skeleton = (WitherSkeleton)world.spawnEntity(location, EntityType.WITHER_SKELETON);
        } catch (Exception e) {
            this.plugin.getLogger().warning("Failed to spawn invasion alien in zone " + zone.id() + ": " + e.getMessage());
            return false;
        }
        skeleton.getPersistentDataContainer().set(this.keys.alien, PersistentDataType.BYTE, (byte)1);
        skeleton.getPersistentDataContainer().set(this.keys.alienZone, PersistentDataType.STRING, zone.id().toLowerCase(Locale.ROOT));
        skeleton.getPersistentDataContainer().set(this.keys.alienTier, PersistentDataType.STRING, zone.tierId().toLowerCase(Locale.ROOT));
        skeleton.setRemoveWhenFarAway(false);
        skeleton.setPersistent(true);
        skeleton.setSilent(false);
        skeleton.setCanPickupItems(false);
        Tier tier = this.getTier(zone.tierId());
        if (tier != null) {
            this.applyAlienProfile(skeleton);
            this.updateAlienName(skeleton);
            this.scheduleAlienHealth(skeleton, tier.health(), 0);
        }
        this.activeAliensPut(skeleton.getUniqueId(), zone.id());
        this.save();
        return true;
    }

    private void despawnZone(String zoneId) {
        if (zoneId == null) {
            return;
        }
        ArrayList<UUID> toRemove = new ArrayList<>();
        for (Map.Entry<UUID, String> entry : this.activeAliens.entrySet()) {
            if (!zoneId.equalsIgnoreCase(entry.getValue())) {
                continue;
            }
            Entity entity = Bukkit.getEntity(entry.getKey());
            if (entity != null) {
                entity.remove();
            }
            toRemove.add(entry.getKey());
        }
        for (UUID uuid : toRemove) {
            this.activeAliens.remove(uuid);
        }
    }

    private int countAliens(String zoneId) {
        if (zoneId == null) {
            return 0;
        }
        int count = 0;
        for (String value : this.activeAliens.values()) {
            if (zoneId.equalsIgnoreCase(value)) {
                ++count;
            }
        }
        return count;
    }

    private boolean activeAliensPut(UUID uuid, String zoneId) {
        if (uuid == null || zoneId == null) {
            return false;
        }
        String normalized = zoneId.toLowerCase(Locale.ROOT);
        String previous = this.activeAliens.put(uuid, normalized);
        return previous == null || !previous.equals(normalized);
    }

    private void activeAliensRemove(UUID uuid) {
        if (uuid == null) {
            return;
        }
        this.activeAliens.remove(uuid);
    }

    private boolean isAlien(Entity entity) {
        return entity instanceof PersistentDataHolder holder
                && holder.getPersistentDataContainer().has(this.keys.alien, PersistentDataType.BYTE);
    }

    private String getAlienZoneId(Entity entity) {
        if (!(entity instanceof PersistentDataHolder holder)) {
            return null;
        }
        return holder.getPersistentDataContainer().get(this.keys.alienZone, PersistentDataType.STRING);
    }

    private String getAlienTierId(Entity entity) {
        if (!(entity instanceof PersistentDataHolder holder)) {
            return null;
        }
        return holder.getPersistentDataContainer().get(this.keys.alienTier, PersistentDataType.STRING);
    }

    private void applyAlienProfile(Entity entity) {
        if (!(entity instanceof LivingEntity living)) {
            return;
        }
        String zoneId = this.getAlienZoneId(entity);
        InvasionZone zone = zoneId == null ? null : this.getZone(zoneId);
        if (zone == null) {
            return;
        }
        Tier tier = this.getTier(zone.tierId());
        if (tier == null) {
            tier = Tier.IRON;
        }
        this.applyMaxHealth(living, tier.health());
        this.applyScale(living, tier.scale());
        this.applyEquipment(living, tier);
        this.updateAlienName(living);
        if (living instanceof org.bukkit.entity.Mob mob) {
            Player nearby = this.findNearbyPlayer(zone, living.getLocation(), tier);
            mob.setTarget(nearby);
        }
    }

    private void applyMaxHealth(LivingEntity living, double health) {
        if (living == null || health <= 0.0D) {
            return;
        }
        try {
            if (living.getAttribute(Attribute.MAX_HEALTH) != null) {
                living.getAttribute(Attribute.MAX_HEALTH).setBaseValue(health);
            }
        } catch (Exception ignored) {
            // Some server implementations defer attribute updates.
        }
        try {
            if (living.getMaxHealth() > 0.0D && living.getHealth() > living.getMaxHealth()) {
                living.setHealth(living.getMaxHealth());
            }
        } catch (Exception ignored) {
            // Retry on the next maintenance pass if the entity has not finished initializing.
        }
    }

    private void scheduleAlienHealth(LivingEntity living, double desiredHealth, int attempts) {
        if (living == null || !living.isValid()) {
            return;
        }
        this.applyMaxHealth(living, desiredHealth);
        double maxHealth = living.getMaxHealth();
        if (maxHealth >= desiredHealth - 0.01D) {
            try {
                living.setHealth(desiredHealth);
            } catch (IllegalArgumentException ignored) {
                double clamped = Math.min(desiredHealth, living.getMaxHealth());
                if (clamped > 0.0D) {
                    try {
                        living.setHealth(clamped);
                    } catch (IllegalArgumentException ignoredToo) {
                        // Leave it for a later maintenance pass.
                    }
                }
            }
            this.updateAlienName(living);
            return;
        }
        if (attempts >= 10) {
            return;
        }
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.scheduleAlienHealth(living, desiredHealth, attempts + 1), 1L);
    }

    private void applyScale(LivingEntity living, float scale) {
        try {
            LivingEntity.class.getMethod("setScale", float.class).invoke(living, scale);
        } catch (Exception ignored) {
            // Older API or server implementation without scale support.
        }
    }

    private void applyEquipment(LivingEntity living, Tier tier) {
        EntityEquipment equipment = living.getEquipment();
        if (equipment == null) {
            return;
        }
        switch (tier) {
            case IRON -> {
                equipment.setHelmet(new ItemStack(Material.CHAINMAIL_HELMET));
                equipment.setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
                equipment.setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
                equipment.setBoots(new ItemStack(Material.CHAINMAIL_BOOTS));
                equipment.setItemInMainHand(this.applyGear(new ItemStack(Material.STONE_SWORD), Map.of("scorche", 2)));
            }
            case GOLD -> {
                equipment.setHelmet(this.applyGear(new ItemStack(Material.GOLDEN_HELMET), Map.of("tank", 2)));
                equipment.setChestplate(this.applyGear(new ItemStack(Material.GOLDEN_CHESTPLATE), Map.of("tank", 2)));
                equipment.setLeggings(this.applyGear(new ItemStack(Material.GOLDEN_LEGGINGS), Map.of("tank", 2)));
                equipment.setBoots(this.applyGear(new ItemStack(Material.GOLDEN_BOOTS), Map.of("tank", 2)));
                equipment.setItemInMainHand(this.applyGear(new ItemStack(Material.IRON_SWORD), Map.of("scorche", 3, "paralyze", 3)));
            }
            case DIAMOND -> {
                equipment.setHelmet(this.applyGear(new ItemStack(Material.DIAMOND_HELMET), Map.of("tank", 4, "hardened", 3)));
                equipment.setChestplate(this.applyGear(new ItemStack(Material.DIAMOND_CHESTPLATE), Map.of("tank", 4, "hardened", 3)));
                equipment.setLeggings(this.applyGear(new ItemStack(Material.DIAMOND_LEGGINGS), Map.of("tank", 4, "hardened", 3, "cactus", 5)));
                equipment.setBoots(this.applyGear(new ItemStack(Material.DIAMOND_BOOTS), Map.of("tank", 4, "hardened", 3)));
                equipment.setItemInMainHand(new ItemStack(Material.DIAMOND_SWORD));
            }
        }
        equipment.setHelmetDropChance(0.0F);
        equipment.setChestplateDropChance(0.0F);
        equipment.setLeggingsDropChance(0.0F);
        equipment.setBootsDropChance(0.0F);
        equipment.setItemInMainHandDropChance(0.0F);
        equipment.setItemInOffHandDropChance(0.0F);
    }

    private ItemStack applyGear(ItemStack item, Map<String, Integer> enchants) {
        if (item == null || enchants == null || enchants.isEmpty() || this.plugin.getGearManager() == null) {
            return item;
        }
        for (Map.Entry<String, Integer> entry : enchants.entrySet()) {
            this.plugin.getGearManager().applyEnchant(item, entry.getKey(), entry.getValue(), entry.getValue());
        }
        return item;
    }

    private void updateAlienName(LivingEntity living) {
        if (living == null) {
            return;
        }
        String zoneId = this.getAlienZoneId(living);
        InvasionZone zone = zoneId == null ? null : this.getZone(zoneId);
        Tier tier = zone == null ? Tier.IRON : this.getTier(zone.tierId());
        if (tier == null) {
            tier = Tier.IRON;
        }
        double health = Math.max(0.0D, living.getHealth());
        double max = tier.health();
        living.setCustomName(Text.color(tier.nameTag() + "\n&c" + RED_HEART + " " + (int)Math.ceil(health) + "/" + (int)max));
        living.setCustomNameVisible(true);
    }

    private Player findNearbyPlayer(InvasionZone zone, Location location, Tier tier) {
        if (zone == null || location == null || location.getWorld() == null) {
            return null;
        }
        Tier effectiveTier = tier == null ? Tier.IRON : tier;
        double radius = effectiveTier.targetRadius();
        Player nearest = null;
        double best = radius * radius;
        for (Player player : location.getWorld().getPlayers()) {
            if (player == null || player.isDead()) {
                continue;
            }
            if (!zone.contains(player.getLocation())) {
                continue;
            }
            if (!this.canDamageTier(player, effectiveTier)) {
                continue;
            }
            double distance = player.getLocation().distanceSquared(location);
            if (distance > best) {
                continue;
            }
            best = distance;
            nearest = player;
        }
        return nearest;
    }

    private Location pickSpawnLocation(InvasionZone zone) {
        if (zone == null || zone.world() == null) {
            return null;
        }
        World world = Bukkit.getWorld(zone.world());
        if (world == null) {
            return null;
        }
        ThreadLocalRandom random = ThreadLocalRandom.current();
        for (int attempt = 0; attempt < 24; ++attempt) {
            int x = random.nextInt(Math.min(zone.minX(), zone.maxX()), Math.max(zone.minX(), zone.maxX()) + 1);
            int y = random.nextInt(Math.min(zone.minY(), zone.maxY()), Math.max(zone.minY(), zone.maxY()) + 1);
            int z = random.nextInt(Math.min(zone.minZ(), zone.maxZ()), Math.max(zone.minZ(), zone.maxZ()) + 1);
            Location candidate = new Location(world, x + 0.5D, y, z + 0.5D);
            if (candidate.getBlock().isPassable() && candidate.clone().add(0.0D, 1.0D, 0.0D).getBlock().isPassable()) {
                return candidate;
            }
        }
        int centerX = (zone.minX() + zone.maxX()) / 2;
        int centerY = (zone.minY() + zone.maxY()) / 2;
        int centerZ = (zone.minZ() + zone.maxZ()) / 2;
        return new Location(world, centerX + 0.5D, centerY, centerZ + 0.5D);
    }

    private void handleZoneEntry(Player player, Location location, boolean announceInitial) {
        if (player == null || location == null) {
            return;
        }
        String current = this.playerZoneState.get(player.getUniqueId());
        InvasionZone zone = this.getZoneAt(location);
        String next = zone == null ? null : zone.id().toLowerCase(Locale.ROOT);
        if (!announceInitial && current != null && current.equals(next)) {
            return;
        }
        if (!announceInitial && current == null && next == null) {
            return;
        }
        if (current != null && current.equals(next)) {
            return;
        }
        this.playerZoneState.put(player.getUniqueId(), next);
        if (zone == null) {
            return;
        }
        Tier tier = this.getTier(zone.tierId());
        if (tier == null) {
            tier = Tier.IRON;
        }
        player.sendTitle(Text.color(tier.title()), Text.color(COMMON_SUBTITLE), 10, 40, 10);
        player.playSound(player.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, (float)ENTRY_SOUND_VOLUME, ENTRY_SOUND_PITCH);
    }

    private void giveKillRewards(Player player, Tier tier) {
        if (player == null || tier == null) {
            return;
        }
        ThreadLocalRandom random = ThreadLocalRandom.current();
        boolean giveCharge = random.nextBoolean();
        switch (tier) {
            case IRON -> {
                if (giveCharge) {
                    this.giveEnergy(player, random.nextInt(100, 201));
                } else {
                    this.giveBankNote(player, random.nextInt(1, 71));
                }
                this.tryContraband(player, "basic_cont", 0.0035D);
            }
            case GOLD -> {
                if (giveCharge) {
                    this.giveEnergy(player, random.nextInt(300, 701));
                } else {
                    this.giveBankNote(player, random.nextInt(40, 101));
                }
                this.tryContraband(player, "rare_cont", 0.0025D);
            }
            case DIAMOND -> {
                if (giveCharge) {
                    this.giveEnergy(player, random.nextInt(1000, 3001));
                } else {
                    this.giveBankNote(player, random.nextInt(300, 1001));
                }
                this.tryContraband(player, "elite_cont", 0.0015D);
                this.tryContraband(player, "legendary_cont", 0.0005D);
            }
        }
    }

    private void addAlienProgress(Player player) {
        if (player == null || this.plugin.getPlayerDataService() == null) {
            return;
        }
        this.plugin.getPlayerDataService().update(player.getUniqueId(), data -> {
            data.addAlienProgress(1);
            int level = data.getAlienLevel();
            while (data.getAlienProgress() >= this.alienKillsForLevel(level)) {
                data.setAlienProgress(data.getAlienProgress() - this.alienKillsForLevel(level));
                level = level + 1;
                data.setAlienLevel(level);
            }
        });
        if (this.plugin.getMiningLevelScoreboardService() != null) {
            this.plugin.getMiningLevelScoreboardService().updateLater(player);
        }
    }

    private void tryDropAlienSupplyCrate(Player player) {
        if (player == null || this.plugin.getAlienSupplyCrateService() == null) {
            return;
        }
        if (ThreadLocalRandom.current().nextInt(2000) != 0) {
            return;
        }
        ItemStack crate = this.plugin.getAlienSupplyCrateService().createCrate(false);
        if (crate == null) {
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(crate);
        for (ItemStack extra : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
    }

    private void tryDropAlienKey(Player player) {
        if (player == null || this.plugin.getAlienSupplyCrateService() == null) {
            return;
        }
        if (ThreadLocalRandom.current().nextDouble() > 0.002D) {
            return;
        }
        ItemStack key = this.plugin.getAlienSupplyCrateService().createKey(1);
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(key);
        for (ItemStack extra : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
    }

    private boolean canDamageTier(Player player, Tier tier) {
        return player != null && tier != null && this.getAlienLevel(player) >= this.requiredAlienLevel(tier);
    }

    private int requiredAlienLevel(Tier tier) {
        if (tier == null) {
            return 1;
        }
        return switch (tier) {
            case IRON -> 1;
            case GOLD -> 30;
            case DIAMOND -> 70;
        };
    }

    private int getAlienLevel(Player player) {
        if (player == null || this.plugin.getPlayerDataService() == null) {
            return 1;
        }
        return Math.max(1, this.plugin.getPlayerDataService().get(player.getUniqueId()).getAlienLevel());
    }

    private int alienKillsForLevel(int level) {
        int safeLevel = Math.max(1, level);
        return 15 + (safeLevel * 3);
    }

    private double alienDamageMultiplier(Player player) {
        int level = this.getAlienLevel(player);
        double bonus = Math.min(0.35D, (double)(level - 1) * 0.005D);
        return 1.0D + Math.max(0.0D, bonus);
    }

    private Player resolvePlayer(Entity entity) {
        if (entity instanceof Player player) {
            return player;
        }
        if (entity instanceof Projectile projectile && projectile.getShooter() instanceof Player player) {
            return player;
        }
        return null;
    }

    private void giveEnergy(Player player, int amount) {
        if (player == null || amount <= 0 || this.plugin.getEnergyItemService() == null) {
            return;
        }
        ItemStack stack = this.plugin.getEnergyItemService().createEnergyItem(amount);
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
        for (ItemStack extra : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
    }

    private void giveBankNote(Player player, double amount) {
        if (player == null || amount <= 0.0D || this.plugin.getBankNoteService() == null) {
            return;
        }
        ItemStack stack = this.plugin.getBankNoteService().createBankNote(amount);
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(stack);
        for (ItemStack extra : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
    }

    private void tryContraband(Player player, String contrabandId, double chance) {
        if (player == null || contrabandId == null || chance <= 0.0D || this.plugin.getContrabandService() == null) {
            return;
        }
        if (ThreadLocalRandom.current().nextDouble() > chance) {
            return;
        }
        ItemStack contraband = this.plugin.getContrabandService().createContraband(contrabandId);
        if (contraband == null) {
            return;
        }
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(contraband);
        for (ItemStack extra : leftover.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), extra);
        }
    }

    private Location toBlockLocation(Location location) {
        return location == null ? null : location.getBlock().getLocation();
    }

    private String format(Location location) {
        if (location == null || location.getWorld() == null) {
            return "unknown";
        }
        return location.getWorld().getName() + " " + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ();
    }

    private final class NamespacedKeys {
        private final NamespacedKey wand;
        private final NamespacedKey alien;
        private final NamespacedKey alienZone;
        private final NamespacedKey alienTier;

        private NamespacedKeys(PrisonsCore plugin) {
            this.wand = Keys.invasionWand(plugin);
            this.alien = Keys.invasionAlien(plugin);
            this.alienZone = Keys.invasionAlienZone(plugin);
            this.alienTier = Keys.invasionAlienTier(plugin);
        }
    }

    public enum Tier {
        IRON("iron", "&7&lIron Alien Zone", "&7&lIron Alien", 120.0D, 1.2F, 24.0D),
        GOLD("gold", "&e&lGold Alien Zone", "&e&lGold Alien", 230.0D, 1.5F, 32.0D),
        DIAMOND("diamond", "&b&lDiamond Alien Zone", "&b&lDiamond Alien", 400.0D, 2.0F, 40.0D);

        private final String id;
        private final String title;
        private final String nameTag;
        private final double health;
        private final float scale;
        private final double targetRadius;

        Tier(String id, String title, String nameTag, double health, float scale, double targetRadius) {
            this.id = id;
            this.title = title;
            this.nameTag = nameTag;
            this.health = health;
            this.scale = scale;
            this.targetRadius = targetRadius;
        }

        public String id() {
            return this.id;
        }

        public String title() {
            return this.title;
        }

        public String nameTag() {
            return this.nameTag;
        }

        public double health() {
            return this.health;
        }

        public float scale() {
            return this.scale;
        }

        public double targetRadius() {
            return this.targetRadius;
        }

        public static Tier fromId(String id) {
            if (id == null) {
                return null;
            }
            for (Tier tier : values()) {
                if (tier.id.equalsIgnoreCase(id)) {
                    return tier;
                }
            }
            return null;
        }
    }

    public static final class Selection {
        private Location pos1;
        private Location pos2;

        public Location getPos1() {
            return this.pos1;
        }

        public Location getPos2() {
            return this.pos2;
        }

        public void setPos1(Location pos1) {
            this.pos1 = pos1;
        }

        public void setPos2(Location pos2) {
            this.pos2 = pos2;
        }

        public boolean isComplete() {
            return this.pos1 != null && this.pos2 != null;
        }
    }

    public static final class InvasionZone {
        private final String id;
        private String tierId;
        private final String world;
        private final int minX;
        private final int minY;
        private final int minZ;
        private final int maxX;
        private final int maxY;
        private final int maxZ;

        public InvasionZone(String id, String tierId, Location pos1, Location pos2) {
            this(id, tierId, pos1 != null && pos1.getWorld() != null ? pos1.getWorld().getName() : pos2 != null && pos2.getWorld() != null ? pos2.getWorld().getName() : null, pos1, pos2);
        }

        public InvasionZone(String id, String tierId, String world, Location pos1, Location pos2) {
            this.id = id;
            this.tierId = tierId;
            this.world = world;
            this.minX = Math.min(pos1.getBlockX(), pos2.getBlockX());
            this.minY = Math.min(pos1.getBlockY(), pos2.getBlockY());
            this.minZ = Math.min(pos1.getBlockZ(), pos2.getBlockZ());
            this.maxX = Math.max(pos1.getBlockX(), pos2.getBlockX());
            this.maxY = Math.max(pos1.getBlockY(), pos2.getBlockY());
            this.maxZ = Math.max(pos1.getBlockZ(), pos2.getBlockZ());
        }

        public boolean contains(Location location) {
            return location != null
                    && location.getWorld() != null
                    && this.world != null
                    && this.world.equals(location.getWorld().getName())
                    && location.getBlockX() >= this.minX && location.getBlockX() <= this.maxX
                    && location.getBlockY() >= this.minY && location.getBlockY() <= this.maxY
                    && location.getBlockZ() >= this.minZ && location.getBlockZ() <= this.maxZ;
        }

        public String id() {
            return this.id;
        }

        public String tierId() {
            return this.tierId;
        }

        public void setTierId(String tierId) {
            this.tierId = tierId;
        }

        public String world() {
            return this.world;
        }

        public int minX() {
            return this.minX;
        }

        public int minY() {
            return this.minY;
        }

        public int minZ() {
            return this.minZ;
        }

        public int maxX() {
            return this.maxX;
        }

        public int maxY() {
            return this.maxY;
        }

        public int maxZ() {
            return this.maxZ;
        }
    }
}
