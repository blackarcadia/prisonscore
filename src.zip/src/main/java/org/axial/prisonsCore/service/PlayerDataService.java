package org.axial.prisonsCore.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.configuration.file.YamlConfiguration;

public class PlayerDataService {
    private final PrisonsCore plugin;
    private final File file;
    private YamlConfiguration cfg;
    private final Map<UUID, PlayerData> cache = new HashMap<UUID, PlayerData>();

    public PlayerDataService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "player-data.yml");
        this.load();
    }

    public void load() {
        if (!this.file.exists()) {
            try {
                this.file.getParentFile().mkdirs();
                this.file.createNewFile();
            }
            catch (IOException e) {
                this.plugin.getLogger().warning("Failed to create player-data.yml: " + e.getMessage());
            }
        }
        this.cfg = YamlConfiguration.loadConfiguration(this.file);
        this.cache.clear();
    }

    public void save() {
        try {
            this.cfg.save(this.file);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Failed to save player-data.yml: " + e.getMessage());
        }
    }

    public PlayerData get(UUID playerId) {
        PlayerData cached = this.cache.get(playerId);
        if (cached != null) {
            return cached;
        }
        String base = "players." + playerId;
        PlayerData data = new PlayerData();
        data.joinedBefore = this.cfg.getBoolean(base + ".joined-before", false);
        data.lastLogoutWorld = this.cfg.getString(base + ".logout.world", null);
        data.lastSeenPvpEnableVersion = this.cfg.getInt(base + ".pvp.last-seen-enable-version", 0);
        data.tutorialStage = this.cfg.getInt(base + ".tutorial.stage", 0);
        data.tutorialRewardBooster = this.cfg.getBoolean(base + ".tutorial.reward-booster", false);
        data.raidPoints = this.cfg.getInt(base + ".raid-points", 0);
        data.prisonRiotShopPoints = this.cfg.getInt(base + ".prison-riot.shop-points", 0);
        data.prisonCoins = this.cfg.getLong(base + ".prison-coins", 0L);
        data.alienLevel = this.cfg.getInt(base + ".alien.level", 1);
        data.alienProgress = this.cfg.getInt(base + ".alien.progress", 0);
        data.inventoryFullNotifications = this.cfg.getBoolean(base + ".toggles.inventory-full-notifications", true);
        data.pickaxeChargeFullNotifications = this.cfg.getBoolean(base + ".toggles.pickaxe-charge-full-notifications", true);
        data.stashNotifications = this.cfg.getBoolean(base + ".toggles.stash-notifications", true);
        data.miningXpActionBar = this.cfg.getBoolean(base + ".toggles.mining-xp-action-bar", true);
        data.chargeActionBar = this.cfg.getBoolean(base + ".toggles.charge-action-bar", true);
        data.enchantProcActionBar = this.cfg.getBoolean(base + ".toggles.enchant-proc-action-bar", true);
        data.tutorialSkipConfirm = this.cfg.getBoolean(base + ".toggles.tutorial-skip-confirm", true);
        data.tpaRequests = this.cfg.getBoolean(base + ".toggles.tpa-requests", true);
        data.payRequests = this.cfg.getBoolean(base + ".toggles.pay-requests", true);
        data.privateMessages = this.cfg.getBoolean(base + ".toggles.private-messages", true);
        data.fragmentNotifications = this.cfg.getBoolean(base + ".toggles.fragment-notifications", true);
        data.chatEnabled = this.cfg.getBoolean(base + ".toggles.chat-enabled", true);
        data.nickname = this.cfg.getString(base + ".nickname", null);
        data.homes = new LinkedHashMap<String, HomeEntry>();
        if (this.cfg.isConfigurationSection(base + ".homes")) {
            for (String key : this.cfg.getConfigurationSection(base + ".homes").getKeys(false)) {
                String homeBase = base + ".homes." + key;
                String name = this.cfg.getString(homeBase + ".name", key);
                String worldName = this.cfg.getString(homeBase + ".world", null);
                World world = worldName == null ? null : Bukkit.getWorld(worldName);
                if (world == null) {
                    continue;
                }
                double x = this.cfg.getDouble(homeBase + ".x", Double.NaN);
                double y = this.cfg.getDouble(homeBase + ".y", Double.NaN);
                double z = this.cfg.getDouble(homeBase + ".z", Double.NaN);
                if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z)) {
                    continue;
                }
                float yaw = (float)this.cfg.getDouble(homeBase + ".yaw", 0.0);
                float pitch = (float)this.cfg.getDouble(homeBase + ".pitch", 0.0);
                data.homes.put(key.toLowerCase(Locale.ROOT), new HomeEntry(name, new Location(world, x, y, z, yaw, pitch)));
            }
        }
        data.unlockedWarps = new HashSet<String>(this.cfg.getStringList(base + ".warps.unlocked"));
        data.unlockedGkits = new HashSet<String>(this.cfg.getStringList(base + ".gkits.unlocked"));
        data.blockedGkits = new HashSet<String>(this.cfg.getStringList(base + ".gkits.blocked"));
        data.kitCooldowns = new HashMap<String, Long>();
        if (this.cfg.isConfigurationSection(base + ".kits.cooldowns")) {
            for (String key : this.cfg.getConfigurationSection(base + ".kits.cooldowns").getKeys(false)) {
                data.kitCooldowns.put(key.toLowerCase(), this.cfg.getLong(base + ".kits.cooldowns." + key, 0L));
            }
        }
        this.cache.put(playerId, data);
        return data;
    }

    public void update(UUID playerId, java.util.function.Consumer<PlayerData> consumer) {
        PlayerData data = this.get(playerId);
        consumer.accept(data);
        this.write(playerId, data);
    }

    private void write(UUID playerId, PlayerData data) {
        String base = "players." + playerId;
        this.cfg.set(base + ".joined-before", (Object)data.joinedBefore);
        this.cfg.set(base + ".logout.world", (Object)data.lastLogoutWorld);
        this.cfg.set(base + ".pvp.last-seen-enable-version", (Object)data.lastSeenPvpEnableVersion);
        this.cfg.set(base + ".tutorial.stage", (Object)data.tutorialStage);
        this.cfg.set(base + ".tutorial.reward-booster", (Object)data.tutorialRewardBooster);
        this.cfg.set(base + ".raid-points", (Object)data.raidPoints);
        this.cfg.set(base + ".prison-riot.shop-points", (Object)data.prisonRiotShopPoints);
        this.cfg.set(base + ".prison-coins", (Object)data.prisonCoins);
        this.cfg.set(base + ".alien.level", (Object)data.alienLevel);
        this.cfg.set(base + ".alien.progress", (Object)data.alienProgress);
        this.cfg.set(base + ".toggles.inventory-full-notifications", (Object)data.inventoryFullNotifications);
        this.cfg.set(base + ".toggles.pickaxe-charge-full-notifications", (Object)data.pickaxeChargeFullNotifications);
        this.cfg.set(base + ".toggles.stash-notifications", (Object)data.stashNotifications);
        this.cfg.set(base + ".toggles.mining-xp-action-bar", (Object)data.miningXpActionBar);
        this.cfg.set(base + ".toggles.charge-action-bar", (Object)data.chargeActionBar);
        this.cfg.set(base + ".toggles.enchant-proc-action-bar", (Object)data.enchantProcActionBar);
        this.cfg.set(base + ".toggles.tutorial-skip-confirm", (Object)data.tutorialSkipConfirm);
        this.cfg.set(base + ".toggles.tpa-requests", (Object)data.tpaRequests);
        this.cfg.set(base + ".toggles.pay-requests", (Object)data.payRequests);
        this.cfg.set(base + ".toggles.private-messages", (Object)data.privateMessages);
        this.cfg.set(base + ".toggles.fragment-notifications", (Object)data.fragmentNotifications);
        this.cfg.set(base + ".toggles.chat-enabled", (Object)data.chatEnabled);
        this.cfg.set(base + ".nickname", (Object)data.nickname);
        this.cfg.set(base + ".homes", null);
        for (Map.Entry<String, HomeEntry> entry : data.homes.entrySet()) {
            String homeBase = base + ".homes." + entry.getKey();
            HomeEntry home = entry.getValue();
            if (home == null || home.location() == null || home.location().getWorld() == null) {
                continue;
            }
            this.cfg.set(homeBase + ".name", (Object)home.name());
            this.cfg.set(homeBase + ".world", (Object)home.location().getWorld().getName());
            this.cfg.set(homeBase + ".x", (Object)home.location().getX());
            this.cfg.set(homeBase + ".y", (Object)home.location().getY());
            this.cfg.set(homeBase + ".z", (Object)home.location().getZ());
            this.cfg.set(homeBase + ".yaw", (Object)home.location().getYaw());
            this.cfg.set(homeBase + ".pitch", (Object)home.location().getPitch());
        }
        this.cfg.set(base + ".warps.unlocked", new java.util.ArrayList<String>(data.unlockedWarps));
        this.cfg.set(base + ".gkits.unlocked", new java.util.ArrayList<String>(data.unlockedGkits));
        this.cfg.set(base + ".gkits.blocked", new java.util.ArrayList<String>(data.blockedGkits));
        this.cfg.set(base + ".kits.cooldowns", new HashMap<String, Long>(data.kitCooldowns));
        this.save();
    }

    public String getChatName(Player player) {
        if (player == null) {
            return "";
        }
        return this.getChatName(player.getUniqueId(), player.getName());
    }

    public String getChatName(UUID playerId, String fallbackName) {
        PlayerData data = this.get(playerId);
        String nickname = data.getNickname();
        if (nickname == null || nickname.isBlank()) {
            return fallbackName == null || fallbackName.isBlank() ? "" : fallbackName;
        }
        return "~" + nickname;
    }

    public List<String> getHomeNames(UUID playerId) {
        PlayerData data = this.get(playerId);
        List<String> names = new ArrayList<String>();
        for (HomeEntry home : data.homes.values()) {
            if (home != null && home.name() != null && !home.name().isBlank()) {
                names.add(home.name());
            }
        }
        return names;
    }

    public Location getHome(UUID playerId, String homeName) {
        PlayerData data = this.get(playerId);
        HomeEntry home = data.getHome(homeName);
        return home == null || home.location() == null ? null : home.location().clone();
    }

    public boolean setHome(UUID playerId, String homeName, Location location) {
        if (playerId == null || homeName == null || location == null || location.getWorld() == null) {
            return false;
        }
        final String normalized = this.normalizeHomeKey(homeName);
        if (normalized.isEmpty()) {
            return false;
        }
        this.update(playerId, data -> data.homes.put(normalized, new HomeEntry(this.cleanHomeName(homeName), location.clone())));
        return true;
    }

    public boolean removeHome(UUID playerId, String homeName) {
        if (playerId == null || homeName == null) {
            return false;
        }
        final String normalized = this.normalizeHomeKey(homeName);
        if (normalized.isEmpty()) {
            return false;
        }
        final boolean[] removed = new boolean[]{false};
        this.update(playerId, data -> removed[0] = data.homes.remove(normalized) != null);
        return removed[0];
    }

    public int getHomeCount(UUID playerId) {
        return this.get(playerId).homes.size();
    }

    public int getHomeLimit(Player player) {
        if (player == null) {
            return 0;
        }
        if (player.hasPermission("prisons.home.unlimited") || player.hasPermission("prisons.home.amount.*") || player.hasPermission("prisons.home.*")) {
            return Integer.MAX_VALUE;
        }
        int limit = player.hasPermission("prisons.home") ? 1 : 0;
        for (int i = 1; i <= 512; ++i) {
            if (player.hasPermission("prisons.home." + i) || player.hasPermission("prisons.home.amount." + i) || player.hasPermission("prisons.homes.amount." + i)) {
                limit = Math.max(limit, i);
            }
        }
        return limit;
    }

    public boolean canUseHomes(Player player) {
        return player != null && this.getHomeLimit(player) > 0;
    }

    private String normalizeHomeKey(String homeName) {
        String cleaned = this.cleanHomeName(homeName);
        return cleaned == null ? "" : cleaned.toLowerCase();
    }

    private String cleanHomeName(String homeName) {
        String cleaned = homeName == null ? null : Text.strip(homeName).trim();
        return cleaned == null ? "" : cleaned;
    }

    public static class PlayerData {
        private boolean joinedBefore;
        private String lastLogoutWorld;
        private int lastSeenPvpEnableVersion;
        private int tutorialStage;
        private boolean tutorialRewardBooster;
        private int raidPoints;
        private int prisonRiotShopPoints;
        private long prisonCoins;
        private int alienLevel = 1;
        private int alienProgress;
        private boolean inventoryFullNotifications = true;
        private boolean pickaxeChargeFullNotifications = true;
        private boolean stashNotifications = true;
        private boolean miningXpActionBar = true;
        private boolean chargeActionBar = true;
        private boolean enchantProcActionBar = true;
        private boolean tutorialSkipConfirm = true;
        private boolean tpaRequests = true;
        private boolean payRequests = true;
        private boolean privateMessages = true;
        private boolean fragmentNotifications = true;
        private boolean chatEnabled = true;
        private String nickname;
        private Map<String, HomeEntry> homes = new LinkedHashMap<String, HomeEntry>();
        private Set<String> unlockedWarps = new HashSet<String>();
        private Set<String> unlockedGkits = new HashSet<String>();
        private Set<String> blockedGkits = new HashSet<String>();
        private Map<String, Long> kitCooldowns = new HashMap<String, Long>();

        public boolean hasJoinedBefore() {
            return this.joinedBefore;
        }

        public int getTutorialStage() {
            return this.tutorialStage;
        }

        public String getLastLogoutWorld() {
            return this.lastLogoutWorld;
        }

        public int getLastSeenPvpEnableVersion() {
            return this.lastSeenPvpEnableVersion;
        }

        public boolean hasTutorialRewardBooster() {
            return this.tutorialRewardBooster;
        }

        public int getRaidPoints() {
            return this.raidPoints;
        }

        public int getPrisonRiotShopPoints() {
            return this.prisonRiotShopPoints;
        }

        public long getPrisonCoins() {
            return this.prisonCoins;
        }

        public int getAlienLevel() {
            return this.alienLevel;
        }

        public int getAlienProgress() {
            return this.alienProgress;
        }

        public boolean hasInventoryFullNotifications() {
            return this.inventoryFullNotifications;
        }

        public boolean hasPickaxeChargeFullNotifications() {
            return this.pickaxeChargeFullNotifications;
        }

        public boolean hasStashNotifications() {
            return this.stashNotifications;
        }

        public boolean hasMiningXpActionBar() {
            return this.miningXpActionBar;
        }

        public boolean hasChargeActionBar() {
            return this.chargeActionBar;
        }

        public boolean hasEnchantProcActionBar() {
            return this.enchantProcActionBar;
        }

        public boolean hasTutorialSkipConfirm() {
            return this.tutorialSkipConfirm;
        }

        public boolean hasTpaRequests() {
            return this.tpaRequests;
        }

        public boolean hasPayRequests() {
            return this.payRequests;
        }

        public boolean hasPrivateMessages() {
            return this.privateMessages;
        }

        public boolean hasFragmentNotifications() {
            return this.fragmentNotifications;
        }

        public boolean hasChatEnabled() {
            return this.chatEnabled;
        }

        public String getNickname() {
            return this.nickname;
        }

        public Map<String, HomeEntry> getHomes() {
            return this.homes;
        }

        public HomeEntry getHome(String homeName) {
            if (homeName == null) {
                return null;
            }
            return this.homes.get(homeName.toLowerCase(Locale.ROOT));
        }

        public void setJoinedBefore(boolean joinedBefore) {
            this.joinedBefore = joinedBefore;
        }

        public void setLastLogoutWorld(String lastLogoutWorld) {
            this.lastLogoutWorld = lastLogoutWorld == null || lastLogoutWorld.isBlank() ? null : lastLogoutWorld;
        }

        public void setLastSeenPvpEnableVersion(int lastSeenPvpEnableVersion) {
            this.lastSeenPvpEnableVersion = Math.max(0, lastSeenPvpEnableVersion);
        }

        public void setTutorialStage(int tutorialStage) {
            this.tutorialStage = tutorialStage;
        }

        public void setTutorialRewardBooster(boolean tutorialRewardBooster) {
            this.tutorialRewardBooster = tutorialRewardBooster;
        }

        public void setRaidPoints(int raidPoints) {
            this.raidPoints = Math.max(0, raidPoints);
        }

        public void addRaidPoints(int raidPoints) {
            this.raidPoints = Math.max(0, this.raidPoints + Math.max(0, raidPoints));
        }

        public void setPrisonRiotShopPoints(int prisonRiotShopPoints) {
            this.prisonRiotShopPoints = Math.max(0, prisonRiotShopPoints);
        }

        public void addPrisonRiotShopPoints(int prisonRiotShopPoints) {
            this.prisonRiotShopPoints = Math.max(0, this.prisonRiotShopPoints + Math.max(0, prisonRiotShopPoints));
        }

        public void setPrisonCoins(long prisonCoins) {
            this.prisonCoins = Math.max(0L, prisonCoins);
        }

        public void addPrisonCoins(long prisonCoins) {
            long delta = Math.max(0L, prisonCoins);
            long updated = this.prisonCoins + delta;
            this.prisonCoins = Math.max(0L, updated);
        }

        public void setAlienLevel(int alienLevel) {
            this.alienLevel = Math.max(1, alienLevel);
        }

        public void setAlienProgress(int alienProgress) {
            this.alienProgress = Math.max(0, alienProgress);
        }

        public void addAlienProgress(int amount) {
            this.alienProgress = Math.max(0, this.alienProgress + Math.max(0, amount));
        }

        public void setInventoryFullNotifications(boolean inventoryFullNotifications) {
            this.inventoryFullNotifications = inventoryFullNotifications;
        }

        public void setPickaxeChargeFullNotifications(boolean pickaxeChargeFullNotifications) {
            this.pickaxeChargeFullNotifications = pickaxeChargeFullNotifications;
        }

        public void setStashNotifications(boolean stashNotifications) {
            this.stashNotifications = stashNotifications;
        }

        public void setMiningXpActionBar(boolean miningXpActionBar) {
            this.miningXpActionBar = miningXpActionBar;
        }

        public void setChargeActionBar(boolean chargeActionBar) {
            this.chargeActionBar = chargeActionBar;
        }

        public void setEnchantProcActionBar(boolean enchantProcActionBar) {
            this.enchantProcActionBar = enchantProcActionBar;
        }

        public void setTutorialSkipConfirm(boolean tutorialSkipConfirm) {
            this.tutorialSkipConfirm = tutorialSkipConfirm;
        }

        public void setTpaRequests(boolean tpaRequests) {
            this.tpaRequests = tpaRequests;
        }

        public void setPayRequests(boolean payRequests) {
            this.payRequests = payRequests;
        }

        public void setPrivateMessages(boolean privateMessages) {
            this.privateMessages = privateMessages;
        }

        public void setFragmentNotifications(boolean fragmentNotifications) {
            this.fragmentNotifications = fragmentNotifications;
        }

        public void setChatEnabled(boolean chatEnabled) {
            this.chatEnabled = chatEnabled;
        }

        public void setNickname(String nickname) {
            String cleaned = nickname == null ? null : Text.strip(nickname).trim();
            if (cleaned != null && cleaned.startsWith("~")) {
                cleaned = cleaned.substring(1).trim();
            }
            this.nickname = cleaned == null || cleaned.isBlank() ? null : cleaned;
        }

        public Set<String> getUnlockedWarps() {
            return this.unlockedWarps;
        }

        public boolean hasUnlockedWarp(String warpKey) {
            return this.unlockedWarps.contains(warpKey);
        }

        public void unlockWarp(String warpKey) {
            this.unlockedWarps.add(warpKey);
        }

        public boolean hasUnlockedGKit(String gkitKey) {
            return gkitKey != null && this.unlockedGkits.contains(gkitKey.toLowerCase());
        }

        public void unlockGKit(String gkitKey) {
            if (gkitKey != null) {
                this.unlockedGkits.add(gkitKey.toLowerCase());
            }
        }

        public void removeGKit(String gkitKey) {
            if (gkitKey != null) {
                this.unlockedGkits.remove(gkitKey.toLowerCase());
            }
        }

        public boolean isGKitBlocked(String gkitKey) {
            return gkitKey != null && this.blockedGkits.contains(gkitKey.toLowerCase());
        }

        public void blockGKit(String gkitKey) {
            if (gkitKey != null) {
                this.blockedGkits.add(gkitKey.toLowerCase());
            }
        }

        public void unblockGKit(String gkitKey) {
            if (gkitKey != null) {
                this.blockedGkits.remove(gkitKey.toLowerCase());
            }
        }

        public long getKitCooldown(String kitKey) {
            if (kitKey == null) {
                return 0L;
            }
            return this.kitCooldowns.getOrDefault(kitKey.toLowerCase(), 0L);
        }

        public void setKitCooldown(String kitKey, long expiresAt) {
            if (kitKey == null) {
                return;
            }
            this.kitCooldowns.put(kitKey.toLowerCase(), expiresAt);
        }

        public void clearKitCooldown(String kitKey) {
            if (kitKey == null) {
                return;
            }
            this.kitCooldowns.remove(kitKey.toLowerCase());
        }

        public void clearAllKitCooldowns() {
            this.kitCooldowns.clear();
        }
    }

    public record HomeEntry(String name, Location location) {
    }
}
