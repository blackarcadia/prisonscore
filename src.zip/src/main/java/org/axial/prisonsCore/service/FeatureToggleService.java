package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.CommandSender;

public class FeatureToggleService {
    private static final String PVP_ENABLE_VERSION_PATH = "features.pvp-enable-version";
    private final PrisonsCore plugin;
    private final Map<Feature, Boolean> enabledByFeature = new EnumMap<>(Feature.class);
    private int pvpEnableVersion;

    public FeatureToggleService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.reload();
    }

    public void reload() {
        this.enabledByFeature.clear();
        for (Feature feature : Feature.values()) {
            this.enabledByFeature.put(feature, this.plugin.getConfig().getBoolean(feature.path(), true));
        }
        this.pvpEnableVersion = Math.max(0, this.plugin.getConfig().getInt(PVP_ENABLE_VERSION_PATH, 0));
    }

    public boolean isEnabled(Feature feature) {
        return this.enabledByFeature.getOrDefault(feature, true);
    }

    public boolean checkEnabled(CommandSender sender, Feature feature) {
        if (this.isEnabled(feature)) {
            return true;
        }
        if (sender != null) {
            sender.sendMessage(Text.color("&c" + feature.messageName() + " are currently disabled"));
        }
        return false;
    }

    public void setEnabled(Feature feature, boolean enabled) {
        boolean wasEnabled = this.isEnabled(feature);
        this.enabledByFeature.put(feature, enabled);
        this.plugin.getConfig().set(feature.path(), enabled);
        if (feature == Feature.PVP && enabled && !wasEnabled) {
            this.pvpEnableVersion++;
            this.plugin.getConfig().set(PVP_ENABLE_VERSION_PATH, this.pvpEnableVersion);
        }
        this.plugin.saveConfig();
    }

    public int getPvpEnableVersion() {
        return this.pvpEnableVersion;
    }

    public Feature resolve(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        String normalized = input.toLowerCase(Locale.ROOT);
        for (Feature feature : Feature.values()) {
            if (feature.matches(normalized)) {
                return feature;
            }
        }
        return null;
    }

    public List<String> featureNames() {
        List<String> names = new ArrayList<>();
        for (Feature feature : Feature.values()) {
            names.add(feature.key());
        }
        return names;
    }

    public enum Feature {
        SHOP("shop", "shop", "shops"),
        METEORS("meteors", "meteors", "meteor"),
        CELL_GUARDS("cellguards", "cell guards", "cellguard", "cell-guards", "cell_guard"),
        GENERATORS("generators", "generators", "generator"),
        REFINED("refined", "refined", "refinedore", "refinedores", "refined-ore", "refined_ore"),
        ENCHANTS("enchants", "enchants", "enchant"),
        ENCHANTER("enchanter", "enchanter"),
        LEVELS("levels", "levels", "level"),
        PVP("pvp", "PVP", "pvp");

        private final String key;
        private final String messageName;
        private final List<String> aliases;

        Feature(String key, String messageName, String... aliases) {
            this.key = key;
            this.messageName = messageName;
            this.aliases = Arrays.asList(aliases);
        }

        public String key() {
            return this.key;
        }

        public String messageName() {
            return this.messageName;
        }

        public String path() {
            return "features." + this.key;
        }

        private boolean matches(String input) {
            if (this.key.equalsIgnoreCase(input)) {
                return true;
            }
            for (String alias : this.aliases) {
                if (alias.equalsIgnoreCase(input)) {
                    return true;
                }
            }
            return false;
        }
    }
}
