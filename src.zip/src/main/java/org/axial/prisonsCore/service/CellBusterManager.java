/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.config.EnergyBarConfig;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class CellBusterManager {
    private final PrisonsCore plugin;
    private final NamespacedKey energyKey;
    private final NamespacedKey levelKey;
    private final NamespacedKey enchantsKey;
    private final EnergyBarConfig barConfig;
    private final int startLevel;
    private final CustomEnchantService customEnchantService;

    public CellBusterManager(PrisonsCore plugin, EnergyBarConfig barConfig, int startLevel, CustomEnchantService customEnchantService) {
        this.plugin = plugin;
        this.energyKey = Keys.cellBusterEnergy(plugin);
        this.levelKey = Keys.cellBusterLevel(plugin);
        this.enchantsKey = Keys.cellBusterEnchants(plugin);
        this.barConfig = barConfig;
        this.startLevel = startLevel;
        this.customEnchantService = customEnchantService;
    }

    public ItemStack createBuster() {
        ItemStack item = new ItemStack(Material.WOODEN_SHOVEL);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Text.color("&cCell Buster &a&l" + this.startLevel));
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, 0);
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, this.startLevel);
        meta.getPersistentDataContainer().set(Keys.cellBuster(this.plugin), PersistentDataType.BYTE, (byte)1);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS});
        meta.setUnbreakable(true);
        item.setItemMeta(meta);
        this.updateLore(item);
        return item;
    }

    public boolean isBuster(ItemStack stack) {
        String name;
        if (stack == null || !stack.hasItemMeta()) {
            return false;
        }
        ItemMeta meta = stack.getItemMeta();
        Byte flag = (Byte)meta.getPersistentDataContainer().get(Keys.cellBuster(this.plugin), PersistentDataType.BYTE);
        if (flag != null && flag == 1) {
            return true;
        }
        String string = name = meta.hasDisplayName() ? Text.strip(meta.getDisplayName()).toLowerCase(Locale.ROOT) : "";
        if (stack.getType() == Material.WOODEN_SHOVEL && name.contains("cell buster")) {
            meta.getPersistentDataContainer().set(Keys.cellBuster(this.plugin), PersistentDataType.BYTE, (byte)1);
            stack.setItemMeta(meta);
            return true;
        }
        return false;
    }

    public int getEnergy(ItemStack stack) {
        if (!this.isBuster(stack)) {
            return 0;
        }
        Integer v = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.energyKey, PersistentDataType.INTEGER);
        return v == null ? 0 : v;
    }

    public void setEnergy(ItemStack stack, int amount) {
        if (!this.isBuster(stack)) {
            return;
        }
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.energyKey, PersistentDataType.INTEGER, Math.max(0, Math.min(amount, this.getMaxEnergy())));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public int getMaxEnergy() {
        return this.plugin.getConfig().getInt("cellbuster.max-energy", 8000);
    }

    public boolean isFull(ItemStack stack) {
        return this.getEnergy(stack) >= this.getMaxEnergy();
    }

    public Map<String, Integer> getEnchants(ItemStack stack) {
        if (!this.isBuster(stack)) {
            return Map.of();
        }
        String raw = (String)stack.getItemMeta().getPersistentDataContainer().get(this.enchantsKey, PersistentDataType.STRING);
        if (raw == null || raw.isEmpty()) {
            return Map.of();
        }
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        for (String part : raw.split(";")) {
            String[] bits = part.split(":");
            if (bits.length != 2) continue;
            try {
                map.put(bits[0], Integer.parseInt(bits[1]));
            }
            catch (NumberFormatException numberFormatException) {
                // empty catch block
            }
        }
        return map;
    }

    public void setEnchants(ItemStack stack, Map<String, Integer> enchants) {
        if (!this.isBuster(stack)) {
            return;
        }
        String serialized = enchants.entrySet().stream().map(e -> (String)e.getKey() + ":" + String.valueOf(e.getValue())).collect(Collectors.joining(";"));
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.enchantsKey, PersistentDataType.STRING, serialized);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
        meta.setEnchantmentGlintOverride(Boolean.valueOf(!enchants.isEmpty()));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public boolean applyEnchant(ItemStack stack, String id, int level, int maxLevel) {
        HashMap<String, Integer> enchants = new HashMap<String, Integer>(this.getEnchants(stack));
        int current = enchants.getOrDefault(id, 0);
        int newLevel = Math.min(maxLevel, Math.max(current, level));
        enchants.put(id, newLevel);
        this.setEnchants(stack, enchants);
        return newLevel != current;
    }

    public int getLevel(ItemStack stack) {
        if (!this.isBuster(stack)) {
            return 1;
        }
        Integer v = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.levelKey, PersistentDataType.INTEGER);
        return v == null ? 1 : v;
    }

    public void levelUp(ItemStack stack) {
        if (!this.isBuster(stack)) {
            return;
        }
        int lvl = this.getLevel(stack) + 1;
        ItemMeta meta = stack.getItemMeta();
        meta.getPersistentDataContainer().set(this.levelKey, PersistentDataType.INTEGER, lvl);
        meta.setDisplayName(Text.color("&cCell Buster &a&l" + lvl));
        stack.setItemMeta(meta);
        this.updateLore(stack);
    }

    public void updateLore(ItemStack stack) {
        if (!this.isBuster(stack)) {
            return;
        }
        int energy = this.getEnergy(stack);
        int max = this.getMaxEnergy();
        int level = this.getLevel(stack);
        Map<String, Integer> ench = this.getEnchants(stack);
        ItemMeta meta = stack.getItemMeta();
        ArrayList<String> lore = new ArrayList<String>();
        if (!ench.isEmpty()) {
            for (Map.Entry<String, Integer> entry : ench.entrySet()) {
                CustomEnchant ce;
                int lvl = entry.getValue();
                Object line = "&d" + entry.getKey() + " " + this.toRoman(lvl);
                if (this.customEnchantService != null && (ce = this.customEnchantService.getById(entry.getKey())) != null) {
                    line = ce.getLoreLine(lvl, "&d{enchant} {level}");
                }
                line = ((String)line).replace("{enchant}", entry.getKey()).replace("{level}", this.toRoman(lvl));
                lore.add(Text.color((String)line));
            }
        }
        double percent = Math.min(1.0, Math.max(0.0, (double)energy / (double)max));
        int filled = (int)Math.round(percent * (double)this.barConfig.getLength());
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < this.barConfig.getLength(); ++i) {
            bar.append(i < filled ? this.barConfig.getFilledColor() + this.barConfig.getFilledChar() : this.barConfig.getEmptyColor() + this.barConfig.getEmptyChar());
        }
        lore.add("");
        lore.add(Text.color(this.plugin.getConfig().getString("energy.label", "&7Pickaxe Charge")));
        Object barLine = this.barConfig.getFormat().replace("{bar}", ChatColor.translateAlternateColorCodes((char)'&', (String)bar.toString())).replace("{current}", String.valueOf(energy)).replace("{max}", String.valueOf(max));
        double percentDisplay = (double)Math.round(percent * 1000.0) / 10.0;
        barLine = (String)barLine + Text.color(" &f&l" + percentDisplay + "%");
        lore.add(Text.color((String)barLine));
        lore.add(Text.color("&7(" + (energy > max ? "&d" : "&f") + energy + " &7/ &f" + max + ")"));
        meta.setLore(lore);
        stack.setItemMeta(meta);
    }

    private String buildBar(int current, int max) {
        int len = Math.max(1, this.barConfig.getLength());
        double pct = max <= 0 ? 0.0 : Math.min(1.0, Math.max(0.0, (double)current / (double)max));
        int filled = (int)Math.round(pct * (double)len);
        String filledPart = this.barConfig.getFilledColor() + this.barConfig.getFilledChar().repeat(filled);
        String emptyPart = this.barConfig.getEmptyColor() + this.barConfig.getEmptyChar().repeat(len - filled);
        return filledPart + emptyPart;
    }

    private String formatEnchants(Map<String, Integer> ench) {
        return ench.entrySet().stream().map(e -> ((String)e.getKey()).toLowerCase(Locale.ROOT) + " " + String.valueOf(e.getValue())).collect(Collectors.joining(", "));
    }

    private String toRoman(int number) {
        String[] romans = new String[]{"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        if (number >= 0 && number < romans.length) {
            return romans[number];
        }
        return String.valueOf(number);
    }
}
