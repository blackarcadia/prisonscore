/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class JetService {
    private final PrisonsCore plugin;
    private final Map<UUID, JetSession> active = new ConcurrentHashMap<UUID, JetSession>();
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<UUID, Long>();
    private int durationSeconds;
    private int cooldownSeconds;
    private double ascendVertical;
    private double ascendForward;
    private double descendVertical;
    private double descendForward;
    private int particleInterval;

    public JetService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.loadConfig();
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "jet.yml");
        if (!file.exists()) {
            this.plugin.saveResource("jet.yml", false);
        }
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        this.durationSeconds = cfg.getInt("duration-seconds", 20);
        this.cooldownSeconds = cfg.getInt("cooldown-seconds", 180);
        this.ascendVertical = cfg.getDouble("ascend-vertical", 0.35);
        this.ascendForward = cfg.getDouble("ascend-forward", 0.55);
        this.descendVertical = -Math.abs(cfg.getDouble("descend-vertical", 0.3));
        this.descendForward = cfg.getDouble("descend-forward", 0.45);
        this.particleInterval = cfg.getInt("particle-interval-ticks", 2);
    }

    public boolean isOnCooldown(Player player) {
        long now = System.currentTimeMillis();
        return this.cooldowns.getOrDefault(player.getUniqueId(), 0L) > now;
    }

    public long cooldownRemainingMs(Player player) {
        long now = System.currentTimeMillis();
        return Math.max(0L, this.cooldowns.getOrDefault(player.getUniqueId(), 0L) - now);
    }

    public void startJet(final Player player) {
        final BukkitTask[] holder = new BukkitTask[1];
        if (this.active.containsKey(player.getUniqueId())) {
            player.sendMessage(Text.color("&cJetpack already active."));
            return;
        }
        long now = System.currentTimeMillis();
        if (this.isOnCooldown(player)) {
            long ms = this.cooldownRemainingMs(player);
            long sec = (ms + 999L) / 1000L;
            player.sendMessage(Text.color("&cJetpack cooling down. &7" + sec + "s remaining."));
            return;
        }
        player.sendMessage(Text.color("&a&lJetpack Initiated"));
        holder[0] = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, new Runnable(){
            int count = 3;

            @Override
            public void run() {
                if (!player.isOnline()) {
                    holder[0].cancel();
                    return;
                }
                if (this.count <= 0) {
                    holder[0].cancel();
                    player.sendMessage(Text.color("&a&lJetpack Active"));
                    player.playSound(player.getLocation(), Sound.ENTITY_ZOMBIE_VILLAGER_CURE, 1.0f, 1.0f);
                    JetService.this.beginFlight(player);
                    return;
                }
                player.sendMessage(Text.color("&e&l" + this.count + "&e..."));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
                --this.count;
            }
        }, 0L, 20L);
    }

    private void beginFlight(Player player) {
        UUID id = player.getUniqueId();
        JetSession session = new JetSession(id);
        this.active.put(id, session);
        session.start(player);
    }

    public void handleSneak(UUID playerId, boolean sneaking) {
        JetSession s = this.active.get(playerId);
        if (s != null) {
            s.setDescending(sneaking);
        }
    }

    public void stop(UUID playerId, boolean fuelOut) {
        this.stop(playerId, fuelOut, fuelOut);
    }

    public void stop(UUID playerId, boolean applyCooldown, boolean showFuelMessage) {
        JetSession s = this.active.remove(playerId);
        if (s != null) {
            s.cancel(applyCooldown, showFuelMessage);
        }
    }

    private class JetSession {
        private final UUID playerId;
        private boolean descending = false;
        private int ticks = 0;
        private BukkitTask velocityTask;
        private BukkitTask particleTask;

        JetSession(UUID playerId) {
            this.playerId = playerId;
        }

        void start(Player player) {
            player.setAllowFlight(true);
            this.velocityTask = Bukkit.getScheduler().runTaskTimer((Plugin)JetService.this.plugin, () -> {
                Player p = Bukkit.getPlayer((UUID)this.playerId);
                if (p == null || !p.isOnline()) {
                    JetService.this.stop(this.playerId, false);
                    return;
                }
                Vector dir = p.getLocation().getDirection();
                dir.setY(0).normalize();
                Vector vel = dir.multiply(this.descending ? JetService.this.descendForward : JetService.this.ascendForward).setY(this.descending ? JetService.this.descendVertical : JetService.this.ascendVertical);
                p.setVelocity(vel);
                ++this.ticks;
                if (p.isOnGround() && this.ticks > 5) {
                    JetService.this.stop(this.playerId, true, false);
                    return;
                }
                if (this.ticks >= JetService.this.durationSeconds * 20) {
                    JetService.this.stop(this.playerId, true, true);
                }
            }, 0L, 2L);
            this.particleTask = Bukkit.getScheduler().runTaskTimer((Plugin)JetService.this.plugin, () -> {
                Player p = Bukkit.getPlayer((UUID)this.playerId);
                if (p == null || !p.isOnline()) {
                    return;
                }
                p.getWorld().spawnParticle(Particle.CLOUD, p.getLocation().subtract(0.0, 0.5, 0.0), 4, 0.2, 0.05, 0.2, 0.01);
            }, 0L, (long)JetService.this.particleInterval);
        }

        void setDescending(boolean descending) {
            this.descending = descending;
        }

        void cancel(boolean applyCooldown, boolean showFuelMessage) {
            Player p;
            if (this.velocityTask != null) {
                this.velocityTask.cancel();
            }
            if (this.particleTask != null) {
                this.particleTask.cancel();
            }
            if ((p = Bukkit.getPlayer((UUID)this.playerId)) != null && p.isOnline()) {
                p.setVelocity(new Vector(0, 0, 0));
                p.setAllowFlight(false);
                if (applyCooldown) {
                    if (showFuelMessage) {
                        p.sendMessage(Text.color("&c&lJetpack has ran out of fuel"));
                    }
                    JetService.this.cooldowns.put(this.playerId, System.currentTimeMillis() + (long)JetService.this.cooldownSeconds * 1000L);
                }
            }
        }
    }
}
