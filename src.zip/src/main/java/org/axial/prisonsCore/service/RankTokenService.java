package org.axial.prisonsCore.service;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class RankTokenService {
    private final PrisonsCore plugin;

    public RankTokenService(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public RankType parseRank(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        String normalized = input.toLowerCase(Locale.ROOT).replace('-', '_').replace(' ', '_');
        for (RankType type : RankType.values()) {
            if (type.id().equals(normalized) || type.groupName().equalsIgnoreCase(normalized)) {
                return type;
            }
        }
        return null;
    }

    public boolean hasRank(Player player, RankType type) {
        if (player == null || type == null) {
            return false;
        }
        return player.hasPermission(type.groupPermission()) || player.hasPermission(type.alternateGroupPermission());
    }

    public ItemStack createToken(RankType type) {
        if (type == null) {
            return null;
        }
        ItemStack token = new ItemStack(type.material());
        ItemMeta meta = token.getItemMeta();
        if (meta == null) {
            return token;
        }
        meta.setDisplayName(Text.color(type.displayName()));
        meta.setLore(List.of(
                Text.color("&7Right-Click to unlock the"),
                Text.color("&e&l&n" + type.plainName() + " &7Rank on this planet."),
                Text.color(""),
                Text.color("&e&l" + type.plainName() + " Perks:"),
                Text.color("&e&l* &7Access to /fix"),
                Text.color("&e&l* &7Access to /tpa"),
                Text.color("&e&l* &7Access to /sell"),
                Text.color("&e&l* &7Access to /nick"),
                Text.color("&e&l* &7Access to /feed"),
                Text.color("&e&l* &7Access to /tpahere"),
                Text.color("&e&l* &7Access to /jet"),
                Text.color("&e&l* &7Access to /near (200 Blocks)"),
                Text.color("&e&l* &75% /sell tax"),
                Text.color("&e&l* &710 Private Vaults (/pv)"),
                Text.color("&e&l* &7Access to 6 homes")
        ));
        this.applyGlint(meta);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        meta.getPersistentDataContainer().set(Keys.rankTokenType(this.plugin), PersistentDataType.STRING, type.id());
        token.setItemMeta(meta);
        return token;
    }

    public boolean isRankToken(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(Keys.rankTokenType(this.plugin), PersistentDataType.STRING);
    }

    public RankType getRankTokenType(ItemStack stack) {
        if (!this.isRankToken(stack)) {
            return null;
        }
        String id = stack.getItemMeta().getPersistentDataContainer().get(Keys.rankTokenType(this.plugin), PersistentDataType.STRING);
        return this.parseRank(id);
    }

    public CompletableFuture<Boolean> grantRank(OfflinePlayer target, RankType type) {
        CompletableFuture<Boolean> future = new CompletableFuture<>();
        if (target == null || type == null) {
            future.complete(Boolean.FALSE);
            return future;
        }
        Bukkit.getScheduler().runTask(this.plugin, () -> {
            if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
                future.completeExceptionally(new IllegalStateException("LuckPerms is not installed."));
                return;
            }
            String command = "lp user " + target.getUniqueId() + " parent set " + type.groupName();
            boolean dispatched = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
            if (!dispatched) {
                future.completeExceptionally(new IllegalStateException("Failed to dispatch LuckPerms rank command."));
                return;
            }
            if (target.isOnline() && target.getPlayer() != null) {
                target.getPlayer().recalculatePermissions();
            }
            future.complete(Boolean.TRUE);
        });
        return future;
    }

    private void applyGlint(ItemMeta meta) {
        if (meta == null) {
            return;
        }
        try {
            Method method = meta.getClass().getMethod("setEnchantmentGlintOverride", Boolean.class);
            method.invoke(meta, Boolean.TRUE);
            return;
        } catch (Exception ignored) {
        }
        Enchantment glint = Enchantment.getByName("UNBREAKING");
        if (glint == null) {
            glint = Enchantment.getByName("DURABILITY");
        }
        if (glint == null) {
            glint = Enchantment.getByName("PROTECTION_ENVIRONMENTAL");
        }
        if (glint != null && !meta.hasEnchant(glint)) {
            meta.addEnchant(glint, 1, true);
        }
    }

    public enum RankType {
        VANGUARD("vanguard", "Vanguard", "&6&lRank: &e&lVanguard", Material.TRIAL_KEY, "group.vanguard", "luckperms.group.vanguard");

        private final String id;
        private final String plainName;
        private final String displayName;
        private final Material material;
        private final String groupPermission;
        private final String alternateGroupPermission;

        RankType(String id, String plainName, String displayName, Material material, String groupPermission, String alternateGroupPermission) {
            this.id = id;
            this.plainName = plainName;
            this.displayName = displayName;
            this.material = material;
            this.groupPermission = groupPermission;
            this.alternateGroupPermission = alternateGroupPermission;
        }

        public String id() {
            return this.id;
        }

        public String plainName() {
            return this.plainName;
        }

        public String displayName() {
            return this.displayName;
        }

        public Material material() {
            return this.material;
        }

        public String groupName() {
            return this.id;
        }

        public String groupPermission() {
            return this.groupPermission;
        }

        public String alternateGroupPermission() {
            return this.alternateGroupPermission;
        }
    }
}
