/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.NamespacedKey
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataType
 */
package org.axial.prisonsCore.service;

import java.io.File;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class EnergyItemService {
    private final PrisonsCore plugin;
    private final NamespacedKey amountKey;
    private final NamespacedKey extractorKey;
    private Material material;
    private String displayName;
    private List<String> lore;
    private Material extractorMaterial = Material.BLAZE_ROD;
    private String extractorDisplay = "&eCharge Extractor";
    private List<String> extractorLore = List.of("&7Extracts all charge", "&7No tax applied");

    public EnergyItemService(PrisonsCore plugin) {
        this.plugin = plugin;
        this.amountKey = Keys.energyItemAmount(plugin);
        this.extractorKey = Keys.energyExtractor(plugin);
        this.loadConfig();
    }

    public ItemStack createEnergyItem(int amount) {
        ItemStack stack = new ItemStack(this.material);
        stack.setAmount(1);
        ItemMeta meta = stack.getItemMeta();
        String formattedAmount = String.format(Locale.ENGLISH, "%,d", amount);
        meta.setDisplayName(Text.color(this.displayName.replace("{amount}", formattedAmount)));
        if (this.lore != null) {
            meta.setLore(this.lore.stream().map(line -> line.replace("{amount}", formattedAmount)).map(Text::color).collect(Collectors.toList()));
        }
        meta.getPersistentDataContainer().set(this.amountKey, PersistentDataType.INTEGER, amount);
        meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES});
        meta.setEnchantmentGlintOverride(Boolean.valueOf(true));
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemStack createExtractorItem() {
        ItemStack stack = new ItemStack(this.extractorMaterial);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(Text.color(this.extractorDisplay));
        if (this.extractorLore != null) {
            meta.setLore(this.extractorLore.stream().map(Text::color).collect(Collectors.toList()));
        }
        meta.getPersistentDataContainer().set(this.extractorKey, PersistentDataType.BYTE, (byte)1);
        stack.setItemMeta(meta);
        return stack;
    }

    public boolean isEnergyItem(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return false;
        }
        return stack.getItemMeta().getPersistentDataContainer().has(this.amountKey, PersistentDataType.INTEGER);
    }

    public boolean isExtractor(ItemStack stack) {
        return stack != null && stack.hasItemMeta() && stack.getItemMeta().getPersistentDataContainer().has(this.extractorKey, PersistentDataType.BYTE);
    }

    public int getAmount(ItemStack stack) {
        if (!this.isEnergyItem(stack)) {
            return 0;
        }
        Integer val = (Integer)stack.getItemMeta().getPersistentDataContainer().get(this.amountKey, PersistentDataType.INTEGER);
        return val == null ? 0 : val;
    }

    public int getTotalAmount(ItemStack stack) {
        if (!this.isEnergyItem(stack)) {
            return 0;
        }
        return this.getAmount(stack) * Math.max(1, stack.getAmount());
    }

    public void giveEnergyItem(Player player, int amount) {
        if (player == null || amount <= 0) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        this.compactEnergyItems(inventory);
        Map<Integer, ItemStack> leftover = inventory.addItem(this.createEnergyItem(amount));
        this.compactEnergyItems(inventory);
        if (this.plugin.getStashService() != null) {
            leftover.values().forEach(item -> this.plugin.getStashService().giveOrStash(player, item));
            return;
        }
        leftover.values().forEach(item -> player.getWorld().dropItem(player.getLocation(), item));
    }

    public void compactEnergyItems(PlayerInventory inventory) {
        if (inventory == null) {
            return;
        }
        Map<Integer, Integer> totalsByValue = new LinkedHashMap<Integer, Integer>();
        Map<Integer, Integer> firstSlotByValue = new LinkedHashMap<Integer, Integer>();
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            ItemStack stack = inventory.getItem(slot);
            if (!this.isEnergyItem(stack)) {
                continue;
            }
            int unitAmount = this.getAmount(stack);
            if (unitAmount <= 0) {
                inventory.setItem(slot, null);
                continue;
            }
            totalsByValue.merge(unitAmount, unitAmount * Math.max(1, stack.getAmount()), Integer::sum);
            firstSlotByValue.putIfAbsent(unitAmount, slot);
            inventory.setItem(slot, null);
        }
        for (Map.Entry<Integer, Integer> entry : firstSlotByValue.entrySet()) {
            int unitAmount = entry.getKey();
            int totalAmount = totalsByValue.getOrDefault(unitAmount, 0);
            if (totalAmount <= 0) {
                continue;
            }
            inventory.setItem(entry.getValue(), this.createEnergyItem(totalAmount));
        }
    }

    private void loadConfig() {
        File file = new File(this.plugin.getDataFolder(), "items.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration((File)file);
        ConfigurationSection section = cfg.getConfigurationSection("items.energy-item");
        if (section == null) {
            return;
        }
        this.material = Material.matchMaterial((String)section.getString("material", "EXPERIENCE_BOTTLE"));
        if (this.material == null) {
            this.material = Material.EXPERIENCE_BOTTLE;
        }
        this.displayName = section.getString("display-name", "&bCharge Shard");
        this.lore = section.getStringList("lore");
        ConfigurationSection extractorSec = section.getConfigurationSection("extractor");
        if (extractorSec != null) {
            this.extractorMaterial = Material.matchMaterial((String)extractorSec.getString("material", this.extractorMaterial.name()));
            if (this.extractorMaterial == null) {
                this.extractorMaterial = Material.BLAZE_ROD;
            }
            this.extractorDisplay = extractorSec.getString("display-name", this.extractorDisplay);
            this.extractorLore = extractorSec.getStringList("lore");
            if (this.extractorLore == null || this.extractorLore.isEmpty()) {
                this.extractorLore = List.of("&7Extracts all charge", "&7No tax applied");
            }
        }
    }

    public void reload() {
        this.loadConfig();
    }
}
