package org.axial.prisonsCore.service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.PickaxeType;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class TutorialService {
    private static final int SKIP_CONFIRM_SECONDS = 30;
    private static final int TITLE_TICKS = 100;
    private static final int REWARD_DURATION_SECONDS = Integer.MAX_VALUE;
    private final PrisonsCore plugin;
    private final TeleportService teleportService;
    private final PlayerLevelService playerLevelService;
    private final BoosterService boosterService;
    private final ShardService shardService;
    private final PlayerDataService playerDataService;
    private final MiningLevelScoreboardService miningLevelScoreboardService;
    private Location spawn;
    private final Map<UUID, Long> skipConfirmations = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, BukkitTask> stagedTasks = new ConcurrentHashMap<UUID, BukkitTask>();
    private final Map<UUID, Integer> allowedTeleports = new ConcurrentHashMap<UUID, Integer>();

    public TutorialService(PrisonsCore plugin, TeleportService teleportService, PlayerLevelService playerLevelService, BoosterService boosterService, ShardService shardService, PlayerDataService playerDataService, MiningLevelScoreboardService miningLevelScoreboardService) {
        this.plugin = plugin;
        this.teleportService = teleportService;
        this.playerLevelService = playerLevelService;
        this.boosterService = boosterService;
        this.shardService = shardService;
        this.playerDataService = playerDataService;
        this.miningLevelScoreboardService = miningLevelScoreboardService;
        this.load();
    }

    public void load() {
        this.spawn = this.resolveTutorialSpawn();
    }

    public void save() {
    }

    public void shutdown() {
        this.stagedTasks.values().forEach(BukkitTask::cancel);
        this.stagedTasks.clear();
        this.skipConfirmations.clear();
        this.allowedTeleports.clear();
    }

    public void setSpawn(Location spawn) {
        this.spawn = this.resolveTutorialSpawn();
    }

    public Location getSpawn() {
        return this.resolveTutorialSpawn();
    }

    public boolean shouldHandleJoin(Player player) {
        Location tutorialSpawn = this.resolveTutorialSpawn();
        return tutorialSpawn != null && (this.isInTutorial(player) || this.shouldStartTutorial(player));
    }

    public void handleJoin(Player player) {
        if (player == null) {
            return;
        }
        this.spawn = this.resolveTutorialSpawn();
        boolean shouldStart = this.shouldStartTutorial(player);
        if (!shouldStart && !this.hasJoinedBefore(player)) {
            this.markJoinedBefore(player);
        }
        if (this.spawn == null) {
            this.updateTutorialScoreboard(player);
            if (shouldStart) {
                this.markJoinedBefore(player);
            }
            this.resumeRewardBooster(player);
            return;
        }
        if (!shouldStart && !this.isInTutorial(player)) {
            this.updateTutorialScoreboard(player);
            this.resumeRewardBooster(player);
            return;
        }
        if (shouldStart) {
            this.markJoinedBefore(player);
            this.setStage(player, Stage.MINE_COAL);
            this.giveStarterBread(player);
        }
        this.cancelStageTask(player.getUniqueId());
        this.allowTeleport(player);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            if (!player.isOnline()) {
                return;
            }
            this.updateTutorialScoreboard(player);
            player.teleport(this.spawn, PlayerTeleportEvent.TeleportCause.PLUGIN);
            this.sendTutorialTitle(player);
            if (shouldStart) {
                Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
                    if (player.isOnline() && this.isInTutorial(player)) {
                        this.announceNewQuestUnlock(player);
                        this.sendTutorialMessage(player, "&6&lTutorial - Mining Coal", "&7Welcome to the tutorial, lets get started by mining some coal!", "", "&7Dont worry you can mine coal with your fist. Go on give it a go!");
                    }
                }, 10L);
            } else {
                this.resumeStage(player);
            }
        });
    }

    public void handleRespawn(Player player, org.bukkit.event.player.PlayerRespawnEvent event) {
        this.spawn = this.resolveTutorialSpawn();
        if (player == null || event == null || !this.isInTutorial(player) || this.spawn == null) {
            return;
        }
        event.setRespawnLocation(this.spawn);
    }

    public boolean isInTutorial(Player player) {
        if (player == null) {
            return false;
        }
        return this.getStage(player).isActive();
    }

    public boolean shouldFilterChat(Player player) {
        return this.isInTutorial(player);
    }

    public void requestSkip(Player player) {
        if (!this.isInTutorial(player)) {
            player.sendMessage(Text.color("&cYou are not currently in the tutorial."));
            return;
        }
        this.skipConfirmations.put(player.getUniqueId(), System.currentTimeMillis() + (long)SKIP_CONFIRM_SECONDS * 1000L);
        this.sendTutorialMessage(player, "&c&lTutorial Skip", "&7Run &f/tutorial skip confirm &7within 30 seconds to leave the tutorial.", "", "&7Skipping means you will not receive the 1.5x XP booster reward.");
    }

    public void skip(Player player) {
        if (!this.isInTutorial(player)) {
            player.sendMessage(Text.color("&cYou are not currently in the tutorial."));
            return;
        }
        Long expiresAt = this.skipConfirmations.get(player.getUniqueId());
        if (expiresAt == null || expiresAt < System.currentTimeMillis()) {
            this.requestSkip(player);
            return;
        }
        this.skipConfirmations.remove(player.getUniqueId());
        this.cancelStageTask(player.getUniqueId());
        this.setStage(player, Stage.SKIPPED);
        this.clearRewardBoosterFlag(player);
        this.updateTutorialScoreboard(player);
        this.allowTeleport(player);
        Location serverSpawn = this.teleportService.getSpawn();
        if (serverSpawn != null) {
            player.teleport(serverSpawn, PlayerTeleportEvent.TeleportCause.PLUGIN);
        }
        this.sendTutorialMessage(player, "&c&lTutorial skipped", "&7You will not recieve a 1.5x XP booster.");
    }

    public boolean shouldBlockTeleportOut(Player player, Location to) {
        this.spawn = this.resolveTutorialSpawn();
        if (player == null || to == null || !this.isInTutorial(player)) {
            return false;
        }
        if (this.consumeAllowedTeleport(player)) {
            return false;
        }
        if (this.spawn == null || this.spawn.getWorld() == null || to.getWorld() == null) {
            return false;
        }
        return !this.spawn.getWorld().getUID().equals(to.getWorld().getUID());
    }

    public void notifyTeleportBlocked(Player player) {
        player.sendMessage(Text.color("&cYou cannot leave the tutorial except with &f/tutorial skip&c."));
    }

    public void handleCoalMined(Player player, Material material) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.MINE_COAL || !this.isCoalOre(material)) {
            return;
        }
        this.setStage(player, Stage.REACH_LEVEL_ONE);
        this.announceNewQuestUnlock(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Mining XP", "&7Mining ores gives you mining XP. Keep a track on your sidebar to keep an eye on your progress to the next level!");
        if (this.playerLevelService.getLevel(player) >= 1) {
            this.handleLevelProgress(player, 0, this.playerLevelService.getLevel(player));
        }
    }

    public void handleExtractCommand(Player player) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.OPEN_ENCHANTS) {
            return;
        }
        this.setStage(player, Stage.PICKAXE_ENCHANTING);
        this.announceNewQuestUnlock(player);
        this.giveTutorialPickaxe(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Pickaxe Enchanting", "&7Mine blocks with this pickaxe to level up its charge. Get this pickaxe to max charge.");
        ItemStack held = player.getInventory().getItemInMainHand();
        if (held != null && this.isTutorialQuestPickaxe(held) && this.pickaxeManager().isFull(held)) {
            this.handlePickaxeChargeFull(player, held);
        }
    }

    public void handleLevelProgress(Player player, int previousLevel, int newLevel) {
        if (player == null) {
            return;
        }
        if (this.hasRewardBooster(player) && newLevel >= 10) {
            this.boosterService.deactivateBooster(player, BoosterService.BoosterType.XP, false);
            this.clearRewardBoosterFlag(player);
        }
        if (!this.isInTutorial(player) || newLevel <= previousLevel) {
            return;
        }
        if (this.getStage(player) == Stage.REACH_LEVEL_FIVE && newLevel >= 5) {
            this.completeTutorial(player);
            return;
        }
        Stage stage = this.getStage(player);
        if (stage == Stage.REACH_LEVEL_ONE && newLevel >= 2) {
            this.setStage(player, Stage.OPEN_LEVELS);
            this.announceNewQuestUnlock(player);
            this.sendTutorialMessage(player, "&6&lTutorial - Levels", "&7You leveled up!", "", "&7With each level you can unlock special rewards and higher tier pickaxes and ores! Run /levels to check your progress.");
            return;
        }
    }

    public void handleLevelsCommand(Player player) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.OPEN_LEVELS) {
            return;
        }
        ItemStack shard = this.shardService.createShard(ShardService.Tier.BASIC);
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, shard);
        } else {
            player.getInventory().addItem(new ItemStack[]{shard});
        }
        this.setStage(player, Stage.CLOSE_SHARD_MENU);
        this.announceNewQuestUnlock(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Fragments", "&7Fragments can be found through mining. Right click the fragment and place it inside the menu! Click it again to then roll its rewards.", "", "&7Ores are sold automatically upon closing the shard menu.");
    }

    public void handleShardMenuClosed(Player player) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.CLOSE_SHARD_MENU) {
            return;
        }
        this.setStage(player, Stage.OPEN_ENCHANTS);
        this.announceNewQuestUnlock(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Pickaxe Enchants", "&7Pickaxes can be enchanted once they have full charge. Pickaxes gain charge from mining ores. Run /enchants to see all the server enchants.");
    }

    public void handleEnchantsCommand(Player player) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.OPEN_ENCHANTS) {
            return;
        }
        this.sendTutorialMessage(player, "&6&lTutorial - Charge", "&7You can extract charge from a pickaxe with /extract. You will be charged a tax based on your permission level and mining level!", "", "&7You can use an extractor to extract the full charge from a pickaxe without tax.", "&7Run /extract.");
    }

    public void handlePickaxeChargeFull(Player player, ItemStack tool) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.PICKAXE_ENCHANTING || !this.isTutorialQuestPickaxe(tool) || !this.pickaxeManager().isFull(tool)) {
            return;
        }
        this.setStage(player, Stage.CHARGE_PIT);
        this.announceNewQuestUnlock(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Charge Pit", "&7Throw this pickaxe into the charge pit located near the Tutorial spawn.");
    }

    public void handleChargePitDrop(Player player, ItemStack stack) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.CHARGE_PIT || !this.isTutorialQuestPickaxe(stack)) {
            return;
        }
        this.setStage(player, Stage.SELECT_ENCHANTMENTS);
        this.announceNewQuestUnlock(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Selecting Enchantments", "&7Click an enchant to select it. Enchants apply based on their %. Chose enchants with higher % success rates for a better chance of application.");
    }

    public void handleEnchantSelected(Player player, ItemStack stack) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.SELECT_ENCHANTMENTS || !this.isTutorialQuestPickaxe(stack)) {
            return;
        }
        this.setStage(player, Stage.GUARDS);
        this.startGuardQuest(player);
    }

    public void handleSkinsCommand(Player player) {
        if (!this.isInTutorial(player) || this.getStage(player) != Stage.ITEM_SKINS_BLOCKS) {
            return;
        }
        this.setStage(player, Stage.REACH_LEVEL_FIVE);
        this.announceNewQuestUnlock(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Reach Level 5", "&7Mine to reach level 5. Upon reaching level 5 you will be sent out of the tutorial and sent to spawn. You will keep all items accrued inside this tutorial.");
        if (this.playerLevelService.getLevel(player) >= 5) {
            this.completeTutorial(player);
        }
    }

    public void resumeStage(Player player) {
        if (!this.isInTutorial(player)) {
            this.resumeRewardBooster(player);
            return;
        }
        this.cancelStageTask(player.getUniqueId());
        Stage stage = this.getStage(player);
        if (stage == Stage.MINE_COAL) {
            this.sendTutorialMessage(player, "&6&lTutorial - Mining Coal", "&7Welcome to the tutorial, lets get started by mining some coal!", "", "&7Dont worry you can mine coal with your fist. Go on give it a go!");
            return;
        }
        if (stage == Stage.REACH_LEVEL_ONE) {
            this.sendTutorialMessage(player, "&6&lTutorial - Mining XP", "&7Mining ores gives you mining XP. Keep a track on your sidebar to keep an eye on your progress to the next level!");
            return;
        }
        if (stage == Stage.OPEN_LEVELS) {
            this.sendTutorialMessage(player, "&6&lTutorial - Levels", "&7You leveled up!", "", "&7With each level you can unlock special rewards and higher tier pickaxes and ores! Run /levels to check your progress.");
            return;
        }
        if (stage == Stage.CLOSE_SHARD_MENU) {
            this.sendTutorialMessage(player, "&6&lTutorial - Fragments", "&7Fragments can be found through mining. Right click the fragment and place it inside the menu! Click it again to then roll its rewards.", "", "&7Ores are sold automatically upon closing the shard menu.");
            return;
        }
        if (stage == Stage.OPEN_ENCHANTS) {
            this.sendTutorialMessage(player, "&6&lTutorial - Charge", "&7You can extract charge from a pickaxe with /extract. You will be charged a tax based on your permission level and mining level!", "", "&7You can use an extractor to extract the full charge from a pickaxe without tax.", "&7Run /extract.");
            return;
        }
        if (stage == Stage.PICKAXE_ENCHANTING) {
            this.sendTutorialMessage(player, "&6&lTutorial - Pickaxe Enchanting", "&7Mine blocks with this pickaxe to level up its charge. Get this pickaxe to max charge.");
            ItemStack held = player.getInventory().getItemInMainHand();
            if (held != null && this.isTutorialQuestPickaxe(held) && this.pickaxeManager().isFull(held)) {
                this.handlePickaxeChargeFull(player, held);
            }
            return;
        }
        if (stage == Stage.CHARGE_PIT) {
            this.sendTutorialMessage(player, "&6&lTutorial - Charge Pit", "&7Throw this pickaxe into the charge pit located near the Tutorial spawn.");
            return;
        }
        if (stage == Stage.SELECT_ENCHANTMENTS) {
            this.sendTutorialMessage(player, "&6&lTutorial - Selecting Enchantments", "&7Click an enchant to select it. Enchants apply based on their %. Chose enchants with higher % success rates for a better chance of application.");
            return;
        }
        if (stage == Stage.GUARDS) {
            this.startGuardQuest(player);
            return;
        }
        if (stage == Stage.ITEM_SKINS_BLOCKS) {
            this.sendTutorialMessage(player, "&6&lTutorial - Item Skins + Custom Blocks", "&7There are a variety of custom skins and blocks. Each skin / block gives its own custom effects when worn or placed.", "", "&7Custom Blocks can only be placed inside your /cell.", "", "&c&lNOTE: &cThe &c&nAxialMod&r &cis required to view the custom models.", "&7Download it at &7&naxialmc.com", "", "&7Run /skins");
            return;
        }
        if (stage == Stage.REACH_LEVEL_FIVE) {
            this.sendTutorialMessage(player, "&6&lTutorial - Reach Level 5", "&7Mine to reach level 5. Upon reaching level 5 you will be sent out of the tutorial and sent to spawn. You will keep all items accrued inside this tutorial.");
            if (this.playerLevelService.getLevel(player) >= 5) {
                this.completeTutorial(player);
            }
        }
    }

    public Stage getStage(Player player) {
        return Stage.fromId(this.playerDataService.get(player.getUniqueId()).getTutorialStage());
    }

    private void setStage(Player player, Stage stage) {
        this.playerDataService.update(player.getUniqueId(), data -> data.setTutorialStage(stage.id()));
    }

    private void giveStarterBread(Player player) {
        player.getInventory().addItem(new ItemStack[]{new ItemStack(Material.BREAD, 16)});
    }

    private void giveTutorialPickaxe(Player player) {
        PickaxeType type = this.pickaxeManager().getType("wooden");
        if (type == null) {
            return;
        }
        ItemStack stack = this.pickaxeManager().createPickaxe(type, 4900);
        this.pickaxeManager().setLevel(stack, 1);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(Keys.tutorialQuestPickaxe(this.plugin), PersistentDataType.BYTE, (byte)1);
            stack.setItemMeta(meta);
        }
        this.giveOrStash(player, stack);
    }

    private void giveOrStash(Player player, ItemStack stack) {
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, stack);
            return;
        }
        java.util.Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack[]{stack});
        if (!leftover.isEmpty()) {
            leftover.values().forEach(item -> player.getWorld().dropItem(player.getLocation(), item));
        }
    }

    private void sendTutorialTitle(Player player) {
        player.sendTitle(Text.color("&6&l/tutorial"), "", 0, TITLE_TICKS, 0);
    }

    private void announceNewQuestUnlock(Player player) {
        player.sendTitle(Text.color("&6&lNew Quest"), Text.color("&fNew Quest In Chat"), 10, 60, 10);
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
    }

    private void sendTutorialMessage(Player player, String ... lines) {
        for (String line : lines) {
            player.sendMessage(line.isEmpty() ? "" : Text.color(line));
        }
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
    }

    private void scheduleStageTask(Player player, long delayTicks, Runnable runnable) {
        this.cancelStageTask(player.getUniqueId());
        BukkitTask task = Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, runnable, delayTicks);
        this.stagedTasks.put(player.getUniqueId(), task);
    }

    private void cancelStageTask(UUID playerId) {
        BukkitTask task = this.stagedTasks.remove(playerId);
        if (task != null) {
            task.cancel();
        }
    }

    private void completeTutorial(Player player) {
        if (!this.isInTutorial(player)) {
            return;
        }
        this.cancelStageTask(player.getUniqueId());
        this.skipConfirmations.remove(player.getUniqueId());
        this.setStage(player, Stage.COMPLETED);
        this.boosterService.activateBooster(player, BoosterService.BoosterType.XP, 1.5, REWARD_DURATION_SECONDS, false);
        this.setRewardBoosterFlag(player, true);
        this.updateTutorialScoreboard(player);
        this.allowTeleport(player);
        Location serverSpawn = this.teleportService.getSpawn();
        if (serverSpawn != null) {
            player.teleport(serverSpawn, PlayerTeleportEvent.TeleportCause.PLUGIN);
        }
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        player.sendTitle(Text.color("&6&lTutorial Complete"), "", 10, 80, 10);
    }

    private void allowTeleport(Player player) {
        this.allowedTeleports.merge(player.getUniqueId(), Integer.valueOf(1), (a, b) -> Integer.valueOf(a + b));
    }

    private boolean consumeAllowedTeleport(Player player) {
        Integer uses = this.allowedTeleports.get(player.getUniqueId());
        if (uses == null || uses <= 0) {
            return false;
        }
        if (uses == 1) {
            this.allowedTeleports.remove(player.getUniqueId());
        } else {
            this.allowedTeleports.put(player.getUniqueId(), Integer.valueOf(uses - 1));
        }
        return true;
    }

    private boolean isCoalOre(Material material) {
        return material == Material.COAL_ORE || material == Material.DEEPSLATE_COAL_ORE;
    }

    private void setRewardBoosterFlag(Player player, boolean active) {
        this.playerDataService.update(player.getUniqueId(), data -> data.setTutorialRewardBooster(active));
    }

    private boolean hasRewardBooster(Player player) {
        return this.playerDataService.get(player.getUniqueId()).hasTutorialRewardBooster();
    }

    private void clearRewardBoosterFlag(Player player) {
        this.setRewardBoosterFlag(player, false);
    }

    private void resumeRewardBooster(Player player) {
        if (!this.hasRewardBooster(player)) {
            return;
        }
        if (this.playerLevelService.getLevel(player) >= 10) {
            this.boosterService.deactivateBooster(player, BoosterService.BoosterType.XP, false);
            this.clearRewardBoosterFlag(player);
            return;
        }
        if (this.boosterService.getXpMultiplier(player) < 1.5) {
            this.boosterService.activateBooster(player, BoosterService.BoosterType.XP, 1.5, REWARD_DURATION_SECONDS, false);
        }
    }

    private boolean hasJoinedBefore(Player player) {
        return this.playerDataService.get(player.getUniqueId()).hasJoinedBefore();
    }

    private boolean isTutorialQuestPickaxe(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) {
            return false;
        }
        return stack.getItemMeta().getPersistentDataContainer().has(Keys.tutorialQuestPickaxe(this.plugin), PersistentDataType.BYTE);
    }

    private PickaxeManager pickaxeManager() {
        return this.plugin.getPickaxeManager();
    }

    private void startGuardQuest(Player player) {
        this.announceNewQuestUnlock(player);
        this.sendTutorialMessage(player, "&6&lTutorial - Guards", "&7Guards act as your safety. They keep you safe as you mine.", "", "&7Do NOT hit other players when in range of a protecting guard. Doing so will trigger you to be come warned.", "", "&7Hitting a player again causes you to become watched. A guard will then follow you.", "", "&7Hitting a player again will then cause you to be wanted and a guard will kill you.");
        this.cancelStageTask(player.getUniqueId());
        this.scheduleStageTask(player, 300L, () -> {
            if (!player.isOnline() || this.getStage(player) != Stage.GUARDS) {
                return;
            }
            this.setStage(player, Stage.ITEM_SKINS_BLOCKS);
            this.announceNewQuestUnlock(player);
            this.sendTutorialMessage(player, "&6&lTutorial - Item Skins + Custom Blocks", "&7There are a variety of custom skins and blocks. Each skin / block gives its own custom effects when worn or placed.", "", "&7Custom Blocks can only be placed inside your /cell.", "", "&c&lNOTE: &cThe &c&nAxialMod&r &cis required to view the custom models.", "&7Download it at &7&naxialmc.com", "", "&7Run /skins");
        });
    }

    private boolean shouldStartTutorial(Player player) {
        if (player == null) {
            return false;
        }
        Stage stage = this.getStage(player);
        if (stage.isActive()) {
            return false;
        }
        return this.playerLevelService.getLevel(player) <= 1
                && this.playerLevelService.getTotalExp(player) == 0L;
    }

    private Location resolveTutorialSpawn() {
        Location location = FixedTeleportLocations.getTutorialSpawn();
        return location == null ? this.spawn : location;
    }

    private void markJoinedBefore(Player player) {
        this.playerDataService.update(player.getUniqueId(), data -> data.setJoinedBefore(true));
    }

    private void updateTutorialScoreboard(Player player) {
        if (this.miningLevelScoreboardService != null) {
            this.miningLevelScoreboardService.setForcedMiningSidebar(player, this.isInTutorial(player));
        }
    }

    public static enum Stage {
        NONE(0),
        MINE_COAL(1),
        REACH_LEVEL_ONE(2),
        OPEN_LEVELS(3),
        CLOSE_SHARD_MENU(4),
        OPEN_ENCHANTS(5),
        PICKAXE_ENCHANTING(6),
        CHARGE_PIT(7),
        SELECT_ENCHANTMENTS(8),
        GUARDS(9),
        ITEM_SKINS_BLOCKS(10),
        REACH_LEVEL_FIVE(11),
        COMPLETED(100),
        SKIPPED(101);

        private static final Map<Integer, Stage> BY_ID = new HashMap<Integer, Stage>();
        private final int id;

        static {
            for (Stage value : values()) {
                BY_ID.put(Integer.valueOf(value.id), value);
            }
        }

        private Stage(int id) {
            this.id = id;
        }

        public int id() {
            return this.id;
        }

        public boolean isActive() {
            return this != NONE && this != COMPLETED && this != SKIPPED;
        }

        public static Stage fromId(int id) {
            Stage stage = BY_ID.get(Integer.valueOf(id));
            return stage == null ? NONE : stage;
        }
    }
}
