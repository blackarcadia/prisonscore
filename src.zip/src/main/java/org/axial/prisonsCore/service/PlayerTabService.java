package org.axial.prisonsCore.service;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class PlayerTabService implements Listener {
    private final PrisonsCore plugin;
    private final PickaxeManager pickaxeManager;
    private final PlayerLevelService playerLevelService;
    private BukkitTask task;

    public PlayerTabService(PrisonsCore plugin, PickaxeManager pickaxeManager, PlayerLevelService playerLevelService) {
        this.plugin = plugin;
        this.pickaxeManager = pickaxeManager;
        this.playerLevelService = playerLevelService;
    }

    public void start() {
        if (this.task != null) {
            this.task.cancel();
        }
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::refreshAll, 1L, 20L);
        this.refreshAll();
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            viewer.setPlayerListHeader(null);
            viewer.setPlayerListFooter(null);
            for (Player other : Bukkit.getOnlinePlayers()) {
                try {
                    if (viewer.canSee(other)) {
                        viewer.listPlayer(other);
                    }
                } catch (Exception ignored) {
                }
            }
        }
    }

    public void update(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        this.hidePlayers(player);
        player.setPlayerListHeaderFooter(Text.color(this.buildHeader(player)), Text.color("&7discord.gg/axialmc"));
    }

    private void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.update(player);
        }
    }

    private void hidePlayers(Player viewer) {
        for (Player other : Bukkit.getOnlinePlayers()) {
            try {
                viewer.unlistPlayer(other);
            } catch (Exception ignored) {
            }
        }
    }

    private String buildHeader(Player player) {
        ItemStack held = player.getInventory().getItemInMainHand();
        String pickaxeLevel = this.pickaxeManager.isPrisonPickaxe(held) ? String.valueOf(this.pickaxeManager.getLevel(held)) : "None";
        int playerLevel = this.playerLevelService.getLevel(player);
        int exp = this.playerLevelService.getExp(player);
        int needed = this.playerLevelService.expNeededForNext(player);
        String expLine = needed > 0 ? Text.formatNumber(exp) + " / " + Text.formatNumber(needed) : Text.formatNumber(exp);
        return "&d&lAxial&6&lPrisons\n \n"
                + "&d&lPickaxe Level\n"
                + "&f     " + pickaxeLevel + "     \n \n"
                + "&6&lPlayer Level\n"
                + "&f     " + playerLevel + "     \n \n"
                + "&b&lEXP\n"
                + "&f     " + expLine + "     \n ";
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.updateLater(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, this::refreshAll, 1L);
    }

    @EventHandler
    public void onHeldItemChange(PlayerItemHeldEvent event) {
        this.updateLater(event.getPlayer());
    }

    @EventHandler
    public void onSwapHandItems(PlayerSwapHandItemsEvent event) {
        this.updateLater(event.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        this.updateLater(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        this.updateLater(event.getPlayer());
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            this.updateLater(player);
        }
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            this.updateLater(player);
        }
    }

    private void updateLater(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.update(player));
    }
}
