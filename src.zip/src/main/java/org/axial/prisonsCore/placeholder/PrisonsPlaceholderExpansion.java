/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  me.clip.placeholderapi.expansion.PlaceholderExpansion
 *  me.clip.placeholderapi.expansion.Relational
 *  org.bukkit.Bukkit
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.entity.Player
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.plugin.Plugin
 *  org.jetbrains.annotations.NotNull
 */
package org.axial.prisonsCore.placeholder;

import java.util.UUID;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import me.clip.placeholderapi.expansion.Relational;
import org.axial.prisonsCore.model.Gang;
import org.axial.prisonsCore.service.GangService;
import org.axial.prisonsCore.service.MeteorService;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.service.ReputationService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.jetbrains.annotations.NotNull;

public class PrisonsPlaceholderExpansion
extends PlaceholderExpansion
implements Relational {
    private final PlayerLevelService playerLevelService;
    private final ReputationService reputationService;
    private final GangService gangService;
    private final MeteorService meteorService;
    private final Plugin plugin;

    public PrisonsPlaceholderExpansion(PlayerLevelService playerLevelService, ReputationService reputationService, GangService gangService, MeteorService meteorService, Plugin plugin) {
        this.playerLevelService = playerLevelService;
        this.reputationService = reputationService;
        this.gangService = gangService;
        this.meteorService = meteorService;
        this.plugin = plugin;
    }

    @NotNull
    public String getIdentifier() {
        return "prisons";
    }

    @NotNull
    public String getAuthor() {
        return "PrisonsCore";
    }

    @NotNull
    public String getVersion() {
        return "1.0";
    }

    public boolean persist() {
        return true;
    }

    public boolean canRegister() {
        return true;
    }

    public String onPlaceholderRequest(Player player, @NotNull String params) {
        String result;
        if (player == null) {
            return "";
        }
        if (params.startsWith("{") && params.endsWith("}")) {
            params = params.substring(1, params.length() - 1);
        }
        if ((result = this.handleGangRelationPlaceholders(player.getUniqueId(), params)) != null) {
            return result;
        }
        switch (params.toLowerCase()) {
            case "level": 
            case "mining_level": 
            case "mininglevel": 
            case "player_level": 
            case "playerlevel": {
                return String.valueOf(this.playerLevelService.getLevel(player));
            }
            case "level_colored":
            case "mining_level_colored":
            case "player_level_colored": {
                int level = this.playerLevelService.getLevel(player);
                return this.colorForLevel(level) + level;
            }
            case "exp": {
                return Text.formatNumber(this.playerLevelService.getExp(player));
            }
            case "exp_total": 
            case "total_exp": 
            case "exp_lifetime": {
                return Text.formatNumber(this.playerLevelService.getTotalExp(player));
            }
            case "exp_needed": 
            case "expneeded": {
                return Text.formatNumber(this.playerLevelService.expNeededForNext(player));
            }
            case "exp_percent":
            case "exppercent": {
                int needed = this.playerLevelService.expNeededForNext(player);
                int exp = this.playerLevelService.getExp(player);
                double percent = needed <= 0 ? 100.0 : Math.min(100.0, (double)exp * 100.0 / (double)needed);
                return Text.formatPercent(percent);
            }
            case "energy_gain": {
                if (player.hasMetadata("energy-gain")) {
                    for (MetadataValue val : player.getMetadata("energy-gain")) {
                        if (!val.getOwningPlugin().equals((Object)this.plugin)) continue;
                        return String.valueOf(val.asInt());
                    }
                }
                return "0";
            }
            case "reputation_stage": {
                return this.reputationService.getStage(player.getUniqueId()).name().toLowerCase();
            }
            case "reputation_stage_display": {
                return this.reputationService.getStageDisplay(player.getUniqueId());
            }
            case "reputation_time_left": {
                return String.valueOf(this.reputationService.getSecondsUntilDecay(player.getUniqueId()));
            }
            case "gang_name": {
                Gang g = this.gangService.getGangByPlayer(player.getUniqueId());
                return g == null ? "" : g.getName();
            }
            case "gang_role": {
                Gang gang = this.gangService.getGangByPlayer(player.getUniqueId());
                return gang == null ? "" : String.valueOf((Object)gang.getRole(player.getUniqueId())).toLowerCase();
            }
            case "gang_points": {
                Gang g2 = this.gangService.getGangByPlayer(player.getUniqueId());
                return g2 == null ? "0" : String.valueOf(g2.getPoints());
            }
            case "meteor_time":
            case "meteor_timer":
            case "meteortime": {
                if (this.meteorService == null) {
                    return "tracking";
                }
                String text = this.meteorService.getNextMeteorTimeText();
                return text == null || text.isBlank() ? "tracking" : text;
            }
        }
        return "";
    }

    public String onPlaceholderRequest(Player viewer, Player target, @NotNull String params) {
        String lower;
        if (viewer == null || target == null) {
            return "";
        }
        switch (lower = params.toLowerCase()) {
            case "gang_relation_color": {
                return this.gangService.nameColor(viewer.getUniqueId(), target.getUniqueId());
            }
            case "gang_relation_name": {
                return this.gangService.nameColor(viewer.getUniqueId(), target.getUniqueId()) + target.getName();
            }
            case "gang_name_colored": {
                Gang gang = this.gangService.getGangByPlayer(target.getUniqueId());
                if (gang == null) {
                    return "";
                }
                return this.gangService.nameColor(viewer.getUniqueId(), target.getUniqueId()) + gang.getName();
            }
        }
        return "";
    }

    public String onRequest(OfflinePlayer player, @NotNull String params) {
        String relation;
        UUID viewerId;
        UUID uUID = viewerId = player != null ? player.getUniqueId() : null;
        if (params.startsWith("{") && params.endsWith("}")) {
            params = params.substring(1, params.length() - 1);
        }
        if ((relation = this.handleGangRelationPlaceholders(viewerId, params)) != null) {
            return relation;
        }
        if (player != null && player.isOnline()) {
            return this.onPlaceholderRequest(player.getPlayer(), params);
        }
        return "";
    }

    private String handleGangRelationPlaceholders(UUID viewerId, String params) {
        String lower = params.toLowerCase();
        String targetName = null;
        if (lower.startsWith("gang_relation_color:")) {
            targetName = params.substring("gang_relation_color:".length());
        } else if (lower.startsWith("gang_relation_color_")) {
            targetName = params.substring("gang_relation_color_".length());
        } else if (lower.startsWith("gang_relation_name:")) {
            targetName = params.substring("gang_relation_name:".length());
        } else if (lower.startsWith("gang_relation_name_")) {
            targetName = params.substring("gang_relation_name_".length());
        } else if (lower.startsWith("gang_name_colored:")) {
            targetName = params.substring("gang_name_colored:".length());
        } else if (lower.startsWith("gang_name_colored_")) {
            targetName = params.substring("gang_name_colored_".length());
        } else {
            return null;
        }
        if (targetName == null || targetName.isEmpty()) {
            return "";
        }
        UUID targetId = this.findUuidByName(targetName);
        if (targetId == null || viewerId == null) {
            return "";
        }
        String color = this.gangService.nameColor(viewerId, targetId);
        if (lower.startsWith("gang_relation_name")) {
            OfflinePlayer target = Bukkit.getOfflinePlayer((UUID)targetId);
            String name = target != null && target.getName() != null ? target.getName() : targetName;
            return color + name;
        }
        if (lower.startsWith("gang_name_colored")) {
            Gang gang = this.gangService.getGangByPlayer(targetId);
            if (gang == null) {
                return "";
            }
            return color + gang.getName();
        }
        return color;
    }

    private UUID findUuidByName(String name) {
        if (name == null || name.isEmpty()) {
            return null;
        }
        try {
            return UUID.fromString(name);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            Player online = Bukkit.getPlayerExact((String)name);
            if (online != null) {
                return online.getUniqueId();
            }
            OfflinePlayer off = Bukkit.getOfflinePlayer((String)name);
            return off != null ? off.getUniqueId() : null;
        }
    }

    private String colorForLevel(int level) {
        if (level >= 80) {
            return "\u00a7b";
        }
        if (level >= 60) {
            return "\u00a7e";
        }
        if (level >= 45) {
            return "\u00a76";
        }
        if (level >= 30) {
            return "\u00a7a";
        }
        if (level >= 20) {
            return "\u00a77";
        }
        return "\u00a7f";
    }
}
