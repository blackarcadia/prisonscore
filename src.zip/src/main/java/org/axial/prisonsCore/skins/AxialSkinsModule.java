package org.axial.prisonsCore.skins;

import java.io.File;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.ability.SkinAbilityRegistry;
import org.axial.prisonsCore.skins.box.SkinBoxListener;
import org.axial.prisonsCore.skins.box.SkinBoxMenu;
import org.axial.prisonsCore.skins.box.SkinBoxService;
import org.axial.prisonsCore.skins.command.SkinGiveCommand;
import org.axial.prisonsCore.skins.command.SkinBoxCommand;
import org.axial.prisonsCore.skins.command.SkinsCommand;
import org.axial.prisonsCore.skins.integration.PrisonsCoreHook;
import org.axial.prisonsCore.skins.listener.AbilityTicker;
import org.axial.prisonsCore.skins.listener.KryoAmuletMiningListener;
import org.axial.prisonsCore.skins.listener.KryoHelmetListener;
import org.axial.prisonsCore.skins.listener.MoonBootsMeteorListener;
import org.axial.prisonsCore.skins.listener.FloatyFlamingoListener;
import org.axial.prisonsCore.skins.listener.RocketLollyListener;
import org.axial.prisonsCore.skins.listener.SkinPersistenceListener;
import org.axial.prisonsCore.skins.listener.UtilityBeltOreListener;
import org.axial.prisonsCore.skins.listener.SkinInventoryListener;
import org.axial.prisonsCore.skins.message.MessageService;
import org.axial.prisonsCore.skins.menu.SkinsMenu;
import org.axial.prisonsCore.skins.skin.SkinManager;
import org.axial.prisonsCore.util.ConfigUpdater;
import org.bukkit.Material;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.configuration.file.YamlConfiguration;

public final class AxialSkinsModule {
    private final PrisonsCore plugin;
    private SkinManager skinManager;
    private MessageService messages;
    private AbilityTicker abilityTicker;
    private PrisonsCoreHook prisonsCoreHook;
    private SkinGiveCommand skinGiveCommand;
    private SkinBoxCommand skinBoxCommand;
    private SkinBoxService skinBoxService;
    private SkinBoxMenu skinBoxMenu;
    private SkinsMenu skinsMenu;
    private MoonBootsMeteorListener moonBootsMeteorListener;
    private UtilityBeltOreListener utilityBeltOreListener;

    public AxialSkinsModule(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public void enable() {
        this.plugin.saveResource("axialskins.yml", false);
        this.plugin.saveResource("axialskins-languages.yml", false);
        ConfigUpdater.saveDefaultAndMerge(this.plugin, "skins.yml");
        this.reload();
        PluginManager pm = this.plugin.getServer().getPluginManager();
        this.registerListener(pm, new SkinInventoryListener(this.skinManager, this.messages));
        this.registerListener(pm, new SkinPersistenceListener(this.plugin, this.skinManager));
        this.skinsMenu = new SkinsMenu(this.skinManager);
        this.registerListener(pm, this.skinsMenu);
        this.skinBoxService = new SkinBoxService(this.plugin, this.skinManager);
        this.skinBoxMenu = new SkinBoxMenu(this.plugin, this.skinBoxService);
        this.registerListener(pm, this.skinBoxMenu);
        this.registerListener(pm, new SkinBoxListener(this.skinBoxService, this.skinBoxMenu));
        this.moonBootsMeteorListener = new MoonBootsMeteorListener(this.plugin);
        this.registerListener(pm, this.moonBootsMeteorListener);
        this.utilityBeltOreListener = new UtilityBeltOreListener(this.plugin);
        this.registerListener(pm, this.utilityBeltOreListener);
        this.registerListener(pm, new KryoAmuletMiningListener(this.plugin));
        this.registerListener(pm, new KryoHelmetListener(this.plugin));
        this.registerListener(pm, new FloatyFlamingoListener(this.plugin));
        this.registerListener(pm, new RocketLollyListener(this.plugin));
        if (this.plugin.getCommand("axialskins") != null) {
            this.skinGiveCommand = new SkinGiveCommand(this);
            this.plugin.getCommand("axialskins").setExecutor((CommandExecutor)this.skinGiveCommand);
            this.plugin.getCommand("axialskins").setTabCompleter((TabCompleter)this.skinGiveCommand);
        } else {
            this.plugin.getLogger().warning("Command 'axialskins' missing from plugin.yml; skin feature not registered.");
        }
        if (this.plugin.getCommand("skinbox") != null) {
            this.skinBoxCommand = new SkinBoxCommand(this.plugin, this.skinBoxService);
            this.plugin.getCommand("skinbox").setExecutor((CommandExecutor)this.skinBoxCommand);
            this.plugin.getCommand("skinbox").setTabCompleter((TabCompleter)this.skinBoxCommand);
        } else {
            this.plugin.getLogger().warning("Command 'skinbox' missing from plugin.yml; skin box feature not registered.");
        }
        if (this.plugin.getCommand("skins") != null) {
            this.plugin.getCommand("skins").setExecutor((CommandExecutor)new SkinsCommand(this.skinsMenu, this.plugin.getTutorialService()));
        } else {
            this.plugin.getLogger().warning("Command 'skins' missing from plugin.yml; tutorial skin command not registered.");
        }
    }

    public void disable() {
        if (this.abilityTicker != null) {
            this.abilityTicker.stop();
        }
    }

    public void reload() {
        File dataFolder = this.plugin.getDataFolder();
        File configFile = new File(dataFolder, "axialskins.yml");
        File languageFile = new File(dataFolder, "axialskins-languages.yml");
        File skinsFile = new File(dataFolder, "skins.yml");
        YamlConfiguration config = YamlConfiguration.loadConfiguration(configFile);
        if (this.messages == null) {
            this.messages = MessageService.load(languageFile);
        } else {
            this.messages.reload(languageFile);
        }
        Material material = Material.matchMaterial(config.getString("axialskins.skin-item-material", Material.ENDER_EYE.name()));
        if (material == null) {
            material = Material.ENDER_EYE;
        }
        SkinAbilityRegistry registry = SkinAbilityRegistry.bootstrap();
        if (this.skinManager == null) {
            this.skinManager = new SkinManager(this.plugin, registry, this.messages, material);
        } else {
            this.skinManager.setRuntimeState(registry, this.messages, material);
        }
        this.prisonsCoreHook = new PrisonsCoreHook(this.plugin);
        int loaded = this.skinManager.loadFromFile(skinsFile);
        if (loaded == 0) {
            this.plugin.getLogger().warning("No skins loaded; check skins.yml");
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.skinManager.syncPlayer(player);
        }
        long period = Math.max(1L, config.getLong("axialskins.ability-tick-period", 1L));
        if (this.abilityTicker != null) {
            this.abilityTicker.stop();
        }
        this.abilityTicker = new AbilityTicker(this.skinManager, period);
        this.abilityTicker.start(this.plugin);
    }

    public SkinManager skinManager() {
        return this.skinManager;
    }

    public SkinBoxService skinBoxService() {
        return this.skinBoxService;
    }

    public MessageService messages() {
        return this.messages;
    }

    public PrisonsCoreHook prisonsCoreHook() {
        return this.prisonsCoreHook;
    }

    public boolean isKryoPickaxeSkin(org.bukkit.inventory.ItemStack itemStack) {
        if (this.skinManager == null || itemStack == null) {
            return false;
        }
        return this.skinManager.skinAppliedTo(itemStack)
                .map(skin -> skin.ability() != null && ("kryopickaxe".equals(skin.ability().id()) || "ore_harvest".equals(skin.ability().id())))
                .orElse(false);
    }

    public boolean hasMoonBootsEquipped(Player player) {
        if (this.skinManager == null || player == null) {
            return false;
        }
        org.bukkit.inventory.ItemStack boots = player.getInventory().getBoots();
        return boots != null && this.skinManager.skinAppliedTo(boots)
                .map(skin -> "moon_boots".equalsIgnoreCase(skin.id()))
                .orElse(false);
    }

    public boolean hasUtilityBeltEquipped(Player player) {
        if (this.skinManager == null || player == null) {
            return false;
        }
        org.bukkit.inventory.ItemStack leggings = player.getInventory().getLeggings();
        return leggings != null && this.skinManager.skinAppliedTo(leggings)
                .map(skin -> "utilitybelt".equalsIgnoreCase(skin.id()))
                .orElse(false);
    }

    public boolean hasFloatyFlamingoEquipped(Player player) {
        if (this.skinManager == null || player == null) {
            return false;
        }
        org.bukkit.inventory.ItemStack leggings = player.getInventory().getLeggings();
        return leggings != null && this.skinManager.skinAppliedTo(leggings)
                .map(skin -> "floaty_flamingo".equalsIgnoreCase(skin.id()))
                .orElse(false);
    }

    public boolean hasKryoAmuletEquipped(Player player) {
        if (this.skinManager == null || player == null) {
            return false;
        }
        org.bukkit.inventory.ItemStack chestplate = player.getInventory().getChestplate();
        return chestplate != null && this.skinManager.skinAppliedTo(chestplate)
                .map(skin -> "kryo_amulet".equalsIgnoreCase(skin.id()))
                .orElse(false);
    }

    public boolean hasKryoHelmetEquipped(Player player) {
        if (this.skinManager == null || player == null) {
            return false;
        }
        org.bukkit.inventory.ItemStack helmet = player.getInventory().getHelmet();
        return helmet != null && this.skinManager.skinAppliedTo(helmet)
                .map(skin -> "kryo_helmet".equalsIgnoreCase(skin.id()))
                .orElse(false);
    }

    private void registerListener(PluginManager pm, Listener listener) {
        pm.registerEvents(listener, (Plugin)this.plugin);
    }
}
