package org.axial.prisonsCore.skins.listener;

import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.axial.prisonsCore.skins.skin.Skin;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;
import org.axial.prisonsCore.util.Text;

public final class RocketLollyListener implements Listener {
    private static final String ROCKET_LOLLY_ABILITY = "rocket_lolly";
    private static final double DOUBLE_DAMAGE_CHANCE = 0.05D;
    private final PrisonsCore plugin;

    public RocketLollyListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        Entity damager = event.getDamager();
        if (!(damager instanceof Player player)) {
            return;
        }
        ItemStack weapon = player.getInventory().getItemInMainHand();
        if (weapon == null || weapon.getType().isAir()) {
            return;
        }
        String weaponType = weapon.getType().name();
        if (!weaponType.endsWith("_AXE") && !weaponType.endsWith("_SWORD")) {
            return;
        }
        AxialSkinsModule skins = this.plugin.getAxialSkinsModule();
        if (skins == null) {
            return;
        }
        Skin skin = skins.skinManager().skinAppliedTo(weapon).orElse(null);
        if (skin == null || skin.ability() == null || !ROCKET_LOLLY_ABILITY.equals(skin.ability().id())) {
            return;
        }
        if (ThreadLocalRandom.current().nextDouble() >= DOUBLE_DAMAGE_CHANCE) {
            return;
        }
        event.setDamage(event.getDamage() * 2.0D);
        player.sendMessage(Text.color("&6&lROCKET LOLLY &6- &c&l2&cx DMG"));
    }
}
