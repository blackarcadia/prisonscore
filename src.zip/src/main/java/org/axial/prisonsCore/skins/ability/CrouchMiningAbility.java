package org.axial.prisonsCore.skins.ability;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class CrouchMiningAbility implements SkinAbility {
    private final int amplifier;
    private final int durationTicks;

    public CrouchMiningAbility(int amplifier, int durationTicks) {
        this.amplifier = amplifier;
        this.durationTicks = durationTicks;
    }

    @Override
    public void tick(Player player, ItemStack itemStack) {
        if (!player.isSneaking()) {
            return;
        }
        player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, this.durationTicks, this.amplifier, true, false, true));
    }

    @Override
    public String id() {
        return "crouch_mining";
    }
}
