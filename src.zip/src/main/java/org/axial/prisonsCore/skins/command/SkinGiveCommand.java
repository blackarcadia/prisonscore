package org.axial.prisonsCore.skins.command;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Stream;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.axial.prisonsCore.skins.message.MessageService;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.skins.skin.SkinManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class SkinGiveCommand implements CommandExecutor, TabCompleter {
    private final AxialSkinsModule module;

    public SkinGiveCommand(AxialSkinsModule module) {
        this.module = module;
    }

    private SkinManager skins() {
        return this.module.skinManager();
    }

    private MessageService messages() {
        return this.module.messages();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("axialskins.admin")) {
            sender.sendMessage(this.messages().get("command.no-permission"));
            return true;
        }
        if (args.length == 0 || "help".equalsIgnoreCase(args[0])) {
            this.sendUsage(sender, label);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if ("list".equals(sub)) {
            this.sendList(sender);
            return true;
        }
        if ("reload".equals(sub)) {
            this.module.reload();
            sender.sendMessage(this.messages().get("command.reloaded"));
            return true;
        }
        if (!"give".equals(sub) || args.length < 2) {
            this.sendUsage(sender, label);
            return true;
        }
        String skinId = args[1];
        Optional<Skin> skin = this.skins().get(skinId);
        if (skin.isEmpty()) {
            sender.sendMessage(this.messages().format("command.unknown-skin", "skin", skinId));
            return true;
        }
        Player target;
        if (args.length >= 3) {
            target = Bukkit.getPlayerExact(args[2]);
            if (target == null) {
                sender.sendMessage(this.messages().format("command.player-not-found", "player", args[2]));
                return true;
            }
        } else if (sender instanceof Player player) {
            target = player;
        } else {
            sender.sendMessage(ChatColor.RED + "You must specify a player from console.");
            return true;
        }
        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Math.max(1, Integer.parseInt(args[3]));
            } catch (NumberFormatException ex) {
                sender.sendMessage(ChatColor.RED + "Invalid amount; must be a number.");
                return true;
            }
        }
        this.giveSkin(target, skin.get(), amount);
        sender.sendMessage(this.messages().format(
                "command.gave",
                "amount", String.valueOf(amount),
                "skin", ChatColor.stripColor(skin.get().displayName()),
                "player", target.getName()
        ));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("axialskins.admin")) {
            return List.of();
        }
        if (args.length == 1) {
            return Stream.of("give", "list", "reload")
                    .filter(option -> option.toLowerCase(Locale.ROOT).startsWith(args[0].toLowerCase(Locale.ROOT)))
                    .toList();
        }
        if (args.length == 2 && "give".equalsIgnoreCase(args[0])) {
            return this.skins().all().keySet().stream()
                    .filter(id -> id.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT)))
                    .sorted()
                    .toList();
        }
        if (args.length == 3 && "give".equalsIgnoreCase(args[0])) {
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT)))
                    .sorted()
                    .toList();
        }
        return List.of();
    }

    private void giveSkin(Player player, Skin skin, int amount) {
        ItemStack item = this.skins().createSkinItem(skin);
        item.setAmount(amount);
        var leftovers = player.getInventory().addItem(item);
        leftovers.values().forEach(extra -> player.getWorld().dropItemNaturally(player.getLocation(), extra));
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(this.messages().format("command.usage-header", "label", label));
        sender.sendMessage(this.messages().format("command.usage-list", "label", label));
        sender.sendMessage(this.messages().format("command.usage-give", "label", label));
        sender.sendMessage(this.messages().format("command.usage-reload", "label", label));
    }

    private void sendList(CommandSender sender) {
        sender.sendMessage(this.messages().get("command.list-header"));
        for (Skin skin : this.skins().all().values()) {
            String ability = skin.ability() == null ? "none" : skin.ability().id();
            sender.sendMessage(this.messages().format(
                    "command.list-entry",
                    "id", skin.id(),
                    "name", ChatColor.stripColor(skin.displayName()),
                    "ability", ability
            ));
        }
    }
}
