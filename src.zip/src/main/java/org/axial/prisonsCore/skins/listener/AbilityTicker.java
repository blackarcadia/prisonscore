package org.axial.prisonsCore.skins.listener;

import java.util.ArrayList;
import java.util.List;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.skins.skin.SkinManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class AbilityTicker {
    private final SkinManager skinManager;
    private final long period;
    private BukkitTask task;

    public AbilityTicker(SkinManager skinManager, long period) {
        this.skinManager = skinManager;
        this.period = Math.max(1L, period);
    }

    public void start(Plugin plugin) {
        this.stop();
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1L, this.period);
    }

    public void stop() {
        if (this.task != null) {
            this.task.cancel();
            this.task = null;
        }
    }

    private void tick() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            for (ItemStack itemStack : this.collectEquipped(player)) {
                this.skinManager.skinAppliedTo(itemStack).ifPresent(skin -> {
                    if (skin.ability() != null) {
                        skin.ability().tick(player, itemStack);
                    }
                });
            }
        }
    }

    private List<ItemStack> collectEquipped(Player player) {
        List<ItemStack> equipped = new ArrayList<>();
        equipped.add(player.getInventory().getItemInMainHand());
        equipped.add(player.getInventory().getItemInOffHand());
        for (ItemStack itemStack : player.getInventory().getArmorContents()) {
            equipped.add(itemStack);
        }
        return equipped;
    }
}
