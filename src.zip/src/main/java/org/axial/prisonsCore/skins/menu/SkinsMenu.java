package org.axial.prisonsCore.skins.menu;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.skins.skin.SkinManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

public final class SkinsMenu implements Listener {
    private static final int ROOT_SIZE = 54;
    private static final int CATEGORY_INFO_SLOT = 4;
    private static final int CENTER_SKIN_SLOT = 22;
    private static final int BACK_SLOT = 49;
    private static final int[] SKIN_SLOTS = new int[]{10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34, 37, 38, 39, 40, 41, 42, 43};
    private static final Category[] ROOT_CATEGORIES = new Category[]{
            Category.PICKAXE,
            Category.HELMET,
            Category.CHESTPLATE,
            Category.WEAPON,
            Category.LEGGINGS,
            Category.BOOTS
    };

    private final SkinManager skinManager;

    public SkinsMenu(SkinManager skinManager) {
        this.skinManager = skinManager;
    }

    public void open(Player player) {
        this.openRoot(player);
    }

    private void openRoot(Player player) {
        RootHolder holder = new RootHolder();
        Inventory inventory = Bukkit.createInventory(holder, ROOT_SIZE, Text.color("&8Skins"));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        for (Category category : ROOT_CATEGORIES) {
            inventory.setItem(category.rootSlot, this.categoryItem(category, this.count(category)));
        }
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.0f);
        player.openInventory(inventory);
    }

    private void openCategory(Player player, Category category) {
        CategoryHolder holder = new CategoryHolder();
        Inventory inventory = Bukkit.createInventory(holder, ROOT_SIZE, Text.color("&8" + category.title + " Skins"));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        inventory.setItem(CATEGORY_INFO_SLOT, this.infoItem(category));
        inventory.setItem(BACK_SLOT, this.backItem());
        List<Skin> skins = this.skinsFor(category);
        if (skins.isEmpty()) {
            inventory.setItem(CENTER_SKIN_SLOT, this.emptyItem(category));
        } else if (skins.size() == 1) {
            inventory.setItem(CENTER_SKIN_SLOT, this.skinDisplayItem(skins.get(0)));
        } else {
            for (int i = 0; i < skins.size() && i < SKIN_SLOTS.length; ++i) {
                inventory.setItem(SKIN_SLOTS[i], this.skinDisplayItem(skins.get(i)));
            }
        }
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.8f, 1.0f);
        player.openInventory(inventory);
    }

    private void fillBackground(Inventory inventory) {
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta meta = filler.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            filler.setItemMeta(meta);
        }
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
    }

    private ItemStack categoryItem(Category category, long count) {
        ItemStack item = new ItemStack(count > 0 ? category.icon : Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color(count > 0 ? category.displayName : "&c" + category.title + " Skins"));
            ArrayList<String> lore = new ArrayList<>();
            lore.add(Text.color("&7Click to view available skins."));
            lore.add(Text.color("&7"));
            lore.add(Text.color("&7Applies to &f" + category.title));
            lore.add(Text.color("&7Available: &f" + count));
            if (count == 0L) {
                lore.add(Text.color("&cNo skins are configured for this category."));
            }
            meta.setLore(lore);
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack infoItem(Category category) {
        ItemStack item = new ItemStack(category.icon);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&f&l" + category.title + " Skins"));
            meta.setLore(List.of(
                    Text.color("&7Select a skin below."),
                    Text.color("&7"),
                    Text.color("&7Use the back button to return.")
            ));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack backItem() {
        ItemStack item = new ItemStack(Material.ARROW);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&f&lBack"));
            meta.setLore(List.of(Text.color("&7Return to the skins menu.")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack emptyItem(Category category) {
        ItemStack item = new ItemStack(Material.BARRIER);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&cNo " + category.title + " skins found"));
            meta.setLore(List.of(Text.color("&7Check your skins.yml configuration.")));
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack skinDisplayItem(Skin skin) {
        return this.skinManager.createSkinItem(skin);
    }

    private List<Skin> skinsFor(Category category) {
        if (this.skinManager == null) {
            return List.of();
        }
        return this.skinManager.all().values().stream()
                .filter(category::matches)
                .sorted(Comparator.comparing(Skin::displayName, String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
    }

    private long count(Category category) {
        return this.skinsFor(category).size();
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof MenuHolder holder)) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        if (event.getClickedInventory() == null || !event.getClickedInventory().equals(event.getView().getTopInventory())) {
            return;
        }
        int slot = event.getRawSlot();
        if (holder instanceof RootHolder) {
            this.handleRootClick(player, slot);
            return;
        }
        if (!(holder instanceof CategoryHolder categoryHolder)) {
            return;
        }
        this.handleCategoryClick(player, categoryHolder, slot);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof MenuHolder) {
            event.setCancelled(true);
        }
    }

    private void handleRootClick(Player player, int slot) {
        for (Category category : ROOT_CATEGORIES) {
            if (category.rootSlot != slot) {
                continue;
            }
            this.openCategory(player, category);
            return;
        }
    }

    private void handleCategoryClick(Player player, CategoryHolder holder, int slot) {
        if (slot == BACK_SLOT) {
            this.openRoot(player);
        }
    }

    private interface MenuHolder extends InventoryHolder {
    }

    private static final class RootHolder implements MenuHolder {
        private Inventory inventory;

        @Override
        public @NotNull Inventory getInventory() {
            return this.inventory;
        }
    }

    private static final class CategoryHolder implements MenuHolder {
        private Inventory inventory;

        private CategoryHolder() {
        }

        @Override
        public @NotNull Inventory getInventory() {
            return this.inventory;
        }
    }

    private enum Category {
        PICKAXE(20, Material.DIAMOND_PICKAXE, "&b&lPickaxe", "Pickaxe", Set.of(Material.DIAMOND_PICKAXE)),
        HELMET(13, Material.DIAMOND_HELMET, "&b&lHelmet", "Helmet", Set.of(Material.DIAMOND_HELMET)),
        CHESTPLATE(22, Material.DIAMOND_CHESTPLATE, "&b&lChestplate", "Chestplate", Set.of(Material.DIAMOND_CHESTPLATE)),
        WEAPON(24, Material.DIAMOND_AXE, "&6&lWeapon Skins", "Weapon", Set.of(Material.DIAMOND_AXE, Material.DIAMOND_SWORD)),
        LEGGINGS(31, Material.DIAMOND_LEGGINGS, "&b&lLeggings", "Leggings", Set.of(Material.DIAMOND_LEGGINGS)),
        BOOTS(40, Material.DIAMOND_BOOTS, "&b&lBoots", "Boots", Set.of(Material.DIAMOND_BOOTS));

        private final int rootSlot;
        private final Material icon;
        private final String displayName;
        private final String title;
        private final Set<Material> sampleMaterials;

        Category(int rootSlot, Material icon, String displayName, String title, Set<Material> sampleMaterials) {
            this.rootSlot = rootSlot;
            this.icon = icon;
            this.displayName = displayName;
            this.title = title;
            this.sampleMaterials = Set.copyOf(sampleMaterials);
        }

        private boolean matches(Skin skin) {
            for (Material sampleMaterial : this.sampleMaterials) {
                if (skin.canApplyTo(sampleMaterial)) {
                    return true;
                }
            }
            return false;
        }
    }
}
