package org.axial.prisonsCore.skins.box;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.skins.skin.SkinManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class SkinBoxService {
    private static final List<String> SKIN_ORDER = List.of("kryo_helmet", "utilitybelt", "kryopickaxe", "moon_boots", "kryo_amulet", "rocket_lolly", "floaty_flamingo");
    private final PrisonsCore plugin;
    private final NamespacedKey skinBoxKey;
    private final SkinManager skinManager;

    public SkinBoxService(PrisonsCore plugin, SkinManager skinManager) {
        this.plugin = plugin;
        this.skinManager = skinManager;
        this.skinBoxKey = new NamespacedKey(plugin, "skin-box");
    }

    public ItemStack createSkinBox(int amount) {
        ItemStack stack = new ItemStack(Material.BEACON);
        stack.setAmount(Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&r&6&lSkin Box &f&l(&71 Item&f&l)"));
            meta.setCustomModelData(Integer.valueOf(103));
            meta.setLore(this.buildLore());
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            meta.getPersistentDataContainer().set(this.skinBoxKey, PersistentDataType.BYTE, (byte)1);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public boolean isSkinBox(ItemStack stack) {
        return stack != null
                && stack.hasItemMeta()
                && stack.getItemMeta().getPersistentDataContainer().has(this.skinBoxKey, PersistentDataType.BYTE);
    }

    public Optional<Skin> rollSkin() {
        List<Skin> skins = this.availableSkins();
        if (skins.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of(skins.get(this.plugin.getRandom().nextInt(skins.size())));
    }

    public List<Skin> availableSkins() {
        if (this.plugin.getAxialSkinsModule() == null || this.plugin.getAxialSkinsModule().skinManager() == null) {
            return List.of();
        }
        SkinManager manager = this.plugin.getAxialSkinsModule().skinManager();
        return SKIN_ORDER.stream()
                .map(manager::get)
                .flatMap(Optional::stream)
                .collect(Collectors.toList());
    }

    public ItemStack createPreviewItem(Skin skin) {
        if (skin == null) {
            return new ItemStack(Material.BARRIER);
        }
        return this.skinManager.createSkinItem(skin);
    }

    private List<String> buildLore() {
        ArrayList<String> lore = new ArrayList<>();
        lore.add(Text.color("&7Right-Click to recieve 1 random Item Skin."));
        lore.add(Text.color("&7"));
        lore.add(Text.color("&7Contains:"));
        for (Skin skin : this.availableSkins()) {
            lore.add(Text.color("&6&l* &f&lItem Skin (&6&l" + this.skinLabel(skin) + "&f&l)"));
        }
        return lore;
    }

    private String skinLabel(Skin skin) {
        if (skin == null || skin.displayName() == null) {
            return "";
        }
        String stripped = Text.strip(skin.displayName());
        int open = stripped.indexOf('(');
        int close = stripped.lastIndexOf(')');
        if (open >= 0 && close > open) {
            return stripped.substring(open + 1, close).trim();
        }
        return stripped;
    }
}
