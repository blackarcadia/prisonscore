package org.axial.prisonsCore.skins.listener;

import org.axial.prisonsCore.skins.skin.SkinManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;

public final class SkinPersistenceListener implements Listener {
    private final Plugin plugin;
    private final SkinManager skinManager;

    public SkinPersistenceListener(Plugin plugin, SkinManager skinManager) {
        this.plugin = plugin;
        this.skinManager = skinManager;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(this.plugin, () -> this.skinManager.syncPlayer(player));
    }
}
