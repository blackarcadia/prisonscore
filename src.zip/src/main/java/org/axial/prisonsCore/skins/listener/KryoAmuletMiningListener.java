package org.axial.prisonsCore.skins.listener;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public final class KryoAmuletMiningListener implements Listener {
    private final PrisonsCore plugin;
    private final ConcurrentMap<UUID, Double> bonusProgress = new ConcurrentHashMap<>();

    public KryoAmuletMiningListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (player == null || block == null) {
            return;
        }
        AxialSkinsModule skins = this.plugin.getAxialSkinsModule();
        if (skins == null || !skins.hasKryoAmuletEquipped(player)) {
            return;
        }
        Material ore = this.normalizeOre(block.getType());
        if (ore == null) {
            return;
        }
        int extra = this.nextBonusAmount(player.getUniqueId());
        if (extra > 0) {
            this.giveItem(player, new ItemStack(ore, extra));
        }
    }

    private int nextBonusAmount(UUID playerId) {
        double progress = this.bonusProgress.merge(playerId, 0.10D, Double::sum);
        int extra = (int) progress;
        if (extra > 0) {
            this.bonusProgress.put(playerId, progress - extra);
        } else {
            this.bonusProgress.put(playerId, progress);
        }
        return extra;
    }

    private void giveItem(Player player, ItemStack item) {
        if (player == null) {
            return;
        }
        if (item == null || item.getType().isAir() || item.getAmount() <= 0) {
            return;
        }
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, item);
            return;
        }
        player.getInventory().addItem(item).values().forEach(extra -> player.getWorld().dropItemNaturally(player.getLocation(), extra));
    }

    private Material normalizeOre(Material type) {
        if (type == null) {
            return null;
        }
        return switch (type) {
            case COAL_ORE, DEEPSLATE_COAL_ORE -> Material.COAL_ORE;
            case IRON_ORE, DEEPSLATE_IRON_ORE -> Material.IRON_ORE;
            case COPPER_ORE, DEEPSLATE_COPPER_ORE -> Material.COPPER_ORE;
            case GOLD_ORE, DEEPSLATE_GOLD_ORE, NETHER_GOLD_ORE -> Material.GOLD_ORE;
            case REDSTONE_ORE, DEEPSLATE_REDSTONE_ORE -> Material.REDSTONE_ORE;
            case LAPIS_ORE, DEEPSLATE_LAPIS_ORE -> Material.LAPIS_ORE;
            case DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE -> Material.DIAMOND_ORE;
            case EMERALD_ORE, DEEPSLATE_EMERALD_ORE -> Material.EMERALD_ORE;
            default -> null;
        };
    }
}
