package org.axial.prisonsCore.skins.box;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public final class SkinBoxMenu implements Listener {
    private static final int INVENTORY_SIZE = 27;
    private static final int CENTER_SLOT = 13;
    private final PrisonsCore plugin;
    private final SkinBoxService skinBoxService;
    private final Map<UUID, Session> sessions = new HashMap<>();

    public SkinBoxMenu(PrisonsCore plugin, SkinBoxService skinBoxService) {
        this.plugin = plugin;
        this.skinBoxService = skinBoxService;
    }

    public void open(Player player) {
        Session existing = this.sessions.remove(player.getUniqueId());
        if (existing != null) {
            existing.cancel();
        }
        Session holder = new Session(player.getUniqueId());
        Inventory inventory = Bukkit.createInventory(holder, INVENTORY_SIZE, Text.color("&8Skin Box"));
        holder.inventory = inventory;
        this.fillBackground(inventory);
        inventory.setItem(CENTER_SLOT, this.rollingItem());
        player.openInventory(inventory);
        this.startSpin(player, holder);
        this.sessions.put(player.getUniqueId(), holder);
    }

    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof Session)) {
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof Session session)) {
            return;
        }
        if (session.completed) {
            this.sessions.remove(session.owner);
            return;
        }
        Player player = (Player)event.getPlayer();
        this.finalizeReward(player, session);
    }

    private void startSpin(Player player, Session session) {
        final BukkitTask[] taskHolder = new BukkitTask[1];
        taskHolder[0] = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            if (session.completed) {
                if (taskHolder[0] != null) {
                    taskHolder[0].cancel();
                }
                return;
            }
            if (session.ticks >= 50) {
                this.finalizeReward(player, session);
                if (taskHolder[0] != null) {
                    taskHolder[0].cancel();
                }
                return;
            }
            Skin preview = this.skinBoxService.rollSkin().orElse(null);
            session.inventory.setItem(CENTER_SLOT, preview == null ? this.rollingItem() : this.skinBoxService.createPreviewItem(preview));
            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 0.6f, 1.4f);
            session.ticks += 2;
        }, 0L, 2L);
        session.task = taskHolder[0];
    }

    private void finalizeReward(Player player, Session session) {
        if (session.completed) {
            return;
        }
        session.completed = true;
        if (session.task != null) {
            session.task.cancel();
        }
        Skin reward = this.skinBoxService.rollSkin().orElse(null);
        if (reward == null) {
            player.sendMessage(Text.color("&cThis skin box has no configured rewards."));
            this.sessions.remove(player.getUniqueId());
            return;
        }
        ItemStack item = this.skinBoxService.createPreviewItem(reward);
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, item);
        } else {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
            for (ItemStack stack : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), stack);
            }
        }
        session.inventory.setItem(CENTER_SLOT, item);
        player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
        player.sendTitle(Text.color("&6&lSkin Box Opened"), "", 5, 30, 10);
        player.sendMessage(Text.color("&8&m------------------------------"));
        player.sendMessage(Text.color("&6&lSkin Box Reward &7(" + Text.strip(reward.displayName()) + "&7)"));
        player.sendMessage(Text.color("&8&m------------------------------"));
        this.sessions.remove(player.getUniqueId());
    }

    private void fillBackground(Inventory inventory) {
        ItemStack filler = this.pane(Material.BLACK_STAINED_GLASS_PANE);
        for (int slot = 0; slot < inventory.getSize(); ++slot) {
            inventory.setItem(slot, filler);
        }
    }

    private ItemStack pane(Material material) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(" ");
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack rollingItem() {
        ItemStack item = new ItemStack(Material.BEACON);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(Text.color("&6&lRolling Skin..."));
            item.setItemMeta(meta);
        }
        return item;
    }

    private static final class Session implements InventoryHolder {
        private final UUID owner;
        private Inventory inventory;
        private BukkitTask task;
        private int ticks;
        private boolean completed;

        private Session(UUID owner) {
            this.owner = owner;
        }

        private void cancel() {
            if (this.task != null) {
                this.task.cancel();
            }
        }

        @Override
        public Inventory getInventory() {
            return this.inventory;
        }
    }
}
