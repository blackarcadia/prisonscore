package org.axial.prisonsCore.skins.listener;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.masks.manager.MaskManager;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.service.MeteorService;
import org.axial.prisonsCore.service.BoosterService;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class MoonBootsMeteorListener implements Listener {
    private final PrisonsCore plugin;

    public MoonBootsMeteorListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (event == null) {
            return;
        }
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (player == null || block == null) {
            return;
        }
        AxialSkinsModule skins = this.plugin.getAxialSkinsModule();
        MeteorService meteorService = this.plugin.getMeteorService();
        PickaxeManager pickaxeManager = this.plugin.getPickaxeManager();
        PlayerLevelService playerLevelService = this.plugin.getPlayerLevelService();
        if (skins == null || meteorService == null || pickaxeManager == null || playerLevelService == null) {
            return;
        }
        if (!skins.hasMoonBootsEquipped(player) || !meteorService.isMeteorOre(block)) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir() || !pickaxeManager.isPrisonPickaxe(tool)) {
            return;
        }
        Material normalized = this.normalizeOreForExp(block.getType());
        int bonusXp = this.applyMoonBootsMeteorBonus(this.computeXpBonus(player, tool, normalized));
        int bonusEnergy = this.applyMoonBootsMeteorBonus(this.computeEnergyBonus(player, tool, normalized));
        if (bonusXp > 0) {
            playerLevelService.addExp(player, bonusXp);
        }
        if (bonusEnergy > 0) {
            if (skins.isKryoPickaxeSkin(tool)) {
                pickaxeManager.addEnergyOverflow(tool, bonusEnergy);
            } else {
                pickaxeManager.addEnergy(tool, bonusEnergy);
            }
        }
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 3, true, false, true));
    }

    private int computeXpBonus(Player player, ItemStack tool, Material normalized) {
        int xp = this.resolveOreExp(normalized);
        if (xp <= 0) {
            return 0;
        }
        xp *= 5;
        xp = (int)Math.round((double)xp * this.plugin.getPickaxeManager().getXpMasteryMultiplier(tool));
        if (this.plugin.getBoosterService() != null) {
            xp = this.plugin.getBoosterService().applyXpBoost(player, xp);
        }
        return xp;
    }

    private int computeEnergyBonus(Player player, ItemStack tool, Material normalized) {
        int energy = this.plugin.getPickaxeManager().energyForBlock(tool, normalized);
        if (energy <= 0) {
            return 0;
        }
        if (this.plugin.getBoosterService() != null) {
            energy = this.plugin.getBoosterService().applyEnergyBoost(player, energy);
        }
        MaskManager maskManager = this.plugin.getMaskModule() != null ? this.plugin.getMaskModule().getMaskManager() : null;
        if (maskManager != null) {
            double percent = maskManager.getEnergyBonusPercent(player);
            if (percent > 0.0) {
                energy = (int)Math.round((double)energy * (1.0 + percent / 100.0));
            }
        }
        return energy;
    }

    private int applyMoonBootsMeteorBonus(int value) {
        return value <= 0 ? 0 : Math.max(1, (int)Math.round((double)value * 1.05));
    }

    private Material normalizeOreForExp(Material type) {
        if (type == null) {
            return Material.AIR;
        }
        switch (type) {
            case DEEPSLATE_COAL_ORE: {
                return Material.COAL_ORE;
            }
            case DEEPSLATE_IRON_ORE: {
                return Material.IRON_ORE;
            }
            case DEEPSLATE_COPPER_ORE: {
                return Material.COPPER_ORE;
            }
            case DEEPSLATE_GOLD_ORE:
            case NETHER_GOLD_ORE: {
                return Material.GOLD_ORE;
            }
            case DEEPSLATE_REDSTONE_ORE: {
                return Material.REDSTONE_ORE;
            }
            case DEEPSLATE_LAPIS_ORE: {
                return Material.LAPIS_ORE;
            }
            case DEEPSLATE_DIAMOND_ORE: {
                return Material.DIAMOND_ORE;
            }
            case DEEPSLATE_EMERALD_ORE: {
                return Material.EMERALD_ORE;
            }
        }
        return type;
    }

    private int resolveOreExp(Material type) {
        String path = "player-level.ore-exp." + type.name();
        if (this.plugin.getConfig().contains(path)) {
            return this.plugin.getConfig().getInt(path, 0);
        }
        return switch (type) {
            case COAL_ORE -> 25;
            case IRON_ORE -> 50;
            case LAPIS_ORE -> 75;
            case REDSTONE_ORE -> 75;
            case GOLD_ORE -> 125;
            case DIAMOND_ORE -> 250;
            case EMERALD_ORE -> 500;
            default -> 0;
        };
    }
}
