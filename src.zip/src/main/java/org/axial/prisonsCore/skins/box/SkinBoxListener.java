package org.axial.prisonsCore.skins.box;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.Event;

public final class SkinBoxListener implements Listener {
    private final SkinBoxService skinBoxService;
    private final SkinBoxMenu skinBoxMenu;

    public SkinBoxListener(SkinBoxService skinBoxService, SkinBoxMenu skinBoxMenu) {
        this.skinBoxService = skinBoxService;
        this.skinBoxMenu = skinBoxMenu;
    }

    @EventHandler(ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.skinBoxService.isSkinBox(item)) {
            return;
        }
        Player player = event.getPlayer();
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        this.consumeOne(item, player);
        this.skinBoxMenu.open(player);
    }

    private void consumeOne(ItemStack item, Player player) {
        if (item == null) {
            return;
        }
        int amount = item.getAmount();
        if (amount <= 1) {
            player.getInventory().setItemInMainHand(null);
            return;
        }
        item.setAmount(amount - 1);
        player.getInventory().setItemInMainHand(item);
    }
}
