package org.axial.prisonsCore.skins.ability;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface SkinAbility {
    void tick(Player player, ItemStack itemStack);

    String id();
}
