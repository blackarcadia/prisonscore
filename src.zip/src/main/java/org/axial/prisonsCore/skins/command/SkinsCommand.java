package org.axial.prisonsCore.skins.command;

import org.axial.prisonsCore.service.TutorialService;
import org.axial.prisonsCore.skins.menu.SkinsMenu;
import org.axial.prisonsCore.util.Text;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class SkinsCommand implements CommandExecutor {
    private final SkinsMenu skinsMenu;
    private final TutorialService tutorialService;

    public SkinsCommand(SkinsMenu skinsMenu, TutorialService tutorialService) {
        this.skinsMenu = skinsMenu;
        this.tutorialService = tutorialService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Text.color("&cOnly players can use this command."));
            return true;
        }
        boolean wasInTutorial = this.tutorialService != null && this.tutorialService.isInTutorial(player);
        if (this.tutorialService != null) {
            this.tutorialService.handleSkinsCommand(player);
        }
        boolean stillInTutorial = this.tutorialService != null && this.tutorialService.isInTutorial(player);
        if (this.skinsMenu != null && (!wasInTutorial || stillInTutorial || this.tutorialService == null)) {
            this.skinsMenu.open(player);
        }
        return true;
    }
}
