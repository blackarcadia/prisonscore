package org.axial.prisonsCore.skins.skin;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.axial.prisonsCore.skins.ability.SkinAbility;
import org.axial.prisonsCore.skins.ability.SkinAbilityRegistry;
import org.axial.prisonsCore.skins.message.MessageService;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

public final class SkinManager {
    private final Map<String, Skin> skins = new HashMap<>();
    private final NamespacedKey appliedSkinKey;
    private final NamespacedKey storedCmdKey;
    private final NamespacedKey storedTypeKey;
    private final NamespacedKey skinItemKey;
    private SkinAbilityRegistry registry;
    private final Plugin plugin;
    private MessageService messages;
    private Material skinItemMaterial;

    public SkinManager(Plugin plugin, SkinAbilityRegistry registry, MessageService messages, Material skinItemMaterial) {
        this.plugin = plugin;
        this.registry = registry;
        this.messages = messages;
        this.skinItemMaterial = skinItemMaterial;
        this.appliedSkinKey = new NamespacedKey(plugin, "applied_skin");
        this.storedCmdKey = new NamespacedKey(plugin, "stored_cmd");
        this.storedTypeKey = new NamespacedKey(plugin, "stored_type");
        this.skinItemKey = new NamespacedKey(plugin, "skin_item");
    }

    public void setRuntimeState(SkinAbilityRegistry registry, MessageService messages, Material skinItemMaterial) {
        this.registry = registry;
        this.messages = messages;
        this.skinItemMaterial = skinItemMaterial;
    }

    public void register(Skin skin) {
        this.skins.put(skin.id(), skin);
    }

    public SkinAbilityRegistry abilityRegistry() {
        return this.registry;
    }

    public Optional<Skin> get(String id) {
        return Optional.ofNullable(this.skins.get(id));
    }

    public Map<String, Skin> all() {
        return Map.copyOf(this.skins);
    }

    public boolean isSkinItem(ItemStack itemStack) {
        if (itemStack == null) {
            return false;
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(this.skinItemKey, PersistentDataType.STRING);
    }

    public boolean hasAppliedSkin(ItemStack itemStack) {
        if (itemStack == null) {
            return false;
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(this.appliedSkinKey, PersistentDataType.STRING);
    }

    public Optional<Skin> skinFromItem(ItemStack itemStack) {
        if (!this.isSkinItem(itemStack)) {
            return Optional.empty();
        }
        ItemMeta meta = itemStack.getItemMeta();
        PersistentDataContainer container = meta.getPersistentDataContainer();
        String id = container.get(this.skinItemKey, PersistentDataType.STRING);
        return this.get(id);
    }

    public Optional<Skin> skinAppliedTo(ItemStack itemStack) {
        return this.appliedSkinId(itemStack).flatMap(this::get);
    }

    public Optional<String> appliedSkinId(ItemStack itemStack) {
        if (!this.hasAppliedSkin(itemStack)) {
            return Optional.empty();
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return Optional.empty();
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        return Optional.ofNullable(container.get(this.appliedSkinKey, PersistentDataType.STRING));
    }

    public ItemStack createSkinItem(Skin skin) {
        ItemStack itemStack = new ItemStack(this.skinItemMaterial);
        ItemMeta meta = itemStack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(skin.displayName());
            List<String> lore = skin.lore().isEmpty() ? this.messages.getList("skin.item-lore") : skin.lore();
            meta.setLore(new ArrayList<>(lore));
            meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            meta.setCustomModelData(Integer.valueOf(skin.itemCustomModelData()));
            meta.getPersistentDataContainer().set(this.skinItemKey, PersistentDataType.STRING, skin.id());
            itemStack.setItemMeta(meta);
        }
        return itemStack;
    }

    public boolean applySkin(ItemStack itemStack, Skin skin) {
        if (itemStack == null || this.isSkinItem(itemStack) || !skin.canApplyTo(itemStack.getType())) {
            return false;
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return false;
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        if (!container.has(this.storedCmdKey, PersistentDataType.INTEGER)) {
            if (meta.hasCustomModelData()) {
                container.set(this.storedCmdKey, PersistentDataType.INTEGER, meta.getCustomModelData());
            } else {
                container.set(this.storedCmdKey, PersistentDataType.INTEGER, -1);
            }
        }
        if (!container.has(this.storedTypeKey, PersistentDataType.STRING)) {
            container.set(this.storedTypeKey, PersistentDataType.STRING, itemStack.getType().name());
        }
        if (skin.material() != null) {
            itemStack.setType(skin.material());
            ItemMeta remapped = Bukkit.getItemFactory().asMetaFor(meta, itemStack);
            if (remapped == null) {
                return false;
            }
            meta = remapped;
            container = meta.getPersistentDataContainer();
        }
        int appliedCustomModelData = skin.appliedCustomModelData();
        if ("rocket_lolly".equalsIgnoreCase(skin.id())) {
            appliedCustomModelData = 211;
        }
        meta.setCustomModelData(Integer.valueOf(appliedCustomModelData));
        container.set(this.appliedSkinKey, PersistentDataType.STRING, skin.id());
        this.updateAppliedSkinLore(meta, skin, skin.id(), true);
        itemStack.setItemMeta(meta);
        return true;
    }

    public Optional<ItemStack> removeSkin(ItemStack itemStack) {
        if (!this.hasAppliedSkin(itemStack)) {
            return Optional.empty();
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return Optional.empty();
        }
        PersistentDataContainer container = meta.getPersistentDataContainer();
        String appliedSkinId = container.get(this.appliedSkinKey, PersistentDataType.STRING);
        Integer storedCmd = container.get(this.storedCmdKey, PersistentDataType.INTEGER);
        String storedType = container.get(this.storedTypeKey, PersistentDataType.STRING);
        Material originalType = null;
        if (storedType != null) {
            originalType = Material.matchMaterial(storedType);
        }
        if (originalType != null) {
            itemStack.setType(originalType);
            ItemMeta remapped = Bukkit.getItemFactory().asMetaFor(meta, itemStack);
            if (remapped != null) {
                meta = remapped;
                container = meta.getPersistentDataContainer();
            }
        }
        if (storedCmd != null && storedCmd.intValue() >= 0) {
            meta.setCustomModelData(storedCmd);
        } else {
            meta.setCustomModelData(null);
        }
        Skin appliedSkin = this.skins.get(appliedSkinId);
        this.updateAppliedSkinLore(meta, appliedSkin, appliedSkinId, false);
        container.remove(this.appliedSkinKey);
        container.remove(this.storedCmdKey);
        container.remove(this.storedTypeKey);
        itemStack.setItemMeta(meta);
        if (appliedSkin == null) {
            return Optional.empty();
        }
        return Optional.of(this.createSkinItem(appliedSkin));
    }

    public int loadFromFile(File file) {
        if (!file.exists()) {
            this.plugin.saveResource("skins.yml", false);
        }
        YamlConfiguration configuration = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = configuration.getConfigurationSection("skins");
        if (section == null) {
            return 0;
        }
        this.skins.clear();
        int loaded = 0;
        for (String id : section.getKeys(false)) {
            ConfigurationSection skinSection = section.getConfigurationSection(id);
            if (skinSection == null) {
                continue;
            }
            String displayName = ChatColor.translateAlternateColorCodes('&', skinSection.getString("name", id));
            int appliedCmd = skinSection.getInt("custom-model-data", 0);
            int itemCmd = skinSection.getInt("item-custom-model-data", appliedCmd);
            String abilityId = skinSection.getString("ability");
            String materialName = skinSection.getString("material", null);
            List<String> lore = skinSection.getStringList("lore").stream()
                    .map(line -> ChatColor.translateAlternateColorCodes('&', line))
                    .toList();
            Set<String> allowedSuffixes = skinSection.getStringList("allowed-material-suffixes").stream()
                    .map(value -> value == null ? "" : value.toUpperCase(Locale.ROOT))
                    .filter(value -> !value.isBlank())
                    .collect(Collectors.toUnmodifiableSet());
            Material material = null;
            if (materialName != null) {
                material = Material.matchMaterial(materialName.toUpperCase(Locale.ROOT));
                if (material == null) {
                    this.plugin.getLogger().warning("Skin '" + id + "' references unknown material '" + materialName + "'");
                }
            }
            SkinAbility ability = abilityId == null ? null : this.registry.resolve(abilityId);
            if (abilityId != null && ability == null) {
                this.plugin.getLogger().warning("Skin '" + id + "' references unknown ability '" + abilityId + "'");
            }
            this.register(new Skin(id, displayName, itemCmd, appliedCmd, ability, material, allowedSuffixes, lore));
            loaded++;
        }
        return loaded;
    }

    public void syncPlayer(Player player) {
        if (player == null) {
            return;
        }
        PlayerInventory inventory = player.getInventory();
        for (ItemStack itemStack : inventory.getContents()) {
            this.syncItem(itemStack);
        }
        for (ItemStack itemStack : inventory.getArmorContents()) {
            this.syncItem(itemStack);
        }
        this.syncItem(inventory.getItemInOffHand());
    }

    public void syncItem(ItemStack itemStack) {
        if (itemStack == null || !this.hasAppliedSkin(itemStack)) {
            return;
        }
        ItemMeta meta = itemStack.getItemMeta();
        if (meta == null) {
            return;
        }
        String skinId = this.appliedSkinId(itemStack).orElse(null);
        if (skinId == null) {
            return;
        }
        Skin skin = this.skins.get(skinId);
        this.updateAppliedSkinLore(meta, skin, skinId, true);
        itemStack.setItemMeta(meta);
    }

    private void updateAppliedSkinLore(ItemMeta meta, Skin skin, String skinId, boolean attached) {
        if (meta == null || skinId == null) {
            return;
        }
        List<String> lore = meta.getLore();
        List<String> updatedLore = lore == null ? new ArrayList<>() : new ArrayList<>(lore);
        String skinName = skin != null ? ChatColor.stripColor(skin.displayName()) : skinId;
        String firstLine = ChatColor.translateAlternateColorCodes('&', "&6&lSkin (" + skinName + ")");
        String secondLine = ChatColor.translateAlternateColorCodes('&', "&7(&7&nAxialMod Required)");
        Set<String> removable = new LinkedHashSet<>();
        removable.add(firstLine);
        removable.add(secondLine);
        removable.add(ChatColor.translateAlternateColorCodes('&', "&7Skin: " + skinName));
        removable.add(ChatColor.translateAlternateColorCodes('&', "&7Skin (" + skinName + ")"));
        updatedLore.removeIf(line -> {
            if (line == null) {
                return false;
            }
            if (removable.contains(line)) {
                return true;
            }
            String stripped = ChatColor.stripColor(line).trim();
            return stripped.equalsIgnoreCase("AxialMod Required")
                    || stripped.equalsIgnoreCase("(AxialMod Required)")
                    || stripped.startsWith("Skin: ")
                    || stripped.startsWith("Skin (");
        });
        if (attached) {
            updatedLore.addAll(this.appliedLoreLines(skinName));
        }
        meta.setLore(updatedLore);
    }

    private List<String> appliedLoreLines(String skinName) {
        List<String> configured = this.messages.getList("skin.applied-lore");
        if (!configured.isEmpty()) {
            List<String> result = new ArrayList<>(configured.size());
            for (String line : configured) {
                result.add(this.formatSkinLoreLine(line, skinName));
            }
            return result;
        }
        return List.of(
                ChatColor.translateAlternateColorCodes('&', "&6&lSkin (" + skinName + ")"),
                ChatColor.translateAlternateColorCodes('&', "&7(&7&nAxialMod Required)")
        );
    }

    private String formatSkinLoreLine(String line, String skinName) {
        if (line == null) {
            return "";
        }
        return ChatColor.translateAlternateColorCodes('&', line.replace("{skin}", skinName));
    }
}
