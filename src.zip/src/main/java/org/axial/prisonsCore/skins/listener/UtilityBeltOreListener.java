package org.axial.prisonsCore.skins.listener;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public final class UtilityBeltOreListener implements Listener {
    private static final Set<Material> ORES = EnumSet.of(
            Material.COAL_ORE,
            Material.DEEPSLATE_COAL_ORE,
            Material.IRON_ORE,
            Material.DEEPSLATE_IRON_ORE,
            Material.COPPER_ORE,
            Material.DEEPSLATE_COPPER_ORE,
            Material.GOLD_ORE,
            Material.DEEPSLATE_GOLD_ORE,
            Material.NETHER_GOLD_ORE,
            Material.REDSTONE_ORE,
            Material.DEEPSLATE_REDSTONE_ORE,
            Material.LAPIS_ORE,
            Material.DEEPSLATE_LAPIS_ORE,
            Material.DIAMOND_ORE,
            Material.DEEPSLATE_DIAMOND_ORE,
            Material.EMERALD_ORE,
            Material.DEEPSLATE_EMERALD_ORE,
            Material.NETHER_QUARTZ_ORE,
            Material.ANCIENT_DEBRIS
    );

    private final PrisonsCore plugin;
    private final ConcurrentMap<UUID, Double> bonusProgress = new ConcurrentHashMap<>();

    public UtilityBeltOreListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (player == null || block == null) {
            return;
        }
        AxialSkinsModule module = this.plugin.getAxialSkinsModule();
        if (module == null || !module.hasUtilityBeltEquipped(player)) {
            return;
        }
        Material type = block.getType();
        if (!this.isOre(type)) {
            return;
        }
        int extra = this.nextBonusAmount(player.getUniqueId());
        if (extra <= 0) {
            return;
        }
        ItemStack bonusDrop = new ItemStack(type, extra);
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, bonusDrop);
        } else {
            player.getInventory().addItem(bonusDrop).values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }
    }

    private int nextBonusAmount(UUID playerId) {
        double progress = this.bonusProgress.merge(playerId, 0.25D, Double::sum);
        int extra = (int) progress;
        if (extra > 0) {
            this.bonusProgress.put(playerId, progress - extra);
        } else {
            this.bonusProgress.put(playerId, progress);
        }
        return extra;
    }

    private boolean isOre(Material material) {
        return material != null && (ORES.contains(material) || material.name().endsWith("_ORE"));
    }
}
