package org.axial.prisonsCore.skins.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.box.SkinBoxService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class SkinBoxCommand implements CommandExecutor, TabCompleter {
    private final PrisonsCore plugin;
    private final SkinBoxService skinBoxService;

    public SkinBoxCommand(PrisonsCore plugin, SkinBoxService skinBoxService) {
        this.plugin = plugin;
        this.skinBoxService = skinBoxService;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("prisons.skinbox.give")) {
            sender.sendMessage(Text.color("&cNo permission."));
            return true;
        }
        if (args.length < 2 || !args[0].equalsIgnoreCase("give")) {
            sender.sendMessage(Text.color("&cUsage: /skinbox give <player> [amount]"));
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            sender.sendMessage(Text.color("&cPlayer not found."));
            return true;
        }
        int amount = 1;
        if (args.length >= 3) {
            try {
                amount = Math.max(1, Integer.parseInt(args[2]));
            } catch (NumberFormatException e) {
                sender.sendMessage(Text.color("&cInvalid amount."));
                return true;
            }
        }
        int remaining = amount;
        while (remaining > 0) {
            ItemStack stack = this.skinBoxService.createSkinBox(Math.min(remaining, 64));
            if (this.plugin.getStashService() != null) {
                this.plugin.getStashService().giveOrStash(target, stack);
            } else {
                target.getInventory().addItem(stack).values().forEach(item -> target.getWorld().dropItemNaturally(target.getLocation(), item));
            }
            remaining -= stack.getAmount();
        }
        sender.sendMessage(Text.color("&aGave " + amount + "x Skin Box to " + target.getName() + "."));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        ArrayList<String> completions = new ArrayList<>();
        if (args.length == 1) {
            if ("give".startsWith(args[0].toLowerCase(Locale.ENGLISH))) {
                completions.add("give");
            }
            return completions;
        }
        if (args.length == 2) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getName().toLowerCase(Locale.ENGLISH).startsWith(args[1].toLowerCase(Locale.ENGLISH))) {
                    completions.add(player.getName());
                }
            }
        }
        return completions;
    }
}
