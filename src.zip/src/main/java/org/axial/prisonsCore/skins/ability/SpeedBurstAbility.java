package org.axial.prisonsCore.skins.ability;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class SpeedBurstAbility implements SkinAbility {
    private final int amplifier;

    public SpeedBurstAbility(int amplifier) {
        this.amplifier = amplifier;
    }

    @Override
    public void tick(Player player, ItemStack itemStack) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, this.amplifier, true, false, true));
    }

    @Override
    public String id() {
        return "speed";
    }
}
