package org.axial.prisonsCore.skins.ability;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public final class RocketLollyAbility implements SkinAbility {
    @Override
    public void tick(Player player, ItemStack itemStack) {
    }

    @Override
    public String id() {
        return "rocket_lolly";
    }
}
