package org.axial.prisonsCore.skins.message;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.YamlConfiguration;

public final class MessageService {
    private final Map<String, Object> messages = new HashMap<>();

    private MessageService() {
        this.seedDefaults();
    }

    public static MessageService load(File file) {
        MessageService service = new MessageService();
        service.reload(file);
        return service;
    }

    public void reload(File file) {
        this.messages.clear();
        this.seedDefaults();
        if (!file.exists()) {
            return;
        }
        YamlConfiguration configuration = YamlConfiguration.loadConfiguration(file);
        for (String key : configuration.getKeys(true)) {
            if (configuration.isConfigurationSection(key)) {
                continue;
            }
            this.messages.put(key, configuration.get(key));
        }
    }

    public String get(String path) {
        Object value = this.messages.get(path);
        if (value instanceof String string) {
            return this.colorize(string);
        }
        return "";
    }

    public List<String> getList(String path) {
        Object value = this.messages.get(path);
        if (!(value instanceof List<?> list)) {
            return Collections.emptyList();
        }
        List<String> result = new ArrayList<>();
        for (Object entry : list) {
            if (entry != null) {
                result.add(this.colorize(String.valueOf(entry)));
            }
        }
        return result;
    }

    public String format(String path, String... replacements) {
        String message = this.get(path);
        if (message.isEmpty()) {
            return message;
        }
        Map<String, String> placeholders = new HashMap<>();
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            placeholders.put(replacements[i], replacements[i + 1]);
        }
        for (Map.Entry<String, String> entry : placeholders.entrySet()) {
            message = message.replace("{" + entry.getKey() + "}", entry.getValue());
        }
        return message;
    }

    private String colorize(String value) {
        return ChatColor.translateAlternateColorCodes('&', value);
    }

    private void seedDefaults() {
        this.messages.put("skin.applied", "&eApplied skin '{skin}' to item.");
        this.messages.put("skin.removed", "&eSkin removed and returned to your inventory.");
        this.messages.put("skin.invalid-target", "&cThis skin can only be applied to matching items.");
        this.messages.put("skin.item-lore", List.of("&7Drag onto an item to apply.", "&7Right-click the skinned item to remove."));
        this.messages.put("skin.applied-lore", List.of("&6&lSkin ({skin})", "&7(&7&nAxialMod Required)"));
        this.messages.put("kryopickaxe.charge-full", "&eCharge is full. Mining continues and extra charge goes into overflow.");
        this.messages.put("command.no-permission", "&cYou do not have permission to use this command.");
        this.messages.put("command.unknown-skin", "&cUnknown skin id: {skin}");
        this.messages.put("command.player-not-found", "&cPlayer not found: {player}");
        this.messages.put("command.gave", "&eGave {amount}x {skin} to {player}.");
        this.messages.put("command.usage-header", "&6AxialSkins commands:");
        this.messages.put("command.usage-list", "&e/{label} list &7- Show available skins.");
        this.messages.put("command.usage-give", "&e/{label} give <skinId> [player] [amount] &7- Give skin items.");
        this.messages.put("command.usage-reload", "&e/{label} reload &7- Reload AxialSkins configuration.");
        this.messages.put("command.list-header", "&6Available skins:");
        this.messages.put("command.list-entry", "&e- {id}&7 ({name}&7, ability: {ability})");
        this.messages.put("command.reloaded", "&aReloaded AxialSkins configuration.");
    }
}
