package org.axial.prisonsCore.skins.ability;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class SkinAbilityRegistry {
    private final Map<String, SkinAbility> abilities;

    public SkinAbilityRegistry(Map<String, SkinAbility> abilities) {
        this.abilities = abilities;
    }

    public SkinAbility resolve(String id) {
        return this.abilities.get(id);
    }

    public Map<String, SkinAbility> all() {
        return Collections.unmodifiableMap(this.abilities);
    }

    public static SkinAbilityRegistry bootstrap() {
        Map<String, SkinAbility> abilities = new HashMap<>();
        SkinAbility speed = new SpeedBurstAbility(1);
        SkinAbility oreHarvest = new OreHarvestAbility();
        SkinAbility kryoPickaxe = new KryoPickaxeAbility();
        SkinAbility kryoAmulet = new KryoAmuletAbility();
        SkinAbility kryoHelmet = new KryoHelmetAbility();
        SkinAbility rocketLolly = new RocketLollyAbility();
        SkinAbility fireWard = new FireWardAbility();
        SkinAbility crouchMining = new CrouchMiningAbility(1, 40);
        abilities.put(speed.id(), speed);
        abilities.put(oreHarvest.id(), oreHarvest);
        abilities.put(kryoPickaxe.id(), kryoPickaxe);
        abilities.put(kryoAmulet.id(), kryoAmulet);
        abilities.put(kryoHelmet.id(), kryoHelmet);
        abilities.put(rocketLolly.id(), rocketLolly);
        abilities.put(fireWard.id(), fireWard);
        abilities.put(crouchMining.id(), crouchMining);
        return new SkinAbilityRegistry(abilities);
    }
}
