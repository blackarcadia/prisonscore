package org.axial.prisonsCore.skins.listener;

import java.util.Set;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

public final class KryoHelmetListener implements Listener {
    private static final Set<String> FIRE_CAUSES = Set.of(
            "FIRE",
            "FIRE_TICK",
            "LAVA",
            "HOT_FLOOR",
            "MELTING"
    );
    private final PrisonsCore plugin;

    public KryoHelmetListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (!(entity instanceof Player player)) {
            return;
        }
        AxialSkinsModule skins = this.plugin.getAxialSkinsModule();
        if (skins == null || !skins.hasKryoHelmetEquipped(player)) {
            return;
        }
        if (!FIRE_CAUSES.contains(event.getCause().name())) {
            return;
        }
        event.setCancelled(true);
        player.setFireTicks(0);
    }
}
