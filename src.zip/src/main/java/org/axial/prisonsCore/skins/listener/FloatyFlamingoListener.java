package org.axial.prisonsCore.skins.listener;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.skins.AxialSkinsModule;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class FloatyFlamingoListener implements Listener {
    private static final double DAMAGE_MULTIPLIER = 0.65D;
    private static final long SOUND_COOLDOWN_MS = 1500L;
    private static final double SOUND_CHANCE = 0.40D;
    private final PrisonsCore plugin;
    private final Map<UUID, Long> soundCooldownUntil = new ConcurrentHashMap<>();

    public FloatyFlamingoListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        AxialSkinsModule skins = this.plugin.getAxialSkinsModule();
        if (skins == null || !skins.hasFloatyFlamingoEquipped(player)) {
            return;
        }
        event.setDamage(Math.max(0.0D, event.getDamage() * DAMAGE_MULTIPLIER));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageSound(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        if (event.getFinalDamage() <= 0.0D) {
            return;
        }
        AxialSkinsModule skins = this.plugin.getAxialSkinsModule();
        if (skins == null || !skins.hasFloatyFlamingoEquipped(player)) {
            return;
        }
        long now = System.currentTimeMillis();
        long until = this.soundCooldownUntil.getOrDefault(player.getUniqueId(), 0L);
        if (now < until) {
            return;
        }
        if (ThreadLocalRandom.current().nextDouble() > SOUND_CHANCE) {
            return;
        }
        this.soundCooldownUntil.put(player.getUniqueId(), now + SOUND_COOLDOWN_MS);
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 0.85F, 1.1F);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        if (event.getPlayer() != null) {
            this.soundCooldownUntil.remove(event.getPlayer().getUniqueId());
        }
    }
}
