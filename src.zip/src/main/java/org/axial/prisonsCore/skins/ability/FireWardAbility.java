package org.axial.prisonsCore.skins.ability;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class FireWardAbility implements SkinAbility {
    @Override
    public void tick(Player player, ItemStack itemStack) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 40, 0, true, false, true));
    }

    @Override
    public String id() {
        return "fireward";
    }
}
