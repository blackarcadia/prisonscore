package org.axial.prisonsCore.skins.listener;

import org.axial.prisonsCore.skins.message.MessageService;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.skins.skin.SkinManager;
import java.util.Optional;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.Sound;
import org.bukkit.inventory.ItemStack;

public final class SkinInventoryListener implements Listener {
    private final SkinManager skinManager;
    private final MessageService messages;

    public SkinInventoryListener(SkinManager skinManager, MessageService messages) {
        this.skinManager = skinManager;
        this.messages = messages;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        Player player = event.getWhoClicked() instanceof Player clicked ? clicked : null;
        if (player == null) {
            return;
        }
        ItemStack cursor = event.getCursor();
        boolean cursorEmpty = cursor == null || cursor.getType().isAir();
        ItemStack current = event.getCurrentItem();
        ClickType click = event.getClick();
        if ((click == ClickType.RIGHT || click == ClickType.SHIFT_RIGHT) && cursorEmpty && current != null && this.skinManager.hasAppliedSkin(current)) {
            this.skinManager.removeSkin(current).ifPresent(item -> player.getInventory().addItem(item));
            event.setCancelled(true);
            event.setCurrentItem(current);
            player.playSound(player.getLocation(), Sound.ENTITY_HORSE_SADDLE, 1.0f, 1.0f);
            player.sendMessage(this.messages.get("skin.removed"));
            return;
        }
        InventoryAction action = event.getAction();
        if (action != InventoryAction.SWAP_WITH_CURSOR && action != InventoryAction.PLACE_ALL && action != InventoryAction.PLACE_ONE && action != InventoryAction.PLACE_SOME) {
            return;
        }
        current = event.getCurrentItem();
        if (!this.skinManager.isSkinItem(cursor) || current == null || current.getType().isAir()) {
            return;
        }
        Optional<Skin> skin = this.skinManager.skinFromItem(cursor);
        if (skin.isEmpty()) {
            return;
        }
        boolean applied = this.skinManager.applySkin(current, skin.get());
        if (!applied) {
            player.sendMessage(this.messages.get("skin.invalid-target"));
            return;
        }
        event.setCancelled(true);
        cursor.setAmount(cursor.getAmount() - 1);
        event.setCursor(cursor.getAmount() > 0 ? cursor : null);
        event.setCurrentItem(current);
        player.playSound(player.getLocation(), Sound.ENTITY_HORSE_SADDLE, 1.0f, 1.0f);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(this.messages.format("skin.applied", "skin", ChatColor.stripColor(skin.get().displayName())));
    }
}
