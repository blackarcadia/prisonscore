package org.axial.prisonsCore.skins.integration;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PickaxeManager;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public final class PrisonsCoreHook {
    private final PrisonsCore plugin;

    public PrisonsCoreHook(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    public boolean isAvailable() {
        return this.plugin.getPickaxeManager() != null;
    }

    public boolean isPrisonPickaxe(ItemStack itemStack) {
        PickaxeManager pickaxeManager = this.plugin.getPickaxeManager();
        return pickaxeManager != null && pickaxeManager.isPrisonPickaxe(itemStack);
    }

    public int getEnergy(ItemStack itemStack) {
        PickaxeManager pickaxeManager = this.plugin.getPickaxeManager();
        return pickaxeManager == null ? 0 : pickaxeManager.getEnergy(itemStack);
    }

    public int getMaxEnergy(ItemStack itemStack) {
        PickaxeManager pickaxeManager = this.plugin.getPickaxeManager();
        return pickaxeManager == null ? 0 : pickaxeManager.getMaxEnergy(itemStack);
    }

    public int energyForBlock(ItemStack itemStack, Material material) {
        PickaxeManager pickaxeManager = this.plugin.getPickaxeManager();
        return pickaxeManager == null ? 0 : pickaxeManager.energyForBlock(itemStack, material);
    }

    public void setEnergyOverflow(ItemStack itemStack, int amount) {
        PickaxeManager pickaxeManager = this.plugin.getPickaxeManager();
        if (pickaxeManager != null) {
            pickaxeManager.setEnergyOverflow(itemStack, amount);
        }
    }

    public void updateLore(ItemStack itemStack) {
        PickaxeManager pickaxeManager = this.plugin.getPickaxeManager();
        if (pickaxeManager != null) {
            pickaxeManager.updateLore(itemStack);
        }
    }
}
