package org.axial.prisonsCore.skins.skin;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import org.axial.prisonsCore.skins.ability.SkinAbility;
import org.bukkit.Material;

public final class Skin {
    private final String id;
    private final String displayName;
    private final int itemCustomModelData;
    private final int appliedCustomModelData;
    private final SkinAbility ability;
    private final Material materialOverride;
    private final Set<String> allowedMaterialSuffixes;
    private final List<String> lore;

    public Skin(String id, String displayName, int itemCustomModelData, int appliedCustomModelData, SkinAbility ability, Material materialOverride, Set<String> allowedMaterialSuffixes, List<String> lore) {
        this.id = id;
        this.displayName = displayName;
        this.itemCustomModelData = itemCustomModelData;
        this.appliedCustomModelData = appliedCustomModelData;
        this.ability = ability;
        this.materialOverride = materialOverride;
        this.allowedMaterialSuffixes = Set.copyOf(allowedMaterialSuffixes);
        this.lore = List.copyOf(lore);
    }

    public String id() {
        return this.id;
    }

    public String displayName() {
        return this.displayName;
    }

    public int itemCustomModelData() {
        return this.itemCustomModelData;
    }

    public int appliedCustomModelData() {
        return this.appliedCustomModelData;
    }

    public int customModelData() {
        return this.appliedCustomModelData;
    }

    public SkinAbility ability() {
        return this.ability;
    }

    public Material material() {
        return this.materialOverride;
    }

    public List<String> lore() {
        return this.lore;
    }

    public boolean canApplyTo(Material material) {
        if (this.allowedMaterialSuffixes.isEmpty()) {
            return true;
        }
        String name = material.name();
        return this.allowedMaterialSuffixes.stream().anyMatch(name::endsWith);
    }
}
