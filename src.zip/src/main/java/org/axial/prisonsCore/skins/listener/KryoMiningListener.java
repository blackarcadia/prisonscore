package org.axial.prisonsCore.skins.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.skins.integration.PrisonsCoreHook;
import org.axial.prisonsCore.skins.message.MessageService;
import org.axial.prisonsCore.skins.skin.Skin;
import org.axial.prisonsCore.skins.skin.SkinManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

public final class KryoMiningListener implements Listener {
    private static final String KRYO_PICKAXE_ABILITY = "kryopickaxe";
    private final MessageService messages;
    private final SkinManager skinManager;
    private final PrisonsCoreHook prisonsCoreHook;
    private final Map<UUID, PendingCharge> pendingCharges = new HashMap<>();

    public KryoMiningListener(SkinManager skinManager, MessageService messages, PrisonsCoreHook prisonsCoreHook) {
        this.skinManager = skinManager;
        this.messages = messages;
        this.prisonsCoreHook = prisonsCoreHook;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir()) {
            return;
        }
        if (!tool.getType().name().endsWith("_PICKAXE")) {
            return;
        }
        Skin skin = this.skinManager.skinAppliedTo(tool).orElse(null);
        if (skin == null) {
            return;
        }
        if (skin.ability() == null || !this.isKryoPickaxeAbility(skin.ability().id())) {
            return;
        }
        if (this.prisonsCoreHook.isAvailable() && this.prisonsCoreHook.isPrisonPickaxe(tool)) {
            this.preAdjustPrisonsCorePickaxe(event, player, tool);
        } else {
            this.handleFallbackPickaxe(event, player, tool);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockBreakMonitor(BlockBreakEvent event) {
        Player player = event.getPlayer();
        PendingCharge pending = this.pendingCharges.remove(player.getUniqueId());
        if (pending == null) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (tool == null || tool.getType().isAir()) {
            return;
        }
        if (event.isCancelled()) {
            this.prisonsCoreHook.setEnergyOverflow(tool, pending.originalEnergy());
            this.prisonsCoreHook.updateLore(tool);
            return;
        }
        int restoredEnergy = pending.originalEnergy() + pending.gain();
        this.prisonsCoreHook.setEnergyOverflow(tool, restoredEnergy);
        this.prisonsCoreHook.updateLore(tool);
        if (pending.originalEnergy() < pending.maxEnergy() && restoredEnergy >= pending.maxEnergy()) {
            player.sendMessage(this.messages.get("kryopickaxe.charge-full"));
        }
    }

    private boolean isKryoPickaxeAbility(String abilityId) {
        return KRYO_PICKAXE_ABILITY.equals(abilityId) || "ore_harvest".equals(abilityId);
    }

    private void preAdjustPrisonsCorePickaxe(BlockBreakEvent event, Player player, ItemStack tool) {
        int originalEnergy = this.prisonsCoreHook.getEnergy(tool);
        int maxEnergy = this.prisonsCoreHook.getMaxEnergy(tool);
        int gain = this.prisonsCoreHook.energyForBlock(tool, event.getBlock().getType());
        if (gain <= 0) {
            gain = 1;
        }
        if (originalEnergy < maxEnergy && originalEnergy + gain < maxEnergy) {
            return;
        }
        this.pendingCharges.put(player.getUniqueId(), new PendingCharge(originalEnergy, gain, maxEnergy));
        this.prisonsCoreHook.setEnergyOverflow(tool, Math.max(0, maxEnergy - gain - 1));
    }

    private void handleFallbackPickaxe(BlockBreakEvent event, Player player, ItemStack tool) {
        event.setCancelled(true);
        event.setDropItems(false);
        Block block = event.getBlock();
        for (ItemStack drop : block.getDrops(tool)) {
            if (drop == null || drop.getType().isAir()) {
                continue;
            }
            var leftovers = player.getInventory().addItem(drop);
            leftovers.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        }
        block.setType(Material.AIR, false);
    }

    private record PendingCharge(int originalEnergy, int gain, int maxEnergy) {
    }
}
