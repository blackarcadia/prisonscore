/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.util;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.ArrayList;
import org.axial.prisonsCore.util.ConfigUpdater;
import org.axial.prisonsCore.util.Text;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

public class LanguageService {
    private final Plugin plugin;
    private final YamlConfiguration lang;

    public LanguageService(Plugin plugin) {
        this.plugin = plugin;
        File file = new File(plugin.getDataFolder(), "languages.yml");
        ConfigUpdater.saveDefaultAndMerge((org.bukkit.plugin.java.JavaPlugin)plugin, "languages.yml");
        this.lang = YamlConfiguration.loadConfiguration((File)file);
        this.migrateCellLore();
        this.migrateCellTierMenu();
        this.migrateCellListMenu();
    }

    public String get(String path, String def) {
        String raw = this.lang.getString(path, def);
        return Text.color(raw);
    }

    public String get(String path, String def, Map<String, String> placeholders) {
        String msg = this.get(path, def);
        if (placeholders != null) {
            for (Map.Entry<String, String> e : placeholders.entrySet()) {
                msg = msg.replace("{" + e.getKey() + "}", e.getValue());
            }
        }
        return msg;
    }

    public List<String> getList(String path, List<String> def) {
        List<String> list = this.lang.getStringList(path);
        if (list == null || list.isEmpty()) {
            list = def;
        }
        return list.stream().map(Text::color).collect(Collectors.toList());
    }

    private void migrateCellLore() {
        List<String> legacy = this.lang.getStringList("cells.menu.tier-item.lore");
        if (legacy == null || legacy.isEmpty() || !legacy.stream().anyMatch(line -> line != null && line.contains("${price}"))) {
            return;
        }
        this.lang.set("cells.menu.tier-item.lore", this.defaultCellTierLore());
    }

    private void migrateCellTierMenu() {
        this.lang.set("cells.menu.tier-item.names.inmate", "&7&lInmate Cells");
        this.lang.set("cells.menu.tier-item.names.trustee", "&6&lTrustee Cells");
        this.lang.set("cells.menu.tier-item.names.warden", "&b&lWarden Cells");
        this.lang.set("cells.menu.tier-item.lore", this.defaultCellTierLore());
    }

    private ArrayList<String> defaultCellTierLore() {
        ArrayList<String> updated = new ArrayList<String>();
        updated.add("&cRequires Mining Level &f&l{required level} &cor higher.");
        updated.add("");
        updated.add("&fPrice: {price}");
        updated.add("");
        updated.add("&7Left-Click to view cells.");
        return updated;
    }

    private void migrateCellListMenu() {
        this.lang.set("cells.menu.list-item.name", "&f&l{cell name}");
        this.lang.set("cells.menu.list-item.rented-name", "&c&l{cell name}");
        ArrayList<String> available = new ArrayList<String>();
        available.add("");
        available.add("&fPrice: {price}");
        available.add("");
        available.add("&aAvailable for purchase");
        this.lang.set("cells.menu.list-item.available-lore", available);
        ArrayList<String> rented = new ArrayList<String>();
        rented.add("");
        rented.add("&fOwner: &7{owner}");
        rented.add("");
        rented.add("&cCell Owned");
        this.lang.set("cells.menu.list-item.rented-lore", rented);
        ArrayList<String> rentedOwn = new ArrayList<String>();
        rentedOwn.add("");
        rentedOwn.add("&fOwner: &7{owner}");
        rentedOwn.add("");
        rentedOwn.add("&aClick to teleport to your cell.");
        this.lang.set("cells.menu.list-item.rented-own-lore", rentedOwn);
    }
}
