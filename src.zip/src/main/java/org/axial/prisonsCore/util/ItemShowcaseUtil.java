package org.axial.prisonsCore.util;

import java.util.IllegalFormatException;
import java.util.Locale;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemShowcaseUtil {
    public static final String TOKEN = "[item]";
    private static final String MESSAGE_PLACEHOLDER = "<<<ITEM_SHOWCASE_MESSAGE>>>";
    private static final String DISPLAY_NAME_PLACEHOLDER = "<<<ITEM_SHOWCASE_DISPLAY_NAME>>>";

    private ItemShowcaseUtil() {
    }

    public static boolean containsToken(String message) {
        return message != null && message.toLowerCase(Locale.ROOT).contains(TOKEN);
    }

    public static String replaceTokenWithName(String message, ItemStack item) {
        if (message == null) {
            return "";
        }
        StringBuilder built = new StringBuilder();
        int start = 0;
        String lowered = message.toLowerCase(Locale.ROOT);
        while (true) {
            int at = lowered.indexOf(TOKEN, start);
            if (at < 0) {
                break;
            }
            built.append(message, start, at);
            built.append('[').append(getItemNamePlain(item)).append(']');
            start = at + TOKEN.length();
        }
        return start == 0 ? message : built.append(message.substring(start)).toString();
    }

    public static Component buildMessage(String prefixLegacy, String message, ItemStack item) {
        Component built = Text.componentNoItalics(prefixLegacy);
        return appendMessageBody(built, message, item);
    }

    public static Component buildShowcaseMessage(String message, ItemStack item) {
        return appendMessageBody(Component.empty(), message, item);
    }

    public static Component buildFormattedMessage(String format, String displayName, String message, ItemStack item) {
        String resolvedFormat = resolveChatFormat(format, displayName, MESSAGE_PLACEHOLDER);
        int placeholderAt = resolvedFormat.indexOf(MESSAGE_PLACEHOLDER);
        if (placeholderAt < 0) {
            return buildMessage(resolvedFormat, message, item);
        }
        Component built = Text.componentNoItalics(resolvedFormat.substring(0, placeholderAt));
        built = appendMessageBody(built, message, item);
        String suffix = resolvedFormat.substring(placeholderAt + MESSAGE_PLACEHOLDER.length());
        if (!suffix.isEmpty()) {
            built = built.append(Text.componentNoItalics(suffix));
        }
        return built;
    }

    public static String buildFormattedPlainMessage(String format, String displayName, String message) {
        return resolveChatFormat(format, displayName, message);
    }

    private static String resolveChatFormat(String format, String displayName, String message) {
        if (format == null || format.isEmpty()) {
            return displayName + ": " + message;
        }
        try {
            return String.format(format, displayName, message);
        } catch (IllegalFormatException ignored) {
            String resolved = format;
            resolved = resolved.replace("%1$s", DISPLAY_NAME_PLACEHOLDER);
            resolved = resolved.replace("%2$s", MESSAGE_PLACEHOLDER);
            resolved = resolved.replace("%displayname%", DISPLAY_NAME_PLACEHOLDER);
            resolved = resolved.replace("%player%", DISPLAY_NAME_PLACEHOLDER);
            resolved = resolved.replace("%message%", MESSAGE_PLACEHOLDER);
            resolved = resolved.replace("{displayname}", DISPLAY_NAME_PLACEHOLDER);
            resolved = resolved.replace("{player}", DISPLAY_NAME_PLACEHOLDER);
            resolved = resolved.replace("{message}", MESSAGE_PLACEHOLDER);
            resolved = replaceFirst(resolved, "%s", DISPLAY_NAME_PLACEHOLDER);
            resolved = replaceFirst(resolved, "%s", MESSAGE_PLACEHOLDER);
            resolved = resolved.replace(DISPLAY_NAME_PLACEHOLDER, displayName);
            resolved = resolved.replace(MESSAGE_PLACEHOLDER, message);
            if (resolved.equals(format)) {
                return displayName + ": " + message;
            }
            return resolved;
        }
    }

    private static String replaceFirst(String input, String target, String replacement) {
        int at = input.indexOf(target);
        if (at < 0) {
            return input;
        }
        return input.substring(0, at) + replacement + input.substring(at + target.length());
    }

    private static Component appendMessageBody(Component built, String message, ItemStack item) {
        int start = 0;
        String lowered = message.toLowerCase(Locale.ROOT);
        while (true) {
            int at = lowered.indexOf(TOKEN, start);
            if (at < 0) {
                break;
            }
            if (at > start) {
                built = built.append(Component.text(message.substring(start, at)).decoration(TextDecoration.ITALIC, false));
            }
            built = built.append(buildShowcaseComponent(item));
            start = at + TOKEN.length();
        }
        if (start < message.length()) {
            built = built.append(Component.text(message.substring(start)).decoration(TextDecoration.ITALIC, false));
        }
        return built;
    }

    public static Component buildShowcaseComponent(ItemStack item) {
        return Component.text("[", NamedTextColor.GRAY)
                .append(getItemNameComponent(item))
                .append(Component.text("]", NamedTextColor.GRAY))
                .hoverEvent(buildHoverComponent(item))
                .decoration(TextDecoration.ITALIC, false);
    }

    public static boolean hasShowcaseableItem(ItemStack item) {
        return item != null && item.getType() != Material.AIR;
    }

    private static Component getItemNameComponent(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            return Text.componentNoItalics(meta.getDisplayName());
        }
        return Component.text(getItemNamePlain(item), NamedTextColor.AQUA).decoration(TextDecoration.ITALIC, false);
    }

    private static String getItemNamePlain(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            return Text.strip(meta.getDisplayName());
        }
        return item.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private static Component buildHoverComponent(ItemStack item) {
        Component hover = getItemNameComponent(item).decoration(TextDecoration.ITALIC, false);
        ItemMeta meta = item.getItemMeta();
        List<String> lore = meta == null ? null : meta.getLore();
        if (lore != null && !lore.isEmpty()) {
            for (String line : lore) {
                hover = hover.append(Component.newline()).append(Text.componentNoItalics(line));
            }
        }
        return hover;
    }
}
