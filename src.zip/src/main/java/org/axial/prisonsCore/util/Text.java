/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  net.kyori.adventure.text.format.TextDecoration
 *  net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
 *  org.bukkit.ChatColor
 */
package org.axial.prisonsCore.util;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.ChatColor;

public final class Text {
    private static final int CENTER_PX = 154;
    private static final int SPACE_PX = 4;
    private static final NumberFormat NUMBER_FORMAT = new DecimalFormat("#,###");
    private static final int[] CHAR_WIDTHS = new int[]{
            5, 1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 1, 5, 5, 5, 5,
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5,
            5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5
    };

    private Text() {
    }

    public static String color(String input) {
        return ChatColor.translateAlternateColorCodes((char)'&', (String)input);
    }

    public static String format(String template, String placeholder, String value) {
        return template.replace("{" + placeholder + "}", value);
    }

    public static String formatNumber(long value) {
        return NUMBER_FORMAT.format(value);
    }

    public static String formatNumber(int value) {
        return NUMBER_FORMAT.format(value);
    }

    public static String formatPercent(double value) {
        return Math.round(Math.max(0.0, Math.min(100.0, value))) + "%";
    }

    public static String strip(String input) {
        return input == null ? "" : ChatColor.stripColor((String)Text.color(input));
    }

    public static Component component(String input) {
        if (input == null) {
            return Component.empty();
        }
        return LegacyComponentSerializer.legacyAmpersand().deserialize(input);
    }

    public static Component componentNoItalics(String input) {
        return Text.component(input).decoration(TextDecoration.ITALIC, false);
    }

    public static String center(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        String stripped = Text.strip(input);
        if (stripped.isEmpty()) {
            return input;
        }
        int messagePxSize = Text.messagePxSize(input);
        int halvedMessageSize = messagePxSize / 2;
        int toCompensate = CENTER_PX - halvedMessageSize;
        int spaceLength = SPACE_PX + 1;
        int compensated = 0;
        StringBuilder builder = new StringBuilder();
        while (compensated < toCompensate) {
            builder.append(' ');
            compensated += spaceLength;
        }
        return builder + input;
    }

    private static int messagePxSize(String message) {
        int size = 0;
        boolean bold = false;
        for (int i = 0; i < message.length(); ++i) {
            char c = message.charAt(i);
            if (c == '&' && i + 1 < message.length()) {
                char code = Character.toLowerCase(message.charAt(i + 1));
                if (code == 'l') {
                    bold = true;
                } else if (code == 'r') {
                    bold = false;
                }
                ++i;
                continue;
            }
            if (c >= CHAR_WIDTHS.length) {
                size += 5;
                if (bold) {
                    ++size;
                }
                continue;
            }
            size += CHAR_WIDTHS[c];
            if (bold && c != ' ') {
                ++size;
            }
            ++size;
        }
        return size;
    }
}
