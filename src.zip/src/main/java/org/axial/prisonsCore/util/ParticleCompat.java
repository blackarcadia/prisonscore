/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 */
package org.axial.prisonsCore.util;

import org.bukkit.Location;
import org.bukkit.World;

public class ParticleCompat {
    public static void spawnExplosion(World world, Location loc) {
        if (world == null || loc == null) {
            return;
        }
        if (ParticleCompat.tryParticle(world, loc, "EXPLOSION_NORMAL", 8, 0.3)) {
            return;
        }
        if (ParticleCompat.tryParticle(world, loc, "EXPLOSION_LARGE", 1, 0.0)) {
            return;
        }
        if (ParticleCompat.tryEffect(world, loc, "EXPLOSION")) {
            return;
        }
    }

    private static boolean tryParticle(World world, Location loc, String name, int count, double spread) {
        try {
            Class<?> particleClass = Class.forName("org.bukkit.Particle");
            Object particle = Enum.valueOf((Class)particleClass, name);
            world.getClass().getMethod("spawnParticle", particleClass, Location.class, Integer.TYPE, Double.TYPE, Double.TYPE, Double.TYPE, Double.TYPE).invoke((Object)world, particle, loc, count, spread, spread, spread, 0.02);
            return true;
        }
        catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean tryEffect(World world, Location loc, String name) {
        try {
            Class<?> effectClass = Class.forName("org.bukkit.Effect");
            Object effect = Enum.valueOf((Class)effectClass, name);
            world.getClass().getMethod("playEffect", Location.class, effectClass, Integer.TYPE).invoke((Object)world, loc, effect, 0);
            return true;
        }
        catch (Throwable ignored) {
            return false;
        }
    }
}
