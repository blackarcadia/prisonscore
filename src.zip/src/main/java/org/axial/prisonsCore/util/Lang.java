/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.util;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.axial.prisonsCore.util.LanguageService;
import org.axial.prisonsCore.util.Text;

public class Lang {
    private static LanguageService service;

    public static void init(LanguageService svc) {
        service = svc;
    }

    public static String msg(String path, String def) {
        return service == null ? Text.color(def) : service.get(path, def);
    }

    public static String msg(String path, String def, Map<String, String> placeholders) {
        return service == null ? Text.color(def) : service.get(path, def, placeholders);
    }

    public static List<String> list(String path, List<String> def) {
        return service == null ? def.stream().map(Text::color).collect(Collectors.toList()) : service.getList(path, def);
    }
}
