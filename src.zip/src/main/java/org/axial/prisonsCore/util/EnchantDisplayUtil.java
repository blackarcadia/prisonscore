package org.axial.prisonsCore.util;

import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.service.GearEnchantService;

public final class EnchantDisplayUtil {
    private EnchantDisplayUtil() {
    }

    public static String format(CustomEnchantService service, String enchantId, int level) {
        if (service != null && enchantId != null) {
            CustomEnchant enchant = service.getById(enchantId);
            if (enchant != null) {
                return Text.color(resolveLevelLine(enchant, level));
            }
        }
        return Text.color("&f&l" + humanize(enchantId) + " &b&l" + roman(level));
    }

    public static String format(GearEnchantService service, String enchantId, int level) {
        if (service != null && enchantId != null) {
            CustomEnchant enchant = service.getById(enchantId);
            if (enchant != null) {
                return Text.color(resolveLevelLine(enchant, level));
            }
        }
        return Text.color("&f&l" + humanize(enchantId) + " &b&l" + roman(level));
    }

    private static String resolveLevelLine(CustomEnchant enchant, int level) {
        if (enchant == null) {
            return "&f&lEnchant &b&l" + roman(level);
        }
        if (!enchant.getDisplayNameLevels().isEmpty()) {
            int idx = Math.min(Math.max(1, level) - 1, enchant.getDisplayNameLevels().size() - 1);
            return enchant.getDisplayNameLevels().get(idx);
        }
        if (!enchant.getLoreFormatLevels().isEmpty()) {
            int idx = Math.min(Math.max(1, level) - 1, enchant.getLoreFormatLevels().size() - 1);
            return enchant.getLoreFormatLevels().get(idx);
        }
        return enchant.getDisplayName() + " " + roman(level);
    }

    private static String humanize(String value) {
        if (value == null || value.isBlank()) {
            return "Enchant";
        }
        String[] parts = value.replace('_', ' ').trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }
            if (sb.length() > 0) {
                sb.append(' ');
            }
            sb.append(Character.toUpperCase(part.charAt(0)));
            if (part.length() > 1) {
                sb.append(part.substring(1).toLowerCase());
            }
        }
        return sb.length() > 0 ? sb.toString() : "Enchant";
    }

    private static String roman(int number) {
        int n = Math.max(1, number);
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                sb.append(numerals[i]);
                n -= values[i];
            }
        }
        return sb.toString();
    }
}
