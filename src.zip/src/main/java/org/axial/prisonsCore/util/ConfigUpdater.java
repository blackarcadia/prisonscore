/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.configuration.Configuration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.plugin.java.JavaPlugin
 */
package org.axial.prisonsCore.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import org.bukkit.configuration.Configuration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

public final class ConfigUpdater {
    private ConfigUpdater() {
    }

    public static void saveDefaultAndMerge(JavaPlugin plugin, String resourcePath) {
        File destination = new File(plugin.getDataFolder(), resourcePath);
        if (!destination.getParentFile().exists() && !destination.getParentFile().mkdirs()) {
            plugin.getLogger().warning("Could not create parent directories for " + destination.getAbsolutePath());
            return;
        }
        try (InputStream defaultStream = plugin.getResource(resourcePath);){
            if (defaultStream == null) {
                plugin.getLogger().warning("Missing bundled resource: " + resourcePath);
                return;
            }
            YamlConfiguration defaults = YamlConfiguration.loadConfiguration((Reader)new InputStreamReader(defaultStream, StandardCharsets.UTF_8));
            YamlConfiguration liveConfig = YamlConfiguration.loadConfiguration((File)destination);
            liveConfig.setDefaults((Configuration)defaults);
            liveConfig.options().copyDefaults(true);
            liveConfig.save(destination);
        }
        catch (IOException exception) {
            plugin.getLogger().log(Level.SEVERE, "Failed to update configuration file: " + resourcePath, exception);
        }
    }
}

