package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.BankNoteService;
import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.util.Lang;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public class BankNoteListener implements Listener {
    private final EconomyService economyService;
    private final BankNoteService bankNoteService;

    public BankNoteListener(EconomyService economyService, BankNoteService bankNoteService) {
        this.economyService = economyService;
        this.bankNoteService = bankNoteService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.bankNoteService.isBankNote(item)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        Player player = event.getPlayer();
        double amount = this.bankNoteService.getAmount(item);
        if (amount <= 0.0) {
            player.sendMessage(Lang.msg("economy.banknote-invalid", "&cThat bank note is invalid."));
            return;
        }
        this.economyService.deposit(player, amount);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(Lang.msg("economy.banknote-redeemed", "&aRedeemed bank note for &2{amount}&a.").replace("{amount}", this.economyService.format(amount)));
        int newAmount = item.getAmount() - 1;
        if (newAmount <= 0) {
            player.getInventory().setItem(event.getHand(), null);
        } else {
            item.setAmount(newAmount);
            player.getInventory().setItem(event.getHand(), item);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onCombine(InventoryClickEvent event) {
        if (!(event.getClickedInventory() instanceof PlayerInventory)) {
            return;
        }
        ItemStack cursor = event.getCursor();
        ItemStack target = event.getCurrentItem();
        if (!this.bankNoteService.isBankNote(cursor) || !this.bankNoteService.isBankNote(target)) {
            return;
        }
        double combined = this.bankNoteService.getTotalAmount(cursor) + this.bankNoteService.getTotalAmount(target);
        event.setCurrentItem(this.bankNoteService.createBankNote(combined));
        event.setCursor(null);
        event.setCancelled(true);
        HumanEntity clicker = event.getWhoClicked();
        if (clicker instanceof Player player) {
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        }
    }
}
