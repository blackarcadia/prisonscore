package org.axial.prisonsCore.listener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.cell.guard.CellGuardService;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.BankNoteService;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.PlayerToggleService;
import org.axial.prisonsCore.service.PlayerToggleService.Toggle;
import org.axial.prisonsCore.util.EnchantDisplayUtil;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class GearEnchantListener implements Listener {
    private static final NamespacedKey QUICK_FEET_KEY = new NamespacedKey("prisonscore", "quick_feet_speed");
    private static final NamespacedKey HEALTH_BOOST_KEY = new NamespacedKey("prisonscore", "health_boost");
    private static final double PROC_MULTIPLIER = 0.20D;
    private final PrisonsCore plugin;
    private final PickaxeManager pickaxeManager;
    private final GearManager gearManager;
    private final GearEnchantService gearEnchantService;
    private final BankNoteService bankNoteService;
    private final GuardService guardService;
    private final CellGuardService cellGuardService;
    private BukkitTask refreshTask;
    private final Map<UUID, Long> silencedUntil = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, Long> bloodUntil = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, Long> weaknessUntil = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, Integer> frenzyStacks = new ConcurrentHashMap<UUID, Integer>();
    private final Map<UUID, BukkitTask> bleedTasks = new ConcurrentHashMap<UUID, BukkitTask>();
    private final Map<UUID, BukkitTask> toxicityTasks = new ConcurrentHashMap<UUID, BukkitTask>();
    private final Map<UUID, BukkitTask> magicVisionTasks = new ConcurrentHashMap<UUID, BukkitTask>();

    public GearEnchantListener(PrisonsCore plugin, PickaxeManager pickaxeManager, GearManager gearManager, GearEnchantService gearEnchantService, BankNoteService bankNoteService, GuardService guardService, CellGuardService cellGuardService) {
        this.plugin = plugin;
        this.pickaxeManager = pickaxeManager;
        this.gearManager = gearManager;
        this.gearEnchantService = gearEnchantService;
        this.bankNoteService = bankNoteService;
        this.guardService = guardService;
        this.cellGuardService = cellGuardService;
    }

    public void start() {
        if (this.refreshTask != null) {
            this.refreshTask.cancel();
        }
        this.refreshTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, this::refreshAll, 1L, 20L);
        this.refreshAll();
    }

    public void stop() {
        if (this.refreshTask != null) {
            this.refreshTask.cancel();
            this.refreshTask = null;
        }
        for (BukkitTask task : this.bleedTasks.values()) {
            if (task != null) {
                task.cancel();
            }
        }
        for (BukkitTask task : this.toxicityTasks.values()) {
            if (task != null) {
                task.cancel();
            }
        }
        for (BukkitTask task : this.magicVisionTasks.values()) {
            if (task != null) {
                task.cancel();
            }
        }
        this.bleedTasks.clear();
        this.toxicityTasks.clear();
        this.magicVisionTasks.clear();
        this.silencedUntil.clear();
        this.bloodUntil.clear();
        this.weaknessUntil.clear();
        this.frenzyStacks.clear();
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.clearQuickFeet(player);
            this.clearHealthBoost(player);
            this.clearSprings(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        this.clearQuickFeet(event.getPlayer());
        this.clearHealthBoost(event.getPlayer());
        this.clearSprings(event.getPlayer());
        this.clearCombatState(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent event) {
        this.clearCombatState(event.getPlayer().getUniqueId());
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onWorldChange(PlayerChangedWorldEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onHeldItemChange(PlayerItemHeldEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwapHandItems(PlayerSwapHandItemsEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            this.refreshLater(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            this.refreshLater(player);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        Entity victimEntity = event.getEntity();
        Entity damager = event.getDamager();
        LivingEntity attacker = this.getLivingAttacker(damager);
        if (!(victimEntity instanceof LivingEntity victim) || attacker == null) {
            return;
        }
        if (victim instanceof Player playerVictim && attacker instanceof Player playerAttacker) {
            ArrayList<String> attackerProcs = new ArrayList<String>();
            ArrayList<String> victimProcs = new ArrayList<String>();
            if (!this.isSilenced(playerAttacker.getUniqueId())) {
                this.handleWeaponProcs(playerAttacker, playerVictim, event, attackerProcs);
            }
            if (!this.isSilenced(playerVictim.getUniqueId())) {
                this.applyProtection(playerVictim, event, damager, playerAttacker, victimProcs);
                this.applyArmorCombatProcs(playerVictim, event, damager, playerAttacker, victimProcs);
            }
            if (!this.isSilenced(playerAttacker.getUniqueId())) {
                ItemStack weapon = playerAttacker.getInventory().getItemInMainHand();
                if (weapon != null && this.gearManager.isGear(weapon)) {
                    this.tryLifesteal(playerAttacker, weapon, this.gearManager.getEnchants(weapon), event.getDamage(), attackerProcs);
                }
            }
            this.sendCombatActionBar(playerAttacker, attackerProcs);
            this.sendCombatActionBar(playerVictim, victimProcs);
            this.clearFrenzy(playerVictim.getUniqueId());
            return;
        }
        this.handleLivingCombat(attacker, victim, damager, event);
        if (attacker instanceof Player playerAttacker && this.isGuardOrCellGuard(victimEntity) && !this.isSilenced(playerAttacker.getUniqueId())) {
            this.applyGuardHunter(playerAttacker, victimEntity, event);
            ItemStack weapon = playerAttacker.getInventory().getItemInMainHand();
            if (weapon != null && this.gearManager.isGear(weapon)) {
                this.tryLifesteal(playerAttacker, weapon, this.gearManager.getEnchants(weapon), event.getDamage(), null);
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent event) {
        if (event == null || event.getEntity() == null) {
            return;
        }
        if (!event.getEntity().getScoreboardTags().contains("magic-vision-clone")) {
            return;
        }
        event.getDrops().clear();
        event.setDroppedExp(0);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onItemDamage(PlayerItemDamageEvent event) {
        ItemStack item = event.getItem();
        if (!this.isArmor(item)) {
            return;
        }
        ArrayList<String> procs = new ArrayList<String>();
        this.tryBloodSport(event, item, procs);
        this.tryArmorDurabilityEnchant(event, item, "hardened", 1.0D, procs);
        this.tryArmorDurabilityEnchant(event, item, "rejuvenate", 2.0D, procs);
        this.sendCombatActionBar(event.getPlayer(), procs);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMine(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player == null || this.pickaxeManager == null || !this.pickaxeManager.isPrisonPickaxe(player.getInventory().getItemInMainHand())) {
            return;
        }
        Material type = event.getBlock().getType();
        if (!type.name().endsWith("_ORE") && type != Material.ANCIENT_DEBRIS) {
            return;
        }
        ItemStack[] armor = player.getInventory().getArmorContents();
        int totalLevel = 0;
        int totalChance = 0;
        CustomEnchant enchant = this.gearEnchantService.getById("gold_mine");
        if (enchant == null) {
            return;
        }
        for (ItemStack piece : armor) {
            if (!this.isArmor(piece) || !enchant.isApplicableTo(piece.getType())) {
                continue;
            }
            int level = this.getEnchantLevel(piece, "gold_mine");
            if (level <= 0) {
                continue;
            }
            totalLevel += level;
            totalChance += this.scaledChance((int)Math.round(enchant.getProcChanceForLevel(level, enchant.getSuccessChance())));
        }
        if (totalLevel <= 0 || totalChance <= 0) {
            return;
        }
        if (!this.roll(this.scaledChance(Math.min(100, totalChance)))) {
            return;
        }
        double amount = Math.max(50.0D, (double)(totalLevel * 50));
        ItemStack note = this.bankNoteService.createBankNote(amount);
        this.giveOrDrop(player, note);
    }

    private void refreshAll() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            this.refreshPlayer(player);
        }
    }

    private void refreshLater(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.refreshPlayer(player));
    }

    private void refreshPlayer(Player player) {
        if (player == null || !player.isOnline()) {
            return;
        }
        ItemStack boots = player.getInventory().getBoots();
        int level = this.getEnchantLevel(boots, "quick_feet");
        if (level > 0) {
            this.applyQuickFeet(player, level);
        } else {
            this.clearQuickFeet(player);
        }
        int springs = this.getEnchantLevel(boots, "springs");
        if (springs > 0) {
            player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 40, Math.max(0, springs - 1), true, false, true));
        } else {
            this.clearSprings(player);
        }
        this.applyHealthBoost(player);
    }

    private void applyQuickFeet(Player player, int level) {
        AttributeInstance movement = player.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movement == null) {
            return;
        }
        this.removeModifier(movement, QUICK_FEET_KEY);
        double bonus = 0.20D * (double)Math.max(1, Math.min(3, level));
        movement.addTransientModifier(new AttributeModifier(QUICK_FEET_KEY, bonus, AttributeModifier.Operation.MULTIPLY_SCALAR_1));
    }

    private void clearQuickFeet(Player player) {
        if (player == null) {
            return;
        }
        AttributeInstance movement = player.getAttribute(Attribute.MOVEMENT_SPEED);
        if (movement != null) {
            this.removeModifier(movement, QUICK_FEET_KEY);
        }
    }

    private void applyHealthBoost(Player player) {
        Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
        AttributeInstance maxHealth = maxHealthAttribute != null ? player.getAttribute(maxHealthAttribute) : null;
        if (maxHealth == null) {
            return;
        }
        this.removeModifier(maxHealth, HEALTH_BOOST_KEY);
        int highestLevel = 0;
        EntityEquipment equipment = player.getEquipment();
        if (equipment != null) {
            highestLevel = Math.max(highestLevel, this.getEnchantLevel(equipment.getHelmet(), "health_boost"));
            highestLevel = Math.max(highestLevel, this.getEnchantLevel(equipment.getChestplate(), "health_boost"));
            highestLevel = Math.max(highestLevel, this.getEnchantLevel(equipment.getLeggings(), "health_boost"));
            highestLevel = Math.max(highestLevel, this.getEnchantLevel(equipment.getBoots(), "health_boost"));
        }
        if (highestLevel <= 0) {
            if (player.getHealth() > this.getMaxHealth(player)) {
                player.setHealth(this.getMaxHealth(player));
            }
            return;
        }
        maxHealth.addTransientModifier(new AttributeModifier(HEALTH_BOOST_KEY, (double)(highestLevel * 2), AttributeModifier.Operation.ADD_NUMBER));
        double max = this.getMaxHealth(player);
        if (player.getHealth() > max) {
            player.setHealth(max);
        }
    }

    private void clearHealthBoost(Player player) {
        Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
        AttributeInstance maxHealth = maxHealthAttribute != null ? player.getAttribute(maxHealthAttribute) : null;
        if (maxHealth == null) {
            return;
        }
        this.removeModifier(maxHealth, HEALTH_BOOST_KEY);
        double max = this.getMaxHealth(player);
        if (player.getHealth() > max) {
            player.setHealth(max);
        }
    }

    private void handleWeaponProcs(LivingEntity attacker, LivingEntity victim, EntityDamageByEntityEvent event, List<String> procs) {
        ItemStack weapon = attacker.getEquipment() != null ? attacker.getEquipment().getItemInMainHand() : null;
        if (weapon == null || weapon.getType().isAir() || !this.gearManager.isGear(weapon)) {
            return;
        }
        Map<String, Integer> enchants = this.gearManager.getEnchants(weapon);
        if (enchants.isEmpty()) {
            return;
        }
        double damage = event.getDamage();
        damage = this.applyWeaponDamageModifiers(attacker, victim, weapon, enchants, damage, event);
        event.setDamage(damage);
        this.tryScorche(victim, weapon, enchants, procs);
        this.tryConfusion(victim, weapon, enchants, procs);
        this.trySlowBlade(victim, weapon, enchants, procs);
        this.tryDaze(victim, weapon, enchants, procs);
        this.tryPoison(victim, weapon, enchants, procs);
        this.tryHungerReplenish(attacker, weapon, enchants, procs);
        this.tryParalyze(victim, weapon, enchants, event, procs);
        this.tryPummel(attacker, victim, weapon, enchants, event, procs);
        this.tryBleed(victim, weapon, enchants, procs);
        this.tryBerserker(attacker, weapon, enchants, procs);
        this.tryWeakness(victim, weapon, enchants, procs);
        this.trySilence(victim, weapon, enchants, procs);
        this.applyMoleculeRepair(attacker, enchants, procs);
    }

    private void handleLivingCombat(LivingEntity attacker, LivingEntity victim, Entity damager, EntityDamageByEntityEvent event) {
        ArrayList<String> attackerProcs = new ArrayList<String>();
        ArrayList<String> victimProcs = new ArrayList<String>();
        if (!this.isSilenced(attacker.getUniqueId())) {
            this.handleWeaponProcs(attacker, victim, event, attackerProcs);
        }
        if (!this.isSilenced(victim.getUniqueId())) {
            this.applyProtection(victim, event, damager, attacker, victimProcs);
            this.applyArmorCombatProcs(victim, event, damager, attacker, victimProcs);
        }
        if (attacker instanceof Player playerAttacker) {
            this.sendCombatActionBar(playerAttacker, attackerProcs);
        }
        if (victim instanceof Player playerVictim) {
            this.sendCombatActionBar(playerVictim, victimProcs);
        }
        this.clearFrenzy(victim.getUniqueId());
    }

    private double applyWeaponDamageModifiers(LivingEntity attacker, LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, double damage, EntityDamageByEntityEvent event) {
        damage = this.applyExecution(attacker, victim, weapon, enchants, damage);
        damage = this.applyFearful(attacker, victim, weapon, enchants, damage);
        damage = this.applySwordsman(attacker, victim, weapon, enchants, damage);
        damage = this.applyFrenzy(attacker, weapon, enchants, damage);
        return Math.max(0.0D, damage);
    }

    private void applyGuardHunter(Player attacker, Entity victim, EntityDamageByEntityEvent event) {
        int level = this.getArmorEnchantTotal(attacker, "guard_hunter");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("guard_hunter");
        if (enchant == null) {
            return;
        }
        event.setDamage(event.getDamage() * (1.0D + 0.08D * (double)level));
    }

    private void tryScorche(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        if (victim instanceof Player playerVictim && this.plugin.getAxialSkinsModule() != null && this.plugin.getAxialSkinsModule().hasKryoHelmetEquipped(playerVictim)) {
            return;
        }
        int level = this.getEnchantLevel(weapon, enchants, "scorche");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("scorche");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        int chance = this.scaledChance(enchant, level);
        if (!this.roll(chance)) {
            return;
        }
        Location loc = victim.getLocation().add(0.0, 1.0, 0.0);
        victim.getWorld().spawnParticle(Particle.FLAME, loc, 24, 0.35, 0.45, 0.35, 0.01);
        victim.setFireTicks(Math.max(victim.getFireTicks(), 40 + level * 20));
        this.clearFrenzy(victim.getUniqueId());
        victim.damage(0.5D + 0.25D * (double)level);
        this.addProc(procs, "scorche", level);
    }

    private void tryConfusion(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "confusion");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("confusion");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        int chance = this.scaledChance(enchant, level);
        if (!this.roll(chance)) {
            return;
        }
        victim.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 40 + level * 20, 0, true, false, true));
        this.addProc(procs, "confusion", level);
    }

    private void trySlowBlade(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "slow_blade");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("slow_blade");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        int chance = this.scaledChance(enchant, level);
        if (!this.roll(chance)) {
            return;
        }
        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40 + level * 20, Math.max(0, level - 1), true, false, true));
        this.addProc(procs, "slow_blade", level);
    }

    private void tryDaze(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "daze");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("daze");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        victim.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 60 + level * 20, 0, true, false, true));
        this.addProc(procs, "daze", level);
    }

    private void tryPoison(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "poison");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("poison");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        victim.addPotionEffect(new PotionEffect(PotionEffectType.POISON, 60 + level * 20, Math.max(0, level - 1), true, false, true));
        this.addProc(procs, "poison", level);
    }

    private void tryHungerReplenish(LivingEntity attacker, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "hunger_replenish");
        if (level <= 0 || !(attacker instanceof Player player)) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("hunger_replenish");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        player.setFoodLevel(Math.min(20, player.getFoodLevel() + 1 + level / 2));
        player.setSaturation(Math.min(20.0F, player.getSaturation() + 1.5F + (float)level * 0.5F));
        this.addProc(procs, "hunger_replenish", level);
    }

    private void tryParalyze(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, EntityDamageByEntityEvent event, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "paralyze");
        if (level <= 0) {
            return;
        }
        if (victim instanceof Player playerVictim && this.plugin.getAxialSkinsModule() != null && this.plugin.getAxialSkinsModule().hasFloatyFlamingoEquipped(playerVictim)) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("paralyze");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        victim.getWorld().strikeLightningEffect(victim.getLocation());
        victim.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40 + level * 10, Math.min(2, level - 1), true, false, true));
        event.setDamage(event.getDamage() + (double)level * 0.75D);
        this.addProc(procs, "paralyze", level);
    }

    private void tryPummel(LivingEntity attacker, LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, EntityDamageByEntityEvent event, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "pummel");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("pummel");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        this.spawnPummelAnimation(attacker, victim, level);
        this.addProc(procs, "pummel", level);
    }

    private void tryBleed(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "bleed");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("bleed");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        this.startBleed(victim, level);
        this.addProc(procs, "bleed", level);
    }

    private void tryLifesteal(LivingEntity attacker, ItemStack weapon, Map<String, Integer> enchants, double damage, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "lifesteal");
        if (level <= 0 || attacker == null) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("lifesteal");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        double heal = Math.max(0.5D, damage * (0.08D * (double)level));
        double max = this.getMaxHealth(attacker);
        attacker.setHealth(Math.min(max, attacker.getHealth() + heal));
        this.addProc(procs, "lifesteal", level);
    }

    private void tryBerserker(LivingEntity attacker, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "beserker");
        if (level <= 0 || attacker == null) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("beserker");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        attacker.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 60 + level * 20, Math.max(0, level - 1), true, false, true));
        attacker.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 60 + level * 20, 0, true, false, true));
        this.addProc(procs, "beserker", level);
    }

    private void tryWeakness(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "weakness");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("weakness");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        this.weaknessUntil.put(victim.getUniqueId(), System.currentTimeMillis() + (long)(4000 + level * 1000));
        this.addProc(procs, "weakness", level);
    }

    private void trySilence(LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, List<String> procs) {
        int level = this.getEnchantLevel(weapon, enchants, "silence");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("silence");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        this.silencedUntil.put(victim.getUniqueId(), System.currentTimeMillis() + (long)(1200 + level * 250));
        this.addProc(procs, "silence", level);
    }

    private double applyExecution(LivingEntity attacker, LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, double damage) {
        int level = this.getEnchantLevel(weapon, enchants, "execution");
        if (level <= 0 || !this.isWeapon(weapon) || !this.isSwordOrAxe(weapon)) {
            return damage;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("execution");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return damage;
        }
        double distance = attacker.getLocation().distance(victim.getLocation());
        double closeness = Math.max(0.0D, 1.0D - Math.min(6.0D, distance) / 6.0D);
        return damage * (1.0D + closeness * (0.08D * (double)level));
    }

    private double applyFearful(LivingEntity attacker, LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, double damage) {
        int level = this.getEnchantLevel(weapon, enchants, "fearful");
        if (level <= 0 || !this.isSwordOrAxe(weapon)) {
            return damage;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("fearful");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return damage;
        }
        double distance = attacker.getLocation().distance(victim.getLocation());
        double closeness = Math.max(0.0D, 1.0D - Math.min(8.0D, distance) / 8.0D);
        double multiplier = 1.0D + closeness * (0.12D * (double)level) - (1.0D - closeness) * (0.20D * (double)level);
        return damage * Math.max(0.25D, multiplier);
    }

    private double applySwordsman(LivingEntity attacker, LivingEntity victim, ItemStack weapon, Map<String, Integer> enchants, double damage) {
        int level = this.getEnchantLevel(weapon, enchants, "swordsman");
        if (level <= 0 || !weapon.getType().name().endsWith("_SWORD")) {
            return damage;
        }
        ItemStack victimHand = victim.getEquipment() != null ? victim.getEquipment().getItemInMainHand() : null;
        if (victimHand == null || !victimHand.getType().name().endsWith("_AXE")) {
            return damage;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("swordsman");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return damage;
        }
        return damage * (1.0D + 0.08D * (double)level);
    }

    private double applyFrenzy(LivingEntity attacker, ItemStack weapon, Map<String, Integer> enchants, double damage) {
        int level = this.getEnchantLevel(weapon, enchants, "frenzy");
        if (level <= 0) {
            return damage;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("frenzy");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return damage;
        }
        int stacks = this.frenzyStacks.getOrDefault(attacker.getUniqueId(), 0);
        double bonus = Math.min(0.50D, (double)stacks * (0.04D + (double)level * 0.01D));
        int cap = Math.max(3, level * 3);
        this.frenzyStacks.put(attacker.getUniqueId(), Math.min(cap, stacks + 1));
        return damage * (1.0D + bonus);
    }

    private double applyGuardHunter(Player attacker, ItemStack weapon, Map<String, Integer> enchants, double damage) {
        int level = this.getEnchantLevel(weapon, enchants, "guard_hunter");
        if (level <= 0) {
            return damage;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("guard_hunter");
        if (enchant == null || !enchant.isApplicableTo(weapon.getType())) {
            return damage;
        }
        return damage * (1.0D + 0.10D * (double)level);
    }

    private void applyProtection(LivingEntity victim, EntityDamageByEntityEvent event, Entity damager, LivingEntity attacker, List<String> procs) {
        EntityEquipment equipment = victim.getEquipment();
        if (equipment == null) {
            return;
        }
        double damage = event.getDamage();
        int protection = this.getArmorEnchantTotal(victim, "protection");
        if (protection > 0) {
            damage *= 1.0D - Math.min(0.20D, (double)protection * 0.04D);
        }
        int crouch = this.getArmorEnchantTotal(victim, "crouch");
        if (crouch > 0 && victim.isSneaking()) {
            damage *= 1.0D - Math.min(0.40D, (double)crouch * 0.05D);
        }
        if (this.isActive(this.bloodUntil, victim.getUniqueId())) {
            damage *= 0.80D;
        }
        int blood = this.getArmorEnchantTotal(victim, "blood");
        if (blood > 0 && this.roll(this.scaledChance(Math.min(100, blood * 12)))) {
            this.bloodUntil.put(victim.getUniqueId(), System.currentTimeMillis() + 5000L + (long)blood * 500L);
            damage *= 0.75D;
            this.addProc(procs, "blood", blood);
        }
        int weakness = this.getArmorEnchantTotal(victim, "weakness");
        if (weakness > 0 && this.isActive(this.weaknessUntil, victim.getUniqueId())) {
            damage *= 1.20D;
        }
        int tank = this.getArmorEnchantTotal(victim, "tank");
        ItemStack attackerWeapon = attacker != null && attacker.getEquipment() != null ? attacker.getEquipment().getItemInMainHand() : null;
        if (tank > 0 && attackerWeapon != null && attackerWeapon.getType().name().endsWith("_AXE")) {
            damage *= 1.0D - Math.min(0.35D, (double)tank * 0.05D);
        }
        int bloated = this.getArmorEnchantTotal(victim, "bloated");
        if (bloated > 0 && this.isGuardOrCellGuard(damager)) {
            damage *= 1.0D - Math.min(0.40D, (double)bloated * 0.05D);
        }
        event.setDamage(Math.max(0.0D, damage));
    }

    private void applyArmorCombatProcs(LivingEntity victim, EntityDamageByEntityEvent event, Entity damager, LivingEntity attacker, List<String> procs) {
        EntityEquipment equipment = victim.getEquipment();
        if (equipment == null) {
            return;
        }
        this.tryShockwave(victim, damager, attacker, equipment, procs);
        this.tryCactus(victim, damager, event, equipment, procs);
        this.tryMagicVision(victim, equipment, procs);
        this.tryToxicity(victim, equipment, procs);
    }

    private void tryShockwave(LivingEntity victim, Entity damager, LivingEntity attacker, EntityEquipment equipment, List<String> procs) {
        int shockwave = this.getArmorEnchantTotal(victim, "shockwave");
        LivingEntity target = attacker != null ? attacker : (damager instanceof LivingEntity living ? living : null);
        if (shockwave <= 0 || target == null) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("shockwave");
        if (enchant == null) {
            return;
        }
        if (!this.roll(this.scaledChance(Math.min(100, shockwave * 12)))) {
            return;
        }
        Vector push = target.getLocation().toVector().subtract(victim.getLocation().toVector());
        if (push.lengthSquared() < 1.0E-6D) {
            push = victim.getLocation().getDirection().clone();
        }
        push.normalize().multiply(0.9D + (double)shockwave * 0.15D);
        push.setY(0.35D + (double)shockwave * 0.04D);
        target.setVelocity(push);
        victim.getWorld().spawnParticle(Particle.CLOUD, victim.getLocation().add(0.0D, 1.0D, 0.0D), 16, 0.35D, 0.25D, 0.35D, 0.05D);
        this.addProc(procs, "shockwave", shockwave);
    }

    private void tryCactus(LivingEntity victim, Entity damager, EntityDamageByEntityEvent event, EntityEquipment equipment, List<String> procs) {
        ItemStack leggings = equipment.getLeggings();
        int level = this.getEnchantLevel(leggings, "cactus");
        if (level <= 0 || !this.isLivingDamageTarget(damager)) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("cactus");
        if (enchant == null || !enchant.isApplicableTo(leggings.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        double reflect = Math.max(0.25D, event.getDamage() * 0.30D);
        ((LivingEntity)damager).damage(reflect);
        this.addProc(procs, "cactus", level);
    }

    private void tryMagicVision(LivingEntity victim, EntityEquipment equipment, List<String> procs) {
        if (!(victim instanceof Player playerVictim)) {
            return;
        }
        int level = this.getArmorEnchantTotal(victim, "magic_vision");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("magic_vision");
        if (enchant == null) {
            return;
        }
        if (!this.roll(this.scaledChance(Math.min(100, level * 14)))) {
            return;
        }
        this.spawnMagicVisionCopies(playerVictim, Math.max(2, level));
        this.addProc(procs, "magic_vision", level);
    }

    private void tryToxicity(LivingEntity victim, EntityEquipment equipment, List<String> procs) {
        int level = this.getArmorEnchantTotal(victim, "toxicity");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("toxicity");
        if (enchant == null) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        this.startToxicityCloud(victim.getLocation(), victim.getUniqueId(), level);
        this.addProc(procs, "toxicity", level);
    }

    private void tryBloodSport(PlayerItemDamageEvent event, ItemStack item, List<String> procs) {
        int level = this.getEnchantLevel(item, "blood_sport");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("blood_sport");
        if (enchant == null || !enchant.isApplicableTo(item.getType())) {
            return;
        }
        int chance = this.scaledChance(enchant, level);
        if (!this.roll(chance)) {
            return;
        }
        event.setDamage(event.getDamage() + Math.max(0, level / 2));
        if (event.getPlayer() != null) {
            Player player = event.getPlayer();
            double heal = 1.0D + 0.5D * (double)Math.max(0, level - 1);
            double max = this.getMaxHealth(player);
            player.setHealth(Math.min(max, player.getHealth() + heal));
        }
        this.addProc(procs, "blood_sport", level);
    }

    private void tryArmorDurabilityEnchant(PlayerItemDamageEvent event, ItemStack item, String id, double repairPerLevel, List<String> procs) {
        int level = this.getEnchantLevel(item, id);
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById(id);
        if (enchant == null || !enchant.isApplicableTo(item.getType())) {
            return;
        }
        if (!this.roll(this.scaledChance(enchant, level))) {
            return;
        }
        event.setDamage(Math.max(0, event.getDamage() - Math.max(1, (int)Math.round(repairPerLevel * (double)level))));
        this.addProc(procs, id, level);
    }

    private void applyMoleculeRepair(LivingEntity attacker, Map<String, Integer> enchants, List<String> procs) {
        EntityEquipment equipment = attacker.getEquipment();
        if (equipment == null) {
            return;
        }
        int level = this.getArmorEnchantTotal(attacker, "molecule");
        if (level <= 0) {
            return;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("molecule");
        if (enchant == null) {
            return;
        }
        if (!this.roll(this.scaledChance(Math.min(100, level * 10)))) {
            return;
        }
        for (ItemStack piece : new ItemStack[]{equipment.getHelmet(), equipment.getChestplate(), equipment.getLeggings(), equipment.getBoots()}) {
            if (piece == null || piece.getType().isAir() || !this.isArmor(piece)) {
                continue;
            }
            int pieceLevel = this.getEnchantLevel(piece, "molecule");
            if (pieceLevel <= 0) {
                continue;
            }
            int repair = Math.max(1, pieceLevel);
            ItemStack clone = piece.clone();
            int current = this.getItemDamage(clone);
            this.gearManager.setDamage(piece, Math.max(0, current - repair));
        }
        this.addProc(procs, "molecule", level);
    }

    private int getItemDamage(ItemStack item) {
        if (item == null || !item.hasItemMeta()) {
            return 0;
        }
        if (item.getItemMeta() instanceof Damageable damageable) {
            return damageable.getDamage();
        }
        return 0;
    }

    private void startBleed(LivingEntity victim, int level) {
        UUID victimId = victim.getUniqueId();
        this.cancelTask(this.bleedTasks.remove(victimId));
        BukkitTask task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, new Runnable(){
            int ticks = 0;

            @Override
            public void run() {
                if (victim == null || !victim.isValid() || victim.isDead()) {
                    GearEnchantListener.this.cancelTask(GearEnchantListener.this.bleedTasks.remove(victimId));
                    return;
                }
                if (this.ticks >= 60 + level * 20) {
                    GearEnchantListener.this.cancelTask(GearEnchantListener.this.bleedTasks.remove(victimId));
                    return;
                }
                ++this.ticks;
                if (this.ticks % 30 == 0) {
                    GearEnchantListener.this.clearFrenzy(victim.getUniqueId());
                    victim.damage(Math.max(0.25D, (double)level * 0.20D));
                    victim.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, victim.getLocation().add(0.0D, 1.0D, 0.0D), 6, 0.2D, 0.3D, 0.2D, 0.0D);
                }
            }
        }, 20L, 1L);
        this.bleedTasks.put(victimId, task);
    }

    private void spawnPummelAnimation(LivingEntity attacker, LivingEntity victim, int level) {
        Location start = attacker.getEyeLocation().add(attacker.getLocation().getDirection().normalize().multiply(1.5D));
        Location end = victim.getLocation().add(0.0D, 1.0D, 0.0D);
        Vector travel = end.clone().subtract(start).toVector();
        double distance = Math.max(1.0D, travel.length());
        Vector step = travel.lengthSquared() < 1.0E-6D ? new Vector(0.0D, 0.0D, 0.1D) : travel.clone().normalize().multiply(distance / 12.0D);
        for (int i = 0; i < Math.min(4, 2 + level / 2); ++i) {
            Location spawn = start.clone().add((double)i * 0.25D, 0.0D, (double)-i * 0.2D);
            BlockDisplay block = (BlockDisplay)attacker.getWorld().spawn(spawn, BlockDisplay.class, d -> {
                d.setBlock(Material.COBBLESTONE.createBlockData());
                d.setGlowing(false);
                d.setBrightness(new Display.Brightness(15, 15));
                d.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0.7f, 0.7f, 0.7f), new Quaternionf()));
            });
            ArmorStand stand = attacker.getWorld().spawn(spawn, ArmorStand.class, s -> {
                s.setInvisible(true);
                s.setMarker(true);
                s.setGravity(false);
                s.setSmall(true);
                s.setArms(false);
                s.setBasePlate(false);
                s.getEquipment().setHelmet(new ItemStack(Material.COBBLESTONE));
            });
            ItemDisplay item = (ItemDisplay)attacker.getWorld().spawn(spawn, ItemDisplay.class, d -> {
                d.setItemStack(new ItemStack(Material.COBBLESTONE));
                d.setBillboard(Display.Billboard.CENTER);
                d.setTransformation(new Transformation(new Vector3f(), new Quaternionf(), new Vector3f(0.45f, 0.45f, 0.45f), new Quaternionf()));
            });
            new BukkitRunnable() {
                int ticks = 0;

                @Override
                public void run() {
                    if (!block.isValid() || !stand.isValid() || !item.isValid() || victim.isDead()) {
                        block.remove();
                        stand.remove();
                        item.remove();
                        this.cancel();
                        return;
                    }
                    ++this.ticks;
                    Location next = block.getLocation().add(step);
                    block.teleport(next);
                    stand.teleport(next);
                    item.teleport(next);
                    attacker.getWorld().playSound(next, Sound.ITEM_ARMOR_EQUIP_WOLF, 0.65F, 0.85F);
                    if (next.distanceSquared(end) <= 1.0D || this.ticks >= 12) {
                        attacker.getWorld().playSound(end, Sound.BLOCK_ANVIL_BREAK, 0.75F, 1.1F);
                        victim.damage(0.25D + (double)level * 0.35D);
                        block.remove();
                        stand.remove();
                        item.remove();
                        this.cancel();
                    }
                }
            }.runTaskTimer((Plugin)this.plugin, 1L, 1L);
        }
    }

    private void spawnMagicVisionCopies(Player victim, int copies) {
        this.cancelTask(this.magicVisionTasks.remove(victim.getUniqueId()));
        BukkitTask task = Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            this.magicVisionTasks.remove(victim.getUniqueId());
            if (!victim.isOnline() || victim.isDead()) {
                return;
            }
            Location center = victim.getLocation().add(0.0D, 0.1D, 0.0D);
            for (int i = 0; i < copies; ++i) {
                double angle = Math.PI * 2.0D * ((double)i / (double)copies);
                Location loc = center.clone().add(Math.cos(angle) * 1.5D, 0.0D, Math.sin(angle) * 1.5D);
                LivingEntity clone = this.spawnMagicVisionClone(victim, loc);
                if (clone == null) {
                    continue;
                }
                new BukkitRunnable() {
                    int ticks = 0;

                    @Override
                    public void run() {
                if (!clone.isValid() || victim.isDead() || this.ticks >= 80) {
                    clone.remove();
                    this.cancel();
                    return;
                }
                        ++this.ticks;
                        clone.teleport(loc);
                    }
                }.runTaskTimer((Plugin)this.plugin, 1L, 1L);
            }
        }, 1L);
        this.magicVisionTasks.put(victim.getUniqueId(), task);
    }

    private LivingEntity spawnMagicVisionClone(Player victim, Location loc) {
        if (victim == null || loc == null || loc.getWorld() == null) {
            return null;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Class<?> npcRegistryClass = Class.forName("net.citizensnpcs.api.npc.NPCRegistry");
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            Class<?> entityTypeClass = Class.forName("org.bukkit.entity.EntityType");
            Object playerType = entityTypeClass.getField("PLAYER").get(null);
            Object npc = npcRegistryClass.getMethod("createNPC", entityTypeClass, String.class).invoke(registry, playerType, victim.getName());
            try {
                npcClass.getMethod("setPersistent", Boolean.TYPE).invoke(npc, false);
            }
            catch (Exception ignored) {
                // empty catch block
            }
            npcClass.getMethod("setProtected", Boolean.TYPE).invoke(npc, false);
            npcClass.getMethod("spawn", Location.class).invoke(npc, loc);
            Object entity = npcClass.getMethod("getEntity", new Class[0]).invoke(npc, new Object[0]);
            if (!(entity instanceof LivingEntity living)) {
                return null;
            }
            living.setCustomName(victim.getName());
            living.setCustomNameVisible(true);
            living.getScoreboardTags().add("magic-vision-clone");
            if (living.getEquipment() != null) {
                living.getEquipment().setHelmet(victim.getInventory().getHelmet());
                living.getEquipment().setChestplate(victim.getInventory().getChestplate());
                living.getEquipment().setLeggings(victim.getInventory().getLeggings());
                living.getEquipment().setBoots(victim.getInventory().getBoots());
                living.getEquipment().setItemInMainHand(victim.getInventory().getItemInMainHand());
            }
            return living;
        }
        catch (Exception e) {
            this.plugin.getLogger().warning("Citizens not found or failed to create magic vision NPC: " + e.getMessage());
            return null;
        }
    }

    private void startToxicityCloud(Location source, UUID excludedPlayer, int level) {
        if (source == null || source.getWorld() == null) {
            return;
        }
        this.cancelTask(this.toxicityTasks.remove(excludedPlayer));
        BukkitTask task = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, new Runnable(){
            int ticks = 0;

            @Override
            public void run() {
                if (this.ticks >= 50 + level * 12) {
                    GearEnchantListener.this.cancelTask(GearEnchantListener.this.toxicityTasks.remove(excludedPlayer));
                    return;
                }
                ++this.ticks;
                Location loc = source.clone().add(0.0D, 0.9D, 0.0D);
                source.getWorld().spawnParticle(Particle.SMOKE, loc, 60, 2.25D, 1.0D, 2.25D, 0.01D);
                source.getWorld().spawnParticle(Particle.WITCH, loc, 24, 2.25D, 1.0D, 2.25D, 0.0D);
                for (Player nearby : source.getWorld().getPlayers()) {
                    if (!nearby.getWorld().equals(source.getWorld()) || nearby.getUniqueId().equals(excludedPlayer) || nearby.getLocation().distanceSquared(source) > 49.0D) {
                        continue;
                    }
                    nearby.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, 60, 0, true, false, true));
                    GearEnchantListener.this.clearFrenzy(nearby.getUniqueId());
                    nearby.damage(Math.max(0.25D, (double)level * 0.10D));
                }
            }
        }, 10L, 10L);
        this.toxicityTasks.put(excludedPlayer, task);
    }

    private void clearSprings(Player player) {
        if (player != null) {
            player.removePotionEffect(PotionEffectType.JUMP_BOOST);
        }
    }

    private boolean isWeapon(ItemStack item) {
        if (item == null) {
            return false;
        }
        String type = item.getType().name();
        return type.endsWith("_SWORD") || type.endsWith("_AXE");
    }

    private boolean isSwordOrAxe(ItemStack item) {
        return this.isWeapon(item);
    }

    private boolean isGuardOrCellGuard(Entity entity) {
        return this.guardService != null && this.guardService.isGuard(entity) || this.cellGuardService != null && this.cellGuardService.isCellGuard(entity);
    }

    private boolean isLivingDamageTarget(Entity entity) {
        return entity instanceof LivingEntity;
    }

    private boolean isActive(Map<UUID, Long> map, UUID id) {
        Long until = map.get(id);
        return until != null && until > System.currentTimeMillis();
    }

    private boolean isSilenced(UUID id) {
        return this.isActive(this.silencedUntil, id);
    }

    private void clearCombatState(UUID id) {
        this.silencedUntil.remove(id);
        this.bloodUntil.remove(id);
        this.weaknessUntil.remove(id);
        this.frenzyStacks.remove(id);
        this.cancelTask(this.bleedTasks.remove(id));
        this.cancelTask(this.toxicityTasks.remove(id));
        this.cancelTask(this.magicVisionTasks.remove(id));
    }

    private void clearFrenzy(UUID id) {
        this.frenzyStacks.remove(id);
    }

    private void cancelTask(BukkitTask task) {
        if (task != null) {
            task.cancel();
        }
    }

    private int getArmorEnchantTotal(LivingEntity player, String id) {
        EntityEquipment equipment = player != null ? player.getEquipment() : null;
        if (equipment == null) {
            return 0;
        }
        int total = 0;
        total += this.getEnchantLevel(equipment.getHelmet(), id);
        total += this.getEnchantLevel(equipment.getChestplate(), id);
        total += this.getEnchantLevel(equipment.getLeggings(), id);
        total += this.getEnchantLevel(equipment.getBoots(), id);
        return total;
    }

    private int getEnchantLevel(ItemStack item, String id) {
        if (item == null || item.getType().isAir() || !this.gearManager.isGear(item)) {
            return 0;
        }
        CustomEnchant enchant = this.gearEnchantService.getById(id);
        if (enchant != null && !enchant.isApplicableTo(item.getType())) {
            return 0;
        }
        return this.gearManager.getEnchants(item).getOrDefault(id, 0);
    }

    private int getEnchantLevel(ItemStack item, Map<String, Integer> enchants, String id) {
        if (item == null || item.getType().isAir() || !this.gearManager.isGear(item)) {
            return 0;
        }
        CustomEnchant enchant = this.gearEnchantService.getById(id);
        if (enchant != null && !enchant.isApplicableTo(item.getType())) {
            return 0;
        }
        return enchants.getOrDefault(id, 0);
    }

    private LivingEntity getLivingAttacker(Entity entity) {
        if (entity instanceof LivingEntity living) {
            return living;
        }
        if (entity instanceof Projectile projectile && projectile.getShooter() instanceof LivingEntity living) {
            return living;
        }
        return null;
    }

    private boolean roll(int chance) {
        int clamped = Math.max(0, Math.min(100, chance));
        return ThreadLocalRandom.current().nextInt(100) < clamped;
    }

    private int scaledChance(int chance) {
        return (int)Math.round((double)Math.max(0, Math.min(100, chance)) * PROC_MULTIPLIER);
    }

    private int scaledChance(CustomEnchant enchant, int level) {
        if (enchant == null) {
            return 0;
        }
        return this.scaledChance((int)Math.round(enchant.getProcChanceForLevel(level, enchant.getSuccessChance())));
    }

    private void sendCombatActionBar(Player player, List<String> procs) {
        if (player == null || procs == null || procs.isEmpty()) {
            return;
        }
        PlayerToggleService toggleService = this.plugin != null ? this.plugin.getPlayerToggleService() : null;
        if (toggleService != null && !toggleService.isEnabled(player, Toggle.ENCHANT_PROC_ACTION_BAR)) {
            return;
        }
        player.sendActionBar(Text.color("&d" + String.join(", ", procs) + " &aPROC"));
    }

    private void addProc(List<String> procs, String enchantId, int level) {
        if (procs != null && enchantId != null && !enchantId.isBlank()) {
            procs.add(this.formatProc(enchantId, level));
        }
    }

    private String formatProc(String enchantId, int level) {
        return EnchantDisplayUtil.format(this.gearEnchantService, enchantId, level);
    }

    private void removeModifier(AttributeInstance instance, NamespacedKey key) {
        for (AttributeModifier modifier : List.copyOf(instance.getModifiers())) {
            if (key.equals(modifier.getKey())) {
                instance.removeModifier(modifier);
            }
        }
    }

    private boolean isArmor(ItemStack item) {
        if (item == null || item.getType().isAir() || !this.gearManager.isGear(item)) {
            return false;
        }
        String type = item.getType().name();
        return type.endsWith("_HELMET") || type.endsWith("_CHESTPLATE") || type.endsWith("_LEGGINGS") || type.endsWith("_BOOTS");
    }

    private double getMaxHealth(LivingEntity player) {
        Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
        AttributeInstance attr = maxHealthAttribute != null && player != null ? player.getAttribute(maxHealthAttribute) : null;
        return attr != null ? attr.getValue() : 20.0D;
    }

    private Attribute resolveMaxHealthAttribute() {
        try {
            return Attribute.valueOf("GENERIC_MAX_HEALTH");
        }
        catch (IllegalArgumentException ignored) {
            try {
                return Attribute.valueOf("MAX_HEALTH");
            }
            catch (IllegalArgumentException ex) {
                return null;
            }
        }
    }

    private void giveOrDrop(Player player, ItemStack stack) {
        Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack[]{stack});
        if (!leftover.isEmpty()) {
            leftover.values().forEach(it -> player.getWorld().dropItem(player.getLocation(), it));
        }
    }
}
