package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.PrivateMessageService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PrivateMessageListener implements Listener {
    private final PrivateMessageService privateMessageService;

    public PrivateMessageListener(PrivateMessageService privateMessageService) {
        this.privateMessageService = privateMessageService;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.privateMessageService.handleQuit(event.getPlayer().getUniqueId());
    }
}
