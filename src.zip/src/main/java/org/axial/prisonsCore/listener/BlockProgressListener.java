package org.axial.prisonsCore.listener;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.service.BlockProgressService;
import org.axial.prisonsCore.service.GeneratorService;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.OreOnlyWorldService;
import org.axial.prisonsCore.service.MeteorService;
import org.axial.prisonsCore.service.PrisonRiotService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.service.BoosterService;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockDamageEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;

public class BlockProgressListener implements Listener {

    private static final float FIST_TO_WOODEN_PICKAXE_SPEED_MULTIPLIER = 10.0f;
    private static final float WOODEN_TO_STONE_PICKAXE_SPEED_MULTIPLIER = 1.2f;
    private static final float RIOT_ORE_SPEED_MULTIPLIER = 3.0f;
    private final PickaxeManager pickaxeManager;
    private final GearManager gearManager;
    private final GearEnchantService gearEnchantService;
    private final BlockProgressService progressService;
    private final OreOnlyWorldService oreOnlyWorldService;
    private final CellService cellService;
    private final GeneratorService generatorService;
    private final MeteorService meteorService;
    private final PrisonRiotService prisonRiotService;
    private final Map<UUID, BlockFace> lastBlockFace = new ConcurrentHashMap<UUID, BlockFace>();

    public BlockProgressListener(PickaxeManager pickaxeManager,
                                 GearManager gearManager,
                                 GearEnchantService gearEnchantService,
                                 BlockProgressService progressService,
                                 OreOnlyWorldService oreOnlyWorldService,
                                 CellService cellService,
                                 GeneratorService generatorService,
                                 MeteorService meteorService,
                                 PrisonRiotService prisonRiotService) {
        this.pickaxeManager = pickaxeManager;
        this.gearManager = gearManager;
        this.gearEnchantService = gearEnchantService;
        this.progressService = progressService;
        this.oreOnlyWorldService = oreOnlyWorldService;
        this.cellService = cellService;
        this.generatorService = generatorService;
        this.meteorService = meteorService;
        this.prisonRiotService = prisonRiotService;
    }

    private boolean isGKitBlock(Block block) {
        return this.meteorService != null && this.meteorService.isGKitBlock(block);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK) return;

        Block block = event.getClickedBlock();
        if (block == null) return;
        Player player = event.getPlayer();
        if (player != null && event.getBlockFace() != null) {
            this.lastBlockFace.put(player.getUniqueId(), event.getBlockFace());
        }
        boolean riotWorld = this.prisonRiotService != null && this.prisonRiotService.isRiotWorld(block.getWorld());
        if (this.cellService != null && this.cellService.isCellDoor(block)) {
            return;
        }
        if (this.cellService != null && this.cellService.getCellAt(block.getLocation()) != null) {
            return;
        }

        // Allow gkit flare blocks to behave like mining targets.
        if (!isOre(block) && !this.isGKitBlock(block)) {
            event.setCancelled(true);
            event.setUseInteractedBlock(Event.Result.DENY);
            event.setUseItemInHand(Event.Result.DENY);
            progressService.clear(block);
            return;
        }

        ItemStack tool = event.getItem();

        if (!isTrackedMiningTool(tool, block)) return;

        if (this.isGKitBlock(block) && this.meteorService != null && event.getPlayer() != null && !this.meteorService.canMineGKitBlock(block, event.getPlayer())) {
            event.setCancelled(true);
            event.setUseInteractedBlock(Event.Result.DENY);
            event.setUseItemInHand(Event.Result.DENY);
            progressService.clear(block);
            event.getPlayer().sendMessage(Text.color("&cYou do not own this Gkit Flare."));
            return;
        }

        if (!riotWorld && pickaxeManager.isPrisonPickaxe(tool)
                && !this.isGKitBlock(block)
                && !pickaxeManager.isAllowedBlock(tool, block.getType())) {

            event.setCancelled(true);
            event.setUseInteractedBlock(Event.Result.DENY);
            event.setUseItemInHand(Event.Result.DENY);
            progressService.clear(block);
            return;
        }

        // Let mining targets continue into BlockDamageEvent so crack progress can start.
        if (!isOre(block) && !this.isGKitBlock(block)) {
            event.setCancelled(true);
            event.setUseInteractedBlock(Event.Result.DENY);
            event.setUseItemInHand(Event.Result.DENY);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockDamage(BlockDamageEvent event) {

        Block block = event.getBlock();
        boolean riotWorld = this.prisonRiotService != null && this.prisonRiotService.isRiotWorld(block.getWorld());
        if (this.cellService != null && this.cellService.isCellDoor(block)) {
            return;
        }
        if (this.cellService != null && this.cellService.getCellAt(block.getLocation()) != null) {
            return;
        }

        // Allow gkit flare blocks to start and continue the normal mining animation.
        if (!isOre(block) && !this.isGKitBlock(block)) {
            event.setCancelled(true);
            progressService.clear(block);
            return;
        }

        ItemStack tool = event.getItemInHand();

        if (!isTrackedMiningTool(tool, block)) return;

        if (this.isGKitBlock(block) && this.meteorService != null && event.getPlayer() != null && !this.meteorService.canMineGKitBlock(block, event.getPlayer())) {
            event.setCancelled(true);
            progressService.clear(block);
            event.getPlayer().sendMessage(Text.color("&cYou do not own this Gkit Flare."));
            return;
        }

        if (!riotWorld && pickaxeManager.isPrisonPickaxe(tool)
                && !this.isGKitBlock(block)
                && !pickaxeManager.isAllowedBlock(tool, block.getType())) {

            event.setCancelled(true);
            progressService.clear(block);
            return;
        }

        Player player = event.getPlayer();
        if (this.progressService.isPacketEventsEnabled()) {
            this.progressService.beginDigging(block, player);
        }
        startMining(player, block);
        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        boolean riotWorld = this.prisonRiotService != null && this.prisonRiotService.isRiotWorld(block.getWorld());
        if (this.cellService != null && this.cellService.isCellDoor(block)) {
            return;
        }
        if (this.cellService != null && this.cellService.getCellAt(block.getLocation()) != null) {
            return;
        }

        // Allow gkit flare blocks to break through the mining system.
        if (!isOre(block) && !this.isGKitBlock(block)) {
            event.setCancelled(true);
            progressService.clear(block);
            return;
        }

        progressService.clear(block);
        if (riotWorld) {
            return;
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (event.getPlayer() != null) {
            this.lastBlockFace.remove(event.getPlayer().getUniqueId());
        }
    }

    private void startMining(Player player, Block block) {
        if (player == null || block == null) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        progressService.ensureTracking(block, player);
        boolean meteorBlock = this.meteorService != null && this.meteorService.isMeteorBlock(block);
        if (meteorBlock) {
            progressService.startMining(player, block, () -> breakSpeed(player, player.getInventory().getItemInMainHand(), block), () -> this.shouldContinueMining(player, block), () -> this.handleMeteorMiningHit(player, block), false);
            return;
        }
        if (this.isGKitBlock(block)) {
            float speed = (float)((1.0D / 1200.0D) * this.pickaxeManager.getMiningSpeedMultiplier(tool));
            progressService.startMining(player, block, speed, () -> this.shouldContinueMining(player, block));
            return;
        }
        progressService.startMining(player, block, () -> breakSpeed(player, player.getInventory().getItemInMainHand(), block), () -> this.shouldContinueMining(player, block));
    }

    private boolean handleMeteorMiningHit(Player player, Block block) {
        if (player == null || block == null || this.meteorService == null) {
            return false;
        }
        int remaining = this.meteorService.hit(block);
        Material quartz = Material.matchMaterial("QUARTZ_ORE");
        Material meteorMaterial = quartz != null ? quartz : Material.NETHER_QUARTZ_ORE;
        Material rewardMaterial = this.meteorService.getOreForPlayer(player);
        BlockFace clickedFace = this.resolveAnimationFace(player);
        this.progressService.clear(block, player);
        this.applyMeteorHitRewards(player, block, rewardMaterial);
        if (remaining > 0) {
            if (block.getType() != meteorMaterial) {
                block.setType(meteorMaterial, false);
            }
            this.playMeteorBreakVisuals(player, block, meteorMaterial, rewardMaterial, clickedFace);
            this.giveMeteorReward(player, rewardMaterial);
            this.restartMeteorMining(player, block);
            return false;
        }
        this.meteorService.clear(block);
        this.playMeteorBreakVisuals(player, block, meteorMaterial, rewardMaterial, clickedFace);
        this.giveMeteorReward(player, rewardMaterial);
        block.setType(Material.AIR, false);
        return false;
    }

    private void restartMeteorMining(Player player, Block block) {
        if (player == null || block == null || this.meteorService == null) {
            return;
        }
        Bukkit.getScheduler().runTask(this.meteorService.getPlugin(), () -> {
            if (!player.isOnline() || block.getType().isAir() || !this.meteorService.isMeteorBlock(block)) {
                return;
            }
            if (this.progressService.isPacketEventsEnabled()) {
                this.progressService.beginDigging(block, player);
            }
            this.startMining(player, block);
        });
    }

    private void playMeteorBreakVisuals(Player player, Block block, Material blockMaterial, Material rewardMaterial, BlockFace clickedFace) {
        if (player == null || block == null || blockMaterial == null || rewardMaterial == null || clickedFace == null) {
            return;
        }
        Location center = block.getLocation().add(0.5, 0.5, 0.5);
        block.getWorld().spawnParticle(Particle.BLOCK_CRUMBLE, center, 6, 0.2, 0.2, 0.2, 0.0, blockMaterial.createBlockData());
        block.getWorld().playSound(center, Sound.BLOCK_STONE_BREAK, 0.85f, 0.95f);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
        if (this.meteorService != null && this.meteorService.getPlugin() != null && this.meteorService.getPlugin().getItemAnimationService() != null) {
            this.meteorService.getPlugin().getItemAnimationService().play(player, block.getLocation(), rewardMaterial, clickedFace);
        }
    }

    private void giveMeteorReward(Player player, Material rewardMaterial) {
        if (player == null || rewardMaterial == null || rewardMaterial.isAir()) {
            return;
        }
        ItemStack reward = new ItemStack(rewardMaterial, 1);
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(reward);
        for (ItemStack stack : overflow.values()) {
            if (stack != null && !stack.getType().isAir() && stack.getAmount() > 0) {
                player.getWorld().dropItemNaturally(player.getLocation(), stack);
            }
        }
    }

    private void applyMeteorHitRewards(Player player, Block block, Material rewardMaterial) {
        if (player == null || block == null || rewardMaterial == null || this.meteorService == null) {
            return;
        }
        PrisonsCore plugin = this.meteorService.getPlugin();
        if (plugin == null) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        BoosterService boosterService = plugin.getBoosterService();
        PlayerLevelService playerLevelService = plugin.getPlayerLevelService();
        if (playerLevelService != null) {
            int playerExp = playerLevelService.getOreExp(rewardMaterial);
            if (playerExp > 0) {
                if (boosterService != null) {
                    playerExp = boosterService.applyXpBoost(player, playerExp);
                }
                playerLevelService.addExp(player, playerExp);
            }
        }
        int gain = this.pickaxeManager.energyForBlock(tool, rewardMaterial);
        if (gain <= 0) {
            Material fallback = this.findMeteorChargeFallback(tool, rewardMaterial);
            if (fallback != null) {
                rewardMaterial = fallback;
                gain = this.pickaxeManager.energyForBlock(tool, rewardMaterial);
            }
        }
        if (gain > 0 && boosterService != null) {
            gain = boosterService.applyEnergyBoost(player, gain);
        }
        if (gain > 0) {
            this.pickaxeManager.addEnergy(tool, gain);
            player.setMetadata("energy-gain", new FixedMetadataValue(plugin, gain));
        }
    }

    private Material findMeteorChargeFallback(ItemStack tool, Material preferred) {
        if (tool == null || preferred == null) {
            return null;
        }
        Material[] candidates = new Material[]{
                preferred,
                Material.EMERALD_ORE,
                Material.DIAMOND_ORE,
                Material.REDSTONE_ORE,
                Material.GOLD_ORE,
                Material.LAPIS_ORE,
                Material.IRON_ORE,
                Material.COAL_ORE
        };
        for (Material candidate : candidates) {
            if (candidate != null && this.pickaxeManager.energyForBlock(tool, candidate) > 0) {
                return candidate;
            }
        }
        return null;
    }

    private BlockFace resolveAnimationFace(Player player) {
        if (player == null) {
            return BlockFace.UP;
        }
        return this.lastBlockFace.getOrDefault(player.getUniqueId(), BlockFace.UP);
    }

    private boolean shouldContinueMining(Player player, Block block) {
        if (player == null || block == null) {
            return false;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (this.progressService.isPacketEventsEnabled()) {
            return this.progressService.isActivelyDigging(player, block) && isTrackedMiningTool(tool, block);
        }
        return this.isLookingAtBlock(player, block) && isTrackedMiningTool(tool, block);
    }

    private float breakSpeed(Player player, ItemStack tool, Block block) {
        if (player == null || block == null) return 0.0f;

        float speed = block.getBreakSpeed(player);
        boolean riotOre = this.prisonRiotService != null
                && this.prisonRiotService.isRiotWorld(block.getWorld())
                && this.isOre(block);

        if (isFistCoalMine(tool, block)) {
            return Math.max(0.0f, speed * FIST_TO_WOODEN_PICKAXE_SPEED_MULTIPLIER);
        }

        if (isWoodenIronMine(tool, block)) {
            speed *= WOODEN_TO_STONE_PICKAXE_SPEED_MULTIPLIER;
        }

        if (pickaxeManager.isPrisonPickaxe(tool)) {
            Map<String, Integer> enchants = pickaxeManager.getEnchants(tool);
            int efficiency = enchants.getOrDefault("efficiency", 0);
            if (efficiency > 0) {
                speed *= 1.0f + (float)efficiency * 0.20f;
            }
            int drillBuff = pickaxeManager.getDrillBuff(tool);
            if (drillBuff > 0) {
                speed *= (float)this.pickaxeManager.getDrillSpeedMultiplier(tool);
                speed += (float)this.pickaxeManager.getDrillProgressBonus(tool);
            }
        }
        int vigor = this.getArmorEnchantLevel(player, "vigor");
        if (vigor > 0) {
            speed *= 1.0f + (float)vigor * 0.05f;
        }
        int doubleDamage = this.getArmorEnchantLevel(player, "double_damage");
        if (doubleDamage > 0) {
            double chance = Math.min(0.5D, (double)doubleDamage * 0.03D);
            speed *= 1.0f + (float)chance;
        }
        if (riotOre) {
            speed *= RIOT_ORE_SPEED_MULTIPLIER;
        }
        speed *= (float)this.pickaxeManager.getMiningSpeedMultiplier(tool);
        return Math.max(0.0f, speed);
    }

    private boolean isTrackedMiningTool(ItemStack tool, Block block) {
        return pickaxeManager.isPrisonPickaxe(tool) || isFistCoalMine(tool, block) || (this.isGKitBlock(block) && this.isPickaxeOrFist(tool));
    }

    private boolean isPickaxeOrFist(ItemStack tool) {
        return tool == null || tool.getType().isAir() || tool.getType().name().endsWith("_PICKAXE");
    }

    private boolean isLookingAtBlock(Player player, Block block) {
        if (player == null || block == null || block.getWorld() == null) {
            return false;
        }
        Block target = player.getTargetBlockExact(6);
        return target != null && target.getLocation().toBlockLocation().equals(block.getLocation().toBlockLocation());
    }

    private boolean isFistCoalMine(ItemStack tool, Block block) {
        if (block == null || !isCoalOre(block.getType())) return false;
        return tool == null || tool.getType().isAir();
    }

    private int getArmorEnchantLevel(Player player, String enchantId) {
        if (player == null || enchantId == null) {
            return 0;
        }
        if (this.gearManager == null || this.gearEnchantService == null) {
            return 0;
        }
        CustomEnchant enchant = this.gearEnchantService.getById(enchantId);
        if (enchant == null) {
            return 0;
        }
        ItemStack[] armor = player.getInventory().getArmorContents();
        int total = 0;
        for (ItemStack piece : armor) {
            if (piece == null || piece.getType().isAir() || !this.gearManager.isGear(piece) || !enchant.isApplicableTo(piece.getType())) {
                continue;
            }
            total += this.gearManager.getEnchants(piece).getOrDefault(enchantId, 0);
        }
        return total;
    }

    private boolean isWoodenIronMine(ItemStack tool, Block block) {
        return tool != null
                && tool.getType() == Material.WOODEN_PICKAXE
                && block != null
                && isIronOre(block.getType());
    }

    private boolean isCoalOre(Material type) {
        return type == Material.COAL_ORE || type == Material.DEEPSLATE_COAL_ORE;
    }

    private boolean isIronOre(Material type) {
        return type == Material.IRON_ORE || type == Material.DEEPSLATE_IRON_ORE;
    }

    private boolean isOre(Block block) {
        Material type = block.getType();
        boolean riotWorld = this.prisonRiotService != null && this.prisonRiotService.isRiotWorld(block.getWorld());
        if (riotWorld && type == Material.STONE) {
            return true;
        }
        if (type == Material.COAL_ORE || type == Material.DEEPSLATE_COAL_ORE
                || type == Material.IRON_ORE || type == Material.DEEPSLATE_IRON_ORE
                || type == Material.COPPER_ORE || type == Material.DEEPSLATE_COPPER_ORE
                || type == Material.GOLD_ORE || type == Material.DEEPSLATE_GOLD_ORE
                || type == Material.NETHER_GOLD_ORE
                || type == Material.REDSTONE_ORE || type == Material.DEEPSLATE_REDSTONE_ORE
                || type == Material.LAPIS_ORE || type == Material.DEEPSLATE_LAPIS_ORE
                || type == Material.DIAMOND_ORE || type == Material.DEEPSLATE_DIAMOND_ORE
                || type == Material.EMERALD_ORE || type == Material.DEEPSLATE_EMERALD_ORE
                || type == Material.NETHER_QUARTZ_ORE
                || type == Material.ANCIENT_DEBRIS) {
            return true;
        }
        Material quartz = Material.matchMaterial("QUARTZ_ORE");
        if (quartz != null && type == quartz) {
            return true;
        }
        return this.generatorService != null && (this.generatorService.isGeneratedOre(block) || this.generatorService.isRefinedBase(block));
    }
}
