/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.event.player.PlayerTeleportEvent
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.LevelDisplayService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

public class LevelDisplayListener
implements Listener {
    private final LevelDisplayService service;

    public LevelDisplayListener(LevelDisplayService service) {
        this.service = service;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.service.spawn(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.service.remove(event.getPlayer());
    }

    @EventHandler(ignoreCancelled=true)
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().distanceSquared(event.getTo()) < 1.0E-4) {
            return;
        }
        this.service.update(event.getPlayer());
    }

    @EventHandler(ignoreCancelled=true)
    public void onTeleport(PlayerTeleportEvent event) {
        this.service.update(event.getPlayer());
    }
}

