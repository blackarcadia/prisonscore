package org.axial.prisonsCore.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.service.SafezoneService;
import org.axial.prisonsCore.cell.guard.CellGuardService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

public class SafezoneListener implements Listener {
    private final SafezoneService safezoneService;
    private final GuardService guardService;
    private final CellGuardService cellGuardService;
    private final Map<UUID, Boolean> safezoneState = new HashMap<UUID, Boolean>();

    public SafezoneListener(SafezoneService safezoneService, GuardService guardService, CellGuardService cellGuardService) {
        this.safezoneService = safezoneService;
        this.guardService = guardService;
        this.cellGuardService = cellGuardService;
    }

    @EventHandler(ignoreCancelled = true)
    public void onWandUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.safezoneService.isWand(item)) {
            return;
        }
        Player player = event.getPlayer();
        if (!player.hasPermission("prisons.safezone.admin")) {
            return;
        }
        if (event.getAction() != Action.LEFT_CLICK_BLOCK && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getClickedBlock() == null) {
            return;
        }
        event.setCancelled(true);
        Location location = event.getClickedBlock().getLocation();
        if (event.getAction() == Action.LEFT_CLICK_BLOCK) {
            this.safezoneService.setPos1(player.getUniqueId(), location);
            player.sendMessage(Text.color("&aSet safezone pos1 to &f" + this.format(location)));
            return;
        }
        this.safezoneService.setPos2(player.getUniqueId(), location);
        player.sendMessage(Text.color("&aSet safezone pos2 to &f" + this.format(location)));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        this.safezoneState.put(player.getUniqueId(), this.safezoneService.isInSafezone(player.getLocation()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.safezoneState.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        this.handleSafezoneEntry(event.getPlayer(), event.getFrom(), event.getTo());
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent event) {
        this.handleSafezoneEntry(event.getPlayer(), event.getFrom(), event.getTo());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onCombat(EntityDamageByEntityEvent event) {
        Entity attacker = this.resolveAttacker(event.getDamager());
        Entity target = event.getEntity();
        boolean attackerRelevant = attacker instanceof Player
                || attacker != null && (this.guardService.isGuard(attacker) || this.cellGuardService != null && this.cellGuardService.isCellGuard(attacker));
        boolean targetRelevant = target instanceof Player
                || this.guardService.isGuard(target)
                || this.cellGuardService != null && this.cellGuardService.isCellGuard(target);
        if (!attackerRelevant || !targetRelevant) {
            return;
        }
        if (attacker != null && (this.guardService.isGuard(attacker) || this.cellGuardService != null && this.cellGuardService.isCellGuard(attacker))) {
            return;
        }
        if (!this.safezoneService.isInSafezone(attacker == null ? null : attacker.getLocation())
                && !this.safezoneService.isInSafezone(target.getLocation())) {
            return;
        }
        event.setCancelled(true);
        if (attacker instanceof Player player) {
            player.sendMessage(Text.color("&cYou cannot fight in a safezone."));
        }
    }

    private Entity resolveAttacker(Entity source) {
        if (source instanceof Projectile projectile) {
            ProjectileSource shooter = projectile.getShooter();
            if (shooter instanceof Entity entity) {
                return entity;
            }
        }
        return source;
    }

    private void handleSafezoneEntry(Player player, Location from, Location to) {
        if (player == null || to == null || from == null) {
            return;
        }
        if (from.getWorld() != null && to.getWorld() != null
                && from.getWorld().equals(to.getWorld())
                && from.getBlockX() == to.getBlockX()
                && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) {
            return;
        }
        boolean wasIn = this.safezoneState.getOrDefault(player.getUniqueId(), this.safezoneService.isInSafezone(from));
        boolean isIn = this.safezoneService.isInSafezone(to);
        this.safezoneState.put(player.getUniqueId(), isIn);
        if (wasIn || !isIn) {
            return;
        }
        player.sendTitle(Text.color("&a&lSafezone"), "", 10, 40, 10);
        player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 1.2f);
    }

    private String format(Location location) {
        return location.getWorld().getName() + " " + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ();
    }
}
