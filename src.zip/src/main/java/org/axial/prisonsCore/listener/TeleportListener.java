/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerMoveEvent
 *  org.bukkit.event.player.PlayerRespawnEvent
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.FeatureToggleService;
import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.service.TeleportService;
import org.axial.prisonsCore.service.TutorialService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import java.util.Set;
import java.util.Locale;

public class TeleportListener
implements Listener {
    private static final String DANGEROUS_SPAWN_MESSAGE = "&aYou logged out in a dangerous place so you have been sent to spawn.";
    private static final Set<String> ALLOWED_JOIN_WORLDS = Set.of("prisons", "tutorial", "koth", "cells", "pit");
    private final PrisonsCore plugin;
    private final TeleportService teleportService;
    private final TutorialService tutorialService;
    private final PlayerDataService playerDataService;
    private final FeatureToggleService featureToggleService;

    public TeleportListener(PrisonsCore plugin, TeleportService teleportService, TutorialService tutorialService, PlayerDataService playerDataService, FeatureToggleService featureToggleService) {
        this.plugin = plugin;
        this.teleportService = teleportService;
        this.tutorialService = tutorialService;
        this.playerDataService = playerDataService;
        this.featureToggleService = featureToggleService;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getFrom().getX() != event.getTo().getX() || event.getFrom().getZ() != event.getTo().getZ()) {
            this.teleportService.handleMove(event.getPlayer().getUniqueId());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Location spawn;
        if (this.tutorialService != null && this.tutorialService.shouldHandleJoin(event.getPlayer())) {
            return;
        }
        if (this.shouldTeleportForDisallowedWorld(event.getPlayer()) && (spawn = this.teleportService.getSpawn()) != null) {
            event.getPlayer().teleport(spawn);
            event.getPlayer().sendMessage(Text.color("&a&l(!) &aYou have been sent to spawn because you logged out somewhere unsafe!"));
            this.scheduleDangerousSpawnCheck(event.getPlayer());
            return;
        }
        if (this.shouldTeleportForMissingLogoutWorld(event.getPlayer()) && (spawn = this.teleportService.getSpawn()) != null) {
            event.getPlayer().teleport(spawn);
            event.getPlayer().sendMessage(Text.color("&a&l(!) &aYou have been sent to spawn because you logged out somewhere unsafe!"));
            this.scheduleDangerousSpawnCheck(event.getPlayer());
            return;
        }
        if (this.shouldTeleportForPvpReenable(event.getPlayer()) && (spawn = this.teleportService.getSpawn()) != null) {
            event.getPlayer().teleport(spawn);
            event.getPlayer().sendMessage(Text.color("&a&l(!) &aYou have been sent to spawn because you logged out somewhere unsafe!"));
            this.scheduleDangerousSpawnCheck(event.getPlayer());
            return;
        }
        if (!event.getPlayer().hasPlayedBefore() && (spawn = this.teleportService.getSpawn()) != null) {
            event.getPlayer().teleport(spawn);
            event.getPlayer().sendMessage(Text.color("&eWelcome! Teleporting you to spawn."));
        }
        this.scheduleDangerousSpawnCheck(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        if (this.playerDataService == null || event.getPlayer() == null) {
            return;
        }
        Location worldLocation = event.getPlayer().getLocation();
        this.playerDataService.update(event.getPlayer().getUniqueId(), stored -> stored.setLastLogoutWorld(worldLocation != null && worldLocation.getWorld() != null ? worldLocation.getWorld().getName() : null));
    }

    private boolean shouldTeleportForPvpReenable(org.bukkit.entity.Player player) {
        if (player == null || this.playerDataService == null || this.featureToggleService == null) {
            return false;
        }
        if (!this.featureToggleService.isEnabled(FeatureToggleService.Feature.PVP)) {
            return false;
        }
        int currentVersion = this.featureToggleService.getPvpEnableVersion();
        if (currentVersion <= 0) {
            return false;
        }
        PlayerDataService.PlayerData data = this.playerDataService.get(player.getUniqueId());
        if (data.getLastSeenPvpEnableVersion() >= currentVersion) {
            return false;
        }
        this.playerDataService.update(player.getUniqueId(), stored -> stored.setLastSeenPvpEnableVersion(currentVersion));
        return true;
    }

    private boolean shouldTeleportForMissingLogoutWorld(Player player) {
        if (player == null || this.playerDataService == null) {
            return false;
        }
        PlayerDataService.PlayerData data = this.playerDataService.get(player.getUniqueId());
        String lastWorld = data.getLastLogoutWorld();
        if (lastWorld == null || lastWorld.isBlank()) {
            return player.hasPlayedBefore();
        }
        return Bukkit.getWorld(lastWorld) == null;
    }

    private boolean shouldTeleportForDisallowedWorld(Player player) {
        if (player == null || player.getWorld() == null) {
            return false;
        }
        String worldName = player.getWorld().getName();
        if (worldName == null) {
            return false;
        }
        return !ALLOWED_JOIN_WORLDS.contains(worldName.toLowerCase(Locale.ROOT));
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        if (this.tutorialService != null && this.tutorialService.isInTutorial(event.getPlayer())) {
            return;
        }
        Location spawn = this.teleportService.getSpawn();
        if (spawn != null) {
            event.setRespawnLocation(spawn);
        }
        this.scheduleDangerousSpawnCheck(event.getPlayer());
    }

    private void scheduleDangerousSpawnCheck(Player player) {
        if (player == null || this.teleportService == null) {
            return;
        }
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            Location spawn;
            if (!player.isOnline() || !this.isSuffocating(player) || (spawn = this.teleportService.getSpawn()) == null) {
                return;
            }
            player.teleport(spawn);
            player.sendMessage(Text.color(DANGEROUS_SPAWN_MESSAGE));
        }, 1L);
    }

    private boolean isSuffocating(Player player) {
        Location eyeLocation = player.getEyeLocation();
        return eyeLocation != null && eyeLocation.getBlock() != null && !eyeLocation.getBlock().isPassable();
    }
}
