package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.Difficulty;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.event.world.WorldLoadEvent;

public class NoNaturalMobSpawnsListener
implements Listener {
    private final PrisonsCore plugin;

    public NoNaturalMobSpawnsListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onServerLoad(ServerLoadEvent event) {
        this.disableNaturalSpawningOnLoadedWorlds();
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        this.disableNaturalSpawning(event.getWorld());
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        SpawnReason reason = event.getSpawnReason();
        if (reason == SpawnReason.COMMAND || reason == SpawnReason.CUSTOM) {
            return;
        }
        event.setCancelled(true);
    }

    private void disableNaturalSpawningOnLoadedWorlds() {
        for (World world : this.plugin.getServer().getWorlds()) {
            this.disableNaturalSpawning(world);
        }
    }

    private void disableNaturalSpawning(World world) {
        if (world != null) {
            world.setDifficulty(Difficulty.HARD);
            world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        }
    }
}
