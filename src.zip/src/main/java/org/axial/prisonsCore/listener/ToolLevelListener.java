package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.LevelRequirementService;
import org.axial.prisonsCore.service.PrisonRiotService;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.service.SeasonService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class ToolLevelListener implements Listener {
    private final GearManager gearManager;
    private final PlayerLevelService playerLevelService;
    private final LevelRequirementService levelRequirementService;
    private final SeasonService seasonService;
    private final CellService cellService;
    private final PrisonRiotService prisonRiotService;

    public ToolLevelListener(GearManager gearManager, PlayerLevelService playerLevelService, LevelRequirementService levelRequirementService, SeasonService seasonService, CellService cellService, PrisonRiotService prisonRiotService) {
        this.gearManager = gearManager;
        this.playerLevelService = playerLevelService;
        this.levelRequirementService = levelRequirementService;
        this.seasonService = seasonService;
        this.cellService = cellService;
        this.prisonRiotService = prisonRiotService;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (this.prisonRiotService != null && this.prisonRiotService.isRiotWorld(event.getBlock().getWorld())) {
            return;
        }
        if (this.cellService != null && this.cellService.isCellDoor(event.getBlock())) {
            return;
        }
        if (this.cellService != null && this.cellService.getCellAt(event.getBlock().getLocation()) != null) {
            return;
        }
        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        if (!this.canUse(event.getPlayer(), item)) {
            event.setCancelled(true);
            this.sendDenied(event.getPlayer(), item);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getClickedBlock() != null && this.prisonRiotService != null && this.prisonRiotService.isRiotWorld(event.getClickedBlock().getWorld())) {
            return;
        }
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.LEFT_CLICK_AIR && event.getAction() != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        if (event.getClickedBlock() != null && this.cellService != null && this.cellService.isCellDoor(event.getClickedBlock())) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.isRestrictedTool(item)) {
            return;
        }
        if (!this.canUse(event.getPlayer(), item)) {
            event.setCancelled(true);
            this.sendDenied(event.getPlayer(), item);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) {
            return;
        }
        if (this.prisonRiotService != null && this.prisonRiotService.isRiotWorld(player.getWorld())) {
            return;
        }
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!this.isRestrictedTool(item)) {
            return;
        }
        if (!this.canUse(player, item)) {
            event.setCancelled(true);
            this.sendDenied(player, item);
        }
    }

    private boolean isRestrictedTool(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) {
            return false;
        }
        return this.requiredLevel(item) > 0 || this.requiredUnlock(item) != null;
    }

    private int requiredLevel(ItemStack item) {
        if (item == null) {
            return -1;
        }
        Material material = item.getType();
        if (material.name().endsWith("_PICKAXE")) {
            return this.levelRequirementService.getRequiredLevelForTool(material);
        }
        return this.gearManager.getRequiredLevel(material);
    }

    private SeasonService.UnlockFeature requiredUnlock(ItemStack item) {
        if (item == null) {
            return null;
        }
        return this.seasonService.getFeature(item.getType());
    }

    private boolean canUse(Player player, ItemStack item) {
        int requiredLevel = this.requiredLevel(item);
        if (requiredLevel > 0 && this.playerLevelService.getLevel(player) < requiredLevel) {
            return false;
        }
        SeasonService.UnlockFeature unlockFeature = this.requiredUnlock(item);
        return unlockFeature == null || this.seasonService.isFeatureUnlocked(unlockFeature);
    }

    private void sendDenied(Player player, ItemStack item) {
        SeasonService.UnlockFeature unlockFeature = this.requiredUnlock(item);
        if (unlockFeature != null && !this.seasonService.isFeatureUnlocked(unlockFeature)) {
            player.sendMessage(Text.color("&cThat item unlocks on Day " + this.seasonService.getUnlockDay(unlockFeature) + "."));
            return;
        }
        int requiredLevel = this.requiredLevel(item);
        player.sendMessage(Text.color("&cYou must be level " + requiredLevel + " to use that item."));
    }
}
