package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.gui.ContrabandMenu;
import org.axial.prisonsCore.service.ContrabandService;
import org.axial.prisonsCore.service.LockboxService;
import org.bukkit.event.Event;
import org.bukkit.event.block.Action;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class ContrabandListener implements Listener {
    private final ContrabandService contrabandService;
    private final ContrabandMenu contrabandMenu;
    private final LockboxService lockboxService;

    public ContrabandListener(ContrabandService contrabandService, ContrabandMenu contrabandMenu, LockboxService lockboxService) {
        this.contrabandService = contrabandService;
        this.contrabandMenu = contrabandMenu;
        this.lockboxService = lockboxService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        String tierId = this.contrabandService.getTierId(item);
        if (tierId == null) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        ItemStack remaining = item.clone();
        remaining.setAmount(remaining.getAmount() - 1);
        event.getPlayer().getInventory().setItemInMainHand(remaining.getAmount() <= 0 ? null : remaining);
        if (this.lockboxService != null) {
            this.lockboxService.recordContrabandOpen(event.getPlayer(), tierId);
        }
        this.contrabandMenu.open(event.getPlayer(), tierId);
    }
}
