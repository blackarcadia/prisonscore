/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.HealthDisplayService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class HealthDisplayListener
implements Listener {
    private final HealthDisplayService service;

    public HealthDisplayListener(HealthDisplayService service) {
        this.service = service;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.service.start();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
    }
}

