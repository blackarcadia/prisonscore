/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Sound
 *  org.bukkit.entity.HumanEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.ChargeOrbService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class ChargeOrbListener
implements Listener {
    private final ChargeOrbService chargeOrbService;
    private final PickaxeManager pickaxeManager;

    public ChargeOrbListener(ChargeOrbService chargeOrbService, PickaxeManager pickaxeManager) {
        this.chargeOrbService = chargeOrbService;
        this.pickaxeManager = pickaxeManager;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCombine(InventoryClickEvent event) {
        ItemStack cursor = event.getCursor();
        ItemStack target = event.getCurrentItem();
        if (cursor == null || target == null || target.getType().isAir()) {
            return;
        }
        boolean slotToken = this.chargeOrbService.isSlotToken(cursor);
        boolean chargeOrb = this.chargeOrbService.isChargeOrb(cursor);
        if (!slotToken && !chargeOrb) {
            return;
        }
        Player player = event.getWhoClicked() instanceof Player ? (Player)event.getWhoClicked() : null;
        if (slotToken) {
            boolean applied = this.pickaxeManager.addChargeSlot(target);
            if (!applied) {
                if (player != null) {
                    player.sendMessage(Text.color("&cThis pickaxe already has the maximum charge slots (8)."));
                }
                return;
            }
            event.setCancelled(true);
            this.consumeOne(event, cursor);
            if (player != null) {
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.4f);
                player.sendMessage(Text.color("&aAdded +1 charge slot (max 8)."));
            }
            return;
        }
        if (this.chargeOrbService.isChargeOrb(target)) {
            int combined = this.chargeOrbService.getTotalPercent(cursor) + this.chargeOrbService.getTotalPercent(target);
            event.setCurrentItem(this.chargeOrbService.createOrb(combined));
            event.setCursor(null);
            event.setCancelled(true);
            if (player != null) {
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.3f);
            }
            return;
        }
        if (!this.pickaxeManager.isPrisonPickaxe(target)) {
            return;
        }
        int percent = this.chargeOrbService.getPercent(cursor);
        boolean applied = this.pickaxeManager.addChargeOrb(target, percent, this.chargeOrbService.getMaxSlots());
        if (!applied) {
            if (player != null) {
                player.sendMessage(Text.color("&cCharge orb not applied (slot full or lower percent)."));
            }
            return;
        }
        this.consumeOne(event, cursor);
        event.setCancelled(true);
        if (player != null) {
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.3f);
            player.sendMessage(Text.color("&aApplied a &e" + percent + "% &acharge orb."));
        }
    }

    private void consumeOne(InventoryClickEvent event, ItemStack cursor) {
        if (cursor.getAmount() <= 1) {
            event.setCursor(null);
        } else {
            cursor.setAmount(cursor.getAmount() - 1);
            event.setCursor(cursor);
        }
    }
}
