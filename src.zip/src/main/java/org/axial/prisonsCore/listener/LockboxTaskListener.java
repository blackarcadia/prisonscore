package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.LockboxService;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

public class LockboxTaskListener implements Listener {
    private final LockboxService lockboxService;

    public LockboxTaskListener(LockboxService lockboxService) {
        this.lockboxService = lockboxService;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (this.lockboxService == null || player == null || block == null) {
            return;
        }
        this.lockboxService.recordMeteorMine(player, block);
        this.lockboxService.recordOreBreak(player, block);
    }
}
