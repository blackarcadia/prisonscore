package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.cell.guard.CellGuardService;
import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.service.FeatureToggleService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.projectiles.ProjectileSource;

public class PVPListener implements Listener {
    private final FeatureToggleService featureToggleService;
    private final GuardService guardService;
    private final CellGuardService cellGuardService;

    public PVPListener(FeatureToggleService featureToggleService, GuardService guardService, CellGuardService cellGuardService) {
        this.featureToggleService = featureToggleService;
        this.guardService = guardService;
        this.cellGuardService = cellGuardService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onPVP(EntityDamageByEntityEvent event) {
        if (this.featureToggleService.isEnabled(FeatureToggleService.Feature.PVP)) {
            return;
        }

        if (this.guardService != null && this.guardService.isGuard(event.getDamager())) {
            return;
        }
        if (this.cellGuardService != null && this.cellGuardService.isCellGuard(event.getDamager())) {
            return;
        }

        if (!(event.getEntity() instanceof Player)) {
            return;
        }

        Player attacker = this.getAttacker(event.getDamager());
        if (attacker == null) {
            return;
        }

        event.setCancelled(true);
        attacker.sendMessage(Text.color("&cPVP is currently disabled."));
    }

    private Player getAttacker(org.bukkit.entity.Entity entity) {
        if (entity instanceof Player player) {
            return player;
        }
        if (entity instanceof Projectile projectile) {
            ProjectileSource projectileSource = projectile.getShooter();
            if (projectileSource instanceof Player shooter) {
                return shooter;
            }
        }
        return null;
    }
}
