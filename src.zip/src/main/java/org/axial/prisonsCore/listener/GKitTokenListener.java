package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.KitService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class GKitTokenListener implements Listener {
    private final KitService kitService;

    public GKitTokenListener(KitService kitService) {
        this.kitService = kitService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.kitService.isGKitToken(item)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        Player player = event.getPlayer();
        KitService.GKitType gkitType = this.kitService.getGKitTokenType(item);
        if (gkitType == null) {
            player.sendMessage(Text.color("&cThat gkit gem is invalid."));
            return;
        }
        if (player.hasPermission(gkitType.permission()) || this.kitService.hasUnlockedGKit(player, gkitType)) {
            player.sendMessage(Text.color("&cYou already own this gkit."));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
            return;
        }
        EquipmentSlot hand = event.getHand();
        this.kitService.unlockGKit(player, gkitType).whenComplete((success, throwable) -> Bukkit.getScheduler().runTask(this.kitService.getPlugin(), () -> {
            if (throwable != null || !Boolean.TRUE.equals(success)) {
                player.sendMessage(Text.color("&cFailed to apply this gkit gem."));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
                return;
            }
            player.sendMessage(Text.color("&aYou unlocked the &f" + gkitType.plainName() + " &agkit."));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            this.consumeOne(player, item, hand);
        }));
    }

    private void consumeOne(Player player, ItemStack stack, EquipmentSlot hand) {
        int amt = stack.getAmount();
        if (amt <= 1) {
            player.getInventory().setItem(hand, null);
            return;
        }
        stack.setAmount(amt - 1);
        player.getInventory().setItem(hand, stack);
    }
}
