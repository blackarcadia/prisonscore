/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.util.Vector
 */
package org.axial.prisonsCore.listener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.ProtectionScrollService;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public class TightDropListener
implements Listener {
    private final PrisonsCore plugin;
    private final ProtectionScrollService protectionScrollService;
    private final Map<UUID, List<ItemStack>> protectedDrops = new HashMap<UUID, List<ItemStack>>();

    public TightDropListener(PrisonsCore plugin, ProtectionScrollService protectionScrollService) {
        this.plugin = plugin;
        this.protectionScrollService = protectionScrollService;
    }

    @EventHandler(priority=EventPriority.LOWEST)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        ArrayList<ItemStack> drops = new ArrayList<ItemStack>(event.getDrops());
        if (drops.isEmpty()) {
            for (ItemStack item2 : player.getInventory().getContents()) {
                if (item2 == null || item2.getType().isAir()) continue;
                drops.add(item2.clone());
            }
            for (ItemStack item2 : player.getInventory().getArmorContents()) {
                if (item2 == null || item2.getType().isAir()) continue;
                drops.add(item2.clone());
            }
            ItemStack off = player.getInventory().getItemInOffHand();
            if (off != null && !off.getType().isAir()) {
                drops.add(off.clone());
            }
        }
        ArrayList<ItemStack> protectedItems = new ArrayList<ItemStack>();
        ArrayList<ItemStack> unprotectedItems = new ArrayList<ItemStack>();
        for (ItemStack drop : drops) {
            if (drop == null || drop.getType().isAir()) continue;
            if (this.protectionScrollService != null && this.protectionScrollService.isProtected(drop)) {
                ItemStack restored = drop.clone();
                this.protectionScrollService.unprotect(restored);
                protectedItems.add(restored);
                continue;
            }
            unprotectedItems.add(drop);
        }
        if (!protectedItems.isEmpty()) {
            this.protectedDrops.put(player.getUniqueId(), protectedItems);
        } else {
            this.protectedDrops.remove(player.getUniqueId());
        }
        if (unprotectedItems.isEmpty()) {
            event.getDrops().clear();
            player.getInventory().clear();
            player.getInventory().setArmorContents(null);
            player.getInventory().setItemInOffHand(null);
            return;
        }
        World world = player.getWorld();
        Location dropLoc = player.getLocation().toBlockLocation().add(0.5, 0.1, 0.5);
        event.getDrops().clear();
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.getInventory().setItemInOffHand(null);
        for (ItemStack drop : unprotectedItems) {
            if (drop == null || drop.getType().isAir()) continue;
            world.dropItem(dropLoc, drop, item -> {
                double spread = 0.08;
                ThreadLocalRandom rnd = ThreadLocalRandom.current();
                Vector velocity = new Vector((rnd.nextDouble() - 0.5) * spread, 0.04, (rnd.nextDouble() - 0.5) * spread);
                item.setVelocity(velocity);
            });
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.restoreLater(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        this.restoreLater(event.getPlayer());
    }

    private void restoreLater(Player player) {
        if (player == null) {
            return;
        }
        Bukkit.getScheduler().runTask(this.plugin, () -> this.restoreProtectedItems(player));
    }

    private void restoreProtectedItems(Player player) {
        List<ItemStack> items = this.protectedDrops.remove(player.getUniqueId());
        if (items == null || items.isEmpty()) {
            return;
        }
        for (ItemStack item : items) {
            if (item == null || item.getType().isAir()) {
                continue;
            }
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack[]{item});
            if (!leftover.isEmpty()) {
                leftover.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
            }
        }
    }
}
