package org.axial.prisonsCore.listener;

import java.util.Random;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class GearEnchantOrbListener implements Listener {
    private final GearEnchantService gearEnchantService;
    private final GearManager gearManager;
    private final Random random = new Random();

    public GearEnchantOrbListener(GearEnchantService gearEnchantService, GearManager gearManager) {
        this.gearEnchantService = gearEnchantService;
        this.gearManager = gearManager;
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        ItemStack cursor = event.getCursor();
        ItemStack target = event.getCurrentItem();
        if (cursor == null || target == null) {
            return;
        }
        if (!this.gearEnchantService.isGearEnchantOrb(cursor)) {
            return;
        }
        if (!this.gearManager.isGear(target)) {
            return;
        }
        String enchantId = this.gearEnchantService.getOrbEnchantId(cursor);
        int level = this.gearEnchantService.getOrbLevel(cursor);
        int percent = this.gearEnchantService.getOrbPercent(cursor);
        CustomEnchant enchant = this.gearEnchantService.getById(enchantId);
        if (enchant == null) {
            return;
        }
        if (!enchant.isApplicableTo(target.getType())) {
            if (event.getWhoClicked() instanceof Player player) {
                player.sendMessage(Text.color("&cThat enchant cannot be applied to this item."));
            }
            return;
        }
        boolean success = this.random.nextInt(100) < Math.max(0, Math.min(100, percent));
        if (success) {
            if (this.gearManager.isBroken(target)) {
                this.gearManager.repair(target);
            }
            this.gearManager.applyEnchant(target, enchantId, level, enchant.getMaxLevel());
            this.gearManager.levelUp(target);
            this.gearManager.updateLore(target);
            if (event.getWhoClicked() instanceof Player player2) {
                player2.playSound(player2.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
                player2.sendMessage(Text.color("&aApplied " + enchant.getDisplayNameForLevel(level) + " to your gear."));
            }
        } else if (event.getWhoClicked() instanceof Player player3) {
            player3.playSound(player3.getLocation(), Sound.BLOCK_ANVIL_DESTROY, 1.0f, 1.0f);
            player3.sendMessage(Text.color("&cGear enchant orb failed."));
        }
        this.consumeOne(event, cursor);
        event.setCurrentItem(target);
        event.setCancelled(true);
    }

    private void consumeOne(InventoryClickEvent event, ItemStack cursor) {
        if (cursor.getAmount() <= 1) {
            event.setCursor(null);
        } else {
            cursor.setAmount(cursor.getAmount() - 1);
            event.setCursor(cursor);
        }
    }
}
