package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.PickaxeManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.inventory.ItemStack;

public class PickaxeBuffListener implements Listener {
    private final PickaxeManager pickaxeManager;

    public PickaxeBuffListener(PickaxeManager pickaxeManager) {
        this.pickaxeManager = pickaxeManager;
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!this.pickaxeManager.isPrisonPickaxe(tool)) {
            return;
        }
        double multiplier = this.pickaxeManager.getIntensityDamageMultiplier(tool);
        if (multiplier >= 1.0D) {
            return;
        }
        event.setDamage(Math.max(0.0D, event.getDamage() * multiplier));
    }
}
