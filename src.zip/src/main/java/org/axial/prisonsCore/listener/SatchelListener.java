/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.service.SatchelManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class SatchelListener
implements Listener {
    private final SatchelManager satchelManager;
    private final EconomyService economyService;

    public SatchelListener(SatchelManager satchelManager, EconomyService economyService) {
        this.satchelManager = satchelManager;
        this.economyService = economyService;
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=false)
    public void onPlace(BlockPlaceEvent event) {
        if (!this.satchelManager.isSatchel(event.getItemInHand())) {
            return;
        }
        event.setCancelled(true);
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (!this.satchelManager.isSatchel(item)) {
            return;
        }
        if (!player.isSneaking()) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        int amount = this.satchelManager.getAmount(item);
        if (amount <= 0) {
            player.sendMessage(Text.color("&7Your satchel is empty."));
            return;
        }
        if (!this.economyService.isReady()) {
            player.sendMessage(Text.color("&cEconomy unavailable."));
            return;
        }
        Material mat = this.satchelManager.getType(item);
        double pricePer = this.economyService.getWorth(mat);
        if (pricePer <= 0.0) {
            player.sendMessage(Text.color("&cNo worth configured for this satchel item."));
            return;
        }
        double total = this.economyService.applySellBoost(pricePer * (double)amount);
        this.economyService.deposit(player, total);
        this.satchelManager.clear(item);
        player.sendMessage(Text.color("&aSold " + amount + " for &2" + this.economyService.format(total)));
    }
}
