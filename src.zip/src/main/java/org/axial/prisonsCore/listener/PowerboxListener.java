package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.gui.PowerboxMenu;
import org.axial.prisonsCore.service.PowerboxService;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class PowerboxListener implements Listener {
    private final PowerboxService powerboxService;
    private final PowerboxMenu powerboxMenu;

    public PowerboxListener(PowerboxService powerboxService, PowerboxMenu powerboxMenu) {
        this.powerboxService = powerboxService;
        this.powerboxMenu = powerboxMenu;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        String powerboxId = this.powerboxService.getPowerboxId(item);
        if (powerboxId == null) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        ItemStack remaining = item.clone();
        remaining.setAmount(remaining.getAmount() - 1);
        event.getPlayer().getInventory().setItemInMainHand(remaining.getAmount() <= 0 ? null : remaining);
        this.powerboxMenu.open(event.getPlayer(), powerboxId);
    }
}
