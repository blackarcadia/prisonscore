package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.AxialModVerificationService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ConnectionMessageListener implements Listener {
    private static final String BORDER = "&d&l&m================&6&l&m================";
    private final AxialModVerificationService axialModVerificationService;

    public ConnectionMessageListener(AxialModVerificationService axialModVerificationService) {
        this.axialModVerificationService = axialModVerificationService;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        event.joinMessage(null);
        Player player = event.getPlayer();
        String playerName = player.getName();
        event.getPlayer().sendMessage(Text.color(
                "\n"
                + BORDER + "&r\n"
                + Text.center("&fWelcome &d&l" + playerName + " &fto &d&lAxial&6&lPrisons") + "\n"
                + Text.center("&7Interstellar Themed Minecraft Prisons Experience!") + "\n"
                + "\n"
                + Text.center("&c&lDISCORD: &fdiscord.gg/axialmc") + "\n"
                + BORDER
        ));
        this.axialModVerificationService.beginVerification(player);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        this.axialModVerificationService.clear(event.getPlayer());
        event.quitMessage(null);
    }
}
