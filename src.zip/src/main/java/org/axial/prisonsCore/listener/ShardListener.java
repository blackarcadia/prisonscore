/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.gui.ShardMenu;
import org.axial.prisonsCore.service.ShardService;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class ShardListener
implements Listener {
    private final ShardService shardService;
    private final ShardMenu shardMenu;

    public ShardListener(ShardService shardService, ShardMenu shardMenu) {
        this.shardService = shardService;
        this.shardMenu = shardMenu;
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.shardService.isShard(item)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        ItemStack single = item.clone();
        single.setAmount(1);
        item.setAmount(item.getAmount() - 1);
        if (event.getHand() == EquipmentSlot.HAND) {
            event.getPlayer().getInventory().setItemInMainHand(item.getAmount() <= 0 ? null : item);
        } else {
            event.getPlayer().getInventory().setItemInOffHand(item.getAmount() <= 0 ? null : item);
        }
        this.shardMenu.open(event.getPlayer(), single);
    }
}
