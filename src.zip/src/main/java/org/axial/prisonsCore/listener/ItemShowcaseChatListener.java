package org.axial.prisonsCore.listener;

import java.util.LinkedHashSet;
import java.util.Set;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.GangService;
import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.service.PlayerToggleService;
import org.axial.prisonsCore.service.TutorialService;
import org.axial.prisonsCore.util.ItemShowcaseUtil;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class ItemShowcaseChatListener implements Listener {
    private static final PlainTextComponentSerializer PLAIN_TEXT = PlainTextComponentSerializer.plainText();
    private final PrisonsCore plugin;
    private final GangService gangService;
    private final PlayerDataService playerDataService;
    private final TutorialService tutorialService;
    private final PlayerToggleService toggleService;

    public ItemShowcaseChatListener(PrisonsCore plugin, GangService gangService, PlayerDataService playerDataService, TutorialService tutorialService, PlayerToggleService toggleService) {
        this.plugin = plugin;
        this.gangService = gangService;
        this.playerDataService = playerDataService;
        this.tutorialService = tutorialService;
        this.toggleService = toggleService;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onChat(AsyncChatEvent event) {
        if (event.isCancelled() || this.gangService.isGangChat(event.getPlayer().getUniqueId())) {
            return;
        }
        String message = PLAIN_TEXT.serialize(event.message());
        if (!ItemShowcaseUtil.containsToken(message)) {
            return;
        }
        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        if (!ItemShowcaseUtil.hasShowcaseableItem(item)) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> event.getPlayer().sendMessage(Text.color("&cHold an item in your main hand to use [item].")));
            return;
        }
        Player sender = event.getPlayer();
        Set<Audience> filteredViewers = new LinkedHashSet<Audience>(event.viewers());
        for (Audience viewer : filteredViewers) {
            if (viewer instanceof Player recipient && !recipient.equals((Object)sender) && (this.tutorialService.shouldFilterChat(recipient) || !this.canSeeChat(recipient))) {
                event.viewers().remove(viewer);
            }
        }
        Component updatedMessage = ItemShowcaseUtil.buildShowcaseMessage(message, item);
        event.message(updatedMessage);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
    public void onLegacyChat(AsyncPlayerChatEvent event) {
        if (event.isCancelled() || this.gangService.isGangChat(event.getPlayer().getUniqueId())) {
            return;
        }
        String message = event.getMessage();
        if (!ItemShowcaseUtil.containsToken(message)) {
            return;
        }
        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        if (!ItemShowcaseUtil.hasShowcaseableItem(item)) {
            event.setCancelled(true);
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> event.getPlayer().sendMessage(Text.color("&cHold an item in your main hand to use [item].")));
            return;
        }
        event.setCancelled(true);
        Player sender = event.getPlayer();
        String format = event.getFormat();
        String displayName = this.playerDataService.getChatName(sender);
        Set<Player> recipients = new LinkedHashSet<Player>();
        for (Player recipient : event.getRecipients()) {
            if (recipient.equals((Object)sender) || (!this.tutorialService.shouldFilterChat(recipient) && this.canSeeChat(recipient))) {
                recipients.add(recipient);
            }
        }
        String consoleMessage = ItemShowcaseUtil.buildFormattedPlainMessage(format, displayName, ItemShowcaseUtil.replaceTokenWithName(message, item));
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            recipients.forEach(recipient -> recipient.sendMessage(ItemShowcaseUtil.buildFormattedMessage(format, displayName, message, item)));
            Bukkit.getConsoleSender().sendMessage(Text.color(consoleMessage));
        });
    }

    private boolean canSeeChat(Player player) {
        return this.toggleService == null || this.toggleService.canReceiveChat(player);
    }
}
