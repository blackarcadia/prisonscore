package org.axial.prisonsCore.listener;

import com.github.retrooper.packetevents.event.simple.PacketPlayReceiveEvent;
import com.github.retrooper.packetevents.event.SimplePacketListenerAbstract;
import com.github.retrooper.packetevents.protocol.packettype.PacketType;
import com.github.retrooper.packetevents.protocol.player.DiggingAction;
import com.github.retrooper.packetevents.util.Vector3i;
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerDigging;
import org.axial.prisonsCore.service.BlockProgressService;
import org.bukkit.Bukkit;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public final class MiningDigPacketListener extends SimplePacketListenerAbstract {
    private final BlockProgressService progressService;

    public MiningDigPacketListener(BlockProgressService progressService) {
        this.progressService = progressService;
    }

    @Override
    public void onPacketPlayReceive(PacketPlayReceiveEvent event) {
        if (event.getPacketType() != PacketType.Play.Client.PLAYER_DIGGING) {
            return;
        }

        WrapperPlayClientPlayerDigging packet = new WrapperPlayClientPlayerDigging(event);
        Player player = Bukkit.getPlayer(event.getUser().getUUID());
        if (player == null) {
            return;
        }

        Vector3i pos = packet.getBlockPosition();
        Block block = player.getWorld().getBlockAt(pos.getX(), pos.getY(), pos.getZ());

        DiggingAction action = packet.getAction();
        if (action == DiggingAction.START_DIGGING) {
            this.progressService.beginDigging(block, player);
            return;
        }

        if (action == DiggingAction.CANCELLED_DIGGING || action == DiggingAction.FINISHED_DIGGING) {
            this.progressService.endDigging(player);
        }
    }
}
