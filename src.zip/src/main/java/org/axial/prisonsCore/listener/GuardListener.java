/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Sound
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDeathEvent
 *  org.bukkit.event.entity.EntityRegainHealthEvent
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Sound;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityRegainHealthEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;

public class GuardListener
implements Listener {
    private final GuardService guardService;
    private final PickaxeManager pickaxeManager;

    public GuardListener(GuardService guardService, PickaxeManager pickaxeManager) {
        this.guardService = guardService;
        this.pickaxeManager = pickaxeManager;
    }

    @EventHandler(ignoreCancelled=true)
    public void onGuardHit(EntityDamageByEntityEvent event) {
        if (!this.guardService.isGuard(event.getEntity())) {
            return;
        }
        Player attacker = null;
        Entity entity = event.getDamager();
        if (entity instanceof Player) {
            Player p;
            attacker = p = (Player)entity;
        } else if (entity instanceof Projectile proj) {
            ProjectileSource shooter = proj.getShooter();
            if (shooter instanceof Player p) {
                attacker = p;
            }
        }
        if (attacker == null) {
            return;
        }
        if (this.isBlockedAgainstGuard(attacker)) {
            event.setCancelled(true);
            attacker.sendMessage(Lang.msg("guard.no-hit", "&cYou cannot hit guards with your fist or a pickaxe."));
            return;
        }
        double dmg = this.guardService.getRetaliationDamage(event.getEntity());
        Player target = attacker;
        event.getEntity().getServer().getScheduler().runTask((Plugin)this.guardService.getPlugin(), () -> {
            if (target.isDead() || !target.isOnline()) {
                return;
            }
            target.damage(dmg);
            target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
            target.sendActionBar(Text.color("&cA guard retaliated!"));
            this.guardService.commandAttack(event.getEntity(), target);
        });
    }

    @EventHandler(ignoreCancelled=true)
    public void onPlayerHit(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player)) {
            return;
        }
        Player attacker = null;
        Entity entity = event.getDamager();
        if (entity instanceof Player) {
            attacker = (Player)entity;
        } else if (entity instanceof Projectile proj) {
            ProjectileSource shooter = proj.getShooter();
            if (shooter instanceof Player p) {
                attacker = p;
            }
        }
        if (attacker == null || !this.isPickaxeHit(attacker)) {
            return;
        }
        event.setCancelled(true);
        attacker.sendMessage(Lang.msg("pickaxe.no-pvp", "&cYou cannot hit players with a pickaxe."));
    }

    @EventHandler
    public void onGuardDamaged(EntityDamageEvent event) {
        Entity entity;
        if (this.guardService.isGuard(event.getEntity()) && (entity = event.getEntity()) instanceof LivingEntity) {
            LivingEntity living = (LivingEntity)entity;
            double scale = this.guardService.healthScale(living);
            double reduction = this.guardService.damageReductionMultiplier(event.getEntity());
            double newDamage = event.getDamage();
            if (scale > 1.0) {
                newDamage /= scale;
            }
            if (reduction > 1.0) {
                newDamage /= reduction;
            }
            if (newDamage < 0.1) {
                newDamage = 0.1;
            }
            event.setDamage(newDamage);
            this.guardService.recordGuardHit(living);
            event.getEntity().getServer().getScheduler().runTask((Plugin)this.guardService.getPlugin(), () -> {
                this.guardService.recordGuardHealth(living);
                this.guardService.updateGuardName(living, living.getCustomName());
            });
        }
    }

    @EventHandler
    public void onGuardHeal(EntityRegainHealthEvent event) {
        Entity entity;
        if (this.guardService.isGuard(event.getEntity()) && (entity = event.getEntity()) instanceof LivingEntity) {
            LivingEntity living = (LivingEntity)entity;
            event.getEntity().getServer().getScheduler().runTask((Plugin)this.guardService.getPlugin(), () -> {
                this.guardService.recordGuardHealth(living);
                this.guardService.updateGuardName(living, living.getCustomName());
            });
        }
    }

    @EventHandler
    public void onGuardDeath(EntityDeathEvent event) {
        if (this.guardService.isGuard((Entity)event.getEntity())) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            this.guardService.handleGuardDeath(event.getEntity());
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        this.guardService.clearTargetForPlayer(event.getEntity().getUniqueId());
        this.guardService.sendHomeAfterKill(event.getEntity());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.guardService.clearTargetForPlayer(event.getPlayer().getUniqueId());
    }

    private boolean isBlockedAgainstGuard(Player player) {
        return this.isFistHit(player) || this.isPickaxeHit(player);
    }

    private boolean isFistHit(Player player) {
        return player.getInventory().getItemInMainHand().getType().isAir();
    }

    private boolean isPickaxeHit(Player player) {
        Material type = player.getInventory().getItemInMainHand().getType();
        return type.name().endsWith("_PICKAXE") || this.pickaxeManager != null && this.pickaxeManager.isPrisonPickaxe(player.getInventory().getItemInMainHand());
    }
}
