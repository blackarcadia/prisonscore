package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.RaidPointService;
import org.axial.prisonsCore.util.Lang;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class RaidPointListener implements Listener {
    private final RaidPointService raidPointService;

    public RaidPointListener(RaidPointService raidPointService) {
        this.raidPointService = raidPointService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.raidPointService.isRaidPointNote(item)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        Player player = event.getPlayer();
        int amount = this.raidPointService.getAmount(item);
        if (amount <= 0) {
            player.sendMessage(Lang.msg("raidpoints.redeem.invalid", "&cThat raid points note is invalid."));
            return;
        }
        this.raidPointService.addPoints(player, amount);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        player.sendMessage(Lang.msg("raidpoints.redeem.success", "&aRedeemed raid points for &f{amount}&a.").replace("{amount}", this.raidPointService.format(amount)));
        int newAmount = item.getAmount() - 1;
        if (newAmount <= 0) {
            player.getInventory().setItem(event.getHand(), null);
        } else {
            item.setAmount(newAmount);
            player.getInventory().setItem(event.getHand(), item);
        }
    }
}
