package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.RankTokenService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class RankTokenListener implements Listener {
    private final RankTokenService rankTokenService;

    public RankTokenListener(RankTokenService rankTokenService) {
        this.rankTokenService = rankTokenService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.rankTokenService.isRankToken(item)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        Player player = event.getPlayer();
        RankTokenService.RankType rankType = this.rankTokenService.getRankTokenType(item);
        if (rankType == null) {
            player.sendMessage(Text.color("&cThat rank token is invalid."));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
            return;
        }
        if (this.rankTokenService.hasRank(player, rankType)) {
            player.sendMessage(Text.color("&cYou already own this rank!"));
            player.sendMessage(Text.color("&7Upgrade your rank with &7&n/store&7."));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
            return;
        }
        EquipmentSlot hand = event.getHand();
        this.rankTokenService.grantRank(player, rankType).whenComplete((success, throwable) -> Bukkit.getScheduler().runTask(this.rankTokenService.getPlugin(), () -> {
            if (throwable != null || !Boolean.TRUE.equals(success)) {
                player.sendMessage(Text.color("&cFailed to apply this rank token."));
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
                return;
            }
            this.consumeOne(player, item, hand);
            this.playClaimAnimation(player, item);
            player.sendTitle(Text.color("&a&lVanguard Rank Claimed"), "", 10, 40, 10);
            player.playSound(player.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 1.0f, 1.0f);
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }));
    }

    private void playClaimAnimation(Player player, ItemStack stack) {
        Location eye = player.getEyeLocation().clone();
        Location start = eye.clone();
        ItemDisplay display = player.getWorld().spawn(start, ItemDisplay.class, spawned -> {
            spawned.setItemStack(stack.clone());
            spawned.setBillboard(Display.Billboard.CENTER);
            spawned.setGravity(false);
            spawned.setSilent(true);
        });
        new BukkitRunnable() {
            private double angle = 0.0;
            private int ticks = 0;

            @Override
            public void run() {
                if (!player.isOnline() || player.isDead() || this.ticks++ > 60 || display.isDead()) {
                    display.remove();
                    cancel();
                    return;
                }
                Location center = eye.clone();
                Location next;
                if (this.ticks <= 42) {
                    double orbitProgress = (double)this.ticks / 42.0;
                    double radius = 1.45 - 0.55 * orbitProgress;
                    double x = Math.cos(this.angle) * radius;
                    double z = Math.sin(this.angle) * radius;
                    double y = 0.15 * Math.sin(this.angle * 2.0);
                    next = center.clone().add(x, y, z);
                    this.angle += Math.PI / 10.0;
                } else {
                    double inhaleProgress = Math.min(1.0, (double)(this.ticks - 42) / 18.0);
                    double x = Math.cos(this.angle) * (0.85 * (1.0 - inhaleProgress));
                    double z = Math.sin(this.angle) * (0.85 * (1.0 - inhaleProgress));
                    double y = 0.08 * (1.0 - inhaleProgress);
                    next = center.clone().add(x, y - (0.45 * inhaleProgress), z);
                    this.angle += Math.PI / 8.0;
                }
                next.setYaw(0.0f);
                next.setPitch(0.0f);
                display.teleport(next);
            }
        }.runTaskTimer(this.rankTokenService.getPlugin(), 1L, 1L);
    }

    private void consumeOne(Player player, ItemStack stack, EquipmentSlot hand) {
        int amount = stack.getAmount();
        if (amount <= 1) {
            player.getInventory().setItem(hand, null);
            return;
        }
        stack.setAmount(amount - 1);
        player.getInventory().setItem(hand, stack);
    }
}
