/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.entity.EntityDamageByEntityEvent
 *  org.bukkit.event.entity.EntityDamageEvent
 *  org.bukkit.event.entity.EntityDamageEvent$DamageCause
 *  org.bukkit.event.entity.PlayerDeathEvent
 *  org.bukkit.event.player.PlayerKickEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.projectiles.ProjectileSource
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.CombatLogManager;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.projectiles.ProjectileSource;

public class CombatLogListener
implements Listener {
    private final CombatLogManager combatLogManager;

    public CombatLogListener(CombatLogManager combatLogManager) {
        this.combatLogManager = combatLogManager;
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (entity instanceof Player) {
            Player player = (Player)entity;
            if (event.getCause() == EntityDamageEvent.DamageCause.FALL) {
                return;
            }
            this.combatLogManager.tag(player);
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onDamageByEntity(EntityDamageByEntityEvent event) {
        Player attacker = this.getAttacker(event.getDamager());
        if (attacker != null) {
            this.combatLogManager.tag(attacker);
        }
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onQuit(PlayerQuitEvent event) {
        this.combatLogManager.handleLogout(event.getPlayer());
    }

    @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
    public void onKick(PlayerKickEvent event) {
        this.combatLogManager.handleLogout(event.getPlayer());
    }

    @EventHandler(priority=EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent event) {
        this.combatLogManager.clearCombat(event.getEntity(), false);
    }

    private Player getAttacker(Entity entity) {
        if (entity instanceof Player) {
            Player player = (Player)entity;
            return player;
        }
        if (entity instanceof Projectile projectile) {
            ProjectileSource projectileSource = projectile.getShooter();
            if (projectileSource instanceof Player shooter) {
                return shooter;
            }
        }
        return null;
    }
}
