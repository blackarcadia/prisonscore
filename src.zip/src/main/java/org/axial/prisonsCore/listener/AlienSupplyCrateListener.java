package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.gui.AlienSupplyCrateMenu;
import org.axial.prisonsCore.service.AlienSupplyCrateService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class AlienSupplyCrateListener implements Listener {
    private final AlienSupplyCrateService service;
    private final AlienSupplyCrateMenu menu;

    public AlienSupplyCrateListener(AlienSupplyCrateService service, AlienSupplyCrateMenu menu) {
        this.service = service;
        this.menu = menu;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.service.isAlienSupplyCrate(item)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        Player player = event.getPlayer();
        if (this.service.isLocked(item)) {
            player.sendMessage(Text.color("&cThis Alien Supply Crate is locked. Use an Alien Key to unlock it."));
            player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.8f, 0.8f);
            return;
        }
        ItemStack remaining = item.clone();
        remaining.setAmount(remaining.getAmount() - 1);
        player.getInventory().setItemInMainHand(remaining.getAmount() <= 0 ? null : remaining);
        this.menu.open(player);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInventoryClick(InventoryClickEvent event) {
        ItemStack cursor = event.getCursor();
        ItemStack target = event.getCurrentItem();
        if (!this.service.isAlienKey(cursor) || !this.service.isAlienSupplyCrate(target) || !this.service.isLocked(target)) {
            return;
        }
        event.setCancelled(true);
        ItemStack unlocked = this.service.setUnlocked(target);
        event.setCurrentItem(unlocked);
        if (cursor.getAmount() <= 1) {
            event.setCursor(null);
        } else {
            cursor.setAmount(cursor.getAmount() - 1);
            event.setCursor(cursor);
        }
        if (event.getWhoClicked() instanceof Player player) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aYou unlocked the Alien Supply Crate."));
        }
    }
}
