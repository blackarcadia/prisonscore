/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemStack
 */
package org.axial.prisonsCore.listener;

import java.util.Map;
import java.util.Random;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.CellBusterManager;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.service.EnchantDustService;
import org.axial.prisonsCore.service.EnchantOrbService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class EnchantOrbListener
implements Listener {
    private final EnchantOrbService enchantOrbService;
    private final PickaxeManager pickaxeManager;
    private final CustomEnchantService customEnchantService;
    private final CellBusterManager cellBusterManager;
    private final EnchantDustService dustService;
    private final Random random = new Random();

    public EnchantOrbListener(EnchantOrbService enchantOrbService, PickaxeManager pickaxeManager, CustomEnchantService customEnchantService, CellBusterManager cellBusterManager, EnchantDustService dustService) {
        this.enchantOrbService = enchantOrbService;
        this.pickaxeManager = pickaxeManager;
        this.customEnchantService = customEnchantService;
        this.cellBusterManager = cellBusterManager;
        this.dustService = dustService;
    }

    @EventHandler(ignoreCancelled=true)
    public void onInventoryClick(InventoryClickEvent event) {
        boolean success;
        ItemStack cursor = event.getCursor();
        ItemStack target = event.getCurrentItem();
        if (cursor == null || target == null) {
            return;
        }
        if (!this.enchantOrbService.isEnchantOrb(cursor)) {
            return;
        }
        boolean isPickaxe = this.pickaxeManager.isPrisonPickaxe(target);
        boolean isBuster = this.cellBusterManager.isBuster(target);
        if (!isPickaxe && !isBuster) {
            return;
        }
        String enchantId = this.enchantOrbService.getEnchantId(cursor);
        int level = this.enchantOrbService.getLevel(cursor);
        int percent = this.enchantOrbService.getPercent(cursor);
        CustomEnchant enchant = this.customEnchantService.getById(enchantId);
        if (enchant == null) {
            return;
        }
        if (enchantId.equalsIgnoreCase("buster_efficiency") && !isBuster) {
            return;
        }
        if (isBuster && !enchantId.equalsIgnoreCase("buster_efficiency")) {
            return;
        }
        boolean bl = success = this.random.nextInt(100) < percent;
        if (success) {
            if (isBuster) {
                this.cellBusterManager.applyEnchant(target, enchantId, level, enchant.getMaxLevel());
                this.cellBusterManager.updateLore(target);
                this.cellBusterManager.setEnergy(target, 0);
            } else {
                this.pickaxeManager.applyEnchant(target, enchantId, level, enchant.getMaxLevel());
                this.pickaxeManager.updateLore(target);
            }
            event.getWhoClicked().sendMessage(Text.color("&aApplied " + enchant.getDisplayNameForLevel(level) + " to your item."));
        } else {
            event.getWhoClicked().sendMessage(Text.color("&cEnchant orb failed."));
            if (!isBuster && this.dustService != null) {
                ItemStack powder = this.dustService.createPowder(enchant.getRarity());
                Map<Integer, ItemStack> leftover = event.getWhoClicked().getInventory().addItem(new ItemStack[]{powder});
                if (!leftover.isEmpty()) {
                    leftover.values().forEach(it -> event.getWhoClicked().getWorld().dropItem(event.getWhoClicked().getLocation(), it));
                }
            }
        }
        event.setCursor(null);
        event.setCurrentItem(target);
        event.setCancelled(true);
    }
}
