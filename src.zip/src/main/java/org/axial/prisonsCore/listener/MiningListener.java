/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Particle
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Display$Billboard
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.ItemDisplay
 *  org.bukkit.entity.Player
 *  org.bukkit.entity.Projectile
 *  org.bukkit.entity.SmallFireball
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.entity.ProjectileHitEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.metadata.FixedMetadataValue
 *  org.bukkit.metadata.MetadataValue
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.projectiles.ProjectileSource
 *  org.bukkit.scheduler.BukkitRunnable
 *  org.bukkit.util.Transformation
 *  org.bukkit.util.Vector
 *  org.joml.Quaternionf
 *  org.joml.Vector3f
 */
package org.axial.prisonsCore.listener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.cell.Cell;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.masks.manager.MaskManager;
import org.axial.prisonsCore.service.BlockProgressService;
import org.axial.prisonsCore.service.BoosterService;
import org.axial.prisonsCore.service.EconomyService;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.service.GeneratorService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.GuardService;
import org.axial.prisonsCore.service.HarbourerBossService;
import org.axial.prisonsCore.service.LevelRequirementService;
import org.axial.prisonsCore.service.MeteorService;
import org.axial.prisonsCore.service.OreOnlyWorldService;
import org.axial.prisonsCore.service.OreRegenService;
import org.axial.prisonsCore.service.ItemAnimationService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.PlayerLevelService;
import org.axial.prisonsCore.service.PlayerToggleService;
import org.axial.prisonsCore.service.PlayerToggleService.Toggle;
import org.axial.prisonsCore.service.PrisonCoinService;
import org.axial.prisonsCore.service.SatchelManager;
import org.axial.prisonsCore.service.ShardService;
import org.axial.prisonsCore.service.TutorialService;
import org.axial.prisonsCore.util.EnchantDisplayUtil;
import org.axial.prisonsCore.util.Lang;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Color;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.World.Environment;
import org.bukkit.block.Block;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.SmallFireball;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import com.github.retrooper.packetevents.protocol.world.BlockFace;
import org.bukkit.util.Vector;

public class MiningListener
implements Listener {
    private static final int METEOR_ORE_MULTIPLIER = 2;
    private final PickaxeManager pickaxeManager;
    private final GearManager gearManager;
    private final PrisonsCore plugin;
    private final PlayerLevelService playerLevelService;
    private final OreRegenService oreRegenService;
    private final CustomEnchantService customEnchantService;
    private final EconomyService economyService;
    private final SatchelManager satchelManager;
    private final Random random = new Random();
    private final LevelRequirementService levelRequirementService;
    private final BlockProgressService blockProgressService;
    private final GuardService guardService;
    private final MeteorService meteorService;
    private final GeneratorService generatorService;
    private final HarbourerBossService harbourerBossService;
    private final BoosterService boosterService;
    private final MaskManager maskManager;
    private final TutorialService tutorialService;
    private final OreOnlyWorldService oreOnlyWorldService;
    private final PlayerToggleService playerToggleService;
    private final PrisonCoinService prisonCoinService;
    private final Map<UUID, Long> fireballCooldowns = new HashMap<UUID, Long>();
    private final Map<UUID, Integer> momentumStacks = new ConcurrentHashMap<UUID, Integer>();
    private final Map<UUID, Long> momentumLast = new ConcurrentHashMap<UUID, Long>();
    private final Map<String, BukkitTask> shatterWaveTasks = new ConcurrentHashMap<String, BukkitTask>();
    private final Map<UUID, Integer> momentumResetTask = new ConcurrentHashMap<UUID, Integer>();
    private final Map<UUID, Integer> lastMineSoundTick = new ConcurrentHashMap<UUID, Integer>();
    private final Map<UUID, Long> oreOnlyWarnAt = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, Long> inventoryFullTitleAt = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, Long> shardIncentiveUntil = new ConcurrentHashMap<UUID, Long>();
    private final Map<UUID, org.bukkit.block.BlockFace> lastBlockFace = new ConcurrentHashMap<UUID, org.bukkit.block.BlockFace>();
    private final Map<Location, Integer> oreHitTick = new HashMap<Location, Integer>();
    private static final double GANG_POINT_NOTE_CHANCE = 0.02D;
    private static final Set<Material> ORES = EnumSet.of(Material.COAL_ORE, new Material[]{Material.DEEPSLATE_COAL_ORE, Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE, Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE, Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE, Material.NETHER_GOLD_ORE, Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE, Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE, Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE, Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE, Material.NETHER_QUARTZ_ORE, Material.ANCIENT_DEBRIS});

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockHit(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null) {
            return;
        }
        if (this.plugin.getPrisonRiotService() != null && this.plugin.getPrisonRiotService().isRiotWorld(block.getWorld())) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!this.pickaxeManager.isPrisonPickaxe(tool)) {
            return;
        }
        if (!this.isOre(block.getType()) && !this.isQuartzOre(block.getType())) {
            return;
        }
        int currentTick = this.plugin.getServer().getCurrentTick();
        Location key = block.getLocation().toBlockLocation();
        Integer lastTick = this.oreHitTick.get(key);
        if (lastTick != null && currentTick - lastTick < 40) {
            return;
        }
        player.spawnParticle(Particle.BUBBLE_POP, key.clone().add(0.5, 1.05, 0.5), 6, 0.25, 0.05, 0.25, 0.02);
        player.playSound(key.clone().add(0.5, 0.5, 0.5), Sound.BLOCK_BUBBLE_COLUMN_BUBBLE_POP, 0.6f, 1.4f);
        this.oreHitTick.put(key, currentTick);
        org.bukkit.block.BlockFace clickedFace = event.getBlockFace();
        if (clickedFace != null) {
            this.lastBlockFace.put(player.getUniqueId(), clickedFace);
        }
    }

    private boolean isOre(Material type) {
        return ORES.contains(type) || this.isQuartzOre(type);
    }

    private boolean isQuartzOre(Material type) {
        if (type == null) {
            return false;
        }
        if (type == Material.NETHER_QUARTZ_ORE) {
            return true;
        }
        Material quartz = Material.matchMaterial("QUARTZ_ORE");
        return quartz != null && type == quartz;
    }

    public MiningListener(PrisonsCore plugin, PickaxeManager pickaxeManager, GearManager gearManager, PlayerLevelService playerLevelService, OreRegenService oreRegenService, CustomEnchantService customEnchantService, EconomyService economyService, LevelRequirementService levelRequirementService, BlockProgressService blockProgressService, GuardService guardService, SatchelManager satchelManager, MeteorService meteorService, GeneratorService generatorService, HarbourerBossService harbourerBossService, BoosterService boosterService, MaskManager maskManager, TutorialService tutorialService, OreOnlyWorldService oreOnlyWorldService, PlayerToggleService playerToggleService, PrisonCoinService prisonCoinService) {
        this.pickaxeManager = pickaxeManager;
        this.gearManager = gearManager;
        this.plugin = plugin;
        this.playerLevelService = playerLevelService;
        this.oreRegenService = oreRegenService;
        this.customEnchantService = customEnchantService;
        this.economyService = economyService;
        this.levelRequirementService = levelRequirementService;
        this.blockProgressService = blockProgressService;
        this.guardService = guardService;
        this.satchelManager = satchelManager;
        this.meteorService = meteorService;
        this.generatorService = generatorService;
        this.harbourerBossService = harbourerBossService;
        this.boosterService = boosterService;
        this.maskManager = maskManager;
        this.tutorialService = tutorialService;
        this.oreOnlyWorldService = oreOnlyWorldService;
        this.playerToggleService = playerToggleService;
        this.prisonCoinService = prisonCoinService;
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        int fireball;
        List<ItemStack> drops;
        int fissure;
        int shatter;
        double bonusPercent;
        int feed;
        int momentum;
        int reqLevel;
        boolean refinedBase;
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        Block block = event.getBlock();
        if (this.plugin.getPrisonRiotService() != null && this.plugin.getPrisonRiotService().isRiotWorld(block.getWorld())) {
            return;
        }
        CellService cellService = this.plugin.getCellService();
        Cell cellAt = cellService != null ? cellService.getCellAt(block.getLocation()) : null;
        if (cellService != null && cellService.isCellDoor(block)) {
            return;
        }
        if (cellAt != null && cellAt.isBossCell() && cellService != null && cellService.isBossCellLocked(cellAt) && (cellService.isBossCellRelevant(block) || cellService.isCellDoor(block))) {
            event.setCancelled(true);
            player.sendMessage(Text.color("&cThis boss cell is on raid cooldown."));
            return;
        }
        if (cellAt != null && cellAt.isBossCell() && cellService != null && cellService.isBossCellRelevant(block)) {
            boolean admin = player.hasPermission("cells.admin");
            boolean raider = this.plugin.getCellGuardService() != null && this.plugin.getCellGuardService().isTrackedRaiderForCell(player.getUniqueId(), cellAt.getId());
            if (!admin && !raider) {
                event.setCancelled(true);
                player.sendMessage(Text.color("&cYou must start or join the raid before breaking boss cell blocks."));
                return;
            }
        }
        Material type = block.getType();
        if (this.oreOnlyWorldService != null && this.oreOnlyWorldService.isRestricted(block.getWorld()) && !this.isAllowedInOreOnlyWorld(block)) {
            event.setCancelled(true);
            this.sendOreOnlyWarning(player);
            return;
        }
        if (this.meteorService != null && this.meteorService.isGKitBlock(block)) {
            if (!this.meteorService.canMineGKitBlock(block, player)) {
                event.setCancelled(true);
                player.sendMessage(Text.color("&cYou do not own this Gkit Flare."));
                return;
            }
            event.setDropItems(false);
            event.setExpToDrop(0);
            event.setCancelled(true);
            this.oreHitTick.remove(block.getLocation().toBlockLocation());
            this.blockProgressService.clear(block);
            this.meteorService.handleGKitBlockBreak(block, player);
            return;
        }
        boolean harbourerPillar = this.harbourerBossService != null && this.harbourerBossService.isPillarBlock(block);
        boolean adminBreak = player.getGameMode() == org.bukkit.GameMode.CREATIVE && player.isSneaking() && (player.isOp() || player.hasPermission("prisoncore.breakblocks"));
        if (adminBreak && this.oreRegenService != null && this.oreRegenService.isManagedOre(block)) {
            event.setExpToDrop(0);
            event.setDropItems(false);
            this.oreHitTick.remove(block.getLocation().toBlockLocation());
            this.blockProgressService.clear(block);
            this.oreRegenService.removeOreForAdmin(block);
            return;
        }
        if (this.isFistCoalMine(tool, type)) {
            event.setExpToDrop(0);
            event.setDropItems(false);
            this.oreHitTick.remove(block.getLocation().toBlockLocation());
            boolean miniPalmProc = this.tryMiniPalmTreeProc(player);
            int previousLevel = this.playerLevelService.getLevel(player);
            Material normalizedType = this.normalizeOreForExp(type);
            int playerExp = this.resolveOreExp(normalizedType);
            int boostedExp = 0;
            if (playerExp > 0) {
                playerExp = (int)Math.round((double)playerExp * this.pickaxeManager.getXpMasteryMultiplier(tool));
                int taxed = this.applyGuardTax(player, playerExp);
                boostedExp = this.boosterService.applyXpBoost(player, taxed);
                boostedExp = this.applyUtilityBeltMiningBonus(player, normalizedType, boostedExp);
                if (miniPalmProc) {
                    boostedExp *= 2;
                }
                this.playerLevelService.addExp(player, boostedExp);
                if (this.tutorialService != null) {
                    this.tutorialService.handleLevelProgress(player, previousLevel, this.playerLevelService.getLevel(player));
                }
            }
            if (harbourerPillar) {
                if (this.harbourerBossService != null) {
                    this.harbourerBossService.handlePillarMine(block);
                }
                block.setType(Material.AIR, false);
            } else if (this.oreRegenService != null) {
                this.oreRegenService.handleMine(block);
            }
            ItemStack reward = new ItemStack(type);
            if (miniPalmProc) {
                reward.setAmount(2);
                this.sendMiniPalmTreeMessage(player, false);
            }
            this.giveMiningReward(player, reward);
            boolean inventoryFull = player.getInventory().firstEmpty() == -1;
            this.handleInventoryFullState(player, inventoryFull);
            this.playItemAnimation(player, block.getLocation(), type, this.resolveAnimationFace(player));
            player.spawnParticle(Particle.CRIT, block.getLocation().add(0.5, 0.5, 0.5), 6, 0.2, 0.2, 0.2, 0.01);
            this.playMineSound(player);
            if (this.prisonCoinService != null) {
                this.prisonCoinService.attemptMiningReward(player, type);
            }
            this.tryGangPointNote(player, block.getLocation());
            this.sendMineActionBar(player, 0, boostedExp, Collections.emptyList(), 0);
            if (this.plugin.getWarpMenu() != null) {
                this.plugin.getWarpMenu().handleSuccessfulMine(player, this.normalizeOreForExp(type), block.getLocation());
            }
            if (this.tutorialService != null) {
                this.tutorialService.handleCoalMined(player, type);
            }
            return;
        }
        if (!this.pickaxeManager.isPrisonPickaxe(tool)) {
            return;
        }
        boolean bl = refinedBase = this.generatorService != null && this.generatorService.isRefinedBase(block);
        if (refinedBase) {
            if (this.generatorService.handleRefinedBaseBroken(block, player)) {
                event.setDropItems(false);
                event.setCancelled(true);
                if (cellAt != null && cellAt.isBossCell()) {
                    cellService.checkBossCellCompletion(cellAt, player);
                }
            }
            return;
        }
        boolean meteorCore = this.meteorService != null && this.meteorService.isMeteorBlock(block);
        boolean meteorOre = this.meteorService != null && this.meteorService.isMeteorOre(block);
        boolean generatorOre = this.generatorService != null && this.generatorService.isGeneratedOre(block);
        boolean meteor = meteorCore || meteorOre;
        boolean special = meteor || generatorOre;
        boolean miniPalmProc = this.tryMiniPalmTreeProc(player);
        this.oreHitTick.remove(block.getLocation().toBlockLocation());
        Material logicalType = meteorCore ? this.meteorService.getOreForLevel(this.playerLevelService.getLevel(player)) : type;
        event.setExpToDrop(0);
        int toolReq = this.levelRequirementService.getRequiredLevelForTool(tool.getType());
        if (toolReq > 0 && this.playerLevelService.getLevel(player) < toolReq) {
            event.setCancelled(true);
            player.sendMessage(Lang.msg("pickaxe.tool-level", "&cYou need level {level} to use that pickaxe.").replace("{level}", String.valueOf(toolReq)));
            return;
        }
        if (this.isChargeLocked(tool)) {
            event.setCancelled(true);
            this.notifyPickaxeChargeFull(player);
            return;
        }
        if (event.getPlayer().isSneaking() && this.oreRegenService.isRegenerating(block) && (event.getPlayer().isOp() || event.getPlayer().hasPermission("prisoncore.breakblocks"))) {
            this.oreRegenService.removePending(block);
            return;
        }
        Material normalizedType = this.normalizeOreForExp(logicalType);
        if (!special && !this.pickaxeManager.isAllowedBlock(tool, normalizedType)) {
            event.setCancelled(true);
            player.sendMessage(Lang.msg("pickaxe.invalid-block", "&cThis pickaxe cannot mine that block."));
            return;
        }
        int n = reqLevel = special ? 0 : this.levelRequirementService.getRequiredLevelForBlock(normalizedType);
        if (reqLevel > 0 && this.playerLevelService.getLevel(player) < reqLevel) {
            event.setCancelled(true);
            player.sendMessage(Text.color("&cYou must be level " + reqLevel + " to mine this block."));
            return;
        }
        int gain = this.pickaxeManager.energyForBlock(tool, normalizedType);
        if (meteorOre) {
            gain *= METEOR_ORE_MULTIPLIER;
        } else if (generatorOre) {
            gain *= 2;
        }
        gain = this.applyCoalPenalty(normalizedType, tool.getType(), gain);
        if (tool.getType() == Material.WOODEN_PICKAXE && type == Material.IRON_ORE) {
            this.pickaxeManager.incrementIronBroken(tool);
        } else if (tool.getType() == Material.GOLDEN_PICKAXE && type == Material.DIAMOND_ORE) {
            this.pickaxeManager.incrementDiamondBroken(tool);
        } else if (tool.getType() == Material.DIAMOND_PICKAXE && type == Material.EMERALD_ORE) {
            this.pickaxeManager.incrementEmeraldBroken(tool);
        }
        double chargeMultiplier = this.pickaxeManager.getChargeMultiplier(tool);
        gain = (int) Math.round((double) gain * chargeMultiplier);
        gain = this.applyArmorChargeBonuses(player, gain);
        gain = this.applyKryoAmuletMiningBonus(player, normalizedType, gain);
        Material expType = this.normalizeOreForExp(logicalType);
        int playerExp = this.resolveOreExp(expType);
        int boostedExp = 0;
        if (meteorOre) {
            playerExp *= METEOR_ORE_MULTIPLIER;
        } else if (generatorOre) {
            playerExp *= 2;
        }
        if (playerExp > 0) {
            playerExp = (int)Math.round((double)playerExp * this.pickaxeManager.getXpMasteryMultiplier(tool));
            int previousLevel = this.playerLevelService.getLevel(player);
            int taxed = this.applyGuardTax(player, playerExp);
            boostedExp = this.boosterService.applyXpBoost(player, taxed);
            boostedExp = this.applyMoonBootsMeteorBonus(player, block, boostedExp);
            boostedExp = this.applyUtilityBeltMiningBonus(player, normalizedType, boostedExp);
            if (miniPalmProc) {
                boostedExp *= 2;
            }
            this.playerLevelService.addExp(player, boostedExp);
            if (this.tutorialService != null) {
                this.tutorialService.handleLevelProgress(player, previousLevel, this.playerLevelService.getLevel(player));
            }
        }
        ArrayList<String> procList = new ArrayList<String>();
        Map<String, Integer> enchants = this.pickaxeManager.getEnchants(tool);
        int luck = enchants.getOrDefault("luck", 0);
        int fortune = enchants.getOrDefault("energycollector", 0);
        if (fortune > 0) {
            double chance = this.procChanceWithLuck("energycollector", fortune, 25.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                gain *= 2;
                procList.add(this.formatProc("energycollector", fortune));
            }
        }
        if ((momentum = enchants.getOrDefault("momentum", 0).intValue()) > 0) {
            gain = this.applyMomentumBonus(player, tool, gain, momentum);
        }
        if ((feed = enchants.getOrDefault("feed", 0).intValue()) > 0) {
            double chance = this.procChanceWithLuck("feed", feed, 20.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                player.setFoodLevel(20);
                player.setSaturation(20.0f);
                player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_EAT, 0.8f, 1.0f);
                player.getWorld().spawnParticle(Particle.EGG_CRACK, player.getLocation().add(0.0, 1.0, 0.0), 10, 0.4, 0.4, 0.4, 0.01);
                procList.add(this.formatProc("feed", feed));
            }
        }
        gain = this.boosterService.applyEnergyBoost(player, gain);
        if (this.maskManager != null && (bonusPercent = this.maskManager.getEnergyBonusPercent(player)) > 0.0) {
            gain = (int) Math.round((double) gain * (1.0 + bonusPercent / 100.0));
        }
        gain = this.applyUtilityBeltMiningBonus(player, normalizedType, gain);
        if (miniPalmProc) {
            gain *= 2;
        }
        int applied = this.isKryoPickaxeSkin(tool) ? this.pickaxeManager.addEnergyOverflow(tool, gain) : this.pickaxeManager.addEnergy(tool, gain);
        player.setMetadata("energy-gain", (MetadataValue) new FixedMetadataValue((Plugin) this.plugin, (Object) applied));
        if (this.isChargeLocked(tool)) {
            this.notifyPickaxeChargeFull(player);
            if (this.tutorialService != null) {
                this.tutorialService.handlePickaxeChargeFull(player, tool);
            }
        }
        if ((shatter = enchants.getOrDefault("shatter", 0).intValue()) > 0) {
            double chance = this.procChanceWithLuck("shatter", shatter, 15.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                this.tryShatterAdjacent(player, block, tool, shatter, logicalType, meteorCore, meteorOre, generatorOre);
                procList.add(this.formatProc("shatter", shatter));
            }
        }
        if ((fissure = enchants.getOrDefault("fissure", 0).intValue()) > 0) {
            double chance = this.procChanceWithLuck("fissure", fissure, 8.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                this.applyFissure(player, block, fissure);
                procList.add(this.formatProc("fissure", fissure));
            }
        }
        boolean rechargeProc = false;
        int recharge = enchants.getOrDefault("recharge", 0);
        if (recharge > 0) {
            double chance = this.procChanceWithLuck("recharge", recharge, 5.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                rechargeProc = true;
                procList.add(this.formatProc("recharge", recharge));
            }
        }
        boolean rockyProc = false;
        int rocky = enchants.getOrDefault("rocky", 0);
        if (rocky > 0) {
            double chance = this.procChanceWithLuck("rocky", rocky, 5.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                rockyProc = true;
                procList.add(this.formatProc("rocky", rocky));
            }
        }
        if (harbourerPillar) {
            if (this.harbourerBossService != null) {
                this.harbourerBossService.handlePillarMine(block);
            }
            block.setType(Material.AIR, false);
        } else if (!special && !rechargeProc) {
            this.oreRegenService.handleMine(block);
        }
        event.setDropItems(false);
        Material dropType = meteorCore ? logicalType : type;
        drops = this.buildMiningDrops(block, tool, player, dropType, meteorCore, meteorOre, generatorOre, this.pickaxeManager.getHoarderMultiplier(tool));
        this.applyArmorDropBonuses(player, drops, type);
        if (miniPalmProc) {
            this.applyMiniPalmTreeOreBonus(drops);
            this.sendMiniPalmTreeMessage(player, true);
        }
        ArrayList<ItemStack> leftovers = new ArrayList<>();
        for (ItemStack drop : drops) {
            if (drop == null) continue;
            int remaining = this.collectIntoSatchels(player, drop);
            if (remaining <= 0) continue;
            ItemStack leftover = drop.clone();
            leftover.setAmount(remaining);
            leftovers.add(leftover);
        }
        ShardService.Tier tierDrop = this.rollFragmentDrop(player, tool, type);
        if (tierDrop != null) {
            leftovers.add(this.plugin.getShardService().createShard(tierDrop));
            this.activateShardIncentive(player);
            if (this.isToggleEnabled(player, Toggle.FRAGMENT_NOTIFICATIONS)) {
                this.notifyFragmentDiscovery(player, tierDrop);
            }
        }
        if (this.plugin.getWarpMenu() != null) {
            this.plugin.getWarpMenu().handleSuccessfulMine(player, expType, block.getLocation());
        }
        if (this.tutorialService != null) {
            this.tutorialService.handleCoalMined(player, type);
        }
        for (ItemStack drop : leftovers) {
            this.giveMiningReward(player, drop);
        }
        this.tryGangPointNote(player, block.getLocation());
        boolean inventoryFull = player.getInventory().firstEmpty() == -1;
        this.handleInventoryFullState(player, inventoryFull);
        this.playItemAnimation(player, block.getLocation(), dropType, this.resolveAnimationFace(player));
        player.spawnParticle(Particle.CRIT, block.getLocation().add(0.5, 0.5, 0.5), 6, 0.2, 0.2, 0.2, 0.01);
        this.playMineSound(player);
        if (this.prisonCoinService != null) {
            this.prisonCoinService.attemptMiningReward(player, type);
        }
        this.tryPrestigeVanish(player, tool);
        if (!special && rechargeProc) {
            Material original = type;
            Bukkit.getScheduler().runTask((Plugin) this.plugin, () -> {
                this.oreRegenService.removePending(block);
                block.setType(original, false);
                block.getWorld().spawnParticle(Particle.CRIT, block.getLocation().add(0.5, 1.0, 0.5), 15, 0.2, 0.1, 0.2, 0.1);
                block.getWorld().playSound(block.getLocation(), Sound.BLOCK_BREWING_STAND_BREW, 1.0f, 1.0f);
            });
        }
        if (rockyProc) {
            this.triggerRockyBurst(player, block, tool, type, logicalType, meteorCore, meteorOre, generatorOre, rocky);
        }
        if ((fireball = enchants.getOrDefault("fireball", 0).intValue()) > 0) {
            double chance = this.procChanceWithLuck("fireball", fireball, 6.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                this.launchFireballs(player, tool, fireball, false);
                procList.add(this.formatProc("fireball", fireball));
            }
        }
        if (meteorCore) {
            int remaining = this.meteorService.hit(block);
            Bukkit.getScheduler().runTask((Plugin) this.plugin, () -> {
                Material quartz = Material.matchMaterial("QUARTZ_ORE");
                Material meteorMaterial = quartz != null ? quartz : Material.NETHER_QUARTZ_ORE;
                block.getWorld().spawnParticle(Particle.BLOCK_CRUMBLE, block.getLocation().add(0.5, 0.5, 0.5), 6, 0.2, 0.2, 0.2, 0.0, meteorMaterial.createBlockData());
                block.getWorld().playSound(block.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_STONE_BREAK, 0.85f, 0.95f);
                player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
                if (remaining > 0) {
                    if (block.getType() != meteorMaterial) {
                        block.setType(meteorMaterial, false);
                    }
                } else {
                    this.meteorService.clear(block);
                    block.setType(Material.AIR, false);
                    block.getWorld().spawnParticle(Particle.EXPLOSION, block.getLocation().add(0.5, 0.5, 0.5), 15, 0.3, 0.3, 0.3, 0.05);
                    block.getWorld().playSound(block.getLocation(), Sound.BLOCK_ANVIL_LAND, 1.0f, 0.8f);
                }
            });
        } else if (meteorOre) {
            this.meteorService.clearMeteorOre(block);
            if (this.oreRegenService != null) {
                this.oreRegenService.removePending(block);
            }
            block.setType(Material.AIR, false);
        } else if (generatorOre) {
            event.setCancelled(true);
            event.setDropItems(false);
            this.generatorService.handleGeneratedOreMined(block, player);
            if (cellAt != null && cellAt.isBossCell()) {
                cellService.checkBossCellCompletion(cellAt, player);
            }
        }
        this.applyErosion(player, block);
        int stackDisplay = this.momentumStacks.getOrDefault(player.getUniqueId(), 1);
        this.sendMineActionBar(player, applied, boostedExp, procList, momentum > 0 ? stackDisplay : 0);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        this.inventoryFullTitleAt.remove(id);
        this.lastBlockFace.remove(id);
    }

    private double procChanceWithLuck(String enchantId, int enchantLevel, double defaultPerLevel, int luckLevel) {
        double baseChance = this.customEnchantService.getProcChancePercent(enchantId, enchantLevel, defaultPerLevel);
        if (luckLevel <= 0) {
            return baseChance;
        }
        return Math.min(100.0, baseChance * (1.0 + 0.1 * (double) luckLevel));
    }

    private int applyMomentumBonus(Player player, ItemStack tool, int currentGain, int enchantLevel) {
        UUID id;
        long last;
        long now = System.currentTimeMillis();
        int stack = now - (last = this.momentumLast.getOrDefault(id = player.getUniqueId(), 0L).longValue()) <= 2000L ? this.momentumStacks.getOrDefault(id, 1) + 1 : 1;
        stack = Math.min(stack, 5 + enchantLevel);
        this.momentumStacks.put(id, stack);
        this.momentumLast.put(id, now);
        this.scheduleMomentumReset(player, tool);
        double multiplier = 1.0 + 0.05 * (double) (enchantLevel + stack - 1);
        return (int) Math.max(1L, Math.round((double) currentGain * multiplier));
    }

    private void scheduleMomentumReset(Player player, ItemStack tool) {
        UUID id = player.getUniqueId();
        Integer existing = this.momentumResetTask.remove(id);
        if (existing != null) {
            Bukkit.getScheduler().cancelTask(existing.intValue());
        }
        int taskId = Bukkit.getScheduler().scheduleSyncDelayedTask((Plugin) this.plugin, () -> {
            this.momentumStacks.remove(id);
            this.momentumLast.remove(id);
        }, 80L);
        this.momentumResetTask.put(id, taskId);
    }

    private void spawnOreVisual(Block block, final Player player, Material type) {
        if (!type.name().endsWith("_ORE")) {
            return;
        }
        Location spawnLocation = block.getLocation().add(0.5, -0.5, 0.5);
        List<Player> viewers = new ArrayList<Player>();
        for (Player viewer : block.getWorld().getPlayers()) {
            if (viewer.getLocation().distanceSquared(spawnLocation) <= 256.0) {
                viewers.add(viewer);
            }
        }
        final ArmorStand display = (ArmorStand) block.getWorld().spawn(spawnLocation, ArmorStand.class, stand -> {
            stand.setInvisible(true);
            stand.setGravity(false);
            stand.setSmall(true);
            stand.setArms(false);
            stand.setBasePlate(false);
            stand.setCustomNameVisible(false);
            if (stand.getEquipment() != null) {
                stand.getEquipment().setHelmet(new ItemStack(type));
            }
        });
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (viewers.contains(viewer)) continue;
            viewer.hideEntity((Plugin) this.plugin, (Entity) display);
        }
        new BukkitRunnable() {
            int ticks = 0;
            float yaw = 0.0f;

            public void run() {
                if (!display.isValid()) {
                    this.cancel();
                    return;
                }
                if (this.ticks >= 20) {
                    display.remove();
                    player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.5f);
                    this.cancel();
                    return;
                }
                Location currentLoc = display.getLocation();
                Location target = player.getLocation().add(0.0, -0.5, 0.0);
                if (this.ticks < 10) {
                    this.yaw += 13.0f;
                    Location next = currentLoc.add(0.0, 0.1225, 0.0);
                    next.setYaw(this.yaw);
                    next.setPitch(0.0f);
                    display.teleport(next);
                } else {
                    this.yaw += 3.0f;
                    Vector toTarget = target.toVector().subtract(currentLoc.toVector());
                    double distance = toTarget.length();
                    if (distance < 0.6) {
                        display.remove();
                        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.5f);
                        this.cancel();
                        return;
                    }
                    Vector motion = toTarget.normalize().multiply(Math.min(0.456, distance * 0.96));
                    Location next = currentLoc.add(motion);
                    next.setYaw(this.yaw);
                    next.setPitch(0.0f);
                    display.teleport(next);
                }
                ++this.ticks;
            }
        }.runTaskTimer((Plugin) this.plugin, 0L, 1L);
    }

    private double applyLuck(double baseChancePercent, double luckMultiplier) {
        return Math.min(95.0, baseChancePercent * luckMultiplier);
    }

    private int applyArmorChargeBonuses(Player player, int gain) {
        if (player == null || gain <= 0) {
            return gain;
        }
        double multiplier = 1.0D;
        int chargeHunter = this.getArmorEnchantLevel(player, "charge_hunter");
        if (chargeHunter > 0) {
            multiplier += (double)chargeHunter * 0.04D;
        }
        int ravenousCharge = this.getArmorEnchantLevel(player, "ravenous_charge");
        if (ravenousCharge > 0 && player.getFoodLevel() >= 20) {
            multiplier += (double)ravenousCharge * 0.05D;
        }
        return Math.max(1, (int)Math.round((double)gain * multiplier));
    }

    private int applyUtilityBeltMiningBonus(Player player, Material minedType, int value) {
        if (player == null || value <= 0 || minedType == null || !this.isOre(minedType)) {
            return value;
        }
        if (this.plugin.getAxialSkinsModule() == null || !this.plugin.getAxialSkinsModule().hasUtilityBeltEquipped(player)) {
            return value;
        }
        return Math.max(1, (int)Math.round((double)value * 1.25D));
    }

    private int applyMoonBootsMeteorBonus(Player player, Block block, int value) {
        if (player == null || value <= 0 || block == null || this.meteorService == null || !this.meteorService.isMeteorOre(block)) {
            return value;
        }
        if (this.plugin.getAxialSkinsModule() == null || !this.plugin.getAxialSkinsModule().hasMoonBootsEquipped(player)) {
            return value;
        }
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 200, 3, true, false, true));
        return Math.max(1, (int)Math.round((double)value * 1.05D));
    }

    private int applyKryoAmuletMiningBonus(Player player, Material minedType, int value) {
        if (player == null || value <= 0 || minedType == null || !this.isOre(minedType)) {
            return value;
        }
        if (this.plugin.getAxialSkinsModule() == null || !this.plugin.getAxialSkinsModule().hasKryoAmuletEquipped(player)) {
            return value;
        }
        return Math.max(1, (int)Math.round((double)value * 1.07D));
    }

    private void applyArmorDropBonuses(Player player, List<ItemStack> drops, Material minedType) {
        if (player == null || drops == null || drops.isEmpty() || minedType == null || !this.isOre(minedType)) {
            return;
        }
        double multiplier = 1.0D;
        int excavation = this.getArmorEnchantLevel(player, "excavation");
        if (excavation > 0 && player.getWorld() != null && player.getWorld().getEnvironment() == Environment.NORMAL) {
            multiplier += (double)excavation * 0.05D;
        }
        multiplier *= this.getShardIncentiveMultiplier(player);
        if (multiplier <= 1.0D) {
            return;
        }
        for (ItemStack drop : drops) {
            if (drop == null || drop.getType().isAir()) {
                continue;
            }
            int amount = drop.getAmount();
            drop.setAmount(Math.max(1, (int)Math.round((double)amount * multiplier)));
        }
    }

    private ShardService.Tier rollFragmentDrop(Player player, ItemStack tool, Material blockType) {
        if (this.plugin.getShardService() == null || blockType == null) {
            return null;
        }
        double bonusMultiplier = 1.0D;
        if (tool != null) {
            bonusMultiplier *= this.pickaxeManager.getFragmentFinderMultiplier(tool);
        }
        bonusMultiplier *= this.getArmorFragmentMultiplier(player);
        return this.plugin.getShardService().rollDrop(blockType, bonusMultiplier);
    }

    private double getArmorFragmentMultiplier(Player player) {
        int discovery = this.getArmorEnchantLevel(player, "discovery");
        return discovery > 0 ? 1.0D + (double)discovery * 0.03D : 1.0D;
    }

    private double getShardIncentiveMultiplier(Player player) {
        if (player == null) {
            return 1.0D;
        }
        Long expires = this.shardIncentiveUntil.get(player.getUniqueId());
        long now = System.currentTimeMillis();
        if (expires == null || expires.longValue() <= now) {
            if (expires != null) {
                this.shardIncentiveUntil.remove(player.getUniqueId());
            }
            return 1.0D;
        }
        int level = this.getArmorEnchantLevel(player, "shard_incentive");
        return level > 0 ? 1.0D + (double)level * 0.05D : 1.0D;
    }

    private void activateShardIncentive(Player player) {
        if (player == null) {
            return;
        }
        int level = this.getArmorEnchantLevel(player, "shard_incentive");
        if (level <= 0) {
            return;
        }
        this.shardIncentiveUntil.put(player.getUniqueId(), System.currentTimeMillis() + 30000L);
    }

    private boolean tryMiniPalmTreeProc(Player player) {
        return this.plugin.getCustomBlockBuffService() != null && this.plugin.getCustomBlockBuffService().tryMiniPalmTreeProc(player);
    }

    private void applyMiniPalmTreeOreBonus(List<ItemStack> drops) {
        if (drops == null || drops.isEmpty()) {
            return;
        }
        for (ItemStack drop : drops) {
            if (drop == null || drop.getAmount() <= 0) {
                continue;
            }
            drop.setAmount(drop.getAmount() * 2);
        }
    }

    private void sendMiniPalmTreeMessage(Player player, boolean includeCharge) {
        if (player == null) {
            return;
        }
        String suffix = includeCharge ? "Charge, XP, and Ores" : "XP and Ores";
        player.sendMessage(Text.color("&e&lMINI PALM TREE &7- &a+25% " + suffix));
    }

    private void handleShatterAlchemyDrops(Player player, List<ItemStack> drops) {
        if (player == null || drops == null || drops.isEmpty()) {
            return;
        }
        int level = this.getArmorEnchantLevel(player, "shatter_alchemy");
        if (level <= 0 || this.economyService == null) {
            for (ItemStack drop : drops) {
                this.giveMiningReward(player, drop);
            }
            return;
        }
        double baseValue = this.economyService.estimateSellValue(drops);
        if (baseValue <= 0.0D) {
            for (ItemStack drop : drops) {
                this.giveMiningReward(player, drop);
            }
            return;
        }
        double multiplier = 1.0D + (double)level * 0.10D;
        this.economyService.sellItemStacks(player, drops, multiplier);
        for (ItemStack drop : drops) {
            if (drop == null || drop.getAmount() <= 0) {
                continue;
            }
            this.giveMiningReward(player, drop);
        }
    }

    private void applyErosion(Player player, Block origin) {
        if (player == null || origin == null) {
            return;
        }
        int level = this.getArmorEnchantLevel(player, "erosion");
        if (level <= 0) {
            return;
        }
        double chance = Math.min(0.45D, 0.06D * (double)level);
        float damage = (float)Math.min(0.35D, 0.12D + 0.03D * (double)level);
        damage *= (float)this.pickaxeManager.getMiningSpeedMultiplier(player.getInventory().getItemInMainHand());
        for (int dx = -1; dx <= 1; ++dx) {
            for (int dy = -1; dy <= 1; ++dy) {
                for (int dz = -1; dz <= 1; ++dz) {
                    if (dx == 0 && dy == 0 && dz == 0) {
                        continue;
                    }
                    Block neighbor = origin.getRelative(dx, dy, dz);
                    if (!this.isVisibleOre(neighbor) || this.random.nextDouble() >= chance) {
                        continue;
                    }
                    this.blockProgressService.addProgress(neighbor, player, damage);
                }
            }
        }
    }

    private int getArmorEnchantLevel(Player player, String enchantId) {
        if (player == null || enchantId == null || this.gearManager == null) {
            return 0;
        }
        ItemStack[] armor = player.getInventory().getArmorContents();
        int total = 0;
        for (ItemStack piece : armor) {
            if (piece == null || piece.getType().isAir() || !this.gearManager.isGear(piece)) {
                continue;
            }
            total += this.gearManager.getEnchants(piece).getOrDefault(enchantId, 0);
        }
        return total;
    }

    private int findSatchelSlot(Player player, Material dropType) {
        ItemStack[] contents = player.getInventory().getContents();
        for (int i = 0; i < contents.length; ++i) {
            ItemStack item = contents[i];
            if (!this.satchelManager.isSatchel(item) || dropType != this.satchelManager.getType(item) || this.satchelManager.getAmount(item) >= this.satchelManager.getCapacity(item))
                continue;
            return i;
        }
        return -1;
    }

    private int collectIntoSatchels(Player player, ItemStack drop) {
        if (player == null || drop == null || drop.getType().isAir() || drop.getAmount() <= 0) {
            return 0;
        }
        int remaining = drop.getAmount();
        int slotIndex;
        while (remaining > 0 && (slotIndex = this.findSatchelSlot(player, drop.getType())) != -1) {
            ItemStack satchel = player.getInventory().getItem(slotIndex);
            int before = remaining;
            remaining = this.satchelManager.addToSatchel(satchel, remaining);
            player.getInventory().setItem(slotIndex, satchel);
            if (remaining != before) continue;
            break;
        }
        return remaining;
    }

    private void tryShatterAdjacent(Player player, Block origin, ItemStack tool, int level, Material logicalType, boolean meteorCore, boolean meteorOre, boolean generatorOre) {
        if (origin == null) {
            return;
        }
        if (!this.isVisibleOre(origin)) {
            return;
        }
        if (meteorCore || meteorOre || this.meteorService != null && this.meteorService.isMeteorBlock(origin) || this.isMeteorOre(origin)) {
            return;
        }
        boolean meteorContext = meteorCore || meteorOre;
        int radius = Math.max(1, level);
        ArrayList<ShatterTarget> targets = new ArrayList<ShatterTarget>();
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dy = -radius; dy <= radius; ++dy) {
                for (int dz = -radius; dz <= radius; ++dz) {
                    if (dx == 0 && dy == 0 && dz == 0) {
                        continue;
                    }
                    Block adj = origin.getRelative(dx, dy, dz);
                    if (!this.isVisibleOre(adj)) {
                        continue;
                    }
                    if (meteorContext ? !this.isMeteorShatterCandidate(adj) : !this.isShatterCandidate(adj, logicalType, meteorCore, meteorOre, generatorOre)) {
                        continue;
                    }
                    targets.add(new ShatterTarget(adj, Math.abs(dx) + Math.abs(dy) + Math.abs(dz)));
                }
            }
        }
        if (targets.isEmpty()) {
            return;
        }
        targets.sort(Comparator.comparingInt(ShatterTarget::distance));
        int maxTargets = Math.max(1, (int)Math.ceil((double)targets.size() * 0.75D));
        if (targets.size() > maxTargets) {
            targets = new ArrayList<ShatterTarget>(targets.subList(0, maxTargets));
        }
        this.queueShatterWave(player, tool, origin, targets, meteorContext);
        if (this.oreRegenService != null) {
            this.oreRegenService.flushPendingState();
        }
    }

    private void queueShatterWave(Player player, ItemStack tool, Block origin, List<ShatterTarget> targets, boolean meteorContext) {
        if (origin == null || origin.getWorld() == null || targets == null || targets.isEmpty()) {
            return;
        }
        String waveKey = origin.getWorld().getUID() + ":" + origin.getX() + ":" + origin.getY() + ":" + origin.getZ();
        BukkitTask existing = this.shatterWaveTasks.remove(waveKey);
        if (existing != null) {
            existing.cancel();
        }
        ArrayList<ShatterTarget> ordered = new ArrayList<ShatterTarget>(targets);
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable(){
            private int index;

            @Override
            public void run() {
                if (this.index >= ordered.size()) {
                    BukkitTask self = MiningListener.this.shatterWaveTasks.remove(waveKey);
                    if (self != null) {
                        self.cancel();
                    }
                    return;
                }
                World world = origin.getWorld();
                if (world == null) {
                    BukkitTask self = MiningListener.this.shatterWaveTasks.remove(waveKey);
                    if (self != null) {
                        self.cancel();
                    }
                    return;
                }
                int processed = 0;
                while (this.index < ordered.size() && processed < 6) {
                    ShatterTarget target = ordered.get(this.index++);
                    Block block = target.block;
                    if (block == null || block.getType().isAir()) {
                        continue;
                    }
                    if (meteorContext) {
                        if (!MiningListener.this.breakMeteorShatterExtra(block, player, tool, true)) {
                            continue;
                        }
                    } else if (!MiningListener.this.attemptBreakExtra(block, player, tool, true, true, true, true, false, true)) {
                        continue;
                    }
                    Location loc = block.getLocation().add(0.5, 0.5, 0.5);
                    world.playSound(loc, Sound.BLOCK_STONE_BREAK, 0.85f, 0.9f + MiningListener.this.random.nextFloat() * 0.15f);
                    world.spawnParticle(Particle.BLOCK_CRUMBLE, loc, 6, 0.2, 0.2, 0.2, 0.0, block.getBlockData());
                    ++processed;
                }
            }
        }, 0L, 1L);
        this.shatterWaveTasks.put(waveKey, task);
    }

    private boolean isVisibleOre(Block block) {
        if (block == null || !this.isOre(block.getType())) {
            return false;
        }
        for (org.bukkit.block.BlockFace face : new org.bukkit.block.BlockFace[]{org.bukkit.block.BlockFace.UP, org.bukkit.block.BlockFace.DOWN, org.bukkit.block.BlockFace.NORTH, org.bukkit.block.BlockFace.SOUTH, org.bukkit.block.BlockFace.EAST, org.bukkit.block.BlockFace.WEST}) {
            Block neighbor = block.getRelative(face);
            if (!neighbor.getType().isOccluding()) {
                return true;
            }
        }
        return false;
    }

    private record ShatterTarget(Block block, int distance) {
    }

    private boolean isShatterCandidate(Block block, Material logicalType, boolean meteorCore, boolean meteorOre, boolean generatorOre) {
        if (block == null || block.getType().isAir()) {
            return false;
        }
        if (this.meteorService != null && this.meteorService.isMeteorBlock(block) || this.isMeteorOre(block)) {
            return false;
        }
        if (meteorCore || meteorOre || generatorOre) {
            return true;
        }
        Material type = block.getType();
        if (type == logicalType) {
            return true;
        }
        Material normalized = this.normalizeOreForExp(type);
        return this.isOre(type) || this.isOre(normalized);
    }

    private boolean isMeteorShatterCandidate(Block block) {
        if (block == null || block.getType().isAir()) {
            return false;
        }
        Material type = block.getType();
        Material normalized = this.normalizeOreForExp(type);
        return this.isOre(type) || this.isOre(normalized) || this.isMeteorOre(block) || this.isGeneratedOre(block);
    }

    private boolean isMeteorOre(Block block) {
        return this.meteorService != null && this.meteorService.isMeteorOre(block);
    }

    private boolean isGeneratedOre(Block block) {
        return this.generatorService != null && this.generatorService.isGeneratedOre(block);
    }

    private boolean breakMeteorShatterExtra(Block block, Player player, ItemStack tool) {
        return this.breakMeteorShatterExtra(block, player, tool, false);
    }

    private boolean breakMeteorShatterExtra(Block block, Player player, ItemStack tool, boolean suppressMineSound) {
        if (block == null || block.getType().isAir()) {
            return false;
        }
        Material type = block.getType();
        Material normalizedType = this.normalizeOreForExp(type);
        boolean harbourerPillar = this.harbourerBossService != null && this.harbourerBossService.isPillarBlock(block);
        if (this.isChargeLocked(tool)) {
            this.notifyPickaxeChargeFull(player);
            return false;
        }
        boolean miniPalmProc = this.tryMiniPalmTreeProc(player);
        int gain = this.pickaxeManager.energyForBlock(tool, normalizedType);
        if (this.isGeneratedOre(block)) {
            gain *= 2;
        }
        gain = this.applyCoalPenalty(normalizedType, tool.getType(), gain);
        Map<String, Integer> enchants = this.pickaxeManager.getEnchants(tool);
        int luck = enchants.getOrDefault("luck", 0);
        int collector = enchants.getOrDefault("energycollector", 0);
        if (collector > 0) {
            double chance = this.procChanceWithLuck("energycollector", collector, 25.0, luck) / 100.0;
            if (this.random.nextDouble() < chance) {
                gain *= 2;
            }
        }
        gain = this.applyArmorChargeBonuses(player, gain);
        gain = this.boosterService.applyEnergyBoost(player, gain);
        double bonusPercent = this.maskManager != null ? this.maskManager.getEnergyBonusPercent(player) : 0.0;
        if (bonusPercent > 0.0) {
            gain = (int)Math.round((double)gain * (1.0 + bonusPercent / 100.0));
        }
        gain = this.applyMoonBootsMeteorBonus(player, block, gain);
        gain = this.applyKryoAmuletMiningBonus(player, normalizedType, gain);
        if (miniPalmProc) {
            gain *= 2;
        }
        if (gain > 0) {
            if (this.isKryoPickaxeSkin(tool)) {
                this.pickaxeManager.addEnergyOverflow(tool, gain);
            } else {
                this.pickaxeManager.addEnergy(tool, gain);
            }
            if (this.isChargeLocked(tool)) {
                this.notifyPickaxeChargeFull(player);
                if (this.tutorialService != null) {
                    this.tutorialService.handlePickaxeChargeFull(player, tool);
                }
            }
        }
        int playerExp = this.resolveOreExp(normalizedType);
        if (this.isGeneratedOre(block)) {
            playerExp *= 2;
        }
        if (playerExp > 0) {
            playerExp = (int)Math.round((double)playerExp * this.pickaxeManager.getXpMasteryMultiplier(tool));
            int taxed = this.applyGuardTax(player, playerExp);
            int boosted = this.boosterService.applyXpBoost(player, taxed);
            boosted = this.applyMoonBootsMeteorBonus(player, block, boosted);
            if (miniPalmProc) {
                boosted *= 2;
            }
            this.playerLevelService.addExp(player, boosted);
        }
        List<ItemStack> drops = this.buildMiningDrops(block, tool, player, type, false, false, false, this.pickaxeManager.getHoarderMultiplier(tool));
        this.applyArmorDropBonuses(player, drops, type);
        if (miniPalmProc) {
            this.applyMiniPalmTreeOreBonus(drops);
        }
        ShardService.Tier tierDrop = this.rollFragmentDrop(player, tool, type);
        ItemStack shardDrop = tierDrop != null ? this.plugin.getShardService().createShard(tierDrop) : null;
        if (tierDrop != null) {
            this.activateShardIncentive(player);
            if (this.isToggleEnabled(player, Toggle.FRAGMENT_NOTIFICATIONS)) {
                this.notifyFragmentDiscovery(player, tierDrop);
            }
        }
        if (miniPalmProc) {
            this.sendMiniPalmTreeMessage(player, true);
        }
        this.handleShatterAlchemyDrops(player, drops);
        if (shardDrop != null) {
            this.giveMiningReward(player, shardDrop);
        }
        if (harbourerPillar) {
            if (this.harbourerBossService != null) {
                this.harbourerBossService.handlePillarMine(block);
            }
            block.setType(Material.AIR, false);
        } else if (this.isMeteorOre(block)) {
            this.meteorService.clearMeteorOre(block);
            if (this.oreRegenService != null) {
                this.oreRegenService.removePending(block);
            }
            block.setType(Material.AIR, false);
        } else if (this.isGeneratedOre(block)) {
            this.generatorService.handleGeneratedOreMined(block, player);
        } else if (this.oreRegenService != null) {
            this.oreRegenService.handleMine(block, false);
        }
        this.applyErosion(player, block);
        this.blockProgressService.clear(block);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.blockProgressService.clear(block), 1L);
        if (!suppressMineSound) {
            this.playMineSound(player);
        }
        this.tryPrestigeVanish(player, tool);
        return true;
    }

    private boolean isAllowedInOreOnlyWorld(Block block) {
        return this.isOre(block.getType()) || this.generatorService != null && this.generatorService.isGeneratedOre(block) || this.meteorService != null && this.meteorService.isMeteorOre(block);
    }

    private void sendOreOnlyWarning(Player player) {
        long now = System.currentTimeMillis();
        Long lastWarn = this.oreOnlyWarnAt.get(player.getUniqueId());
        if (lastWarn != null && now - lastWarn.longValue() < 1500L) {
            return;
        }
        this.oreOnlyWarnAt.put(player.getUniqueId(), now);
        player.sendMessage(Text.color("&cOnly ore blocks can be mined in this world."));
    }

    private boolean attemptBreakExtra(Block block, Player player, ItemStack tool) {
        return this.attemptBreakExtra(block, player, tool, null, false, false, false, false, false, false);
    }

    private boolean attemptBreakExtra(Block block, Player player, ItemStack tool, boolean ignoreAllowedBlock, boolean ignoreChargeCap, boolean ignoreRegen, boolean deferOreSave, boolean skipChargeGain) {
        return this.attemptBreakExtra(block, player, tool, null, ignoreAllowedBlock, ignoreChargeCap, ignoreRegen, deferOreSave, skipChargeGain, false);
    }

    private boolean attemptBreakExtra(Block block, Player player, ItemStack tool, boolean ignoreAllowedBlock, boolean ignoreChargeCap, boolean ignoreRegen, boolean deferOreSave, boolean skipChargeGain, boolean suppressMineSound) {
        return this.attemptBreakExtra(block, player, tool, null, ignoreAllowedBlock, ignoreChargeCap, ignoreRegen, deferOreSave, skipChargeGain, suppressMineSound);
    }

    private boolean attemptBreakExtra(Block block, Player player, ItemStack tool, BlockBreakEvent event, boolean ignoreAllowedBlock, boolean ignoreChargeCap, boolean ignoreRegen, boolean deferOreSave, boolean skipChargeGain, boolean suppressMineSound) {
        boolean generatorOre;
        if (block == null || block.getType().isAir()) {
            return false;
        }
        boolean riotWorld = this.plugin.getPrisonRiotService() != null && this.plugin.getPrisonRiotService().isRiotWorld(block.getWorld());
        Material type = block.getType();
        if (riotWorld) {
            if (this.plugin.getPrisonRiotService() == null || !this.plugin.getPrisonRiotService().isRoundActive() || !this.plugin.getPrisonRiotService().isParticipant(player)) {
                return false;
            }
            if (!this.isOre(type)) {
                return false;
            }
            Material normalizedType = this.normalizeOreForExp(type);
            int riotPoints = this.plugin.getPrisonRiotService().getOrePoints(normalizedType);
            if (riotPoints > 0) {
                this.plugin.getPrisonRiotService().addEventPoints(player.getUniqueId(), riotPoints);
            }
            int riotExp = this.plugin.getPrisonRiotService().getOreExp(normalizedType);
            if (riotExp > 0) {
                this.playerLevelService.addExp(player, riotExp);
            }
            if (event != null) {
                event.setCancelled(true);
                event.setDropItems(false);
                event.setExpToDrop(0);
            }
            block.setType(Material.AIR, false);
            this.blockProgressService.clear(block);
            Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.blockProgressService.clear(block), 1L);
            if (!suppressMineSound) {
                this.playMineSound(player);
            }
            this.tryPrestigeVanish(player, tool);
            return true;
        }
        if (this.generatorService != null && this.generatorService.handleRefinedBaseBroken(block, player)) {
            return true;
        }
        Material normalizedType = this.normalizeOreForExp(type);
        if (!ignoreAllowedBlock && !this.pickaxeManager.isAllowedBlock(tool, normalizedType)) {
            return false;
        }
        boolean meteorOre = this.meteorService != null && this.meteorService.isMeteorOre(block);
        boolean bl = generatorOre = this.generatorService != null && this.generatorService.isGeneratedOre(block);
        boolean miniPalmProc = this.tryMiniPalmTreeProc(player);
        if (!riotWorld && !ignoreRegen && this.oreRegenService.isRegenerating(block) && !meteorOre) {
            return false;
        }
        if (this.isChargeLocked(tool) && !ignoreChargeCap) {
            this.notifyPickaxeChargeFull(player);
            return false;
        }
        int gain = 0;
        if (!skipChargeGain) {
            gain = this.pickaxeManager.energyForBlock(tool, normalizedType);
            if (meteorOre) {
                gain *= METEOR_ORE_MULTIPLIER;
            } else if (generatorOre) {
                gain *= 2;
            }
            gain = this.applyCoalPenalty(normalizedType, tool.getType(), gain);
            Map<String, Integer> enchants = this.pickaxeManager.getEnchants(tool);
            int luck = enchants.getOrDefault("luck", 0);
            int collector = enchants.getOrDefault("energycollector", 0);
            if (collector > 0) {
                double chance = this.procChanceWithLuck("energycollector", collector, 25.0, luck) / 100.0;
                if (this.random.nextDouble() < chance) {
                    gain *= 2;
                }
            }
            gain = this.applyArmorChargeBonuses(player, gain);
            if (gain > 0 && (!this.isChargeLocked(tool) || ignoreChargeCap)) {
                double bonusPercent;
                gain = this.boosterService.applyEnergyBoost(player, gain);
                if (this.maskManager != null && (bonusPercent = this.maskManager.getEnergyBonusPercent(player)) > 0.0) {
                    gain = (int) Math.round((double) gain * (1.0 + bonusPercent / 100.0));
                }
                gain = this.applyMoonBootsMeteorBonus(player, block, gain);
                gain = this.applyKryoAmuletMiningBonus(player, normalizedType, gain);
                gain = this.applyUtilityBeltMiningBonus(player, normalizedType, gain);
                if (miniPalmProc) {
                    gain *= 2;
                }
                if (this.isKryoPickaxeSkin(tool)) {
                    this.pickaxeManager.addEnergyOverflow(tool, gain);
                } else {
                    this.pickaxeManager.addEnergy(tool, gain);
                }
                if (this.isChargeLocked(tool)) {
                    this.notifyPickaxeChargeFull(player);
                    if (this.tutorialService != null) {
                        this.tutorialService.handlePickaxeChargeFull(player, tool);
                    }
                }
            }
        }
        Material expType = normalizedType;
        int playerExp = this.resolveOreExp(expType);
        if (meteorOre) {
            playerExp *= METEOR_ORE_MULTIPLIER;
        } else if (generatorOre) {
            playerExp *= 2;
        }
        if (playerExp > 0) {
            playerExp = (int)Math.round((double)playerExp * this.pickaxeManager.getXpMasteryMultiplier(tool));
            int taxed = this.applyGuardTax(player, playerExp);
            int boosted = this.boosterService.applyXpBoost(player, taxed);
            boosted = this.applyUtilityBeltMiningBonus(player, normalizedType, boosted);
            if (miniPalmProc) {
                boosted *= 2;
            }
            this.playerLevelService.addExp(player, boosted);
        }
        List<ItemStack> drops = riotWorld ? Collections.emptyList() : this.buildMiningDrops(block, tool, player, type, false, meteorOre, generatorOre, this.pickaxeManager.getHoarderMultiplier(tool));
        this.applyArmorDropBonuses(player, drops, type);
        if (miniPalmProc) {
            this.applyMiniPalmTreeOreBonus(drops);
        }
        ShardService.Tier tierDrop = this.rollFragmentDrop(player, tool, type);
        ItemStack shardDrop = tierDrop != null ? this.plugin.getShardService().createShard(tierDrop) : null;
        if (tierDrop != null && !riotWorld) {
            this.activateShardIncentive(player);
            if (this.isToggleEnabled(player, Toggle.FRAGMENT_NOTIFICATIONS)) {
                this.notifyFragmentDiscovery(player, tierDrop);
            }
        }
        if (!riotWorld) {
            this.handleShatterAlchemyDrops(player, drops);
        }
        if (miniPalmProc) {
            this.sendMiniPalmTreeMessage(player, true);
        }
        if (shardDrop != null && !riotWorld) {
            this.giveMiningReward(player, shardDrop);
        }
        if (meteorOre) {
            this.meteorService.clearMeteorOre(block);
            if (this.oreRegenService != null) {
                this.oreRegenService.removePending(block);
            }
            block.setType(Material.AIR, false);
        } else if (generatorOre) {
            if (event != null) {
                event.setCancelled(true);
                event.setDropItems(false);
            }
            this.generatorService.handleGeneratedOreMined(block, player);
        } else if (riotWorld) {
            block.setType(Material.AIR, false);
        } else if (deferOreSave) {
            this.oreRegenService.handleMine(block, false);
        } else {
            this.oreRegenService.handleMine(block);
            block.setType(Material.STONE, false);
        }
        this.applyErosion(player, block);
        this.blockProgressService.clear(block);
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.blockProgressService.clear(block), 1L);
        if (!suppressMineSound) {
            this.playMineSound(player);
        }
        this.tryPrestigeVanish(player, tool);
        return true;
    }

    private List<ItemStack> buildMiningDrops(Block block, ItemStack tool, Player player, Material dropType, boolean meteorCore, boolean meteorOre, boolean generatorOre, double hoarderMultiplier) {
        if (meteorCore) {
            return Collections.singletonList(new ItemStack(dropType));
        }
        if (meteorOre) {
            return Collections.singletonList(new ItemStack(dropType, 64));
        }
        if (generatorOre) {
            ArrayList<ItemStack> drops = new ArrayList<>();
            drops.add(new ItemStack(dropType));
            this.applyHoarderMultiplier(drops, hoarderMultiplier);
            return drops;
        }
        Material bonus = null;
        if (dropType == Material.COAL_ORE) {
            bonus = Material.COAL;
        } else if (dropType == Material.IRON_ORE) {
            bonus = Material.IRON_INGOT;
        } else if (dropType == Material.GOLD_ORE) {
            bonus = Material.GOLD_INGOT;
        } else if (dropType == Material.LAPIS_ORE) {
            bonus = Material.LAPIS_LAZULI;
        } else if (dropType == Material.REDSTONE_ORE) {
            bonus = Material.REDSTONE;
        } else if (dropType == Material.DIAMOND_ORE) {
            bonus = Material.DIAMOND;
        } else if (dropType == Material.EMERALD_ORE) {
            bonus = Material.EMERALD;
        }
        ArrayList<ItemStack> drops = new ArrayList<>();
        drops.add(new ItemStack(dropType));
        if (bonus != null && this.random.nextDouble() < 0.1) {
            drops.add(new ItemStack(bonus));
        }
        if (bonus == null) {
            drops.addAll(block.getDrops(tool, (Entity) player));
        }
        this.applyHoarderMultiplier(drops, hoarderMultiplier);
        return drops;
    }

    private void applyFissure(Player player, Block origin, int level) {
        int radius = 1 + (level - 1) / 2;
        float damage = Math.min(0.15f + 0.05f * (float) (level - 1), 0.9f);
        damage *= (float)this.pickaxeManager.getMiningSpeedMultiplier(player.getInventory().getItemInMainHand());
        int maxBlocks = 3 + level * 2;
        int affected = 0;
        for (int dx = -radius; dx <= radius && affected < maxBlocks; ++dx) {
            for (int dy = -radius; dy <= radius && affected < maxBlocks; ++dy) {
                for (int dz = -radius; dz <= radius && affected < maxBlocks; ++dz) {
                    Block target;
                    if (dx == 0 && dy == 0 && dz == 0 || (target = origin.getRelative(dx, dy, dz)).getType().isAir() || target.getType() == Material.STONE || !this.pickaxeManager.isAllowedBlock(player.getInventory().getItemInMainHand(), target.getType()))
                        continue;
                    this.blockProgressService.addProgress(target, player, damage);
                    ++affected;
                }
            }
        }
    }

    private void triggerRockyBurst(Player player, Block origin, ItemStack tool, Material visualType, Material logicalType, boolean meteorCore, boolean meteorOre, boolean generatorOre, int level) {
        if (player == null || origin == null || tool == null || visualType == null || origin.getWorld() == null) {
            return;
        }
        World world = origin.getWorld();
        Location procLoc = origin.getLocation().add(0.5, 0.5, 0.5);
        world.playSound(procLoc, Sound.BLOCK_STONE_BREAK, 1.0f, 0.9f);
        world.playSound(procLoc, Sound.BLOCK_GRAVEL_BREAK, 0.85f, 0.8f);
        world.spawnParticle(Particle.BLOCK_CRUMBLE, procLoc, 12, 0.35, 0.25, 0.35, 0.0, visualType.createBlockData());
        List<Block> targets = this.findRockyTargets(origin, tool, logicalType, meteorCore, meteorOre, generatorOre, level);
        if (targets.isEmpty()) {
            return;
        }
        int displayCount = Math.min(targets.size(), Math.max(3, Math.min(12, 3 + level)));
        Location source = player.getEyeLocation().clone();
        Vector forward = source.getDirection().normalize();
        source.add(forward.clone().multiply(0.7));
        source.add(0.0, -0.35, 0.0);
        List<Block> chosenTargets = new ArrayList<Block>(targets);
        Collections.shuffle(chosenTargets, this.random);
        chosenTargets = chosenTargets.subList(0, displayCount);
        for (int i = 0; i < chosenTargets.size(); ++i) {
            Block target = chosenTargets.get(i);
            if (target == null) {
                continue;
            }
            Location targetLoc = target.getLocation().add(0.5, 0.5, 0.5);
            double spreadAngle = (double)i / (double)chosenTargets.size() * Math.PI * 2.0;
            double spreadDistance = 1.3 + this.random.nextDouble() * (0.9 + (double)level * 0.15);
            Vector spread = new Vector(Math.cos(spreadAngle) * spreadDistance, 0.0, Math.sin(spreadAngle) * spreadDistance);
            Location apex = source.clone().add(0.0, 4.0 + (double)level * 0.4 + this.random.nextDouble() * 1.5, 0.0).add(spread);
            this.spawnRockyDisplay(player, tool, target, visualType, source.clone(), apex, targetLoc, logicalType, meteorCore, meteorOre, generatorOre, level);
        }
    }

    private List<Block> findRockyTargets(Block origin, ItemStack tool, Material logicalType, boolean meteorCore, boolean meteorOre, boolean generatorOre, int level) {
        ArrayList<Block> targets = new ArrayList<Block>();
        if (origin == null || origin.getWorld() == null) {
            return targets;
        }
        int radius = Math.max(4, 5 + level);
        Location center = origin.getLocation();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();
        for (int dx = -radius; dx <= radius; ++dx) {
            for (int dy = -radius; dy <= radius; ++dy) {
                for (int dz = -radius; dz <= radius; ++dz) {
                    Block candidate = origin.getWorld().getBlockAt(cx + dx, cy + dy, cz + dz);
                    if (candidate.equals(origin) || candidate.getType().isAir()) {
                        continue;
                    }
                    if (this.oreRegenService != null && this.oreRegenService.isRegenerating(candidate)) {
                        continue;
                    }
                    Material type = candidate.getType();
                    Material normalized = this.normalizeOreForExp(type);
                    if (!meteorCore && !meteorOre && !generatorOre && !this.pickaxeManager.isAllowedBlock(tool, normalized)) {
                        continue;
                    }
                    if (!this.isRockyTarget(candidate, type, normalized, meteorCore, meteorOre, generatorOre, tool)) {
                        continue;
                    }
                    targets.add(candidate);
                }
            }
        }
        Collections.shuffle(targets, this.random);
        return targets;
    }

    private void spawnRockyDisplay(Player player, ItemStack tool, Block target, Material visualType, Location start, Location apex, Location targetLoc, Material logicalType, boolean meteorCore, boolean meteorOre, boolean generatorOre, int level) {
        if (player == null || tool == null || target == null || visualType == null || start == null || apex == null || targetLoc == null) {
            return;
        }
        World world = target.getWorld();
        if (world == null) {
            return;
        }
        final ArmorStand display = (ArmorStand) world.spawn(start, ArmorStand.class, spawned -> {
            spawned.setInvisible(true);
            spawned.setGravity(false);
            spawned.setSmall(true);
            spawned.setArms(false);
            spawned.setBasePlate(false);
            spawned.setInvulnerable(true);
            spawned.setPersistent(false);
            spawned.setCustomNameVisible(false);
            if (spawned.getEquipment() != null) {
                spawned.getEquipment().setHelmet(new ItemStack(visualType));
            }
        });
        new BukkitRunnable() {
            private int ticks;
            private Location current = start.clone();

            @Override
            public void run() {
                if (!display.isValid() || player.isDead() || !player.isOnline()) {
                    if (display.isValid()) {
                        display.remove();
                    }
                    this.cancel();
                    return;
                }
                ++this.ticks;
                Location next;
                if (this.ticks <= 7) {
                    Vector toApex = apex.toVector().subtract(this.current.toVector());
                    double distance = Math.max(0.15, toApex.length());
                    Vector step = toApex.normalize().multiply(Math.min(0.8, distance * 0.34));
                    next = this.current.clone().add(step);
                } else {
                    Vector toTarget = targetLoc.toVector().subtract(this.current.toVector());
                    double distance = toTarget.length();
                    if (distance <= 0.7) {
                        display.remove();
                        world.playSound(targetLoc, Sound.BLOCK_ANVIL_LAND, 0.9f, 1.15f);
                        world.spawnParticle(Particle.BLOCK_CRUMBLE, targetLoc, 10, 0.25, 0.25, 0.25, 0.0, visualType.createBlockData());
                        MiningListener.this.breakRockyImpactArea(player, tool, target, visualType, logicalType, meteorCore, meteorOre, generatorOre, level);
                        this.cancel();
                        return;
                    }
                    Vector step = toTarget.normalize().multiply(Math.min(1.15, Math.max(0.22, distance * 0.28)));
                    next = this.current.clone().add(step);
                }
                next.setYaw(this.current.getYaw() + 18.0f);
                next.setPitch(0.0f);
                display.teleport(next);
                this.current = next;
            }
        }.runTaskTimer((Plugin) this.plugin, 1L, 1L);
    }

    private void breakRockyImpactArea(Player player, ItemStack tool, Block center, Material visualType, Material logicalType, boolean meteorCore, boolean meteorOre, boolean generatorOre, int level) {
        if (player == null || tool == null || center == null || center.getWorld() == null) {
            return;
        }
        World world = center.getWorld();
        int radius = Math.max(1, Math.min(3, 1 + level / 2));
        int maxBlocks = Math.max(4, Math.min(20, 4 + level * 3));
        HashSet<String> visited = new HashSet<String>();
        int broken = 0;
        for (int dy = 0; dy >= -1 && broken < maxBlocks; --dy) {
            for (int dx = -radius; dx <= radius && broken < maxBlocks; ++dx) {
                for (int dz = -radius; dz <= radius && broken < maxBlocks; ++dz) {
                    Block candidate = center.getRelative(dx, dy, dz);
                    if (candidate == null || candidate.getType().isAir()) {
                        continue;
                    }
                    if (this.oreRegenService != null && this.oreRegenService.isRegenerating(candidate)) {
                        continue;
                    }
                    Material candidateType = candidate.getType();
                    Material normalized = this.normalizeOreForExp(candidateType);
                    if (!this.isRockyTarget(candidate, candidateType, normalized, meteorCore, meteorOre, generatorOre, tool)) {
                        continue;
                    }
                    String key = candidate.getWorld().getName() + ":" + candidate.getX() + ":" + candidate.getY() + ":" + candidate.getZ();
                    if (!visited.add(key)) {
                        continue;
                    }
                    if (broken == 0) {
                        world.playSound(candidate.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_STONE_BREAK, 0.8f, 0.95f);
                    }
                    this.attemptBreakExtra(candidate, player, tool);
                    world.spawnParticle(Particle.BLOCK_CRUMBLE, candidate.getLocation().add(0.5, 0.5, 0.5), 6, 0.2, 0.2, 0.2, 0.0, visualType.createBlockData());
                    ++broken;
                }
            }
        }
        if (broken > 1) {
            world.playSound(center.getLocation().add(0.5, 0.5, 0.5), Sound.BLOCK_ANVIL_LAND, 0.9f, 0.95f);
        }
    }

    private boolean isRockyTarget(Block candidate, Material candidateType, Material normalizedType, boolean meteorCore, boolean meteorOre, boolean generatorOre, ItemStack tool) {
        if (candidate == null || candidateType == null || candidateType.isAir()) {
            return false;
        }
        if (meteorCore || meteorOre || generatorOre) {
            if (this.isMeteorOre(candidate)) {
                return true;
            }
            if (this.isGeneratedOre(candidate)) {
                return this.isOre(candidateType);
            }
            return this.isOre(candidateType);
        }
        if (!this.pickaxeManager.isAllowedBlock(tool, normalizedType)) {
            return false;
        }
        return this.isOre(candidateType) || this.isOre(normalizedType);
    }

    private Material normalizeOreForExp(Material type) {
        switch (type) {
            case DEEPSLATE_COAL_ORE: {
                return Material.COAL_ORE;
            }
            case DEEPSLATE_IRON_ORE: {
                return Material.IRON_ORE;
            }
            case DEEPSLATE_COPPER_ORE: {
                return Material.COPPER_ORE;
            }
            case DEEPSLATE_GOLD_ORE:
            case NETHER_GOLD_ORE: {
                return Material.GOLD_ORE;
            }
            case DEEPSLATE_REDSTONE_ORE: {
                return Material.REDSTONE_ORE;
            }
            case DEEPSLATE_LAPIS_ORE: {
                return Material.LAPIS_ORE;
            }
            case DEEPSLATE_DIAMOND_ORE: {
                return Material.DIAMOND_ORE;
            }
            case DEEPSLATE_EMERALD_ORE: {
                return Material.EMERALD_ORE;
            }
        }
        return type;
    }

    private int resolveOreExp(Material type) {
        String path = "player-level.ore-exp." + type.name();
        if (this.plugin.getConfig().contains(path)) {
            return this.plugin.getConfig().getInt(path, 0);
        }
        // Fallback defaults to prevent zero XP if config is missing/old
        return switch (type) {
            case COAL_ORE -> 25;
            case IRON_ORE -> 50;
            case LAPIS_ORE -> 75;
            case REDSTONE_ORE -> 75;
            case GOLD_ORE -> 125;
            case DIAMOND_ORE -> 250;
            case EMERALD_ORE -> 500;
            default -> 0;
        };
    }

    private void handleInventoryFullState(Player player, boolean inventoryFull) {
        if (player == null) {
            return;
        }
        UUID id = player.getUniqueId();
        if (!inventoryFull) {
            this.inventoryFullTitleAt.remove(id);
            return;
        }
        if (!this.isToggleEnabled(player, Toggle.INVENTORY_FULL_NOTIFICATIONS)) {
            return;
        }
        String title = "&c&l(!) &cYour inventory is full!";
        String subtitle = "&7Make space to keep mining";
        String message = "&c&l(!) &cYour inventory is full!\n&7Make room to keep mining! All additional items have been destroyed.";
        player.sendTitle(Text.color(title), Text.color(subtitle), 5, 40, 10);
        player.sendMessage(Text.color(message));
        this.inventoryFullTitleAt.put(id, System.currentTimeMillis());
    }

    private void playItemAnimation(Player player, Location blockLocation, Material material, org.bukkit.block.BlockFace clickedFace) {
        ItemAnimationService animationService = this.plugin.getItemAnimationService();
        if (animationService == null || player == null || blockLocation == null || material == null) {
            return;
        }
        animationService.play(player, blockLocation, material, clickedFace);
    }

    private org.bukkit.block.BlockFace resolveAnimationFace(Player player) {
        if (player == null) {
            return org.bukkit.block.BlockFace.UP;
        }
        return this.lastBlockFace.getOrDefault(player.getUniqueId(), org.bukkit.block.BlockFace.UP);
    }

    private void giveMiningReward(Player player, ItemStack item) {
        if (player == null || item == null || item.getType().isAir() || item.getAmount() <= 0) {
            return;
        }
        ItemStack reward = item.clone();
        int remaining = this.collectIntoSatchels(player, reward);
        if (remaining <= 0) {
            return;
        }
        reward.setAmount(remaining);
        if (this.plugin.getStashService() != null) {
            this.plugin.getStashService().giveOrStash(player, reward);
            return;
        }
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(new ItemStack[]{reward});
        for (ItemStack stack : overflow.values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), stack);
        }
    }

    private void tryGangPointNote(Player player, Location blockLocation) {
        if (player == null || this.plugin.getGangPointService() == null) {
            return;
        }
        if (this.random.nextDouble() >= GANG_POINT_NOTE_CHANCE) {
            return;
        }
        Location effectLocation = blockLocation != null ? blockLocation.clone().add(0.5, 0.5, 0.5) : player.getLocation();
        if (effectLocation.getWorld() != null) {
            effectLocation.getWorld().spawnParticle(Particle.DUST, effectLocation, 28, 0.18, 0.18, 0.18, 0.0, new Particle.DustOptions(Color.fromRGB(0, 255, 0), 1.35f));
            effectLocation.getWorld().playSound(effectLocation, "minecraft:block.piston.extend", 1.0f, 1.0f);
        }
        player.sendMessage(Text.color("&a&l(!) &aYou discovered &f&n10&r &aGang Points\n&7Redeem them to boost your gangs total points."));
        this.plugin.getGangPointService().giveGangPointNote(player, 10);
    }

    private void notifyFragmentDiscovery(Player player, ShardService.Tier tierDrop) {
        if (player == null || tierDrop == null || this.plugin.getShardService() == null) {
            return;
        }
        String fragmentName = this.plugin.getShardService().getDisplayName(tierDrop).replace("&l", "").replace("&L", "");
        player.sendMessage(Text.color("&6&l(!) &6Fragment Discovered!\n&f" + fragmentName));
        player.playSound(player.getLocation(), "minecraft:entity.firework_rocket.twinkle_far", 1.0f, 1.0f);
        player.playSound(player.getLocation(), "minecraft:entity.player.levelup", 1.0f, 1.0f);
        player.sendTitle(Text.color("&6&lFragment Discovered"), Text.color("&f" + fragmentName), 5, 40, 10);
    }

    private boolean isFistCoalMine(ItemStack tool, Material type) {
        return this.isCoalOre(type) && (tool == null || tool.getType().isAir());
    }

    private boolean isCoalOre(Material type) {
        return type == Material.COAL_ORE || type == Material.DEEPSLATE_COAL_ORE;
    }

    private void sendMineActionBar(Player player, int chargeGain, int boostedExp, List<String> procList, int momentumStacks) {
        StringBuilder action = new StringBuilder();
        if (chargeGain > 0 && this.isToggleEnabled(player, Toggle.CHARGE_ACTION_BAR)) {
            action.append("+").append(chargeGain).append(" Charge");
        }
        if (boostedExp > 0 && this.isToggleEnabled(player, Toggle.MINING_XP_ACTION_BAR)) {
            if (action.length() > 0) {
                action.append(" &7| &7");
            }
            action.append("+ ").append(boostedExp).append(" XP");
        }
        if (!procList.isEmpty() && this.isToggleEnabled(player, Toggle.ENCHANT_PROC_ACTION_BAR)) {
            if (action.length() > 0) {
                action.append(" &7| &7");
            }
            action.append(String.join(", ", procList)).append(" &aPROC");
        }
        if (momentumStacks > 0 && this.isToggleEnabled(player, Toggle.ENCHANT_PROC_ACTION_BAR)) {
            if (action.length() > 0) {
                action.append(" &7| ");
            }
            action.append("&dMomentum x").append(momentumStacks);
        }
        if (action.length() > 0) {
            player.sendActionBar(Text.color("&d" + action));
        }
    }

    private String formatProc(String enchantId, int level) {
        return EnchantDisplayUtil.format(this.customEnchantService, enchantId, level);
    }

    private void notifyPickaxeChargeFull(Player player) {
        if (player == null) {
            return;
        }
        if (this.isToggleEnabled(player, Toggle.PICKAXE_CHARGE_FULL_NOTIFICATIONS)) {
            player.sendTitle(Text.color("&cPickaxe is full of charge"), "", 5, 40, 10);
            player.sendMessage(Lang.msg("pickaxe.full", "&eYour pickaxe is full of charge."));
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        }
    }

    private boolean isToggleEnabled(Player player, Toggle toggle) {
        return this.playerToggleService == null || this.playerToggleService.isEnabled(player, toggle);
    }

    private boolean isChargeLocked(ItemStack tool) {
        if (this.isKryoPickaxeSkin(tool)) {
            return false;
        }
        return this.pickaxeManager.isPrisonPickaxe(tool)
                && this.pickaxeManager.getLevel(tool) < this.pickaxeManager.getMaxLevel()
                && this.pickaxeManager.isFull(tool);
    }

    private boolean isKryoPickaxeSkin(ItemStack tool) {
        if (tool == null || this.plugin.getAxialSkinsModule() == null) {
            return false;
        }
        return this.plugin.getAxialSkinsModule().isKryoPickaxeSkin(tool);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (this.meteorService != null && event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null && this.meteorService.isMeteorBlock(event.getClickedBlock())) {
            int remaining = this.meteorService.getMeteorOreCount(event.getClickedBlock());
            event.setCancelled(true);
            event.setUseInteractedBlock(Event.Result.DENY);
            event.setUseItemInHand(Event.Result.DENY);
            event.getPlayer().sendActionBar(Text.color("&6This meteor is enriched with &f&l" + remaining + " Ores"));
            return;
        }
        ItemStack tool = event.getItem();
        if (tool == null || !this.pickaxeManager.isPrisonPickaxe(tool)) {
            return;
        }
        Map<String, Integer> enchants = this.pickaxeManager.getEnchants(tool);
        int level = enchants.getOrDefault("fireball", 0);
        if (level <= 0) {
            return;
        }
        Player player = event.getPlayer();
        long now = System.currentTimeMillis();
        long cooldownMs = Math.max(20000L, 120000L - (long) (level - 1) * 10000L);
        long last = this.fireballCooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now - last < cooldownMs) {
            long remaining = (cooldownMs - (now - last)) / 1000L;
            player.sendActionBar(Text.color("&cFireball ready in " + remaining + "s"));
            return;
        }
        this.fireballCooldowns.put(player.getUniqueId(), now);
        this.launchFireballs(player, tool, level, true);
        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onProjectileHit(ProjectileHitEvent event) {
        Projectile projectile = event.getEntity();
        if (!(projectile instanceof SmallFireball)) {
            return;
        }
        SmallFireball fb = (SmallFireball) projectile;
        if (!fb.hasMetadata("prisons-fireball")) {
            return;
        }
        ProjectileSource projectileSource = fb.getShooter();
        if (!(projectileSource instanceof Player player)) {
            return;
        }
        Block hitBlock = event.getHitBlock();
        if (hitBlock == null) {
            return;
        }
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!this.pickaxeManager.isPrisonPickaxe(tool)) {
            return;
        }
        this.attemptBreakExtra(hitBlock, player, tool);
    }

    private void launchFireballs(Player player, ItemStack tool, int level, boolean fromAbility) {
        int maxTargets = Math.min(3 + level, 12);
        double radius = 8.0;
        ArrayList<Block> targets = new ArrayList<Block>();
        World world = player.getWorld();
        Location center = player.getLocation();
        int cx = center.getBlockX();
        int cy = center.getBlockY();
        int cz = center.getBlockZ();
        int dx = -((int) radius);
        while ((double) dx <= radius && targets.size() < maxTargets) {
            int dy = -((int) radius);
            while ((double) dy <= radius && targets.size() < maxTargets) {
                int dz = -((int) radius);
                while ((double) dz <= radius && targets.size() < maxTargets) {
                    Block b;
                    if (!((double) (dx * dx + dy * dy + dz * dz) > radius * radius) && !(b = world.getBlockAt(cx + dx, cy + dy, cz + dz)).getType().isAir() && b.getType() != Material.STONE && this.pickaxeManager.isAllowedBlock(tool, b.getType())) {
                        targets.add(b);
                    }
                    ++dz;
                }
                ++dy;
            }
            ++dx;
        }
        for (Block target : targets) {
            Vector dir = target.getLocation().add(0.5, 0.5, 0.5).toVector().subtract(player.getEyeLocation().toVector()).normalize();
            SmallFireball fb = (SmallFireball) player.launchProjectile(SmallFireball.class, dir.multiply(0.8));
            fb.setIsIncendiary(false);
            fb.setYield(0.0f);
            fb.setMetadata("prisons-fireball", (MetadataValue) new FixedMetadataValue((Plugin) this.plugin, (Object) true));
            fb.setMetadata("prisons-owner", (MetadataValue) new FixedMetadataValue((Plugin) this.plugin, (Object) player.getUniqueId().toString()));
            fb.setMetadata("prisons-level", (MetadataValue) new FixedMetadataValue((Plugin) this.plugin, (Object) level));
            new BukkitRunnable() {
                @Override
                public void run() {
                    if (fb.isDead() || fb.isOnGround() || !fb.isValid()) {
                        this.cancel();
                        return;
                    }
                    fb.getWorld().spawnParticle(Particle.FLAME, fb.getLocation(), 4, 0.05, 0.05, 0.05, 0.001);
                }
            }.runTaskTimer((Plugin) this.plugin, 1L, 1L);
        }
    }

    private int applyGuardTax(Player player, int exp) {
        double maxDistance = GuardService.GUARD_PROTECTION_RANGE;
        double maxTax = 0.2;
        double nearest = this.guardService.nearestGuardDistance(player.getLocation(), maxDistance);
        if (nearest < 0.0) {
            return exp;
        }
        double taxFraction = (maxDistance - nearest) / maxDistance * maxTax;
        double reduction = Math.ceil((double) exp * taxFraction);
        int taxed = (int) Math.max(0.0, (double) exp - reduction);
        return taxed;
    }

    private void playMineSound(Player player) {
        UUID id = player.getUniqueId();
        int tick = Bukkit.getCurrentTick();
        Integer last = this.lastMineSoundTick.get(id);
        if (last != null && last == tick) {
            return;
        }
        this.lastMineSoundTick.put(id, tick);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
    }

    private void applyHoarderMultiplier(List<ItemStack> drops, double hoarderMultiplier) {
        if (drops == null || drops.isEmpty() || hoarderMultiplier <= 1.0D) {
            return;
        }
        for (ItemStack stack : drops) {
            if (stack == null || stack.getType().isAir()) {
                continue;
            }
            int amount = Math.max(1, (int)Math.ceil((double)stack.getAmount() * hoarderMultiplier));
            stack.setAmount(Math.min(stack.getMaxStackSize(), amount));
        }
    }

    private void tryPrestigeVanish(Player player, ItemStack tool) {
        if (player == null || tool == null || !this.pickaxeManager.isPrisonPickaxe(tool)) {
            return;
        }
        double chance = this.pickaxeManager.getVanishChance(tool);
        int durationTicks = this.pickaxeManager.getVanishDurationTicks(tool);
        if (chance <= 0.0D || durationTicks <= 0) {
            return;
        }
        if (this.random.nextDouble() >= chance) {
            return;
        }
        if (this.plugin.getVanishService() != null) {
            this.plugin.getVanishService().vanishTemporarily(player, durationTicks);
        }
    }

    private int applyCoalPenalty(Material oreType, Material toolType, int gain) {
        if (oreType != Material.COAL_ORE) {
            return gain;
        }
        double multiplier = switch (toolType) {
            case STONE_PICKAXE -> 0.95;
            case IRON_PICKAXE -> 0.90;
            case GOLDEN_PICKAXE -> 0.75;
            case DIAMOND_PICKAXE -> 0.50;
            default -> 1.0;
        };
        return (int) Math.max(1L, Math.round((double) gain * multiplier));
    }

}
