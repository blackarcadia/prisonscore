package org.axial.prisonsCore.listener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.DestructionScrollService;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.service.ProtectionScrollService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class ScrollListener implements Listener {
    private final PrisonsCore plugin;
    private final GearManager gearManager;
    private final GearEnchantService gearEnchantService;
    private final ProtectionScrollService protectionScrollService;
    private final DestructionScrollService destructionScrollService;

    public ScrollListener(PrisonsCore plugin, GearManager gearManager, GearEnchantService gearEnchantService, ProtectionScrollService protectionScrollService, DestructionScrollService destructionScrollService) {
        this.plugin = plugin;
        this.gearManager = gearManager;
        this.gearEnchantService = gearEnchantService;
        this.protectionScrollService = protectionScrollService;
        this.destructionScrollService = destructionScrollService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        ItemStack cursor = event.getCursor();
        ItemStack target = event.getCurrentItem();
        if (cursor == null || target == null || target.getType().isAir()) {
            return;
        }
        if (this.protectionScrollService.isProtectionScroll(cursor)) {
            this.applyProtection(event, cursor, target);
            return;
        }
        if (this.destructionScrollService.isDestructionScroll(cursor)) {
            this.applyDestruction(event, cursor, target);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.refreshLater(event.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        this.refreshLater(event.getPlayer());
    }

    private void applyProtection(InventoryClickEvent event, ItemStack cursor, ItemStack target) {
        event.setCancelled(true);
        if (this.protectionScrollService.isProtectionScroll(target) || this.destructionScrollService.isDestructionScroll(target)) {
            return;
        }
        Player player = event.getWhoClicked() instanceof Player ? (Player)event.getWhoClicked() : null;
        this.protectionScrollService.protect(target);
        this.consumeOne(event, cursor);
        event.setCurrentItem(target);
        if (player != null) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
            player.sendMessage(Text.color("&aYour item is now protected on death."));
        }
    }

    private void applyDestruction(InventoryClickEvent event, ItemStack cursor, ItemStack target) {
        event.setCancelled(true);
        if (this.protectionScrollService.isProtectionScroll(target) || this.destructionScrollService.isDestructionScroll(target) || !this.gearManager.isGear(target)) {
            return;
        }
        Map<String, Integer> enchants = this.gearManager.getEnchants(target);
        if (enchants.isEmpty()) {
            if (event.getWhoClicked() instanceof Player player) {
                player.sendMessage(Text.color("&cThat gear has no custom enchants to remove."));
            }
            return;
        }
        List<Map.Entry<String, Integer>> entries = new ArrayList<Map.Entry<String, Integer>>(enchants.entrySet());
        Map.Entry<String, Integer> chosen = entries.get(ThreadLocalRandom.current().nextInt(entries.size()));
        enchants.remove(chosen.getKey());
        this.gearManager.setEnchants(target, enchants);
        this.gearManager.updateLore(target);
        int percent = this.destructionScrollService.getPercent(cursor);
        CustomEnchant enchant = this.gearEnchantService.getById(chosen.getKey());
        ItemStack orb = enchant != null ? this.gearEnchantService.createOrb(chosen.getKey(), chosen.getValue(), percent) : null;
        this.consumeOne(event, cursor);
        event.setCurrentItem(target);
        if (event.getWhoClicked() instanceof Player player) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            if (orb != null) {
                if (this.plugin.getStashService() != null) {
                    this.plugin.getStashService().giveOrStash(player, orb);
                } else {
                    Map<Integer, ItemStack> leftover = player.getInventory().addItem(orb);
                    if (!leftover.isEmpty()) {
                        leftover.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
                    }
                }
                player.sendMessage(Text.color("&aRemoved " + (enchant != null ? enchant.getDisplayNameForLevel(chosen.getValue()) : chosen.getKey()) + " &afrom your gear."));
            }
        }
    }

    private void refreshLater(Player player) {
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.protectionScrollService.refreshInventory(player));
    }

    private void consumeOne(InventoryClickEvent event, ItemStack cursor) {
        if (cursor.getAmount() <= 1) {
            event.setCursor(null);
        } else {
            cursor.setAmount(cursor.getAmount() - 1);
            event.setCursor(cursor);
        }
    }
}
