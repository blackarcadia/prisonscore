package org.axial.prisonsCore.listener;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.Gang;
import org.axial.prisonsCore.service.GangService;
import org.axial.prisonsCore.service.PlayerDataService;
import org.axial.prisonsCore.service.PlayerToggleService;
import org.axial.prisonsCore.service.TutorialService;
import org.axial.prisonsCore.util.ItemShowcaseUtil;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class GangChatListener implements Listener {
    private final PrisonsCore plugin;
    private final GangService gangService;
    private final PlayerDataService playerDataService;
    private final TutorialService tutorialService;
    private final PlayerToggleService toggleService;

    public GangChatListener(PrisonsCore plugin, GangService gangService, PlayerDataService playerDataService, TutorialService tutorialService, PlayerToggleService toggleService) {
        this.plugin = plugin;
        this.gangService = gangService;
        this.playerDataService = playerDataService;
        this.tutorialService = tutorialService;
        this.toggleService = toggleService;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        if (!this.gangService.isGangChat(sender.getUniqueId())) {
            return;
        }
        Gang gang = this.gangService.getGangByPlayer(sender.getUniqueId());
        if (gang == null) {
            this.gangService.setGangChat(sender.getUniqueId(), false);
            return;
        }
        event.setCancelled(true);
        String message = event.getMessage();
        ItemStack item = sender.getInventory().getItemInMainHand();
        if (ItemShowcaseUtil.containsToken(message) && !ItemShowcaseUtil.hasShowcaseableItem(item)) {
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> sender.sendMessage(Text.color("&cHold an item in your main hand to use [item].")));
            return;
        }
        Set<Player> recipients = new LinkedHashSet<Player>();
        gang.getMembers().keySet().forEach(uuid -> {
            Player p = Bukkit.getPlayer((UUID)uuid);
            if (p != null && p.isOnline() && (p.equals((Object)sender) || (!this.tutorialService.shouldFilterChat(p) && this.canSeeChat(p)))) {
                recipients.add(p);
            }
        });
        String prefix = "&2[" + gang.getName() + "] &2" + this.playerDataService.getChatName(sender) + ": &2";
        String consoleMessage = Text.color(prefix + (ItemShowcaseUtil.containsToken(message) ? ItemShowcaseUtil.replaceTokenWithName(message, item) : message));
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            if (ItemShowcaseUtil.containsToken(message)) {
                recipients.forEach(recipient -> recipient.sendMessage(ItemShowcaseUtil.buildMessage(prefix, message, item)));
            } else {
                String formatted = Text.color(prefix + message);
                recipients.forEach(recipient -> recipient.sendMessage(formatted));
            }
            Bukkit.getConsoleSender().sendMessage(consoleMessage);
        });
    }

    private boolean canSeeChat(Player player) {
        return this.toggleService == null || this.toggleService.canReceiveChat(player);
    }
}
