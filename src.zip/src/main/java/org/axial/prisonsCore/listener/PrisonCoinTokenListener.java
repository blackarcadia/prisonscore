package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.PrisonCoinService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public class PrisonCoinTokenListener implements Listener {
    private final PrisonCoinService prisonCoinService;

    public PrisonCoinTokenListener(PrisonCoinService prisonCoinService) {
        this.prisonCoinService = prisonCoinService;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.prisonCoinService.isCoinToken(item)) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        Player player = event.getPlayer();
        long amount = this.prisonCoinService.getTokenAmount(item);
        if (amount <= 0L) {
            player.sendMessage(Text.color("&cThat Prison Coin token is invalid."));
            return;
        }
        this.prisonCoinService.redeemCoinToken(player, item);
        player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        int newAmount = item.getAmount() - 1;
        if (newAmount <= 0) {
            player.getInventory().setItem(event.getHand(), null);
        } else {
            item.setAmount(newAmount);
            player.getInventory().setItem(event.getHand(), item);
        }
    }
}
