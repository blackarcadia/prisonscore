/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.FeatureToggleService;
import org.axial.prisonsCore.service.KitService;
import org.axial.prisonsCore.service.MeteorService;
import org.axial.prisonsCore.service.SeasonService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class FlareListener
implements Listener {
    private final MeteorService meteorService;
    private final KitService kitService;
    private final FeatureToggleService featureToggleService;

    public FlareListener(MeteorService meteorService, KitService kitService, FeatureToggleService featureToggleService) {
        this.meteorService = meteorService;
        this.kitService = kitService;
        this.featureToggleService = featureToggleService;
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=false)
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_BLOCK && action != Action.RIGHT_CLICK_AIR) {
            return;
        }
        ItemStack item = event.getItem();
        boolean gkitFlare = this.meteorService != null && this.meteorService.isGKitFlare(item);
        if (!this.isMeteorFlare(item) && !gkitFlare) {
            return;
        }
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        Player player = event.getPlayer();
        Location loc = action == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null ? event.getClickedBlock().getLocation().add(0.5, 1.0, 0.5) : player.getLocation().getBlock().getLocation().add(0.5, 1.0, 0.5);
        if (gkitFlare) {
            if (!this.featureToggleService.checkEnabled(player, FeatureToggleService.Feature.METEORS)) {
                return;
            }
            KitService.GKitType gkitType = this.meteorService.getGKitFlareType(item);
            if (gkitType != null && this.meteorService.spawnGKitFlareAt(loc, true, player, gkitType)) {
                this.consumeOne(player, item);
                player.getWorld().playSound(loc, Sound.ENTITY_ILLUSIONER_PREPARE_BLINDNESS, 1.0f, 0.6f);
                player.sendMessage(Text.color("&dYou launched a " + gkitType.plainName() + " flare!"));
            }
            return;
        }
        SeasonService seasonService = this.meteorService == null ? null : this.meteorService.getPlugin().getSeasonService();
        if (seasonService != null && !seasonService.isFeatureUnlocked(SeasonService.UnlockFeature.METEOR_FLARES)) {
            player.sendMessage(Text.color("&cMeteor Flares unlock on Day " + seasonService.getUnlockDay(SeasonService.UnlockFeature.METEOR_FLARES) + "."));
            return;
        }
        if (!this.featureToggleService.checkEnabled(player, FeatureToggleService.Feature.METEORS)) {
            return;
        }
        if (this.meteorService.spawnMeteorAt(loc, true, player)) {
            this.consumeOne(player, item);
            player.getWorld().playSound(loc, Sound.ENTITY_ILLUSIONER_PREPARE_BLINDNESS, 1.0f, 0.6f);
            player.sendMessage(Text.color("&dYou launched a meteor flare!"));
        }
    }

    private boolean isMeteorFlare(ItemStack item) {
        if (item == null || item.getType() != Material.REDSTONE_TORCH) {
            return false;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.hasDisplayName()) {
            return false;
        }
        String name = Text.strip(meta.getDisplayName()).toLowerCase();
        return name.contains("meteor") && name.contains("flare");
    }

    private void consumeOne(Player player, ItemStack stack) {
        int amt = stack.getAmount();
        if (amt <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            stack.setAmount(amt - 1);
            player.getInventory().setItemInMainHand(stack);
        }
    }
}
