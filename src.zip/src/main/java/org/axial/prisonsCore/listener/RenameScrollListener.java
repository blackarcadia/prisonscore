/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.inventory.EquipmentSlot
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.listener;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.service.RenameScrollService;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public class RenameScrollListener
implements Listener {
    private final PrisonsCore plugin;
    private final PickaxeManager pickaxeManager;
    private final RenameScrollService renameScrollService;
    private final Set<UUID> renameMode = Collections.synchronizedSet(new HashSet());

    public RenameScrollListener(PrisonsCore plugin, PickaxeManager pickaxeManager, RenameScrollService renameScrollService) {
        this.plugin = plugin;
        this.pickaxeManager = pickaxeManager;
        this.renameScrollService = renameScrollService;
    }

    @EventHandler(priority=EventPriority.LOWEST, ignoreCancelled=false)
    public void onScrollUse(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (!this.renameScrollService.isRenameScroll(item)) {
            return;
        }
        if (event.getHand() == EquipmentSlot.OFF_HAND) {
            return;
        }
        Player player = event.getPlayer();
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);
        if (this.renameMode.contains(player.getUniqueId())) {
            player.sendMessage(Text.color("&cYou are already in rename mode. Type the new name or 'cancel'."));
            return;
        }
        this.consumeOne(item, player);
        this.renameMode.add(player.getUniqueId());
        player.sendMessage(Text.color("&aRename mode enabled. Type the new name in chat. Type &ccancel &ato abort and get your scroll back."));
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!this.renameMode.contains(player.getUniqueId())) {
            return;
        }
        String message = event.getMessage().trim();
        event.setCancelled(true);
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.handleRename(player, message));
    }

    private void handleRename(Player player, String message) {
        if (!this.renameMode.contains(player.getUniqueId())) {
            return;
        }
        if (message.equalsIgnoreCase("cancel")) {
            this.renameMode.remove(player.getUniqueId());
            this.giveScroll(player);
            player.sendMessage(Text.color("&cRename cancelled. Scroll returned."));
            return;
        }
        ItemStack held = player.getInventory().getItemInMainHand();
        if (held == null || held.getType() == Material.AIR || !this.pickaxeManager.isPrisonPickaxe(held)) {
            player.sendMessage(Text.color("&cHold a prison pickaxe to rename it. Type your desired name or 'cancel'."));
            return;
        }
        this.pickaxeManager.setCustomName(held, message);
        this.renameMode.remove(player.getUniqueId());
        player.sendMessage(Text.color("&aPickaxe renamed to &r" + Text.color(message) + "&a."));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        if (this.renameMode.remove(id)) {
            this.giveScroll(event.getPlayer());
        }
    }

    private void consumeOne(ItemStack item, Player player) {
        if (item == null) {
            return;
        }
        int amount = item.getAmount();
        if (amount <= 1) {
            player.getInventory().setItem(player.getInventory().getHeldItemSlot(), null);
        } else {
            item.setAmount(amount - 1);
        }
    }

    private void giveScroll(Player player) {
        ItemStack scroll = this.renameScrollService.createScroll();
        if (this.renameScrollService.getPlugin().getStashService() != null) {
            this.renameScrollService.getPlugin().getStashService().giveOrStash(player, scroll);
        } else {
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(new ItemStack[]{scroll});
            if (!leftover.isEmpty()) {
                leftover.values().forEach(stack -> player.getWorld().dropItemNaturally(player.getLocation(), stack));
            }
        }
    }
}
