package org.axial.prisonsCore.listener;

import java.util.List;
import org.axial.prisonsCore.model.Gang;
import org.axial.prisonsCore.service.GangService;
import org.axial.prisonsCore.util.Lang;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class GangInviteListener implements Listener {
    private final GangService gangService;

    public GangInviteListener(GangService gangService) {
        this.gangService = gangService;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        List<String> pending = this.gangService.consumePendingInvites(player.getUniqueId());
        if (pending.isEmpty()) {
            return;
        }
        for (String gangId : pending) {
            Gang gang = this.gangService.getGang(gangId);
            if (gang == null) {
                continue;
            }
            player.sendMessage(Lang.msg("gang.invite.target", "&e&l(!) &eYou have been invited to join &f&l{gang}&e.\n&7Join with /gang join &f{gang}&7.").replace("{gang}", gang.getName()));
        }
    }
}
