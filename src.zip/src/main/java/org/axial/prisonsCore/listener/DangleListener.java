/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.kyori.adventure.text.Component
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.Display$Billboard
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.EntityType
 *  org.bukkit.entity.ItemDisplay
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.AsyncPlayerChatEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package org.axial.prisonsCore.listener;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.kyori.adventure.text.Component;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.CustomEnchantService;
import org.axial.prisonsCore.service.PickaxeManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.Plugin;
import java.util.Map;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class DangleListener
implements Listener {
    private static final String TRIGGER = "[dangle]";
    private static final long LIFETIME_TICKS = 200L;
    private final PrisonsCore plugin;
    private final PickaxeManager pickaxeManager;
    private final CustomEnchantService customEnchantService;
    private final Map<UUID, UUID> activeDisplays = new ConcurrentHashMap<UUID, UUID>();
    private final Map<UUID, BukkitTask> removalTasks = new ConcurrentHashMap<UUID, BukkitTask>();
    private final Map<UUID, BukkitTask> followTasks = new ConcurrentHashMap<UUID, BukkitTask>();
    private final Map<UUID, ItemStack> pendingReturns = new ConcurrentHashMap<UUID, ItemStack>();

    public DangleListener(PrisonsCore plugin, PickaxeManager pickaxeManager, CustomEnchantService customEnchantService) {
        this.plugin = plugin;
        this.pickaxeManager = pickaxeManager;
        this.customEnchantService = customEnchantService;
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        String message = event.getMessage();
        if (!message.trim().equals(TRIGGER)) {
            return;
        }
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir()) {
            return;
        }
        String cleaned = message.replace(TRIGGER, this.formatItemPlaceholder(hand));
        event.setMessage(cleaned);
        ItemStack snapshot = hand.clone();
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.spawnDisplayAndHold(player, snapshot));
    }

    private void spawnDisplayAndHold(Player player, ItemStack item) {
        UUID pid = player.getUniqueId();
        this.removeExisting(pid);
        if (!this.takeOneFromHand(player, item.getType())) {
            return;
        }
        this.pendingReturns.put(pid, item.clone());
        String label = this.buildLabel(item);
        Location loc = player.getEyeLocation().add(player.getLocation().getDirection().normalize().multiply(2.25));
        loc.setYaw(0.0f);
        loc.setPitch(0.0f);
        ItemDisplay display = (ItemDisplay)player.getWorld().spawnEntity(loc, EntityType.ITEM_DISPLAY);
        display.setItemStack(item);
        display.setBillboard(Display.Billboard.FIXED);
        display.setRotation(0.0f, 0.0f);
        display.setCustomNameVisible(true);
        display.customName((Component)Component.text((String)label));
        this.activeDisplays.put(pid, display.getUniqueId());
        BukkitTask followTask = Bukkit.getScheduler().runTaskTimer((Plugin)this.plugin, () -> {
            Player p = Bukkit.getPlayer((UUID)pid);
            if (p == null || !p.isOnline()) {
                display.remove();
                this.cancelFollow(pid);
                return;
            }
            Location target = p.getEyeLocation().add(p.getLocation().getDirection().normalize().multiply(2.25));
            target.setYaw(0.0f);
            target.setPitch(0.0f);
            Location current = display.getLocation();
            Vector delta = target.clone().subtract(current).toVector();
            double distSq = delta.lengthSquared();
            if (distSq < 1.0E-4) {
                return;
            }
            double smoothingFactor = 0.18;
            Vector step = delta.clone().multiply(smoothingFactor);
            double maxStep = 0.28;
            double len = step.length();
            if (len > maxStep) {
                step.multiply(maxStep / len);
            }
            Location smooth = current.add(step);
            smooth.setYaw(0.0f);
            smooth.setPitch(0.0f);
            display.teleport(smooth);
        }, 1L, 1L);
        this.followTasks.put(pid, followTask);
        BukkitTask task = Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            this.giveBack(pid, player);
            display.remove();
            this.activeDisplays.remove(pid);
            this.removalTasks.remove(pid);
            this.cancelFollow(pid);
            this.pendingReturns.remove(pid);
        }, 200L);
        this.removalTasks.put(pid, task);
    }

    private void removeExisting(UUID playerId) {
        BukkitTask task;
        Entity entity;
        UUID current = this.activeDisplays.remove(playerId);
        if (current != null && (entity = Bukkit.getEntity((UUID)current)) != null) {
            entity.remove();
        }
        if ((task = this.removalTasks.remove(playerId)) != null) {
            task.cancel();
        }
        this.cancelFollow(playerId);
        this.giveBack(playerId, Bukkit.getPlayer((UUID)playerId));
    }

    private String formatItemPlaceholder(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta != null && meta.hasDisplayName()) {
            return ChatColor.stripColor((String)Text.color(meta.getDisplayName()));
        }
        return item.getType().name().toLowerCase().replace('_', ' ');
    }

    private String buildLabel(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        return meta != null && meta.hasDisplayName() ? Text.color(meta.getDisplayName()) : String.valueOf(ChatColor.YELLOW) + item.getType().name().toLowerCase().replace('_', ' ');
    }

    private String resolveEnchantName(String id) {
        CustomEnchant ce;
        if (this.customEnchantService != null && (ce = this.customEnchantService.getById(id)) != null) {
            return ce.getDisplayName();
        }
        return id.replace('_', ' ');
    }

    private String toRoman(int number) {
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder out = new StringBuilder();
        int n = Math.max(1, number);
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                n -= values[i];
                out.append(numerals[i]);
            }
        }
        return out.toString();
    }

    private boolean takeOneFromHand(Player player, Material type) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType() != type || hand.getAmount() < 1) {
            return false;
        }
        if (hand.getAmount() == 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
        }
        return true;
    }

    private void giveBack(UUID playerId, Player player) {
        ItemStack pending = this.pendingReturns.remove(playerId);
        if (pending == null || player == null) {
            return;
        }
        Map<Integer, ItemStack> overflow = player.getInventory().addItem(new ItemStack[]{pending});
        overflow.values().forEach(it -> player.getWorld().dropItemNaturally(player.getLocation(), it));
    }

    private void cancelFollow(UUID playerId) {
        BukkitTask follow = this.followTasks.remove(playerId);
        if (follow != null) {
            follow.cancel();
        }
    }
}
