/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerItemDamageEvent
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.Damageable
 *  org.bukkit.inventory.meta.ItemMeta
 */
package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.GearManager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;

public class GearBreakListener
implements Listener {
    private final GearManager gearManager;

    public GearBreakListener(GearManager gearManager) {
        this.gearManager = gearManager;
    }

    @EventHandler(ignoreCancelled=true)
    public void onItemDamage(PlayerItemDamageEvent event) {
        int incoming;
        int remaining;
        ItemStack item = event.getItem();
        if (!this.gearManager.isGear(item)) {
            return;
        }
        short maxDurability = item.getType().getMaxDurability();
        if (maxDurability <= 0) {
            return;
        }
        int current = 0;
        ItemMeta itemMeta = item.getItemMeta();
        if (itemMeta instanceof Damageable) {
            Damageable dmg = (Damageable)itemMeta;
            current = dmg.getDamage();
        }
        if ((remaining = maxDurability - 1 - current - (incoming = event.getDamage())) >= 0) {
            return;
        }
        event.setCancelled(true);
        this.gearManager.setDamage(item, maxDurability - 1);
        this.gearManager.markBroken(item);
        int slot = event.getPlayer().getInventory().getHeldItemSlot();
        if (event.getPlayer().getInventory().getItem(slot) != null && this.gearManager.isBroken(event.getPlayer().getInventory().getItem(slot))) {
            event.getPlayer().getInventory().setItem(slot, null);
        }
        event.getPlayer().getInventory().addItem(new ItemStack[]{item});
        event.getPlayer().updateInventory();
    }
}

