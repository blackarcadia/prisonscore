/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.EventPriority
 *  org.bukkit.event.Listener
 *  org.bukkit.event.server.RemoteServerCommandEvent
 *  org.bukkit.event.server.ServerCommandEvent
 *  org.bukkit.plugin.Plugin
 */
package org.axial.prisonsCore.listener;

import java.util.Locale;
import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.server.RemoteServerCommandEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.plugin.Plugin;

public class StopCommandListener
implements Listener {
    private final PrisonsCore plugin;

    public StopCommandListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onConsoleCommand(ServerCommandEvent event) {
        if (this.isStopLike(event.getCommand())) {
            event.setCancelled(true);
            this.notifyAndShutdown(event.getSender().getName());
        }
    }

    @EventHandler(priority=EventPriority.HIGHEST, ignoreCancelled=true)
    public void onRconCommand(RemoteServerCommandEvent event) {
        if (this.isStopLike(event.getCommand())) {
            event.setCancelled(true);
            this.notifyAndShutdown("RCON");
        }
    }

    private boolean isStopLike(String commandLine) {
        if (commandLine == null) {
            return false;
        }
        String trimmed = commandLine.trim();
        int space = trimmed.indexOf(32);
        String root = space == -1 ? trimmed : trimmed.substring(0, space);
        root = root.toLowerCase(Locale.ROOT);
        return root.equals("stop") || root.equals("end");
    }

    private void notifyAndShutdown(String source) {
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> {
            Bukkit.getConsoleSender().sendMessage(String.valueOf(ChatColor.YELLOW) + "[PrisonsCore] " + source + " requested shutdown; stopping server safely.");
            Bukkit.shutdown();
        });
    }
}

