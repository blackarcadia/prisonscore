package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.service.DupeTrackingService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;

public class DupeTrackingListener implements Listener {
    private final DupeTrackingService dupeTrackingService;

    public DupeTrackingListener(DupeTrackingService dupeTrackingService) {
        this.dupeTrackingService = dupeTrackingService;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        this.dupeTrackingService.requestScan();
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onInventoryClick(InventoryClickEvent event) {
        this.dupeTrackingService.requestScan();
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onInventoryDrag(InventoryDragEvent event) {
        this.dupeTrackingService.requestScan();
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onInventoryClose(InventoryCloseEvent event) {
        this.dupeTrackingService.requestScan();
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onDrop(PlayerDropItemEvent event) {
        this.dupeTrackingService.track(event.getItemDrop().getItemStack());
        this.dupeTrackingService.requestScan();
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onPickup(EntityPickupItemEvent event) {
        this.dupeTrackingService.track(event.getItem().getItemStack());
        this.dupeTrackingService.requestScan();
    }

    @EventHandler(ignoreCancelled = true, priority = EventPriority.MONITOR)
    public void onItemSpawn(ItemSpawnEvent event) {
        this.dupeTrackingService.track(event.getEntity().getItemStack());
        this.dupeTrackingService.requestScan();
    }
}
