package org.axial.prisonsCore.listener;

import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.service.GuardService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerLoadEvent;

public class GuardStartupListener implements Listener {
    private final GuardService guardService;
    private final PrisonsCore plugin;
    private boolean scheduled = false;

    public GuardStartupListener(GuardService guardService) {
        this.guardService = guardService;
        this.plugin = guardService.getPlugin();
    }

    @EventHandler
    public void onServerLoad(ServerLoadEvent event) {
        this.scheduleReload();
    }

    private void scheduleReload() {
        if (this.scheduled) {
            return;
        }
        this.scheduled = true;
        this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.guardService.reload(), 40L);
    }
}
