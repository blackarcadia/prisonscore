/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.cell;

public enum CellTier {
    INMATE(20, 3000000.0),
    TRUSTEE(45, 10000000.0),
    WARDEN(80, 25000000.0);

    private final int requiredMiningLevel;
    private final double weeklyPrice;

    private CellTier(int requiredMiningLevel, double weeklyPrice) {
        this.requiredMiningLevel = requiredMiningLevel;
        this.weeklyPrice = weeklyPrice;
    }

    public int getRequiredMiningLevel() {
        return this.requiredMiningLevel;
    }

    public double getWeeklyPrice() {
        return this.weeklyPrice;
    }
}
