package org.axial.prisonsCore.cell.guard;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.plugin.Plugin;

public class CellGuardChunkListener implements Listener {
    private final CellGuardService cellGuardService;

    public CellGuardChunkListener(CellGuardService cellGuardService) {
        this.cellGuardService = cellGuardService;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onChunkLoad(ChunkLoadEvent event) {
        if (this.cellGuardService == null || event.getChunk() == null) {
            return;
        }

        Bukkit.getScheduler().runTask((Plugin)this.cellGuardService.getPlugin(), () -> this.cellGuardService.reconcileChunk(event.getChunk()));
    }
}
