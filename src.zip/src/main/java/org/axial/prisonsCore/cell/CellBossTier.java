package org.axial.prisonsCore.cell;

public enum CellBossTier {
    INMATE,
    TRUSTEE,
    WARDEN;
}
