package org.axial.prisonsCore.cell;

import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.event.world.WorldLoadEvent;

public final class CellStartupListener implements Listener {

    private final PrisonsCore plugin;

    public CellStartupListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onServerLoad(ServerLoadEvent event) {
        if (this.plugin.getCellService() != null) {
            this.plugin.getCellService().restoreConfiguredDoors();
            this.plugin.getCellService().restoreBossSnapshots();
            this.plugin.getCellService().restoreAllCellSigns();
        }
    }

    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        if (this.plugin.getCellService() != null) {
            this.plugin.getCellService().restoreConfiguredDoors();
            this.plugin.getCellService().restoreBossSnapshots();
            this.plugin.getCellService().restoreAllCellSigns();
        }
    }
}
