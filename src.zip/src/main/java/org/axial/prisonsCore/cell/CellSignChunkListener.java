package org.axial.prisonsCore.cell;

import org.axial.prisonsCore.PrisonsCore;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.plugin.Plugin;

public final class CellSignChunkListener implements Listener {

    private final PrisonsCore plugin;

    public CellSignChunkListener(PrisonsCore plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onChunkLoad(ChunkLoadEvent event) {
        if (this.plugin.getCellService() == null || event.getChunk() == null) {
            return;
        }
        Chunk chunk = event.getChunk();
        Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> this.plugin.getCellService().restoreCellSigns(chunk));
    }
}
