/*
 * Decompiled with CFR 0.152.
 *
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Keyed
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Tag
 *  org.bukkit.World
 *  org.bukkit.attribute.Attribute
 *  org.bukkit.attribute.AttributeInstance
 *  org.bukkit.block.Block
 *  org.bukkit.block.data.Bisected$Half
 *  org.bukkit.block.data.BlockData
 *  org.bukkit.block.data.type.Door
 *  org.bukkit.configuration.ConfigurationSection
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.ArmorStand
 *  org.bukkit.entity.Entity
 *  org.bukkit.entity.LivingEntity
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.EntityEquipment
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.persistence.PersistentDataContainer
 *  org.bukkit.persistence.PersistentDataType
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package org.axial.prisonsCore.cell.guard;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.Keys;
import org.axial.prisonsCore.PrisonsCore;
import org.axial.prisonsCore.cell.Cell;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.cell.guard.CellGuardTier;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Keyed;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.Chunk;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.type.Door;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class CellGuardService {
    private static final String CELL_GUARD_TEXTURE = "ewogICJ0aW1lc3RhbXAiIDogMTczODE5Njg1NDM0NSwKICAicHJvZmlsZUlkIiA6ICJmMzNlZGMyNTRmNDk0NWY2YTg5ZjFjM2JhZmNkZjIwNiIsCiAgInByb2ZpbGVOYW1lIiA6ICJGVV9CYWJ5IiwKICAic2lnbmF0dXJlUmVxdWlyZWQiIDogdHJ1ZSwKICAidGV4dHVyZXMiIDogewogICAgIlNLSU4iIDogewogICAgICAidXJsIiA6ICJodHRwOi8vdGV4dHVyZXMubWluZWNyYWZ0Lm5ldC90ZXh0dXJlL2Q4ZDc1YWJmYzAyYTZmNjU2YjUyNDI2ODA0YWFlNDk4ZTljM2NhOTRhOTdkN2RiYzM2OTczYTM2MGJkZjNlNzAiLAogICAgICAibWV0YWRhdGEiIDogewogICAgICAgICJtb2RlbCIgOiAic2xpbSIKICAgICAgfQogICAgfQogIH0KfQ==";
    private static final String CELL_GUARD_SIGNATURE = "Jr7s1UxNgwnnJqajNNJVq/r+Q4TaI0PY4k7ZCZbMtxFPfRV85wop6XoIvEftUxL7IdX+lLZrt5zNgn6BZ77EL1WYrUsAgEjt4ce/h8yvqxE50bsTLSmVZmPqM1u7r1rq7LAsYtKl+pQn3U+dHAfTAoHhJf1daEL9kfw/ctK4MOxSGSrkObqXWXC6XEvpBA8maOTE93lw6l1OYWFmqnX8T1quaI9v3f6iAiEQqV420wiXFrbDI2ctb3r2WF7yd6EkJEmpf7b7bpIYtYeybdZCRffWfAyYiQJ7F/DLvEg2qhZldYolNv7yKM+KbHN+zoJmV23SzI5jzn4bn/R4jQzPUW6S+JOib2oZR5pkGnW0zxgiUmUQWWaI4M06U9+dpVRbuphO2dd1AaoRQJgElHEbJuAznI5KzezS4yKrYPNufw4m8uPI80RlHCxOVsvHFriUGxWyof66U6+cP/POkNgBiWF7pI1cQhSZH6mv50rmd22yuovttLHVJgPOanMSM7YZhnbfiG5uUDCoxOcO+aZ2FeyqtZwd9kuux1NN/3YBk8Bb3sD9dYS24S53PtqhvQUJJj/sR3U8zq+fprqXM1aPyru7z4MfeGx4pGOm+V+3sjyuYWtvr1GcL4shTUbK4YzdNNY4X+McdPGzilHPHPk8z3Ym5h5+T90rhK0bPvKNHvo=";
    private final PrisonsCore plugin;
    private final CellService cellService;
    private final File dataFile;
    private YamlConfiguration dataCfg;
    private final Map<UUID, Placement> placements = new HashMap<UUID, Placement>();
    private final Map<String, Set<UUID>> placementsByCell = new HashMap<String, Set<UUID>>();
    private final Map<UUID, UUID> npcToPlacement = new HashMap<UUID, UUID>();
    private final Map<UUID, UUID> guardTargets = new HashMap<UUID, UUID>();
    private final Map<UUID, String> activeRaiders = new HashMap<UUID, String>();
    private final Map<UUID, UUID> healthStands = new HashMap<UUID, UUID>();
    private final Map<UUID, Long> guardEquipReadyAt = new HashMap<UUID, Long>();
    private final Map<UUID, Double> guardPendingHealth = new HashMap<UUID, Double>();
    private final Map<UUID, Long> guardHealthReadyAt = new HashMap<UUID, Long>();
    private final Map<UUID, Long> guardPhaseReadyAt = new HashMap<UUID, Long>();
    private final Map<UUID, Long> guardAttackReadyAt = new HashMap<UUID, Long>();
    private BukkitTask monitorTask;
    private boolean skinWarningLogged = false;

    // =========================
// RAID SYSTEM
// =========================
    private final Map<String, Set<UUID>> activeRaids = new HashMap<>();
    private final Map<UUID, Long> raiderTimeout = new HashMap<>();

    private final Set<UUID> spawningPlacements = new HashSet<>();
    private boolean startupPurgeDone = false;

    private static final long RAID_TIMEOUT = 60_000L; // 60 seconds

    public CellGuardService(PrisonsCore plugin, CellService cellService) {
        this.plugin = plugin;
        this.cellService = cellService;
        this.dataFile = new File(plugin.getDataFolder(), "cell-guards.yml");

        this.initFile();

        // Startup reconcile is delayed and repeated so Citizens can finish restoring any persisted NPCs.
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!this.startupPurgeDone) {
                this.purgeRuntimeCellGuardEntities();
                this.startupPurgeDone = true;
            }
            this.load();
            this.cleanupOrphanGuards();
            this.rebindOrRespawnGuards();
            this.save();
        }, 40L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            this.cleanupOrphanGuards();
            this.rebindOrRespawnGuards();
            this.save();
        }, 80L);
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            this.cleanupOrphanGuards();
            this.rebindOrRespawnGuards();
            this.save();
        }, 120L);

        this.startMonitor();
    }
    private void linkExistingGuards() {

        plugin.getLogger().info("[CellGuards] Linking existing guards...");

        for (Placement placement : new HashSet<>(this.placements.values())) {

            if (placement == null) continue;

            UUID placementId = placement.id();

            for (World world : Bukkit.getWorlds()) {
                for (Entity entity : world.getEntities()) {

                    if (!(entity instanceof LivingEntity living)) continue;
                    if (entity.isDead()) continue;

                    if (!this.isCellGuard(entity)) continue;

                    String stored = living.getPersistentDataContainer().get(
                            Keys.cellGuardPlacement(this.plugin),
                            PersistentDataType.STRING
                    );

                    if (stored == null) continue;

                    if (stored.equalsIgnoreCase(placementId.toString())) {

                        placement.setNpcId(living.getUniqueId());
                        this.npcToPlacement.put(living.getUniqueId(), placementId);

                        break;
                    }
                }
            }
        }

        plugin.getLogger().info("[CellGuards] Linking complete.");
    }
    private void respawnAllGuards() {

        plugin.getLogger().info("[CellGuards] Respawning guards...");

        for (Placement placement : new HashSet<>(this.placements.values())) {

            if (placement == null) continue;

            try {
                UUID placementId = placement.id();

                LivingEntity found = null;

                // =========================
                // ✅ CHECK EXISTING ENTITY (WORLD SCAN)
                // =========================
                for (World world : Bukkit.getWorlds()) {
                    for (Entity entity : world.getEntities()) {

                        if (!(entity instanceof LivingEntity living)) continue;
                        if (entity.isDead()) continue;

                        String stored = living.getPersistentDataContainer().get(
                                Keys.cellGuardPlacement(this.plugin),
                                PersistentDataType.STRING
                        );

                        if (stored == null) continue;

                        if (stored.equalsIgnoreCase(placementId.toString())) {
                            found = living;
                            break;
                        }
                    }
                    if (found != null) break;
                }

                // =========================
                // ✅ FOUND → RELINK ONLY
                // =========================
                if (found != null) {
                    placement.setNpcId(found.getUniqueId());
                    this.npcToPlacement.put(found.getUniqueId(), placementId);
                    continue;
                }

                // =========================
                // 🔥 STEP 3: FINAL SAFETY CHECK BEFORE SPAWN
                // =========================
                boolean alreadyExists = false;

                for (World world : Bukkit.getWorlds()) {
                    for (Entity entity : world.getEntities()) {

                        if (!(entity instanceof LivingEntity living)) continue;

                        String stored = living.getPersistentDataContainer().get(
                                Keys.cellGuardPlacement(this.plugin),
                                PersistentDataType.STRING
                        );

                        if (stored == null) continue;

                        if (stored.equalsIgnoreCase(placementId.toString())) {
                            placement.setNpcId(living.getUniqueId());
                            this.npcToPlacement.put(living.getUniqueId(), placementId);

                            plugin.getLogger().warning("[CellGuards] BLOCKED duplicate spawn for " + placementId);

                            alreadyExists = true;
                            break;
                        }
                    }
                    if (alreadyExists) break;
                }

                if (alreadyExists) {
                    continue; // 🚫 DO NOT SPAWN
                }

                // =========================
                // ❌ SAFE TO SPAWN
                // =========================
                placement.setNpcId(null);
                this.spawnGuardForPlacement(placement);

            } catch (Exception e) {
                plugin.getLogger().warning("[CellGuards] Failed to respawn guard "
                        + placement.id() + ": " + e.getMessage());
            }
        }

        plugin.getLogger().info("[CellGuards] Respawn complete.");
    }
    public PrisonsCore getPlugin() {
        return this.plugin;
    }

    public void shutdown() {

        // =========================
        // ⏹ STOP TASKS
        // =========================
        if (this.monitorTask != null) {
            this.monitorTask.cancel();
            this.monitorTask = null;
        }

        // =========================
        // 🧹 PURGE RUNTIME STATE
        // =========================
        this.purgeRuntimeCellGuardEntities();

        // =========================
        // 💾 SAVE EVERYTHING (CRITICAL FIX)
        // =========================
        try {
            this.save();
            this.plugin.getLogger().info("[CellGuards] Saved guard data on shutdown.");
        } catch (Exception e) {
            this.plugin.getLogger().warning("[CellGuards] Failed to save guard data: " + e.getMessage());
        }
    }

    public Placement getPlacement(UUID placementId) {
        return this.placements.get(placementId);
    }

    public UUID getPlacementIdByNpc(UUID npcId) {
        return this.npcToPlacement.get(npcId);
    }

    public ItemStack createGuardAnchor(CellGuardTier tier, int amount) {
        ItemStack item = new ItemStack(Material.ARMOR_STAND, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Text.color(this.guardAnchorName(tier)));
        meta.setLore(List.of(Text.color("&7Place inside your cell to spawn"), Text.color("&7a " + tier.displayName()), Text.color("&7The placed block is the guard's home.")));
        meta.getPersistentDataContainer().set(Keys.cellGuardTier(this.plugin), PersistentDataType.STRING, tier.name());
        item.setItemMeta(meta);
        return item;
    }

    private String guardAnchorName(CellGuardTier tier) {
        return switch (tier) {
            case BASIC -> "&e&lCell Guard &7(&fBasic&7)";
            case UNIQUE -> "&e&lCell Guard &7(&aUnique&7)";
            case RARE -> "&e&lCell Guard &7(&9Rare&7)";
            case ELITE -> "&e&lCell Guard &7(&eElite&7)";
            case LEGENDARY -> "&e&lCell Guard &7(&6Legendary&7)";
        };
    }

    private void startRaid(String cellId, Player attacker) {

        cellId = cellId.toLowerCase();

        this.activeRaids.computeIfAbsent(cellId, k -> new HashSet<>())
                .add(attacker.getUniqueId());

        this.raiderTimeout.put(attacker.getUniqueId(), System.currentTimeMillis() + RAID_TIMEOUT);

        this.markRaider(attacker.getUniqueId(), cellId);

        // alert guards instantly
        this.triggerGuards(cellId, attacker, attacker.getLocation());
    }

    public void markRaider(UUID playerId, String cellId) {
        if (playerId == null || cellId == null) {
            return;
        }
        this.activeRaiders.put(playerId, cellId.toLowerCase(Locale.ROOT));
        this.raiderTimeout.put(playerId, System.currentTimeMillis() + RAID_TIMEOUT);
        this.activeRaids.computeIfAbsent(cellId.toLowerCase(Locale.ROOT), k -> new HashSet<>()).add(playerId);
    }

    public boolean isGuardAnchor(ItemStack stack) {
        if (stack == null) {
            return false;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return false;
        }
        return meta.getPersistentDataContainer().has(Keys.cellGuardTier(this.plugin), PersistentDataType.STRING);
    }

    public CellGuardTier tierFromItem(ItemStack stack) {
        if (stack == null) {
            return null;
        }
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return null;
        }
        String name = (String)meta.getPersistentDataContainer().get(Keys.cellGuardTier(this.plugin), PersistentDataType.STRING);
        if (name == null) {
            return null;
        }
        try {
            return CellGuardTier.valueOf(name);
        }
        catch (IllegalArgumentException e) {
            return null;
        }
    }

    public void removeAllForCell(String cellId) {
        if (cellId == null) {
            return;
        }
        String key = cellId.toLowerCase(Locale.ROOT);
        Set<UUID> ids = this.placementsByCell.remove(key);
        if (ids == null) {
            return;
        }
        for (UUID pid : ids) {
            this.removePlacementInternal(pid, null, false);
        }
        this.save();
    }

    public boolean placeGuard(Cell cell, CellGuardTier tier, Location blockLocation, Player owner) {
        World world;
        if (cell == null || tier == null || blockLocation == null || owner == null) {
            return false;
        }
        if (cell.isBossCell()) {
            if (!owner.hasPermission("cells.admin")) {
                return false;
            }
        } else if (cell.getOwner() == null || !cell.getOwner().equals(owner.getUniqueId())) {
            return false;
        }
        Location home = blockLocation.getBlock().getLocation().add(0.5, 0.0, 0.5);
        home.setYaw(owner.getLocation().getYaw());
        home.setPitch(owner.getLocation().getPitch());
        Location entrance = cell.getSpawnLocation();
        if (entrance == null) {
            entrance = cell.getDoorLocation();
        }
        if (entrance == null && cell.getRegion() != null && (world = Bukkit.getWorld((String)cell.getRegion().getWorldName())) != null) {
            Vector min = cell.getRegion().getMin();
            Vector max = cell.getRegion().getMax();
            entrance = new Location(world, (min.getX() + max.getX()) / 2.0 + 0.5, max.getY() + 0.5, (min.getZ() + max.getZ()) / 2.0 + 0.5);
        }
        if (entrance == null) {
            owner.sendMessage(Text.color("&cCould not determine a cell entrance for pathing."));
            return false;
        }
        if (!this.hasClearPath(home, entrance)) {
            owner.sendMessage(Text.color("&cCell guard needs a clear path to the cell spawn point."));
            return false;
        }
        UUID id = UUID.randomUUID();
        Placement placement = new Placement(id, cell.getId(), tier, home);
        this.placements.put(id, placement);
        this.placementsByCell.computeIfAbsent(cell.getId().toLowerCase(Locale.ROOT), k -> new HashSet()).add(id);
        this.spawnGuardForPlacement(placement);
        this.save();
        owner.sendMessage(Text.color("&aSpawned a " + tier.name() + " cell guard."));
        return true;
    }

    public void handleDoorRaid(Cell cell, Player attacker) {

        if (cell == null || attacker == null) return;
        if (cell.isBossCell()) {
            if (!this.cellService.bossCellCanRaid(cell)) {
                return;
            }
            this.startRaid(cell.getId(), attacker);
            return;
        }

        if (cell.getOwner() == null) return;

        if (this.cellService.hasAccess(cell, attacker.getUniqueId())) return;

        this.startRaid(cell.getId(), attacker);
    }

    public void handleOccupantAttack(Player attacker, Player victim, Cell cell) {

        if (attacker == null || victim == null || cell == null) return;
        if (cell.getOwner() == null) return;

        if (!cell.isInside(victim.getLocation())) return;

        if (!victim.getUniqueId().equals(cell.getOwner()) &&
                !cell.getAccess().contains(victim.getUniqueId())) return;

        if (this.cellService.hasAccess(cell, attacker.getUniqueId())) return;

        this.startRaid(cell.getId(), attacker);
    }

    public void handlePlayerMove(Player player, Location to) {
        boolean farFromDoor;
        if (player == null || to == null) {
            return;
        }
        String cellId = this.activeRaiders.get(player.getUniqueId());
        if (cellId == null) {
            return;
        }
        Cell cell = this.cellService.getCell(cellId);
        Location door = cell != null ? cell.getDoorLocation() : null;
        boolean bl = farFromDoor = door == null || door.getWorld() == null || to.getWorld() == null || !door.getWorld().equals((Object)to.getWorld()) || door.distanceSquared(to) > 2500.0;
        if (cell == null || !cell.isInside(to) && farFromDoor) {
            this.forgive(player.getUniqueId(), cellId);
        }
    }

    public void handlePlayerQuit(Player player) {
        if (player == null) return;

        String cellId = this.activeRaiders.get(player.getUniqueId());
        if (cellId != null) {
            this.endRaidForPlayer(player.getUniqueId(), cellId);
        }
    }

    public void handlePlayerDeath(Player player) {
        if (player == null) return;

        String cellId = this.activeRaiders.get(player.getUniqueId());
        if (cellId != null) {
            this.endRaidForPlayer(player.getUniqueId(), cellId);
        }
    }

    public void handleGuardDeath(LivingEntity guard) {
        if (guard == null) {
            return;
        }
        UUID id = guard.getUniqueId();
        UUID placementId = this.npcToPlacement.remove(id);
        this.guardTargets.remove(id);
        this.guardEquipReadyAt.remove(id);
        this.guardPendingHealth.remove(id);
        this.guardHealthReadyAt.remove(id);
        this.guardAttackReadyAt.remove(id);
        if (placementId == null) {
            return;
        }
        Placement placement = this.placements.get(placementId);
        if (placement == null) {
            return;
        }
        placement.setNpcId(null);
        placement.setCurrentHealth(this.sanitizeGuardHealth(placement.tier(), placement.currentHealth()));
        this.removeHealthStand(id);
    }

    public boolean hasLivingGuards(Cell cell) {
        if (cell == null) {
            return false;
        }
        Set<UUID> ids = this.placementsByCell.get(cell.getId().toLowerCase(Locale.ROOT));
        if (ids == null || ids.isEmpty()) {
            return false;
        }
        for (UUID pid : ids) {
            Placement placement = this.placements.get(pid);
            if (placement == null || placement.npc() == null) {
                continue;
            }
            Entity guard = Bukkit.getEntity((UUID)placement.npc());
            if (guard instanceof LivingEntity living && !living.isDead()) {
                return true;
            }
        }
        return false;
    }

    public Set<UUID> getRaidParticipants(String cellId) {
        Set<UUID> participants = new HashSet<UUID>();
        if (cellId == null) {
            return participants;
        }
        String key = cellId.toLowerCase(Locale.ROOT);
        for (Map.Entry<UUID, String> entry : this.activeRaiders.entrySet()) {
            if (key.equalsIgnoreCase(entry.getValue())) {
                participants.add(entry.getKey());
            }
        }
        return participants;
    }

    public void clearRaidTracking(String cellId) {
        if (cellId == null) {
            return;
        }
        String key = cellId.toLowerCase(Locale.ROOT);
        Set<UUID> removed = new HashSet<UUID>();
        for (Map.Entry<UUID, String> entry : new HashMap<UUID, String>(this.activeRaiders).entrySet()) {
            if (key.equalsIgnoreCase(entry.getValue())) {
                removed.add(entry.getKey());
            }
        }
        this.activeRaids.remove(key);
        for (UUID id : removed) {
            this.activeRaiders.remove(id);
            this.raiderTimeout.remove(id);
        }
    }

    public void reconcileChunk(Chunk chunk) {
        if (chunk == null || chunk.getWorld() == null) {
            return;
        }

        int chunkX = chunk.getX();
        int chunkZ = chunk.getZ();
        World world = chunk.getWorld();

        for (Placement placement : new HashSet<>(this.placements.values())) {
            if (placement == null || placement.home() == null || placement.home().getWorld() == null) {
                continue;
            }
            if (!placement.home().getWorld().equals(world)) {
                continue;
            }
            if (placement.home().getBlockX() >> 4 != chunkX || placement.home().getBlockZ() >> 4 != chunkZ) {
                continue;
            }

            this.spawnGuardForPlacement(placement);
        }
    }

    public void respawnAllForCell(String cellId) {
        if (cellId == null) {
            return;
        }
        Set<UUID> ids = this.placementsByCell.get(cellId.toLowerCase(Locale.ROOT));
        if (ids == null || ids.isEmpty()) {
            return;
        }
        for (UUID pid : new HashSet<UUID>(ids)) {
            Placement placement = this.placements.get(pid);
            if (placement == null) {
                continue;
            }
            Entity existing = placement.npc() == null ? null : Bukkit.getEntity((UUID)placement.npc());
            if (existing instanceof LivingEntity living && !living.isDead()) {
                continue;
            }
            placement.setNpcId(null);
            this.spawnGuardForPlacement(placement);
        }
        this.save();
    }

    public boolean isCellGuard(Entity entity) {
        if (entity == null) {
            return false;
        }
        if (this.npcToPlacement.containsKey(entity.getUniqueId())) {
            return true;
        }
        if (!(entity instanceof LivingEntity)) {
            return false;
        }
        LivingEntity living = (LivingEntity)entity;
        PersistentDataContainer pdc = living.getPersistentDataContainer();
        return pdc.has(Keys.cellGuardPlacement(this.plugin), PersistentDataType.STRING);
    }

    public boolean isTrackedRaider(UUID playerId) {
        return this.activeRaiders.containsKey(playerId);
    }

    public boolean isTrackedRaiderForCell(UUID playerId, String cellId) {
        if (playerId == null || cellId == null) {
            return false;
        }
        String tracked = this.activeRaiders.get(playerId);
        return tracked != null && tracked.equalsIgnoreCase(cellId);
    }

    private void triggerGuards(String cellId, Player target, Location trigger) {
        Set<UUID> ids = this.placementsByCell.get(cellId.toLowerCase(Locale.ROOT));
        if (ids == null || ids.isEmpty()) {
            return;
        }
        for (UUID pid : ids) {
            LivingEntity living;
            UUID guardId;
            Entity guard;
            Placement placement = this.placements.get(pid);
            if (placement == null || !((guard = (guardId = placement.npc()) == null ? null : Bukkit.getEntity((UUID)guardId)) instanceof LivingEntity) || (living = (LivingEntity)guard).isDead()) continue;
            this.commandAttack(living, target);
        }
    }

    public void commandAttack(LivingEntity guard, Player target) {
        if (guard == null || target == null) {
            return;
        }

        this.guardTargets.put(guard.getUniqueId(), target.getUniqueId());

        // =========================
        // 🔥 FORCE AGGRESSIVE CHASE
        // =========================
        guard.setAI(true);
        if (guard instanceof Mob mob) {
            mob.setTarget(target);
        }

        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry").invoke(null);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, guard);

            if (npc != null) {
                Object navigator = npc.getClass().getMethod("getNavigator").invoke(npc);

                // ⚡ HIGH SPEED + NO STUCK
                navigator.getClass().getMethod("getLocalParameters").invoke(navigator);

                navigator.getClass().getMethod("setTarget", Entity.class, boolean.class)
                        .invoke(navigator, target, true);
            }
        } catch (Exception ignored) {}

        // =========================
        // 💀 FORCE RE-TARGET LOOP
        // =========================
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (guard.isDead() || !target.isOnline()) return;

            if (guard instanceof Mob mob) {
                mob.setTarget(target);
            }

        }, 0L, 10L); // every 0.5s
    }

    private void tryStrikeGuard(LivingEntity guard, Player target, Placement placement) {
        if (guard == null || target == null || placement == null) {
            return;
        }
        if (guard.isDead() || target.isDead() || !target.isOnline()) {
            return;
        }
        if (guard.getWorld() == null || target.getWorld() == null || !guard.getWorld().equals(target.getWorld())) {
            return;
        }
        if (guard.getLocation().distanceSquared(target.getLocation()) > 6.25D) {
            return;
        }
        long now = System.currentTimeMillis();
        long readyAt = this.guardAttackReadyAt.getOrDefault(guard.getUniqueId(), 0L);
        if (now < readyAt) {
            return;
        }
        this.guardAttackReadyAt.put(guard.getUniqueId(), now + 1000L);
        double damage = Math.max(1.0D, this.attackDamageForTier(placement.tier()));
        target.damage(damage, guard);
        target.playSound(target.getLocation(), Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
        target.sendActionBar(Text.color("&cA cell guard attacked you!"));
    }

    private double attackDamageForTier(CellGuardTier tier) {
        if (tier == null) {
            return 4.0D;
        }
        return switch (tier) {
            case BASIC -> 4.0D;
            case UNIQUE -> 5.0D;
            case RARE -> 6.0D;
            case ELITE -> 7.0D;
            case LEGENDARY -> 9.0D;
        };
    }

    private void sendGuardHome(Placement placement, Entity guard) {
        if (placement == null || guard == null) {
            return;
        }

        Location home = placement.home();
        if (home == null) {
            return;
        }

        this.stopNavigation(guard);

        try {
            guard.teleport(home);
        } catch (Exception ignored) {}

        if (guard instanceof LivingEntity living && living instanceof Mob mob) {
            mob.setTarget(null);
        }

        UUID guardId = guard.getUniqueId();
        this.guardTargets.remove(guardId);
        this.guardAttackReadyAt.remove(guardId);
    }

    private void phaseTowardsTarget(LivingEntity guard, Player target) {
        if (guard == null || target == null) return;

        Location gLoc = guard.getLocation();
        Location tLoc = target.getLocation();

        double distance = gLoc.distance(tLoc);

        // If blocked or too far → phase forward
        if (distance > 2.5) {

            Vector direction = tLoc.toVector().subtract(gLoc.toVector()).normalize();

            Location next = gLoc.clone().add(direction.multiply(1.5));

            // 🔥 IGNORE BLOCKS (THIS IS THE MAGIC)
            next.setY(Math.max(next.getY(), tLoc.getY()));

            guard.teleport(next);
        }
    }

    private void sendHomeForPlayer(UUID playerId) {
        Map<UUID, UUID> snapshot = new HashMap<UUID, UUID>(this.guardTargets);
        for (Map.Entry<UUID, UUID> entry : snapshot.entrySet()) {
            if (!entry.getValue().equals(playerId)) continue;
            UUID guardId = entry.getKey();
            UUID placementId = this.npcToPlacement.get(guardId);
            Placement placement = placementId == null ? null : this.placements.get(placementId);
            Entity guard = Bukkit.getEntity((UUID)guardId);
            this.sendGuardHome(placement, guard);
        }
        this.activeRaiders.remove(playerId);
    }

    private void forgive(UUID playerId, String cellId) {
        this.sendHomeForPlayer(playerId);
        this.activeRaiders.remove(playerId);
    }

    private void endRaidForPlayer(UUID playerId, String cellId) {

        this.sendHomeForPlayer(playerId);

        this.activeRaiders.remove(playerId);
        this.raiderTimeout.remove(playerId);

        Set<UUID> set = this.activeRaids.get(cellId);
        if (set != null) {
            set.remove(playerId);

            if (set.isEmpty()) {
                this.activeRaids.remove(cellId);

                // send ALL guards home
                Set<UUID> guards = this.placementsByCell.get(cellId);
                if (guards != null) {
                    for (UUID pid : guards) {
                        Placement placement = this.placements.get(pid);
                        if (placement == null) continue;

                        Entity guard = Bukkit.getEntity(placement.npc());
                        this.sendGuardHome(placement, guard);
                    }
                }
            }
        }
    }

    private void startMonitor() {
        if (this.monitorTask != null) {
            this.monitorTask.cancel();
        }

        this.monitorTask = this.plugin.getServer().getScheduler().runTaskTimer(this.plugin, () -> {

            long now = System.currentTimeMillis();

            // =========================
            // 🚪 HANDLE OFFLINE RAIDERS
            // =========================
            for (UUID raider : new HashSet<>(this.activeRaiders.keySet())) {
                if (Bukkit.getPlayer(raider) != null) {
                    continue;
                }
                String cellId = this.activeRaiders.get(raider);
                if (cellId != null) {
                    this.endRaidForPlayer(raider, cellId);
                }
            }

            // =========================
            // ⏱ HANDLE RAIDER TIMEOUTS
            // =========================
            for (UUID raider : new HashSet<>(this.raiderTimeout.keySet())) {
                Long timeout = this.raiderTimeout.get(raider);
                if (timeout != null && now > timeout) {
                    String cellId = this.activeRaiders.get(raider);
                    if (cellId != null) {
                        this.endRaidForPlayer(raider, cellId);
                    }
                }
            }

            // =========================
            // 🛡 HANDLE GUARDS
            // =========================
            for (UUID guardId : new HashSet<>(this.npcToPlacement.keySet())) {

                Entity ent = Bukkit.getEntity(guardId);
                UUID placementId = this.npcToPlacement.get(guardId);
                Placement placement = placementId == null ? null : this.placements.get(placementId);

                // =========================
                // ❌ INVALID / DEAD
                // =========================
                if (!(ent instanceof LivingEntity living) || living.isDead()) {
                    if (placement != null && !this.isPlacementChunkLoaded(placement)) {
                        continue;
                    }

                    if (placement != null) {
                        placement.setNpcId(null);
                        this.spawnGuardForPlacement(placement);
                    }

                    this.npcToPlacement.remove(guardId);
                    this.guardTargets.remove(guardId);
                    this.removeHealthStand(guardId);
                    this.guardEquipReadyAt.remove(guardId);
                    this.guardPendingHealth.remove(guardId);
                    this.guardHealthReadyAt.remove(guardId);
                    this.guardAttackReadyAt.remove(guardId);
                    continue;
                }

                // =========================
                // 🧠 UPDATE STATE
                // =========================
                if (placement != null) {
                    this.applyHealthIfReady(guardId);
                    this.restorePlacementHealthIfNeeded(living, placement);

                    Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
                    double max = maxHealthAttribute != null && living.getAttribute(maxHealthAttribute) != null
                            ? living.getAttribute(maxHealthAttribute).getBaseValue()
                            : living.getMaxHealth();

                    this.updateHealthStand(living, placement.tier(), living.getHealth(), max);
                    this.ensureUnprotected(living);
                    this.ensureEquipment(living, placement.tier());
                } else {
                    this.stopNavigation(ent);
                }

                // =========================
                // 🎯 TARGET LOGIC
                // =========================
                UUID targetId = this.guardTargets.get(guardId);

                // 🔄 Re-acquire raider if needed
                if (targetId == null && placement != null) {
                    Player reacquire = this.findActiveRaiderForCell(
                            placement.cellId(),
                            living.getLocation(),
                            100.0
                    );

                    if (reacquire != null) {
                        this.commandAttack(living, reacquire);
                        targetId = reacquire.getUniqueId();
                    }
                }

                // ❌ No target → idle
                if (targetId == null) {
                    this.stopNavigation(living);
                    continue;
                }

                Player target = Bukkit.getPlayer(targetId);

                // ❌ Invalid target
                if (target == null || target.isDead() || !target.isOnline()) {
                    this.stopNavigation(living);
                    this.sendGuardHome(placement, living);
                    continue;
                }

                // ❌ Not in raid anymore
                String cellId = this.activeRaiders.get(targetId);
                if (cellId == null || placement == null ||
                        !placement.cellId().equalsIgnoreCase(cellId)) {

                    this.stopNavigation(living);
                    this.sendGuardHome(placement, living);
                    continue;
                }

                // =========================
                // 🔥 FORCE CHASE
                // =========================
                if (living instanceof Mob mob) {
                    mob.setTarget(target);
                }

                this.tryStrikeGuard(living, target, placement);

                // =========================
                // 👻 PHASE MOVEMENT
                // =========================
                this.phaseTowardsTarget(living, target);
            }

        }, 0L, 10L); // every 0.5 seconds
    }


    private Player findActiveRaiderForCell(String cellId, Location from, double maxDistance) {
        if (cellId == null || from == null) {
            return null;
        }
        double best = maxDistance * maxDistance;
        Player bestPlayer = null;
        for (Map.Entry<UUID, String> entry : new HashMap<UUID, String>(this.activeRaiders).entrySet()) {
            double d;
            Player p;
            if (!cellId.equalsIgnoreCase(entry.getValue()) || (p = Bukkit.getPlayer((UUID)entry.getKey())) == null || !p.isOnline() || p.isDead() || !from.getWorld().equals((Object)p.getWorld()) || !((d = from.distanceSquared(p.getLocation())) < best)) continue;
            best = d;
            bestPlayer = p;
        }
        return bestPlayer;
    }

    private boolean isAtCellEntrance(Cell cell, Location loc) {
        if (cell == null || loc == null) {
            return false;
        }
        Location door = cell.getDoorLocation();
        if (door == null || door.getWorld() == null || loc.getWorld() == null) {
            return false;
        }
        if (!door.getWorld().equals((Object)loc.getWorld())) {
            return false;
        }
        return door.distanceSquared(loc) <= 25.0;
    }

    private void initFile() {
        if (this.dataFile.exists()) {
            this.dataCfg = YamlConfiguration.loadConfiguration((File)this.dataFile);
            return;
        }
        try {
            this.dataFile.getParentFile().mkdirs();
            this.dataFile.createNewFile();
            this.dataCfg = new YamlConfiguration();
            this.dataCfg.set("cells", new HashMap());
            this.dataCfg.save(this.dataFile);
        }
        catch (IOException e) {
            this.plugin.getLogger().warning("Failed to create cell-guards.yml: " + e.getMessage());
            this.dataCfg = new YamlConfiguration();
        }
    }

    private void load() {

        this.dataCfg = YamlConfiguration.loadConfiguration(this.dataFile);

        this.placements.clear();
        this.placementsByCell.clear();
        this.npcToPlacement.clear();

        ConfigurationSection sec = this.dataCfg.getConfigurationSection("guards");
        if (sec == null) {
            plugin.getLogger().warning("[CellGuards] No guards section found.");
            return;
        }

        for (String key : sec.getKeys(false)) {
            try {
                ConfigurationSection g = sec.getConfigurationSection(key);
                if (g == null) continue;

                UUID id = UUID.fromString(key);

                String cellId = g.getString("cell");
                String tierName = g.getString("tier");
                String npc = g.getString("npc");

                String worldName = g.getString("world");
                double x = g.getDouble("x");
                double y = g.getDouble("y");
                double z = g.getDouble("z");

                if (cellId == null || tierName == null || worldName == null) {
                    plugin.getLogger().warning("[CellGuards] Invalid guard data for " + key);
                    continue;
                }

                World world = Bukkit.getWorld(worldName);
                if (world == null) {
                    plugin.getLogger().warning("[CellGuards] World not found: " + worldName);
                    continue;
                }

                Location home = new Location(world, x, y, z);

                CellGuardTier tier = CellGuardTier.valueOf(tierName);

                Placement placement = new Placement(id, cellId, tier, home);
                placement.setCurrentHealth(this.sanitizeGuardHealth(tier, g.getDouble("health", tier.health())));
                if (npc != null) {
                    try {
                        placement.setNpcId(UUID.fromString(npc));
                    } catch (IllegalArgumentException ignored) {
                        // ignore invalid persisted NPC ids
                    }
                }

                // ✅ ADD TO MAIN MAP
                this.placements.put(id, placement);

                // ✅ ADD TO CELL MAP (CRITICAL)
                this.placementsByCell
                        .computeIfAbsent(cellId.toLowerCase(Locale.ROOT), k -> new HashSet<>())
                        .add(id);

            } catch (Exception e) {
                plugin.getLogger().warning("[CellGuards] Failed to load guard " + key + ": " + e.getMessage());
            }
        }

        plugin.getLogger().info("[CellGuards] Loaded " + placements.size() + " guards.");
        plugin.getLogger().info("Loaded guards: " + this.placements.size());
        // Do not schedule another respawn here. The constructor owns the single startup respawn pass.
    }

    private void rebindOrRespawnGuards() {
        // =========================
        // 🔥 REBIND / RESPAWN GUARDS
        // =========================
        Bukkit.getScheduler().runTaskLater(this.plugin, () -> {

            for (Placement placement : this.placements.values()) {

                if (placement == null) continue;

                UUID npcId = placement.npc();
                Entity existing = npcId != null ? Bukkit.getEntity(npcId) : null;

                // =========================
                // ✅ CASE 1: NPC STILL EXISTS → REBIND
                // =========================
                if (existing instanceof LivingEntity && !existing.isDead()) {
                    LivingEntity living = (LivingEntity) existing;
                    this.npcToPlacement.put(existing.getUniqueId(), placement.id());
                    this.recordGuardHealth(living);
                    continue;
                }

                // =========================
                // 🚫 CASE 2: CHECK FOR DUPLICATE NEARBY
                // =========================
                Location home = placement.home();

                for (Entity entity : home.getWorld().getEntities()) {

                    if (!(entity instanceof LivingEntity living)) continue;
                    if (entity.isDead()) continue;

                    if (!this.isCellGuard(entity)) continue;

                    Location loc = entity.getLocation();

                    // 🔥 STRICT radius (prevents wrong binding)
                    if (loc.distanceSquared(home) > 1.0) continue;

                    // found matching guard → bind it
                    placement.setNpcId(entity.getUniqueId());
                    this.npcToPlacement.put(entity.getUniqueId(), placement.id());
                    if (entity instanceof LivingEntity) {
                        this.recordGuardHealth((LivingEntity) entity);
                    }

                    existing = entity;
                    break;
                }

                // =========================
                // ❌ CASE 3: STILL MISSING → RESPAWN
                // =========================
                if (existing == null) {
                    this.spawnGuardForPlacement(placement);
                }
            }

            this.save();
        }, 20L); // delay 1 second (VERY IMPORTANT)
    }
    public void save() {

        if (this.dataCfg == null) return;

        this.dataCfg.set("guards", null);

        for (Placement placement : this.placements.values()) {

            String path = "guards." + placement.id();

            this.dataCfg.set(path + ".cell", placement.cellId());
            this.dataCfg.set(path + ".tier", placement.tier().name());
            if (placement.npc() != null) {
                this.dataCfg.set(path + ".npc", placement.npc().toString());
            } else {
                this.dataCfg.set(path + ".npc", null);
            }

            Location l = placement.home();

            this.dataCfg.set(path + ".world", l.getWorld().getName());
            this.dataCfg.set(path + ".x", l.getX());
            this.dataCfg.set(path + ".y", l.getY());
            this.dataCfg.set(path + ".z", l.getZ());
            this.dataCfg.set(path + ".health", placement.currentHealth());
        }

        try {
            this.dataCfg.save(this.dataFile);
        } catch (IOException e) {
            this.plugin.getLogger().warning("[CellGuards] Failed to save guards: " + e.getMessage());
        }
    }

    private void spawnGuardForPlacement(Placement placement) {

        if (placement == null) {
            return;
        }

        Location home = placement.home();
        if (home == null || home.getWorld() == null) {
            return;
        }

        // =========================
        // 🚫 HARD DUPLICATE BLOCK (tracked)
        // =========================
        if (placement.npc() != null) {
            Entity existing = Bukkit.getEntity(placement.npc());

            if (existing instanceof LivingEntity && !existing.isDead()) {
                placement.setNpcId(existing.getUniqueId());
                this.npcToPlacement.put(existing.getUniqueId(), placement.id());
                this.restorePlacementHealthIfNeeded((LivingEntity)existing, placement);
                return;
            }
        }

        // =========================
        // 🚫 HARD DUPLICATE BLOCK (world scan by placement key first)
        // =========================
        for (Entity entity : home.getWorld().getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity.isDead()) continue;
            if (!this.isCellGuard(entity)) continue;

            String stored = living.getPersistentDataContainer().get(
                    Keys.cellGuardPlacement(this.plugin),
                    PersistentDataType.STRING
            );

            if (stored != null && stored.equalsIgnoreCase(placement.id().toString())) {
                placement.setNpcId(entity.getUniqueId());
                this.npcToPlacement.put(entity.getUniqueId(), placement.id());
                this.restorePlacementHealthIfNeeded(living, placement);
                return;
            }
        }

        // =========================
        // 🚫 FALLBACK DUPLICATE BLOCK (very close same location)
        // =========================
        for (Entity entity : home.getWorld().getEntities()) {
            if (!(entity instanceof LivingEntity)) continue;
            if (entity.isDead()) continue;
            if (!this.isCellGuard(entity)) continue;

            Location existingLoc = entity.getLocation();
            if (existingLoc.getWorld() == null || !existingLoc.getWorld().equals(home.getWorld())) continue;
            if (existingLoc.distanceSquared(home) > 0.25) continue;

            placement.setNpcId(entity.getUniqueId());
            this.npcToPlacement.put(entity.getUniqueId(), placement.id());
            this.restorePlacementHealthIfNeeded((LivingEntity)entity, placement);
            return;
        }

        // =========================
        // 🧹 CLEAN OLD IF EXISTS
        // =========================
        if (placement.npc() != null) {
            Entity old = Bukkit.getEntity(placement.npc());
            this.destroyNpc(old);

            if (old != null) {
                old.remove();
            }
        }

        // KEEP THE REST OF YOUR ORIGINAL METHOD BELOW THIS LINE EXACTLY AS IT ALREADY IS

        // =========================
        // 🧹 CLEAN OLD IF EXISTS
        // =========================
        if (placement.npc() != null) {
            Entity old = Bukkit.getEntity(placement.npc());
            this.destroyNpc(old);

            if (old != null) {
                old.remove();
            }

            this.npcToPlacement.remove(placement.npc());
            this.guardTargets.remove(placement.npc());
        }

        // =========================
        // ✅ SAFE SPAWN
        // =========================
        Entity npc = this.createCitizensNPC(home, Text.color(placement.tier().displayName()));

        if (!(npc instanceof LivingEntity living)) {
            this.plugin.getLogger().warning("Failed to spawn cell guard for cell " + placement.cellId());
            return;
        }

        this.applyFacing(living, home);
        living.setRemoveWhenFarAway(false);
        this.ensureUnprotected(living);

        this.scheduleHealthApply(living, this.sanitizeGuardHealth(placement.tier(), placement.currentHealth()));
        this.updateGuardName(living, placement.tier());
        this.restorePlacementHealthIfNeeded(living, placement);

        living.getPersistentDataContainer().set(
                Keys.cellGuardPlacement(this.plugin),
                PersistentDataType.STRING,
                placement.id().toString()
        );

        placement.setNpcId(living.getUniqueId());
        this.npcToPlacement.put(living.getUniqueId(), placement.id());
        this.save();

        this.scheduleSkinApplications(living);

        this.plugin.getServer().getScheduler().runTaskLater(
                this.plugin,
                () -> this.equipGuard(living, placement.tier()),
                5L
        );

        this.guardEquipReadyAt.put(living.getUniqueId(), System.currentTimeMillis() + 250L);
    }

    private void cleanupOrphanGuards() {

        plugin.getLogger().info("[CellGuards] Cleaning up orphan/duplicate guards...");

        Map<UUID, Entity> keptByPlacement = new HashMap<>();

        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : new java.util.ArrayList<>(world.getEntities())) {

                if (!(entity instanceof LivingEntity living)) continue;
                if (entity.isDead()) continue;

                UUID placementId = this.readPlacementId(living);

                if (placementId == null) {
                    // Clean old name-only Citizens leftovers near saved guard homes.
                    placementId = this.findNearbyPlacementForRuntimeEntity(entity, 9.0D);
                    if (placementId == null) continue;
                }

                Placement placement = this.placements.get(placementId);
                if (placement == null) {
                    this.destroyNpc(entity);
                    entity.remove();
                    continue;
                }

                Entity kept = keptByPlacement.get(placementId);
                if (kept == null || kept.isDead()) {
                    keptByPlacement.put(placementId, entity);
                    placement.setNpcId(entity.getUniqueId());
                    this.npcToPlacement.put(entity.getUniqueId(), placementId);
                    living.getPersistentDataContainer().set(
                            Keys.cellGuardPlacement(this.plugin),
                            PersistentDataType.STRING,
                            placementId.toString()
                    );
                    continue;
                }

                // Prefer the entity closest to the saved home; remove the other one.
                Entity remove = entity;
                Location home = placement.home();
                if (home != null && kept.getWorld().equals(entity.getWorld())) {
                    double keptDist = kept.getLocation().distanceSquared(home);
                    double newDist = entity.getLocation().distanceSquared(home);
                    if (newDist < keptDist) {
                        remove = kept;
                        keptByPlacement.put(placementId, entity);
                        placement.setNpcId(entity.getUniqueId());
                        this.npcToPlacement.put(entity.getUniqueId(), placementId);
                    }
                }

                plugin.getLogger().warning("[CellGuards] Removing duplicate guard for placement " + placementId);
                this.destroyNpc(remove);
                remove.remove();
            }
        }

        this.cleanupOrphanHealthStands();
        plugin.getLogger().info("[CellGuards] Cleanup complete.");
    }

    private void purgeRuntimeCellGuardEntities() {
        plugin.getLogger().info("[CellGuards] Purging runtime cell guard NPCs before respawn...");

        this.npcToPlacement.clear();
        this.healthStands.clear();
        this.guardTargets.clear();
        this.guardEquipReadyAt.clear();
        this.guardPendingHealth.clear();
        this.guardHealthReadyAt.clear();
        this.guardPhaseReadyAt.clear();
        this.guardAttackReadyAt.clear();

        for (Placement placement : this.placements.values()) {
            if (placement != null) {
                placement.setNpcId(null);
            }
        }

        int removed = 0;
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : new java.util.ArrayList<>(world.getEntities())) {
                if (this.isRuntimeCellGuardEntity(entity)) {
                    this.removeGuardPassengers(entity);
                    this.destroyNpc(entity);
                    entity.remove();
                    removed++;
                    continue;
                }

                if (this.isCellGuardHealthStand(entity)) {
                    entity.remove();
                    removed++;
                }
            }
        }

        plugin.getLogger().info("[CellGuards] Purged " + removed + " old runtime cell guard entities.");
    }

    private UUID readPlacementId(LivingEntity living) {
        if (living == null) return null;
        String stored = living.getPersistentDataContainer().get(
                Keys.cellGuardPlacement(this.plugin),
                PersistentDataType.STRING
        );
        if (stored == null || stored.isBlank()) return null;
        try {
            return UUID.fromString(stored);
        } catch (IllegalArgumentException ignored) {
            return null;
        }
    }

    private UUID findNearbyPlacementForRuntimeEntity(Entity entity, double maxDistanceSquared) {
        if (entity == null || entity.getWorld() == null) return null;
        if (!this.hasCellGuardName(entity)) return null;

        UUID bestId = null;
        double best = maxDistanceSquared;

        for (Placement placement : this.placements.values()) {
            if (placement == null || placement.home() == null || placement.home().getWorld() == null) continue;
            if (!placement.home().getWorld().equals(entity.getWorld())) continue;
            double d = placement.home().distanceSquared(entity.getLocation());
            if (d <= best) {
                best = d;
                bestId = placement.id();
            }
        }

        return bestId;
    }

    private boolean isRuntimeCellGuardEntity(Entity entity) {
        if (!(entity instanceof LivingEntity living)) return false;
        if (this.readPlacementId(living) != null) return true;
        if (this.npcToPlacement.containsKey(entity.getUniqueId())) return true;
        return this.findNearbyPlacementForRuntimeEntity(entity, 64.0D) != null;
    }

    private boolean hasCellGuardName(Entity entity) {
        if (entity == null) return false;
        String name = entity.getCustomName();
        if (name == null || name.isBlank()) {
            name = entity.getName();
        }
        if (name == null) return false;
        String plain = ChatColor.stripColor(Text.color(name));
        if (plain == null) plain = name;
        plain = plain.toLowerCase(Locale.ROOT);
        for (CellGuardTier tier : CellGuardTier.values()) {
            String tierName = ChatColor.stripColor(Text.color(tier.displayName()));
            if (tierName != null && plain.contains(tierName.toLowerCase(Locale.ROOT))) {
                return true;
            }
        }
        return plain.contains("cell guard") || plain.contains("basic guard") || plain.contains("unique guard")
                || plain.contains("rare guard") || plain.contains("elite guard") || plain.contains("legendary guard");
    }

    private boolean isCellGuardHealthStand(Entity entity) {
        if (!(entity instanceof ArmorStand stand)) return false;
        PersistentDataContainer pdc = stand.getPersistentDataContainer();
        if (pdc.has(Keys.cellGuardHealthStand(this.plugin), PersistentDataType.BYTE)) {
            String owner = pdc.get(Keys.cellGuardHealthStandOwner(this.plugin), PersistentDataType.STRING);
            if (owner == null) {
                return true;
            }
            try {
                UUID placementId = UUID.fromString(owner);
                Placement placement = this.placements.get(placementId);
                if (placement == null || placement.npc() == null) {
                    return true;
                }
                Entity guard = Bukkit.getEntity((UUID)placement.npc());
                return !(guard instanceof LivingEntity) || guard.isDead();
            } catch (IllegalArgumentException ignored) {
                return true;
            }
        }
        if (!stand.isMarker()) {
            return false;
        }
        String name = stand.getCustomName();
        if (name == null) return false;
        String plain = ChatColor.stripColor(Text.color(name));
        if (plain == null || !plain.contains("❤")) return false;

        for (Placement placement : this.placements.values()) {
            if (placement == null || placement.home() == null || placement.home().getWorld() == null) continue;
            if (!placement.home().getWorld().equals(entity.getWorld())) continue;
            if (placement.home().distanceSquared(entity.getLocation()) <= 100.0D) {
                return true;
            }
        }
        return false;
    }

    private boolean isPlacementChunkLoaded(Placement placement) {
        if (placement == null || placement.home() == null || placement.home().getWorld() == null) {
            return false;
        }
        World world = placement.home().getWorld();
        int chunkX = placement.home().getBlockX() >> 4;
        int chunkZ = placement.home().getBlockZ() >> 4;
        return world.isChunkLoaded(chunkX, chunkZ);
    }

    private void cleanupOrphanHealthStands() {
        for (World world : Bukkit.getWorlds()) {
            for (Entity entity : new java.util.ArrayList<>(world.getEntities())) {
                if (this.isCellGuardHealthStand(entity)) {
                    Entity vehicle = entity.getVehicle();
                    if (vehicle != null) {
                        vehicle.removePassenger(entity);
                    }
                    entity.remove();
                }
            }
        }
    }

    private void removeGuardPassengers(Entity entity) {
        if (entity == null) {
            return;
        }
        for (Entity passenger : new java.util.ArrayList<>(entity.getPassengers())) {
            passenger.remove();
        }
        Entity vehicle = entity.getVehicle();
        if (vehicle != null) {
            vehicle.removePassenger(entity);
        }
    }

    private Entity createCitizensNPC(Location loc, String name) {
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Class<?> npcRegistryClass = Class.forName("net.citizensnpcs.api.npc.NPCRegistry");
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            Class<?> entityTypeClass = Class.forName("org.bukkit.entity.EntityType");
            Object playerType = entityTypeClass.getField("PLAYER").get(null);
            Method create = npcRegistryClass.getMethod("createNPC", entityTypeClass, String.class);
            Object npc = create.invoke(registry, playerType, Text.color(name));
            this.applyPersistentSkin(npc, npcClass);
            try {
                npcClass.getMethod("setPersistent", Boolean.TYPE).invoke(npc, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            Method spawn = npcClass.getMethod("spawn", Location.class);
            spawn.invoke(npc, loc);
            try {
                npcClass.getMethod("setProtected", Boolean.TYPE).invoke(npc, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            Method getEntity = npcClass.getMethod("getEntity", new Class[0]);
            Entity bukkitEntity = (Entity)getEntity.invoke(npc, new Object[0]);
            this.applyFacing(bukkitEntity, loc);
            return bukkitEntity;
        }
        catch (Exception e) {
            this.plugin.getLogger().warning("Citizens not found or failed to create cell guard NPC: " + e.getMessage());
            return null;
        }
    }

    private void applyFacing(Entity entity, Location facing) {
        if (entity == null || facing == null) {
            return;
        }
        Location updated = entity.getLocation();
        updated.setYaw(facing.getYaw());
        updated.setPitch(facing.getPitch());
        entity.teleport(updated);
    }

    private void scheduleSkinApplications(Entity npc) {
        long[] delays;
        for (long delay : delays = new long[]{0L, 20L}) {
            this.applySkinAsync(npc, delay);
        }
    }

    private void applySkinAsync(Entity npc, long delay) {
        if (npc == null) {
            return;
        }
        this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            try {
                Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
                Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
                Object npcHandle = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, npc);
                if (npcHandle == null) {
                    return;
                }
                Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
                this.applyPersistentSkin(npcHandle, npcClass);
            }
            catch (Exception exception) {
                // empty catch block
            }
        }, delay);
    }

    private void ensureSkin(LivingEntity living) {
        if (living == null) {
            return;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npcHandle = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, living);
            if (npcHandle == null) {
                return;
            }
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            this.applyPersistentSkin(npcHandle, npcClass);
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void applyPersistentSkin(Object npc, Class<?> npcClass) {
        block32: {
            if (npc == null || npcClass == null) {
                return;
            }
            try {
                Class<?> skinTraitClass = this.resolveSkinTraitClass();
                Method getOrAddTrait = npcClass.getMethod("getOrAddTrait", Class.class);
                Object trait = getOrAddTrait.invoke(npc, skinTraitClass);
                if (trait == null) {
                    return;
                }
                try {
                    skinTraitClass.getMethod("setFetchDefaultSkin", Boolean.TYPE).invoke(trait, false);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                try {
                    skinTraitClass.getMethod("setShouldUpdateSkins", Boolean.TYPE).invoke(trait, false);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                try {
                    skinTraitClass.getMethod("setUpdateSkins", Boolean.TYPE).invoke(trait, false);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                try {
                    skinTraitClass.getMethod("setUseCache", Boolean.TYPE).invoke(trait, false);
                }
                catch (Exception exception) {
                    // empty catch block
                }
                try {
                    Class<?> metadataEnum = Class.forName("net.citizensnpcs.api.npc.NPC$Metadata");
                    Object dataStore = npcClass.getMethod("data", new Class[0]).invoke(npc, new Object[0]);
                    Method setPersistent = dataStore.getClass().getMethod("setPersistent", metadataEnum, Object.class);
                    try {
                        Object useLatest = Enum.valueOf((Class)metadataEnum, "PLAYER_SKIN_USE_LATEST");
                        setPersistent.invoke(dataStore, useLatest, false);
                    }
                    catch (Exception useLatest) {
                        // empty catch block
                    }
                    try {
                        Object skinUuid = Enum.valueOf((Class)metadataEnum, "PLAYER_SKIN_UUID_METADATA");
                        setPersistent.invoke(dataStore, skinUuid, "cellguardskin");
                    }
                    catch (Exception exception) {}
                }
                catch (Exception metadataEnum) {
                    // empty catch block
                }
                try {
                    skinTraitClass.getMethod("clearTexture", new Class[0]).invoke(trait, new Object[0]);
                }
                catch (Exception metadataEnum) {
                    // empty catch block
                }
                boolean applied = false;
                try {
                    skinTraitClass.getMethod("setSkinPersistent", String.class, String.class, String.class, Boolean.TYPE).invoke(trait, UUID.randomUUID().toString(), CELL_GUARD_SIGNATURE, CELL_GUARD_TEXTURE, true);
                    applied = true;
                }
                catch (NoSuchMethodException dataStore) {
                }
                catch (Exception e) {
                    this.logSkinError("4-arg setSkinPersistent", e);
                }
                try {
                    skinTraitClass.getMethod("setSkinPersistent", String.class, String.class, String.class).invoke(trait, UUID.randomUUID().toString(), CELL_GUARD_SIGNATURE, CELL_GUARD_TEXTURE);
                    applied = true;
                }
                catch (NoSuchMethodException e) {
                }
                catch (Exception e) {
                    this.logSkinError("3-arg setSkinPersistent", e);
                }
                if (!applied) {
                    try {
                        skinTraitClass.getMethod("setSkinPersistent", String.class, String.class).invoke(trait, CELL_GUARD_SIGNATURE, CELL_GUARD_TEXTURE);
                        applied = true;
                    }
                    catch (Exception e) {
                        this.logSkinError("2-arg setSkinPersistent", e);
                    }
                }
                if (!applied) {
                    if (!this.skinWarningLogged) {
                        this.plugin.getLogger().warning("Failed to apply cell guard skin: setSkinPersistent not available.");
                        this.skinWarningLogged = true;
                    }
                    return;
                }
                this.invokeIfPresent(skinTraitClass, trait, "updateSkin");
                this.invokeIfPresent(skinTraitClass, trait, "applySkin");
                this.invokeIfPresent(skinTraitClass, trait, "updateAndApply");
            }
            catch (Exception e) {
                if (this.skinWarningLogged) break block32;
                String msg = e == null ? "unknown" : e.getClass().getName() + (String)(e.getMessage() == null ? "" : ": " + e.getMessage());
                this.plugin.getLogger().warning("Failed to apply cell guard skin: " + msg);
                if (e != null) {
                    e.printStackTrace();
                }
                this.skinWarningLogged = true;
            }
        }
    }

    private Class<?> resolveSkinTraitClass() throws ClassNotFoundException {
        String[] candidates = new String[]{"net.citizensnpcs.api.trait.SkinTrait", "net.citizensnpcs.api.trait.trait.SkinTrait", "net.citizensnpcs.trait.SkinTrait", "net.citizensnpcs.trait.trait.SkinTrait"};
        ClassNotFoundException last = null;
        for (String name : candidates) {
            try {
                return Class.forName(name);
            }
            catch (ClassNotFoundException e) {
                last = e;
            }
        }
        throw last != null ? last : new ClassNotFoundException("SkinTrait not found");
    }

    private void logSkinError(String step, Exception e) {
        if (!this.skinWarningLogged) {
            String msg = e == null ? "unknown" : e.getClass().getName() + (String)(e.getMessage() == null ? "" : ": " + e.getMessage());
            this.plugin.getLogger().warning("Cell guard skin step failed (" + step + "): " + msg);
            if (e != null) {
                e.printStackTrace();
            }
            this.skinWarningLogged = true;
        }
    }

    private void invokeIfPresent(Class<?> clazz, Object target, String method) {
        try {
            clazz.getMethod(method, new Class[0]).invoke(target, new Object[0]);
        }
        catch (NoSuchMethodException noSuchMethodException) {
        }
        catch (Exception e) {
            this.logSkinError(method, e);
        }
    }

    private void stopNavigation(Entity ent) {
        if (ent == null) {
            return;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, ent);
            if (npc == null) {
                return;
            }
            Object navigator = npc.getClass().getMethod("getNavigator", new Class[0]).invoke(npc, new Object[0]);
            Class<?> navigatorClass = Class.forName("net.citizensnpcs.api.ai.Navigator");
            try {
                navigatorClass.getMethod("cancelNavigation", new Class[0]).invoke(navigator, new Object[0]);
            }
            catch (Exception exception) {}
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void ensureUnprotected(Entity ent) {
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, ent);
            if (npc == null) {
                return;
            }
            Class<?> npcClass = Class.forName("net.citizensnpcs.api.npc.NPC");
            try {
                npcClass.getMethod("setProtected", Boolean.TYPE).invoke(npc, false);
            }
            catch (Exception exception) {
                // empty catch block
            }
            try {
                Class<?> metadataEnum = Class.forName("net.citizensnpcs.api.npc.NPC$Metadata");
                Object dataStore = npcClass.getMethod("data", new Class[0]).invoke(npc, new Object[0]);
                Object protectedMeta = Enum.valueOf((Class)metadataEnum, "DEFAULT_PROTECTED");
                dataStore.getClass().getMethod("setPersistent", metadataEnum, Object.class).invoke(dataStore, protectedMeta, false);
            }
            catch (Exception exception) {}
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void equipGuard(LivingEntity living, CellGuardTier tier) {
        EntityEquipment equip = living.getEquipment();
        if (equip == null) {
            return;
        }
        equip.setHelmet(tier.helmet());
        equip.setChestplate(tier.chest());
        equip.setLeggings(tier.legs());
        equip.setBoots(tier.boots());
        equip.setItemInMainHand(tier.weapon());
        this.setDropChancesSafe(equip);
        this.setUnbreakable(equip);
        this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            EntityEquipment eq = living.getEquipment();
            if (eq == null) {
                return;
            }
            eq.setHelmet(tier.helmet());
            eq.setChestplate(tier.chest());
            eq.setLeggings(tier.legs());
            eq.setBoots(tier.boots());
            eq.setItemInMainHand(tier.weapon());
            this.setDropChancesSafe(eq);
            this.setUnbreakable(eq);
        }, 20L);
    }

    private void ensureEquipment(LivingEntity living, CellGuardTier tier) {
        EntityEquipment equip;
        if (living == null || tier == null) {
            return;
        }
        Long readyAt = this.guardEquipReadyAt.get(living.getUniqueId());
        if (readyAt != null && System.currentTimeMillis() < readyAt) {
            return;
        }
        if (readyAt != null && System.currentTimeMillis() >= readyAt) {
            this.guardEquipReadyAt.remove(living.getUniqueId());
        }
        if ((equip = living.getEquipment()) == null) {
            return;
        }
        boolean missing = false;
        if (this.isEmpty(equip.getHelmet())) {
            equip.setHelmet(tier.helmet());
            missing = true;
        }
        if (this.isEmpty(equip.getChestplate())) {
            equip.setChestplate(tier.chest());
            missing = true;
        }
        if (this.isEmpty(equip.getLeggings())) {
            equip.setLeggings(tier.legs());
            missing = true;
        }
        if (this.isEmpty(equip.getBoots())) {
            equip.setBoots(tier.boots());
            missing = true;
        }
        if (this.isEmpty(equip.getItemInMainHand())) {
            equip.setItemInMainHand(tier.weapon());
            missing = true;
        }
        if (!missing) {
            return;
        }
        this.setDropChancesSafe(equip);
        this.setUnbreakable(equip);
        this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> {
            EntityEquipment eq = living.getEquipment();
            if (eq == null) {
                return;
            }
            if (this.isEmpty(eq.getHelmet())) {
                eq.setHelmet(tier.helmet());
            }
            if (this.isEmpty(eq.getChestplate())) {
                eq.setChestplate(tier.chest());
            }
            if (this.isEmpty(eq.getLeggings())) {
                eq.setLeggings(tier.legs());
            }
            if (this.isEmpty(eq.getBoots())) {
                eq.setBoots(tier.boots());
            }
            if (this.isEmpty(eq.getItemInMainHand())) {
                eq.setItemInMainHand(tier.weapon());
            }
            this.setDropChancesSafe(eq);
            this.setUnbreakable(eq);
        }, 10L);
    }

    private void setDropChancesSafe(EntityEquipment equip) {
        try {
            equip.setHelmetDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setChestplateDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setLeggingsDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setBootsDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
        try {
            equip.setItemInMainHandDropChance(0.0f);
        }
        catch (UnsupportedOperationException unsupportedOperationException) {
            // empty catch block
        }
    }

    private void setUnbreakable(EntityEquipment equip) {
        this.tryUnbreakable(equip.getHelmet());
        this.tryUnbreakable(equip.getChestplate());
        this.tryUnbreakable(equip.getLeggings());
        this.tryUnbreakable(equip.getBoots());
        this.tryUnbreakable(equip.getItemInMainHand());
    }

    private void tryUnbreakable(ItemStack item) {
        if (item == null) {
            return;
        }
        ItemMeta meta = item.getItemMeta();
        if (meta == null) {
            return;
        }
        meta.setUnbreakable(true);
        item.setItemMeta(meta);
    }

    private boolean isEmpty(ItemStack item) {
        return item == null || item.getType() == Material.AIR;
    }

    private void phaseGuardThroughDoor(LivingEntity guard, Player target, Placement placement, Cell cell) {
        Location dest;
        if (guard == null || target == null || placement == null || cell == null) {
            return;
        }
        if (!cell.hasDoorConfigured()) {
            return;
        }
        Location doorLoc = cell.getDoorLocation();
        if (doorLoc == null || doorLoc.getWorld() == null) {
            return;
        }
        if (!doorLoc.getWorld().equals((Object)guard.getWorld())) {
            return;
        }
        double guardToTarget = guard.getLocation().distanceSquared(target.getLocation());
        if (guardToTarget < 4.0) {
            return;
        }
        long now = System.currentTimeMillis();
        Long readyAt = this.guardPhaseReadyAt.get(guard.getUniqueId());
        if (readyAt != null && now < readyAt) {
            return;
        }
        if (!this.doorBetween(guard, target, doorLoc)) {
            return;
        }
        Location snapDest = this.doorSnapDestination(guard.getLocation(), doorLoc, target.getLocation());
        Location location = dest = snapDest != null ? snapDest : this.findPhaseDestination(target, target.getLocation().toVector().subtract(guard.getLocation().toVector()));
        if (dest == null) {
            return;
        }
        guard.teleport(dest);
        this.guardPhaseReadyAt.put(guard.getUniqueId(), now + 1000L);
        this.commandAttack(guard, target);
    }

    private boolean isDoorBlockingPath(LivingEntity guard, Player target, Cell cell) {
        return this.doorBetween(guard, target, cell != null ? cell.getDoorLocation() : null);
    }

    private boolean doorBetween(LivingEntity guard, Player target, Location doorLoc) {
        if (guard == null || target == null || doorLoc == null) {
            return false;
        }
        if (doorLoc.getWorld() == null || !doorLoc.getWorld().equals((Object)guard.getWorld()) || !doorLoc.getWorld().equals((Object)target.getWorld())) {
            return false;
        }
        Vector dir = target.getLocation().toVector().subtract(guard.getLocation().toVector());
        double dist = dir.length();
        if (dist < 0.5) {
            return false;
        }
        dir.normalize();
        Vector step = dir.clone().multiply(0.25);
        Location pos = guard.getLocation().clone().add(0.0, 1.0, 0.0);
        for (double walked = 0.0; walked <= dist; walked += 0.25) {
            Block b = pos.getBlock();
            if (Tag.DOORS.isTagged((Material) b.getType())) {
                return true;
            }
            Block feet = pos.clone().add(0.0, -1.0, 0.0).getBlock();
            if (Tag.DOORS.isTagged((Material) feet.getType())) {
                return true;
            }
            pos.add(step);
        }
        return false;
    }

    private boolean sameBlock(Block a, Block b) {
        if (a == null || b == null) {
            return false;
        }
        return a.getWorld().equals((Object)b.getWorld()) && a.getX() == b.getX() && a.getY() == b.getY() && a.getZ() == b.getZ();
    }

    private Location doorSnapDestination(Location guardLoc, Location doorLoc, Location targetLoc) {
        try {
            BlockData data = doorLoc.getBlock().getBlockData();
            if (!(data instanceof Door)) {
                return null;
            }
            Door door = (Door)data;
            Block base = doorLoc.getBlock();
            if (door.getHalf() == Bisected.Half.TOP) {
                base = base.getRelative(0, -1, 0);
            }
            Vector doorCenter = base.getLocation().add(0.5, 1.0, 0.5).toVector();
            Vector face = new Vector(door.getFacing().getModX(), 0, door.getFacing().getModZ());
            if (face.lengthSquared() == 0.0) {
                return null;
            }
            face.normalize();
            Vector guardVec = guardLoc.toVector();
            double side = guardVec.subtract(doorCenter).dot(face);
            double targetSide = targetLoc.toVector().subtract(doorCenter).dot(face);
            if (side * targetSide > 0.0) {
                return null;
            }
            Vector destVec = doorCenter.clone().add(face.clone().multiply(targetSide >= 0.0 ? 1.5 : -1.5));
            Location dest = new Location(doorLoc.getWorld(), destVec.getX(), doorCenter.getY(), destVec.getZ(), targetLoc.getYaw(), targetLoc.getPitch());
            return dest;
        }
        catch (Exception ignored) {
            return null;
        }
    }

    private Location findPhaseDestination(Player target, Vector fromDirection) {
        Vector dir;
        if (target == null || target.getWorld() == null) {
            return null;
        }
        Location base = target.getLocation().clone();
        Vector vector = dir = fromDirection == null ? new Vector(0, 0, 0) : fromDirection.clone();
        if (dir.lengthSquared() < 1.0E-4) {
            dir = target.getLocation().getDirection();
        }
        if (dir.lengthSquared() < 1.0E-4) {
            dir = new Vector(1, 0, 0);
        }
        dir.setY(0);
        if (dir.lengthSquared() > 0.0) {
            dir.normalize();
        }
        List<Vector> offsets = List.of(dir.clone().multiply(-1.2), dir.clone().multiply(-0.6), new Vector(-dir.getZ(), 0.0, dir.getX()).multiply(1.0), new Vector(dir.getZ(), 0.0, -dir.getX()).multiply(1.0), new Vector(0, 0, 0));
        for (Vector offset : offsets) {
            Location spot = base.clone().add(offset);
            if (!this.isSafeTeleportSpot(spot)) continue;
            spot.setYaw(target.getLocation().getYaw());
            spot.setPitch(target.getLocation().getPitch());
            return spot;
        }
        Location fallback = base.clone();
        fallback.setYaw(target.getLocation().getYaw());
        fallback.setPitch(target.getLocation().getPitch());
        return fallback;
    }

    private boolean isSafeTeleportSpot(Location spot) {
        if (spot == null || spot.getWorld() == null) {
            return false;
        }
        Block feet = spot.getBlock();
        Block head = feet.getRelative(0, 1, 0);
        return this.isPassable(feet) && this.isPassable(head);
    }

    private boolean isPassable(Block block) {
        if (block == null) {
            return false;
        }
        if (Tag.DOORS.isTagged((Material) block.getType())) {
            return true;
        }
        try {
            return block.isPassable();
        }
        catch (NoSuchMethodError ignored) {
            return !block.getType().isSolid();
        }
    }

    private void scheduleHealthApply(LivingEntity living, double hp) {
        if (living == null) {
            return;
        }
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance maxAttr = maxHealthAttribute != null ? living.getAttribute(maxHealthAttribute) : null;
            if (maxAttr != null) {
                maxAttr.setBaseValue(hp);
            }
            living.setHealth(Math.min(hp, this.resolvedMaxHealth(living)));
        }
        catch (Exception maxAttr) {
            // empty catch block
        }
        long delayTicks = 20L;
        this.guardPendingHealth.put(living.getUniqueId(), hp);
        this.guardHealthReadyAt.put(living.getUniqueId(), System.currentTimeMillis() + delayTicks * 50L);
        this.plugin.getServer().getScheduler().runTaskLater((Plugin)this.plugin, () -> this.applyHealthIfReady(living.getUniqueId()), delayTicks);
    }

    private void applyHealthIfReady(UUID guardId) {
        Entity ent = Bukkit.getEntity((UUID)guardId);
        if (!(ent instanceof LivingEntity)) {
            return;
        }
        LivingEntity living = (LivingEntity)ent;
        Long readyAt = this.guardHealthReadyAt.get(guardId);
        Double target = this.guardPendingHealth.get(guardId);
        if (readyAt == null || target == null) {
            return;
        }
        if (System.currentTimeMillis() < readyAt) {
            return;
        }
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance maxAttr = maxHealthAttribute != null ? living.getAttribute(maxHealthAttribute) : null;
            if (maxAttr != null) {
                maxAttr.setBaseValue(target.doubleValue());
            }
            living.setHealth(Math.min(target, this.resolvedMaxHealth(living)));
            UUID placementId = this.npcToPlacement.get(guardId);
            if (placementId != null) {
                Placement placement = this.placements.get(placementId);
                if (placement != null) {
                    placement.setCurrentHealth(this.sanitizeGuardHealth(placement.tier(), living.getHealth()));
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        this.guardPendingHealth.remove(guardId);
        this.guardHealthReadyAt.remove(guardId);
    }

    private boolean hasClearPath(Location from, Location to) {
        if (from == null || to == null) {
            return false;
        }
        if (from.getWorld() == null || to.getWorld() == null) {
            return false;
        }
        if (!from.getWorld().getName().equals(to.getWorld().getName())) {
            return false;
        }
        Vector dir = to.toVector().subtract(from.toVector());
        double length = dir.length();
        if (length == 0.0) {
            return true;
        }
        dir.normalize();
        double step = 0.5;
        Location head = from.clone().add(0.0, 1.0, 0.0);
        Vector stepVec = dir.clone().multiply(step);
        for (double walked = 0.0; walked <= length; walked += step) {
            if (this.isBlocking(head.getBlock())) {
                return false;
            }
            if (this.isBlocking(head.clone().add(0.0, -1.0, 0.0).getBlock())) {
                return false;
            }
            head.add(stepVec);
        }
        return true;
    }

    private boolean isBlocking(Block block) {
        if (block == null) {
            return false;
        }
        if (Tag.DOORS.isTagged((Material) block.getType())) {
            return false;
        }
        try {
            return !block.isPassable();
        }
        catch (NoSuchMethodError ignored) {
            return block.getType().isSolid();
        }
    }

    private void dropGuard(Placement placement) {
        if (placement.npc() != null) {
            Entity npc = Bukkit.getEntity((UUID)placement.npc());
            this.destroyNpc(npc);
            if (npc != null) {
                npc.remove();
            }
            this.npcToPlacement.remove(placement.npc());
            this.guardTargets.remove(placement.npc());
            this.removeHealthStand(placement.npc());
            this.guardEquipReadyAt.remove(placement.npc());
            this.guardPendingHealth.remove(placement.npc());
            this.guardHealthReadyAt.remove(placement.npc());
            this.guardAttackReadyAt.remove(placement.npc());
        }
    }

    private void destroyNpc(Entity entity) {
        if (entity == null) {
            return;
        }
        try {
            Class<?> citizensApi = Class.forName("net.citizensnpcs.api.CitizensAPI");
            Object registry = citizensApi.getMethod("getNPCRegistry", new Class[0]).invoke(null, new Object[0]);
            Object npc = registry.getClass().getMethod("getNPC", Entity.class).invoke(registry, entity);
            if (npc != null) {
                npc.getClass().getMethod("destroy", new Class[0]).invoke(npc, new Object[0]);
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    private void spawnHealthStand(LivingEntity guard, CellGuardTier tier) {
        this.removeHealthStand(guard.getUniqueId());
        ArmorStand stand = (ArmorStand)guard.getWorld().spawn(guard.getLocation().add(0.0, 1.9, 0.0), ArmorStand.class, as -> {
            as.setVisible(false);
            as.setMarker(true);
            as.setGravity(false);
            as.setSmall(true);
            as.setCustomNameVisible(true);
            as.setPersistent(false);
            as.setInvulnerable(true);
            as.getPersistentDataContainer().set(Keys.cellGuardHealthStand(this.plugin), PersistentDataType.BYTE, (byte)1);
            as.getPersistentDataContainer().set(Keys.cellGuardHealthStandOwner(this.plugin), PersistentDataType.STRING, guard.getUniqueId().toString());
        });
        this.healthStands.put(guard.getUniqueId(), stand.getUniqueId());
        Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
        double max = maxHealthAttribute != null && guard.getAttribute(maxHealthAttribute) != null ? guard.getAttribute(maxHealthAttribute).getBaseValue() : guard.getHealth();
        double current = guard.getHealth();
        stand.setCustomName(Text.color("&f" + (int)Math.ceil(current) + " &c\u2764"));
        guard.addPassenger((Entity)stand);
        stand.teleport(guard.getLocation().add(0.0, 1.9, 0.0));
    }

    private void updateHealthStand(LivingEntity guard, CellGuardTier tier, double current, double max) {
        Entity ent;
        UUID standId = this.healthStands.get(guard.getUniqueId());
        ArmorStand stand = null;
        if (standId != null && (ent = Bukkit.getEntity((UUID)standId)) instanceof ArmorStand) {
            ArmorStand as;
            stand = as = (ArmorStand)ent;
        }
        if (stand == null || stand.isDead()) {
            Entity ent2;
            this.spawnHealthStand(guard, tier);
            UUID newStandId = this.healthStands.get(guard.getUniqueId());
            Entity entity = ent2 = newStandId != null ? Bukkit.getEntity((UUID)newStandId) : null;
            if (ent2 instanceof ArmorStand) {
                ArmorStand as;
                stand = as = (ArmorStand)ent2;
            } else {
                return;
            }
        }
        if (!guard.getPassengers().contains(stand)) {
            guard.addPassenger((Entity)stand);
        }
        stand.setCustomName(Text.color("&f" + (int)Math.ceil(current) + " &c\u2764"));
        stand.teleport(guard.getLocation().add(0.0, 1.9, 0.0));
        this.recordGuardHealth(guard, current);
    }

    private void removeHealthStand(UUID guardId) {
        UUID standId = this.healthStands.remove(guardId);
        if (standId == null) {
            return;
        }
        Entity ent = Bukkit.getEntity((UUID)standId);
        if (ent != null) {
            Entity vehicle = ent.getVehicle();
            if (vehicle != null) {
                vehicle.removePassenger(ent);
            }
            ent.remove();
        }
    }

    public void updateGuardName(LivingEntity guard) {
        if (guard == null) {
            return;
        }
        UUID pid = this.npcToPlacement.get(guard.getUniqueId());
        if (pid == null) {
            return;
        }
        Placement placement = this.placements.get(pid);
        if (placement == null) {
            return;
        }
        this.updateGuardName(guard, placement.tier());
    }

    private void updateGuardName(LivingEntity guard, CellGuardTier tier) {
        if (guard == null || tier == null) {
            return;
        }
        Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
        double max = maxHealthAttribute != null && guard.getAttribute(maxHealthAttribute) != null ? guard.getAttribute(maxHealthAttribute).getBaseValue() : guard.getMaxHealth();
        double current = guard.getHealth();
        String base = tier.displayName();
        guard.setCustomName(Text.color(base));
        guard.setCustomNameVisible(true);
        this.updateHealthStand(guard, tier, current, max);
    }

    public void recordGuardHealth(LivingEntity guard) {
        if (guard == null) {
            return;
        }
        this.recordGuardHealth(guard, guard.getHealth());
    }

    public void recordGuardHealth(LivingEntity guard, double currentHealth) {
        if (guard == null) {
            return;
        }
        UUID placementId = this.npcToPlacement.get(guard.getUniqueId());
        if (placementId == null) {
            return;
        }
        Placement placement = this.placements.get(placementId);
        if (placement == null) {
            return;
        }
        placement.setCurrentHealth(this.sanitizeGuardHealth(placement.tier(), currentHealth));
    }

    private double sanitizeGuardHealth(CellGuardTier tier, double currentHealth) {
        double fallback = tier != null ? tier.health() : 1.0D;
        if (Double.isNaN(currentHealth) || Double.isInfinite(currentHealth) || currentHealth <= 0.0D) {
            return fallback;
        }
        return currentHealth;
    }

    private Attribute resolveMaxHealthAttribute() {
        try {
            return Attribute.valueOf("GENERIC_MAX_HEALTH");
        }
        catch (IllegalArgumentException ignored) {
            try {
                return Attribute.valueOf("MAX_HEALTH");
            }
            catch (IllegalArgumentException ex) {
                return null;
            }
        }
    }

    private double resolvedMaxHealth(LivingEntity living) {
        if (living == null) {
            return 0.0D;
        }
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            if (maxHealthAttribute != null) {
                AttributeInstance attr = living.getAttribute(maxHealthAttribute);
                if (attr != null) {
                    return attr.getBaseValue();
                }
            }
        }
        catch (Exception ignored) {
            // fall back to the entity API value below
        }
        return living.getMaxHealth();
    }

    private void restorePlacementHealthIfNeeded(LivingEntity living, Placement placement) {
        if (living == null || placement == null) {
            return;
        }
        double desired = this.sanitizeGuardHealth(placement.tier(), placement.currentHealth());
        if (desired <= 0.0D) {
            return;
        }
        double actualMax = this.resolvedMaxHealth(living);
        if (actualMax + 0.1D >= desired) {
            return;
        }
        try {
            Attribute maxHealthAttribute = this.resolveMaxHealthAttribute();
            AttributeInstance maxAttr = maxHealthAttribute != null ? living.getAttribute(maxHealthAttribute) : null;
            if (maxAttr != null) {
                maxAttr.setBaseValue(desired);
            }
            living.setHealth(Math.min(desired, this.resolvedMaxHealth(living)));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public boolean removePlacement(UUID placementId, Player receiver, boolean giveBack) {
        boolean removed = this.removePlacementInternal(placementId, receiver, giveBack);
        if (removed) {
            this.save();
        }
        return removed;
    }

    private boolean removePlacementInternal(UUID placementId, Player receiver, boolean giveBack) {
        Placement placement = this.placements.remove(placementId);
        if (placement == null) {
            return false;
        }
        this.dropGuard(placement);
        this.placementsByCell.computeIfPresent(placement.cellId().toLowerCase(Locale.ROOT), (k, v) -> {
            v.remove(placementId);
            return v.isEmpty() ? null : v;
        });
        this.npcToPlacement.values().removeIf(id -> id.equals(placementId));
        this.guardTargets.keySet().removeIf(id -> id.equals(placement.npc()));
        if (giveBack && receiver != null) {
            Map<Integer, ItemStack> leftovers = receiver.getInventory().addItem(new ItemStack[]{this.createGuardAnchor(placement.tier(), 1)});
            leftovers.values().forEach(item -> receiver.getWorld().dropItemNaturally(receiver.getLocation(), item));
        }
        return true;
    }

    public static class Placement {
        private final UUID id;
        private final String cellId;
        private final CellGuardTier tier;
        private final Location home;
        private UUID npcId;
        private double currentHealth;

        Placement(UUID id, String cellId, CellGuardTier tier, Location home) {
            this.id = id;
            this.cellId = cellId;
            this.tier = tier;
            this.home = home;
            this.currentHealth = tier != null ? tier.health() : 1.0D;
        }

        public UUID id() {
            return this.id;
        }

        public String cellId() {
            return this.cellId;
        }

        public CellGuardTier tier() {
            return this.tier;
        }

        public Location home() {
            return this.home;
        }

        public UUID npc() {
            return this.npcId;
        }

        public void setNpcId(UUID npcId) {
            this.npcId = npcId;
        }

        public double currentHealth() {
            return this.currentHealth;
        }

        public void setCurrentHealth(double currentHealth) {
            this.currentHealth = currentHealth;
        }
    }
}
