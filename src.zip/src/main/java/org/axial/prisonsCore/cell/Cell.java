/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.OfflinePlayer
 */
package org.axial.prisonsCore.cell;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.axial.prisonsCore.cell.CellDoorType;
import org.axial.prisonsCore.cell.CellRegion;
import org.axial.prisonsCore.cell.CellBossTier;
import org.axial.prisonsCore.cell.CellTier;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;

public class Cell {
    private final String id;
    private final CellTier tier;
    private final CellRegion region;
    private Location doorLocation;
    private String doorWorldName;
    private Location signLocation;
    private Location spawnLocation;
    private String spawnWorldName;
    private Location homeLocation;
    private CellDoorType doorType;
    private UUID owner;
    private long rentExpiry;
    private boolean bossCell;
    private CellBossTier bossTier;
    private final Set<UUID> access = new HashSet<UUID>();

    public Cell(String id, CellTier tier, CellRegion region) {
        this.id = id;
        this.tier = tier;
        this.region = region;
    }

    public String getId() {
        return this.id;
    }

    public CellTier getTier() {
        return this.tier;
    }

    public CellRegion getRegion() {
        return this.region;
    }

    public Location getDoorLocation() {
        return this.doorLocation;
    }

    public void setDoorLocation(Location doorLocation) {
        this.doorLocation = doorLocation;
        if (doorLocation != null && doorLocation.getWorld() != null) {
            this.doorWorldName = doorLocation.getWorld().getName();
        }
    }

    public String getDoorWorldName() {
        return this.doorWorldName;
    }

    public void setDoorWorldName(String doorWorldName) {
        this.doorWorldName = doorWorldName;
    }

    public Location getSignLocation() {
        return this.signLocation;
    }

    public void setSignLocation(Location signLocation) {
        this.signLocation = signLocation;
    }

    public Location getSpawnLocation() {
        if (this.spawnLocation != null && this.spawnLocation.getWorld() == null && this.spawnWorldName != null) {
            org.bukkit.World world = Bukkit.getWorld(this.spawnWorldName);
            if (world != null) {
                this.spawnLocation = new Location(world, this.spawnLocation.getX(), this.spawnLocation.getY(), this.spawnLocation.getZ(), this.spawnLocation.getYaw(), this.spawnLocation.getPitch());
            }
        }
        return this.spawnLocation;
    }

    public void setSpawnLocation(Location spawnLocation) {
        this.spawnLocation = spawnLocation;
        if (spawnLocation == null) {
            this.spawnWorldName = null;
        } else if (spawnLocation.getWorld() != null) {
            this.spawnWorldName = spawnLocation.getWorld().getName();
        }
    }

    public String getSpawnWorldName() {
        return this.spawnWorldName;
    }

    public void setSpawnWorldName(String spawnWorldName) {
        this.spawnWorldName = spawnWorldName;
    }

    public Location getHomeLocation() {
        return this.homeLocation;
    }

    public void setHomeLocation(Location homeLocation) {
        this.homeLocation = homeLocation;
    }

    public CellDoorType getDoorType() {
        return this.doorType;
    }

    public void setDoorType(CellDoorType doorType) {
        this.doorType = doorType;
    }

    public UUID getOwner() {
        return this.owner;
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    public long getRentExpiry() {
        return this.rentExpiry;
    }

    public void setRentExpiry(long rentExpiry) {
        this.rentExpiry = rentExpiry;
    }

    public boolean isBossCell() {
        return this.bossCell;
    }

    public void setBossCell(boolean bossCell) {
        this.bossCell = bossCell;
    }

    public CellBossTier getBossTier() {
        return this.bossTier;
    }

    public void setBossTier(CellBossTier bossTier) {
        this.bossTier = bossTier;
    }

    public Set<UUID> getAccess() {
        return this.access;
    }

    public boolean hasDoorConfigured() {
        return this.doorLocation != null && this.doorType != null && this.doorWorldName != null;
    }

    public boolean isOwned() {
        return this.owner != null;
    }

    public boolean isInside(Location location) {
        return this.region.contains(location);
    }

    public String ownerName() {
        if (this.owner == null) {
            return "None";
        }
        OfflinePlayer offline = Bukkit.getOfflinePlayer((UUID)this.owner);
        return offline.getName() == null ? this.owner.toString() : offline.getName();
    }
}
