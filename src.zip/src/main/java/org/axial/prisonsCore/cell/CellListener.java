/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 *  org.bukkit.block.Block
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.block.Action
 *  org.bukkit.event.block.BlockBreakEvent
 *  org.bukkit.event.block.BlockPlaceEvent
 *  org.bukkit.event.player.PlayerInteractEvent
 */
package org.axial.prisonsCore.cell;

import org.axial.prisonsCore.cell.Cell;
import org.axial.prisonsCore.cell.CellService;
import org.axial.prisonsCore.model.CustomEnchant;
import org.axial.prisonsCore.service.GearEnchantService;
import org.axial.prisonsCore.service.GearManager;
import org.axial.prisonsCore.util.Text;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class CellListener
implements Listener {
    private final CellService cellService;
    private final GearManager gearManager;
    private final GearEnchantService gearEnchantService;

    public CellListener(CellService cellService, GearManager gearManager, GearEnchantService gearEnchantService) {
        this.cellService = cellService;
        this.gearManager = gearManager;
        this.gearEnchantService = gearEnchantService;
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        Cell cell = this.cellService.getCellAt(event.getBlock().getLocation());
        if (cell == null) {
            return;
        }
        if (player.hasPermission("cells.admin")) {
            return;
        }
        if (cell.isOwned()) {
            if (this.cellService.hasAccess(cell, player.getUniqueId())) {
                return;
            }
            event.setCancelled(true);
            player.sendMessage(Text.color("&cYou cannot place blocks in someone else's cell."));
        } else {
            event.setCancelled(true);
            player.sendMessage(Text.color("&cYou cannot build in an unowned cell."));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTrackedPlace(BlockPlaceEvent event) {
        if (this.cellService.getCellAt(event.getBlockPlaced().getLocation()) != null) {
            this.cellService.markPlayerPlacedBlock(event.getBlockPlaced());
        }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        Block block = event.getBlock();
        if (this.cellService.isCellDoor(block)) {
            Cell cell = this.cellService.getCellByDoor(block);
            if (cell != null && player.isSneaking() && player.hasPermission("cells.admin") && cell.isBossCell()) {
                CellDoorType doorType = cell.getDoorType();
                if (doorType != null) {
                    block.setType(Material.AIR, false);
                    Block above = block.getRelative(0, 1, 0);
                    if (above.getType() == doorType.getMaterial()) {
                        above.setType(Material.AIR, false);
                    }
                    this.cellService.clearDoor(cell);
                    player.getInventory().addItem(this.cellService.createDoorItem(doorType, 1));
                    player.sendMessage(Text.color("&aCell door removed and returned to your inventory."));
                }
                event.setCancelled(true);
                return;
            }
            CellService.DoorBreakResult result = this.cellService.handleDoorHit(player, cell, block);
            int shredBonus = this.getShredBonus(player);
            for (int i = 0; i < shredBonus && result == CellService.DoorBreakResult.DAMAGE_TICK; ++i) {
                result = this.cellService.handleDoorHit(player, cell, block);
            }
            switch (result) {
                case WRONG_TOOL: {
                    player.sendMessage(Text.color("&cYou need a Cell Buster to break this door."));
                    break;
                }
                case NO_DOOR: {
                    break;
                }
                case COOLDOWN: {
                    player.sendMessage(Text.color("&cThis boss cell is on raid cooldown."));
                    break;
                }
                case DAMAGE_TICK: {
                    if (cell != null && cell.isBossCell()) {
                        this.cellService.checkBossCellCompletion(cell, player);
                    }
                    break;
                }
                case BROKEN: {
                    player.sendMessage(Text.color("&cCell door broken! Raid the cell."));
                    if (cell != null && cell.isBossCell()) {
                        this.cellService.onBossCellBreak(cell, player);
                    }
                    break;
                }
            }
            event.setCancelled(true);
            return;
        }
        Cell cell = this.cellService.getCellAt(block.getLocation());
        if (cell == null || !cell.isOwned()) {
            return;
        }
        if (player.hasPermission("cells.admin") || this.cellService.hasAccess(cell, player.getUniqueId())) {
            return;
        }
        Material type = block.getType();
        if (type == Material.CHEST || type == Material.TRAPPED_CHEST || type == Material.BARREL) {
            event.setCancelled(true);
            player.sendMessage(Text.color("&cYou cannot break chests in another player's cell, but you can open them."));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onTrackedBreak(BlockBreakEvent event) {
        if (this.cellService.getCellAt(event.getBlock().getLocation()) != null) {
            this.cellService.unmarkPlayerPlacedBlock(event.getBlock());
        }
    }

    @EventHandler(ignoreCancelled=true)
    public void onDoorInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.getClickedBlock() == null) {
            return;
        }
        if (!this.cellService.isCellDoor(event.getClickedBlock())) {
            return;
        }
        Player player = event.getPlayer();
        Cell cell = this.cellService.getCellByDoor(event.getClickedBlock());
        if (cell == null) {
            return;
        }
        if (player.hasPermission("cells.admin")) {
            return;
        }
        if (!this.cellService.hasAccess(cell, player.getUniqueId())) {
            event.setCancelled(true);
            player.sendMessage(Text.color("&cYou cannot open this cell door."));
        }
    }

    private int getShredBonus(Player player) {
        if (player == null || this.gearManager == null || this.gearEnchantService == null) {
            return 0;
        }
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand == null || hand.getType().isAir() || !hand.getType().name().endsWith("_AXE") || !this.gearManager.isGear(hand)) {
            return 0;
        }
        CustomEnchant enchant = this.gearEnchantService.getById("shred");
        if (enchant == null || !enchant.isApplicableTo(hand.getType())) {
            return 0;
        }
        return Math.max(0, this.gearManager.getEnchants(hand).getOrDefault("shred", 0));
    }
}
