/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 */
package org.axial.prisonsCore.model;

import org.bukkit.Material;

public enum EnchantRarity {
    BASIC(Material.GRAY_DYE),
    UNCOMMON(Material.LIGHT_BLUE_DYE),
    UNIQUE(Material.CYAN_DYE),
    RARE(Material.LIME_DYE),
    ELITE(Material.YELLOW_DYE),
    LEGENDARY(Material.ORANGE_DYE);

    private final Material displayMaterial;

    private EnchantRarity(Material displayMaterial) {
        this.displayMaterial = displayMaterial;
    }

    public Material getDisplayMaterial() {
        return this.displayMaterial;
    }

    public Material getOrbMaterial() {
        return this.displayMaterial;
    }

    public String getColorCode() {
        return switch (this) {
            case BASIC -> "&f&l";
            case UNCOMMON -> "&b&l";
            case UNIQUE -> "&3&l";
            case RARE -> "&a&l";
            case ELITE -> "&e&l";
            case LEGENDARY -> "&6&l";
        };
    }

    public static EnchantRarity fromString(String raw, EnchantRarity def) {
        if (raw == null) {
            return def;
        }
        try {
            return EnchantRarity.valueOf(raw.toUpperCase());
        }
        catch (IllegalArgumentException ex) {
            return def;
        }
    }
}
