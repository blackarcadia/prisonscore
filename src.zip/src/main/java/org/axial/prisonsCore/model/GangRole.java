/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.model;

public enum GangRole {
    MEMBER,
    TRUSTED,
    MOD,
    CO_LEADER,
    LEADER;


    public boolean isHigherOrEqual(GangRole other) {
        return this.ordinal() >= other.ordinal();
    }

    public GangRole promote() {
        return switch (this.ordinal()) {
            default -> throw new MatchException(null, null);
            case 0 -> TRUSTED;
            case 1 -> MOD;
            case 2 -> CO_LEADER;
            case 3, 4 -> LEADER;
        };
    }

    public GangRole demote() {
        return switch (this.ordinal()) {
            default -> throw new MatchException(null, null);
            case 4 -> CO_LEADER;
            case 3 -> MOD;
            case 2 -> TRUSTED;
            case 1 -> MEMBER;
            case 0 -> MEMBER;
        };
    }
}

