/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.model;

import java.util.HashSet;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import org.axial.prisonsCore.model.EnchantRarity;
import org.bukkit.Material;

public class CustomEnchant {
    private final String id;
    private final String displayName;
    private final String description;
    private final int successChance;
    private final int maxLevel;
    private final EnchantRarity rarity;
    private final List<String> displayNameLevels;
    private final List<Double> procChances;
    private final List<String> loreFormatLevels;
    private final String loreFormat;
    private final Set<String> applicableTypes;

    public CustomEnchant(String id, String displayName, String description, int successChance, int maxLevel, EnchantRarity rarity, List<Double> procChances, List<String> loreFormatLevels, String loreFormat, List<String> applicableTypes) {
        this(id, displayName, description, successChance, maxLevel, rarity, procChances, Collections.emptyList(), loreFormatLevels, loreFormat, applicableTypes);
    }

    public CustomEnchant(String id, String displayName, String description, int successChance, int maxLevel, EnchantRarity rarity, List<Double> procChances, List<String> displayNameLevels, List<String> loreFormatLevels, String loreFormat, List<String> applicableTypes) {
        this.id = id;
        this.displayName = displayName;
        this.description = description;
        this.successChance = successChance;
        this.maxLevel = maxLevel;
        this.rarity = rarity;
        this.displayNameLevels = displayNameLevels == null ? List.of() : displayNameLevels;
        this.procChances = procChances;
        this.loreFormatLevels = loreFormatLevels == null ? List.of() : loreFormatLevels;
        this.loreFormat = loreFormat;
        this.applicableTypes = applicableTypes == null ? Set.of() : applicableTypes.stream().filter(s -> s != null && !s.isBlank()).map(s -> s.trim().toUpperCase(Locale.ROOT)).collect(Collectors.toCollection(HashSet::new));
    }

    public String getId() {
        return this.id;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public String getDisplayNameForLevel(int level) {
        if (!this.displayNameLevels.isEmpty()) {
            int idx = Math.min(Math.max(1, level) - 1, this.displayNameLevels.size() - 1);
            return this.displayNameLevels.get(idx);
        }
        return this.displayName + " " + this.roman(level);
    }

    public String getDescription() {
        return this.description;
    }

    public int getSuccessChance() {
        return this.successChance;
    }

    public int getMaxLevel() {
        return this.maxLevel;
    }

    public EnchantRarity getRarity() {
        return this.rarity;
    }

    public double getProcChanceForLevel(int level, double fallback) {
        if (this.procChances == null || this.procChances.isEmpty()) {
            return fallback;
        }
        int index = Math.min(level - 1, this.procChances.size() - 1);
        Double val = this.procChances.get(index);
        if (val == null) {
            return fallback;
        }
        return val;
    }

    public String getLoreLine(int level, String defaultFormat) {
        if (!this.loreFormatLevels.isEmpty()) {
            int idx = Math.min(level - 1, this.loreFormatLevels.size() - 1);
            return this.loreFormatLevels.get(idx);
        }
        if (this.loreFormat != null) {
            return this.loreFormat;
        }
        return defaultFormat;
    }

    public List<String> getDisplayNameLevels() {
        return List.copyOf(this.displayNameLevels);
    }

    public List<String> getLoreFormatLevels() {
        return List.copyOf(this.loreFormatLevels);
    }

    public boolean isApplicableTo(Material material) {
        if (material == null) {
            return false;
        }
        if (this.applicableTypes.isEmpty() || this.applicableTypes.contains("ALL") || this.applicableTypes.contains("ANY")) {
            return true;
        }
        String type = material.name();
        for (String allowed : this.applicableTypes) {
            if (this.matchesAllowedType(type, allowed)) {
                return true;
            }
        }
        return false;
    }

    public Set<String> getApplicableTypes() {
        return Set.copyOf(this.applicableTypes);
    }

    private boolean matchesAllowedType(String materialName, String allowed) {
        return switch (allowed) {
            case "ARMOR" -> materialName.endsWith("_HELMET") || materialName.endsWith("_CHESTPLATE") || materialName.endsWith("_LEGGINGS") || materialName.endsWith("_BOOTS");
            case "WEAPON" -> materialName.endsWith("_SWORD") || materialName.endsWith("_AXE") || materialName.equals("TRIDENT");
            case "SWORD" -> materialName.endsWith("_SWORD");
            case "AXE" -> materialName.endsWith("_AXE");
            case "HOE" -> materialName.endsWith("_HOE");
            case "SHOVEL" -> materialName.endsWith("_SHOVEL");
            case "HELMET" -> materialName.endsWith("_HELMET");
            case "CHESTPLATE" -> materialName.endsWith("_CHESTPLATE");
            case "LEGGINGS" -> materialName.endsWith("_LEGGINGS");
            case "BOOTS" -> materialName.endsWith("_BOOTS");
            case "TRIDENT", "SHIELD", "BOW", "CROSSBOW" -> materialName.equals(allowed);
            default -> materialName.equals(allowed);
        };
    }

    private String roman(int number) {
        int n = Math.max(1, number);
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] numerals = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; ++i) {
            while (n >= values[i]) {
                sb.append(numerals[i]);
                n -= values[i];
            }
        }
        return sb.toString();
    }
}
