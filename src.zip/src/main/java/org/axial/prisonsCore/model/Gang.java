/*
 * Decompiled with CFR 0.152.
 */
package org.axial.prisonsCore.model;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.axial.prisonsCore.model.GangRole;

public class Gang {
    private String id;
    private String name;
    private final Map<UUID, GangRole> members = new HashMap<UUID, GangRole>();
    private int points = 0;

    public Gang(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Map<UUID, GangRole> getMembers() {
        return this.members;
    }

    public int getPoints() {
        return this.points;
    }

    public void addPoints(int amount) {
        this.points = Math.max(0, this.points + amount);
    }

    public UUID getLeader() {
        return this.members.entrySet().stream().filter(e -> e.getValue() == GangRole.LEADER).map(Map.Entry::getKey).findFirst().orElse(null);
    }

    public boolean hasMember(UUID uuid) {
        return this.members.containsKey(uuid);
    }

    public GangRole getRole(UUID uuid) {
        return this.members.getOrDefault(uuid, null);
    }

    public void setRole(UUID uuid, GangRole role) {
        this.members.put(uuid, role);
    }

    public void removeMember(UUID uuid) {
        this.members.remove(uuid);
    }
}

