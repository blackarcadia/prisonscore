/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 */
package org.axial.prisonsCore.model;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Material;

public class PickaxeType {
    private final String id;
    private final Material material;
    private final String displayName;
    private final int maxEnergy;
    private final Set<Material> allowedBlocks;
    private final Map<Material, Integer> energyValues;
    private final List<String> baseLore;

    public PickaxeType(String id, Material material, String displayName, int maxEnergy, Set<Material> allowedBlocks, Map<Material, Integer> energyValues, List<String> baseLore) {
        this.id = id;
        this.material = material;
        this.displayName = displayName;
        this.maxEnergy = maxEnergy;
        this.allowedBlocks = allowedBlocks;
        this.energyValues = energyValues;
        this.baseLore = baseLore;
    }

    public String getId() {
        return this.id;
    }

    public Material getMaterial() {
        return this.material;
    }

    public String getDisplayName() {
        return this.displayName;
    }

    public int getMaxEnergy() {
        return this.maxEnergy;
    }

    public Set<Material> getAllowedBlocks() {
        return Collections.unmodifiableSet(this.allowedBlocks);
    }

    public Map<Material, Integer> getEnergyValues() {
        return Collections.unmodifiableMap(this.energyValues);
    }

    public List<String> getBaseLore() {
        return this.baseLore;
    }
}

